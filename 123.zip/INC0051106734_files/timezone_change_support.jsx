/*! RESOURCE: /scripts/timezone_change_support.js */
var TimeZoneChanger = Class.create();
TimeZoneChanger.prototype = {
initialize: function(span_name) {
this.span = gel(span_name);
this.parent = $(this.span).up();
this.legend = this.parent.previous();
this.select = gel(span_name + "_select");
this.maxChars = 32;
this.fillTimeZones();
CustomEvent.observe('user.logout', this.updateTimeZoneForLogout.bind(this));
CustomEvent.observe('user.login', this.updateTimeZoneForLogin.bind(this));
this.hideTimezoneElems();
},
hideTimezoneElems : function(){
if (this.parent){
hideObject(this.parent);
}
if (this.legend) {
hideObject(this.legend);
}
},
showTimezoneElems : function() {
if (this.parent) {
showObjectInline(this.parent);
}
if (this.legend){
showObjectInlineBlock(this.legend);
}
showObjectInline(gel("select_toggle"));
},
updateTimeZoneForLogout: function() {
this.hideTimezoneElems();
},
updateTimeZoneForLogin: function( user) {
var ajax = new GlideAjax("TimezoneAjax");
ajax.addParam("sysparm_name", "getRole");
ajax.getXMLAnswer(this._updateTimeZoneResponse.bind(this), {}, user);
},
_updateTimeZoneResponse: function(answer, user) {
var urole = answer;
var hide = true;
if (user.hasRole('admin') || (urole != null && user.hasRoleFromList(urole)))
hide = false;
if (hide) {
this.hideTimezoneElems();
return;
}
this.showTimezoneElems();
this.setUserTimeZone();
},
fillTimeZones: function() {
var ajax = new GlideAjax("TimezoneAjax");
ajax.addParam("sysparm_name", "getTimeZones");
ajax.getXML(this.getTimeZonesResponse.bind(this));
},
getTimeZonesResponse: function(response) {
var xml = response.responseXML;
var e = xml.documentElement;
var currentTZ = e.getAttribute("currentTZ");
var items = xml.getElementsByTagName("item");
if (items.length == 0)
return;
for (var i = this.select.length - 1; i > -1; i--)
this.select.remove(i);
found = false;
for (var i = 0; i < items.length; i++) {
var item = items[i];
var selected = (item.getAttribute("value") == currentTZ);
var orig = item.getAttribute('label');
var label = this.maxChars && orig.length > this.maxChars ? orig.substring(0, this.maxChars) + ' ...' : orig;
addOption(this.select, item.getAttribute('value'), label, selected, orig);
if (selected)
found = true;
}
if (!found) {
var label = this.maxChars && currentTZ.length > this.maxChars ? currentTZ.substring(0, this.maxChars) + ' ...' : currentTZ;
addOptionAt(this.select, currentTZ, label, 0, currentTZ);
this.select.selectedIndex = 0;
}
},
changeTimeZone: function() {
var o = this.select.options[this.select.selectedIndex];
var ajax = new GlideAjax("TimezoneAjax");
ajax.addParam("sysparm_name", "changeTimeZone");
ajax.addParam("sysparm_value", o.getAttribute("value"));
ajax.getXML(this.changeTimeZoneResponse.bind(this));
},
changeTimeZoneResponse: function(response) {
var win = getMainWindow();
var sURL = unescape(win.location.pathname);
reloadWindow(win);
},
getDefaultTimeZone: function() {
var ajax = new GlideAjax("TimezoneAjax");
ajax.addParam("sysparm_name", "getDefaultTimeZone");
ajax.getXML(this.getDefaultTimeZoneResponse.bind(this));
},
getDefaultTimeZoneResponse: function(response) {
this.setDefaultTimeZoneResponse(response, true);
},
setUserTimeZone: function() {
var ajax = new GlideAjax("TimezoneAjax");
ajax.addParam("sysparm_name", "getDefaultTimeZone");
ajax.getXML(this.getDefaultTimeZoneResponse2.bind(this));
},
getDefaultTimeZoneResponse2: function(response) {
this.setDefaultTimeZoneResponse(response, false);
},
setDefaultTimeZoneResponse: function(response, changeFlag) {
var xml = response.responseXML;
var e = xml.documentElement;
var currentTZ = e.getAttribute("currentTZ");
for (var i = 0; i < this.select.options.length; i++) {
if (this.select.options[i].value == currentTZ) {
this.select.selectedIndex = i;
if (changeFlag)
this.changeTimeZone();
return;
}
}
var label = this.maxChars && currentTZ.length > this.maxChars ? currentTZ.substring(0, this.maxChars) + ' ...' : currentTZ;
addOptionAt(this.select, currentTZ, label, 0, currentTZ);
this.select.selectedIndex = 0;
if (changeFlag)
this.changeTimeZone();
}
};
;
