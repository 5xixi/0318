/*! RESOURCE: /scripts/classes/ChatActivity.js */
var ChatActivity = Class.create({
initialize: function(expandMsg, collapseMsg, imgHide, imgReveal, documentId) {
this.expandMsg = expandMsg;
this.collapseMsg = collapseMsg;
this.imgHide = imgHide;
this.imgReveal = imgReveal;
this.documentId = documentId;
},
toggleDisplay: function(table, id) {
var e = $(id);
if (!e)
return;
e.toggle();
setPreference(table + ".chat.display", e.visible() ? "" : "none");
},
toggle: function(id) {
var e = $('chat_' + id);
if (!e)
return;
var state = e.getAttribute('data-state');
if (state == "none") {
this._showChat(e, id);
var ajax = new GlideAjax("AJAXChat");
ajax.addParam("sysparm_type", "get_history");
ajax.addParam("sysparm_channel", id)
ajax.addParam("sysparm_sys_id", this.documentId);
ajax.getXML(this._toggleResponse.bind(this, id));
} else if (state == "visible")
this._hideChat(e, id);
else
this._showChat(e, id);
},
_toggleResponse: function(id, response) {
var e = $('chat_' + id);
if (!e)
return;
var x = response.responseXML;
x = x.getElementsByTagName("span");
e.innerHTML = getXMLString(x[0]);
this._showChat(e, id);
},
_hideChat: function(e, id) {
e.setAttribute('data-state', 'hidden');
e.hide();
$('chat_image_' + id).src = this.imgReveal;
},
_showChat: function(e, id) {
e.setAttribute('data-state', 'visible');
e.show();
$('chat_image_' + id).src = this.imgHide;
},
toString: function() { return 'ChatActivity'; }
});
;
