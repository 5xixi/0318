/*! RESOURCE: /scripts/js_includes_customer.js */
/*! RESOURCE: UI Action Context Menu */
function showUIActionContext(event) {
if (!g_user.hasRole("ui_action_admin"))
return;
var element = Event.element(event);
if (element.tagName.toLowerCase() == "span")
element = element.parentNode;
var id = element.getAttribute("gsft_id");
var mcm = new GwtContextMenu('context_menu_action_' + id);
mcm.clear();
mcm.addURL(getMessage('Edit UI Action'), "sys_ui_action.do?sys_id=" + id, "gsft_main");
contextShow(event, mcm.getID(), 500, 0, 0);
Event.stop(event);
}
addLoadEvent(function() {
document.on('contextmenu', '.action_context', function (evt, element) {
showUIActionContext(evt);
});
});
/*! RESOURCE: Validate Client Script Functions */
function validateFunctionDeclaration(fieldName, functionName) {
var code = g_form.getValue(fieldName);
if (code == "")
return true;
code = removeCommentsFromClientScript(code);
var patternString = "function(\\s+)" + functionName + "((\\s+)|\\(|\\[\r\n])";
var validatePattern = new RegExp(patternString);
if (!validatePattern.test(code)) {
var msg = new GwtMessage().getMessage('Missing function declaration for') + ' ' + functionName;
g_form.showErrorBox(fieldName, msg);
return false;
}
return true;
}
function validateNoServerObjectsInClientScript(fieldName) {
var code = g_form.getValue(fieldName);
if (code == "")
return true;
code = removeCommentsFromClientScript(code);
var doubleQuotePattern = /"[^"\r\n]*"/g;
code = code.replace(doubleQuotePattern,"");
var singleQuotePattern = /'[^'\r\n]*'/g;
code = code.replace(singleQuotePattern,"");
var rc = true;
var gsPattern = /(\s|\W)gs\./;
if (gsPattern.test(code)) {
var msg = new GwtMessage().getMessage('The object "gs" should not be used in client scripts.');
g_form.showErrorBox(fieldName, msg);
rc = false;
}
var currentPattern = /(\s|\W)current\./;
if (currentPattern.test(code)) {
var msg = new GwtMessage().getMessage('The object "current" should not be used in client scripts.');
g_form.showErrorBox(fieldName, msg);
rc = false;
}
return rc;
}
function validateUIScriptIIFEPattern(fieldName, scopeName, scriptName) {
var code = g_form.getValue(fieldName);
var rc = true;
if("global" == scopeName)
return rc;
code = removeCommentsFromClientScript(code);
code = removeSpacesFromClientScript(code);
code = removeNewlinesFromClientScript(code);
var requiredStart =  "var"+scopeName+"="+scopeName+"||{};"+scopeName+"."+scriptName+"=(function(){\"usestrict\";";
var requiredEnd = "})();";
if(!code.startsWith(requiredStart)) {
var msg = new GwtMessage().getMessage("Missing closure assignment.");
g_form.showErrorBox(fieldName,msg);
rc = false;
}
if(!code.endsWith(requiredEnd)) {
var msg = new GwtMessage().getMessage("Missing immidiately-invoked function declaration end.");
g_form.showErrorBox(fieldName,msg);
rc = false;
}
return rc;
}
function validateNotCallingFunction (fieldName, functionName) {
var code = g_form.getValue(fieldName);
var rc = true;
var reg = new RegExp(functionName, "g");
var matches;
code = removeCommentsFromClientScript(code);
if (code == '')
return rc;
matches = code.match(reg);
rc = (matches && (matches.length == 1));
if(!rc) {
var msg = "Do not explicitly call the " + functionName + " function in your business rule. It will be called automatically at execution time.";
msg = new GwtMessage().getMessage(msg);
g_form.showErrorBox(fieldName,msg);
}
return rc;
}
function removeCommentsFromClientScript(code) {
var pattern1 = /\/\*(.|[\r\n])*?\*\//g;
code = code.replace(pattern1,"");
var pattern2 = /\/\/.*/g;
code = code.replace(pattern2,"");
return code;
}
function removeSpacesFromClientScript(code) {
var pattern = /\s*/g;
return code.replace(pattern,"");
}
function removeNewlinesFromClientScript(code) {
var pattern = /[\r\n]*/g;
return code.replace(pattern,"");
}
/*! RESOURCE: AddIconToField */
function AddIconToField(ctrl,iconId,glyph,ttl,fn,parms,style,position) {
try {
if (ctrl) {
if (!style) {
style='default';
}
if (!position) {
position='after';
}
if (position.toLowerCase()=='before') {
ctrl.insert({before : '<a id="' + iconId + '"><span aria-label="' + ttl + '" data-original-title="' + ttl + '" style="margin-right:5px;" class="btn btn-' + style.toLowerCase() + ' icon-' + glyph + '" alt="' + ttl + '" title="' + ttl + '" name=""></span></a>'});
} else {
var addons = $j(ctrl).parents('.form-group').children('.form-field-addons');
if (addons.length > 0) {
$j(addons[0]).prepend('<a id="' + iconId + '"><span aria-label="' + ttl + '" data-original-title="' + ttl + '" class="btn btn-' + style.toLowerCase() + ' icon-' + glyph + '" alt="' + ttl + '" title="' + ttl + '" name=""></span></a>');
} else {
ctrl.insert({after : '<a id="' + iconId + '"><span aria-label="' + ttl + '" data-original-title="' + ttl + '" style="margin-left:5px;" class="btn btn-' + style.toLowerCase() + ' icon-' + glyph + '" alt="' + ttl + '" title="' + ttl + '" name=""></span></a>'});
}
}
if (fn) {
var cctrl = $(iconId);
if (cctrl && fn) {
cctrl.observe('click', function() {
fn(parms);
});
}
}
}
} catch (ex) {
jslog('error adding icon to field: ' + ex.message);
}
}
/*! RESOURCE: MoreBookmarks */
addLateLoadEvent(function() {
try {
if (!window.IFramePane) return;
IFramePane.prototype._loadLinkFromUrl = IFramePane.prototype.loadLinkFromUrl;
IFramePane.prototype.loadLinkFromUrl = function(link) {
var i = link.lastIndexOf('sysparm_cancelable');
var query = i > -1 ? link.substr(i) : '';
if (i > -1) link = link.substr(0, i - 1);
if (link.indexOf('filter:') === 0) {
var filter = link.substr('filter:'.length);
var gtw = getTopWindow();
if (gtw) {
gtw.navFilterKeyUp(filter);
gtw.$('filter').value = filter;
}
return;
}
else if (link.indexOf('javascript:') === 0) {
var js = link.substr('javascript:'.length);
link = new Function('query', js)(query);
}
if (link) {
this._loadLinkFromUrl(link);
}
}
} catch (e) {
var str = 'FilterBookmarks UI Script error: ' + e.message;
isWebKit ? console.log(str) : jslog(str);
}
});
/*! RESOURCE: ToolTip */
var u_tooltip = (function(){
var id = 'u_tooltip';
var top = 20;
var left = 0;
var maxw = 300;
var speed = 15;
var timer = 10;
var pause = 1000;
var endalpha = 96;
var alpha = 0;
var width = 0;
var tt,t,c,b,h,x,y;
var ie = document.all ? true : false;
var cval = '';
var css = ''
css += '#' + id + ' {position:absolute; display:block; background-color: #f6f6f6; border: 1px solid #888;border-radius:4px;z-index:3;}';
css += '#' + id + 'cont {font-family: Tahoma, Geneva, sans-serif; font-size: 8pt; display:block; padding:2px 12px 3px 7px; color:#1d1d1d;}';
createStyleSheet(css, 'u_tooltip_css');
return {
createBase:function() {
tt = document.createElement('div');
tt.setAttribute('id',id);
t = document.createElement('div');
t.setAttribute('id',id + 'top');
c = document.createElement('div');
c.setAttribute('id',id + 'cont');
b = document.createElement('div');
b.setAttribute('id',id + 'bot');
tt.appendChild(t);
tt.appendChild(c);
tt.appendChild(b);
document.body.appendChild(tt);
tt.style.opacity = 0;
tt.style.filter = 'alpha(opacity=0)';
document.observe('mousemove', this.pos);
tt.visible = false;
tt.fading = false;
u_tooltip.tt = tt;
},
show:function(v,w) {
if(tt == null) u_tooltip.createBase();
tt.show = true;
width = w;
cval = v;
},
_show:function() {
u_tooltip.setOffset();
tt.fading = 1;
tt.style.display = 'block';
tt.style.width = width ? width + 'px' : 'auto';
c.innerHTML = cval;
if(!width && ie){
t.style.display = 'none';
b.style.display = 'none';
tt.style.width = tt.offsetWidth;
t.style.display = 'block';
b.style.display = 'block';
}
u_tooltip.setOffset();
clearInterval(tt.timer);
tt.timer = setInterval(function(){u_tooltip.fade(1);},timer);
},
hide:function() {
if(tt == null) return;
tt.show = false;
u_tooltip._hide();
},
_hide: function() {
if (!tt.visible || tt.fading == -1) return;
tt.fading = -1;
clearInterval(tt.timer);
tt.timer = setInterval(function(){u_tooltip.fade(-1)},timer);
},
setOffset: function() {
if (tt == null) return;
if(tt.offsetWidth > maxw){tt.style.width = maxw + 'px'}
tt.style.left = (x + left) + 'px';
tt.style.top = (y + top) + 'px';
},
pos:function(e){
if(tt == null) return;
x = ie ? event.clientX + document.documentElement.scrollLeft : e.pageX;
y = ie ? event.clientY + document.documentElement.scrollTop : e.pageY;
clearTimeout(tt.paused);
if (tt.visible) {
u_tooltip._hide();
} else if (tt.show) {
tt.paused = setTimeout(function() {
u_tooltip._show();
}, pause);
}
},
fade:function(d){
if(tt == null) return;
var a = alpha;
if((a != endalpha && d == 1) || (a != 0 && d == -1)){
tt.fading = d;
var i = speed;
if(endalpha - a < speed && d == 1){
i = endalpha - a;
}else if(alpha < speed && d == -1){
i = a;
}
alpha = a + (i * d);
tt.style.display = 'block';
tt.style.opacity = alpha * .01;
tt.style.filter = 'alpha(opacity=' + alpha + ')';
}else{
tt.fading = false;
tt.visible = d == 1;
clearInterval(tt.timer);
tt.style.display = d == -1 ? 'none' : 'block';
}
}
};
})();
/*! RESOURCE: MoreGlideForm */
if (window['GlideForm']) {
GlideForm.prototype.u_addHelp = function(field, text, colour, icon, appendIcon) {
return this.u__messageFactory('help', field, text, colour, icon, appendIcon);
}
GlideForm.prototype.u_showHelp = function(field) {
return this.u__show('help', field);
}
GlideForm.prototype.u_hideHelp = function(field) {
return this.u__hide('help', field);
}
GlideForm.prototype.u_toggleHelp = function(field) {
return this.u__toggle('help', field);
}
GlideForm.prototype.u_removeHelp = function(field) {
return this.u__remove('help', field);
}
GlideForm.prototype.u_addInfo = function(field, text, colour, icon) {
this.u_removeInfo(field);
if (!colour) colour = '#def';
if (!icon && icon !== false) icon = '<img src="images/outputmsg_success.gifx" alt="Informational Message">';
return this.u__messageFactory('fieldInfo', field, text, colour, icon);
}
GlideForm.prototype.u_showInfo = function(field) {
return this.u__show('fieldInfo', field);
}
GlideForm.prototype.u_hideInfo = function(field) {
return this.u__hide('fieldInfo', field);
}
GlideForm.prototype.u_toggleInfo = function(field) {
return this.u__toggle('fieldInfo', field);
}
GlideForm.prototype.u_removeInfo = function(field) {
return this.u__remove('fieldInfo', field);
}
GlideForm.prototype.u_addError = function(field, text, colour, icon) {
this.u_removeError(field);
if (!colour) colour = '#fdd';
if (!icon && icon !== false) icon = '<img src="images/outputmsg_error.gifx" alt="Error Message">';
return this.u__messageFactory('fieldError', field, text, colour, icon);
}
GlideForm.prototype.u_showError = function(field) {
return this.u__show('fieldError', field);
}
GlideForm.prototype.u_hideError = function(field) {
return this.u__hide('fieldError', field);
}
GlideForm.prototype.u_toggleError = function(field) {
return this.u__toggle('fieldError', field);
}
GlideForm.prototype.u_removeError = function(field) {
return this.u__remove('fieldError', field);
}
GlideForm.prototype.u__messageFactory = function(type, field, text, colour, icon, appendIcon) {
var glideEl = g_form.getGlideUIElement(field);
if (!glideEl) return false;
if (!colour) colour = '#efefef';
var id = 'u_' + type + '.' + glideEl.getID();
if ($(id)) this.u__remove(type, field);
var parentEl = $(glideEl.getElementParentNode()),
newEl = new Element('tr', {'id': id}),
iconEl = false;
if (!parentEl) {
var glideControl = g_form.getControl(field);
if (glideControl) {
parentEl = $(glideControl).up('tr');
}
if (!parentEl) return false;
}
if (icon !== false) {
if (type == 'fieldInfo' || type == 'fieldError') {
text = icon + '&nbsp;' + text;
} else {
if (!icon || icon == '?') icon = '<strong style="color: blue">?</strong>';
iconEl = new Element('span', {'id': id + '.icon'});
iconEl.update('<a title="Help" href="javascript:void(0);" onclick="g_form.u_toggleHelp(\'' + field + '\');return false;">' + icon + '</a>');
}
}
newEl.update('<td colspan="2"><div>' + text + '</div></td>');
newEl.down(1).setStyle({backgroundColor: colour, margin: '2px 12px', padding: '3px'});
newEl.hide();
var doneInsert = false,
isWide = parentEl.down('td').hasClassName('label_left');
var fieldEl = isWide || appendIcon ? $(glideEl.getElement()) : false;
if (isWide) {
if (iconEl) {
iconEl.setStyle({margin: '4px'});
parentEl.down('td.label_right').insert({top: iconEl});
}
if (fieldEl) {
fieldEl.up('tr').insert({before: newEl});
doneInsert = true;
}
}
if (!doneInsert) {
parentEl.insert({after: newEl});
if (iconEl) {
if (appendIcon) {
iconEl.setStyle({margin: '2px'});
fieldEl.insert({after: iconEl});
} else {
iconEl.setStyle({cssFloat: 'right', marginRight: '2px'});
parentEl.down().insert({top: iconEl});
}
}
}
if (type == 'fieldInfo') this.u_showInfo(field);
else if (type == 'fieldError') this.u_showError(field);
return true;
}
GlideForm.prototype.u__show = function(type, field) {
var glideEl = g_form.getGlideUIElement(field);
if (!glideEl) return;
var id = $('u_' + type + '.' + glideEl.getID());
if (!id) return;
id.style.display = '';
}
GlideForm.prototype.u__hide = function(type, field) {
var glideEl = g_form.getGlideUIElement(field);
if (!glideEl) return;
var id = $('u_' + type + '.' + glideEl.getID());
if (!id) return;
id.style.display = 'none';
}
GlideForm.prototype.u__toggle = function(type, field) {
var glideEl = g_form.getGlideUIElement(field);
if (!glideEl) return;
var id = $('u_' + type + '.' + glideEl.getID());
if (!id) return;
if (id.style.display == '') id.style.display = 'none';
else id.style.display = '';
}
GlideForm.prototype.u__remove = function(type, field) {
var glideEl = g_form.getGlideUIElement(field);
if (!glideEl) return;
var id = 'u_' + type + '.' + glideEl.getID();
var el = $(id);
var icon = $(id + '.icon');
if (el) el.remove();
if (icon) icon.remove();
}
GlideForm.prototype.u_addTooltip = function(field, text, width) {
if (typeof(u_tooltip) != 'object') return false;
var glideEl = g_form.getGlideUIElement(field);
if (!glideEl) return false;
var parentEl = $(glideEl.getElementParentNode());
if (!parentEl) return false;
parentEl.observe('mouseover', function (t, w) {
return function(event){
var show = true;
if (event.findElement('a')) show = false;
if (event.toElement && event.toElement.getAttribute('class').indexOf('label-text') > -1 && event.toElement.getAttribute('data-original-title') != '') show = false
var td = event.findElement('td');
if (td && td.getAttribute('title')) show = false;
var el = event.element();
if (el && el.getAttribute('title')) show = false;
show ? u_tooltip.show(t, w) : u_tooltip.hide();
};
}(text, width)
);
parentEl.observe('mouseleave', function () {u_tooltip.hide();});
return true;
}
GlideForm.prototype.u_section = {
getTabIndex: function(tabName) {
var tabCaptions = $$('span[class=tab_caption_text]');
tabName = tabName.replace(/\s+/g, '&nbsp;');
for (var i = 0; i < tabCaptions.length; i++) {
if(tabCaptions[i].innerHTML.indexOf(tabName) > -1) {
return i;
}
}
return false;
},
getTab: function(tabName) {
var tab = $$('span[tab_caption="' + tabName + '"]');
tab = tab[0] ? tab[0] : false;
return tab || tab === 0 ? tab : false;
},
select: function(tabName) {
var i = this.getTabIndex(tabName);
if (i === false) return false;
this.show(tabName);
g_tabs2Sections.setActive(i);
return i
},
show: function(tabName) {
var i = this.getTabIndex(tabName);
if (i !== false) g_tabs2Sections.showTab(i);
return i
},
hide: function(tabName) {
var i = this.getTabIndex(tabName);
if (i !== false) g_tabs2Sections.hideTab(i);
return i;
},
showAll: function() {
g_tabs2Sections.showAll();
},
hideAll: function() {
g_tabs2Sections.hideAll();
}
};
GlideForm.prototype.u_toggleLabels = function() {
if (!('u__toggledLabels' in this)) this.u__toggledLabels = false;
var e, label;
if (this.u__toggledLabels) {
for (var i = 0; (e = this.elements[i]); i++) {
if (!(label = this.u_getLabel(e.fieldName))) continue;
label = this.u_getLabel(e.fieldName);
label.innerHTML = e.u_label;
label.style.color = '';
}
} else {
for (var i = 0; (e = this.elements[i]); i++) {
if (!(label = this.u_getLabel(e.fieldName))) continue;
e.u_label = label.innerHTML;
label.innerHTML = e.fieldName;
label.style.color = '#06f';
}
}
this.u__toggledLabels = !this.u__toggledLabels;
};
GlideForm.prototype.u_getLabel = function(id) {
id = '.' + id;
var label;
var labels = document.getElementsByTagName('label');
for (var i = 0; (label = labels[i]); i++) {
if (label.htmlFor.endsWith(id)) return label;
}
return false;
};
}
/*! RESOURCE: CodeEditorCSS */
addLateLoadEvent(function() {
users = ['tuadmin_jn', 'tuadmin_ts', 'tuadmin_jm', 'tuadmin_js', 'marc.guy'];
if (window['g_user'] && users.indexOf(g_user.userName) > -1) {
updateCodeEditorCSS();
}
});
function updateCodeEditorCSS() {
var cssText = '.CodeMirror div {font-family: Consolas, monospaced}';
var body = document.getElementsByTagName("body")[0];
var rules = document.createElement("style");
rules.setAttribute("type", "text/css");
if (navigator.userAgent.toLowerCase().indexOf("msie") >= 0) {
body.appendChild(rules);
var ss = rules.styleSheet;
ss.cssText = cssText;
} else {
try{
rules.appendChild(document.createTextNode(cssText));
}catch(e){
rules.cssText = cssText;
}
body.appendChild(rules);
}
}
/*! RESOURCE: logIt */
function logIt(msg, append){
var enabled = true;
if (enabled){
append = (append) ? append : "logIt UI Script";
jslog(append + ": " + msg);
}
}
/*! RESOURCE: shortcuts */
shortcut = {
'all_shortcuts':{},
'add': function(shortcut_combination,callback,opt) {
var default_options = {
'type':'keydown',
'propagate':false,
'disable_in_input':false,
'target':document,
'keycode':false
}
if(!opt) opt = default_options;
else {
for(var dfo in default_options) {
if(typeof opt[dfo] == 'undefined') opt[dfo] = default_options[dfo];
}
}
var ele = opt.target;
if(typeof opt.target == 'string') ele = document.getElementById(opt.target);
var ths = this;
shortcut_combination = shortcut_combination.toLowerCase();
var func = function(e) {
e = e || window.event;
if(opt['disable_in_input']) {
var element;
if(e.target) element=e.target;
else if(e.srcElement) element=e.srcElement;
if(element.nodeType==3) element=element.parentNode;
if(element.tagName == 'INPUT' || element.tagName == 'TEXTAREA') return;
}
if (e.keyCode) code = e.keyCode;
else if (e.which) code = e.which;
var character = String.fromCharCode(code).toLowerCase();
if(code == 188) character=",";
if(code == 190) character=".";
var keys = shortcut_combination.split("+");
var kp = 0;
var shift_nums = {
"`":"~",
"1":"!",
"2":"@",
"3":"#",
"4":"$",
"5":"%",
"6":"^",
"7":"&",
"8":"*",
"9":"(",
"0":")",
"-":"_",
"=":"+",
";":":",
"'":"\"",
",":"<",
".":">",
"/":"?",
"\\":"|"
}
var special_keys = {
'esc':27,
'escape':27,
'tab':9,
'space':32,
'return':13,
'enter':13,
'backspace':8,
'scrolllock':145,
'scroll_lock':145,
'scroll':145,
'capslock':20,
'caps_lock':20,
'caps':20,
'numlock':144,
'num_lock':144,
'num':144,
'pause':19,
'break':19,
'insert':45,
'home':36,
'delete':46,
'end':35,
'pageup':33,
'page_up':33,
'pu':33,
'pagedown':34,
'page_down':34,
'pd':34,
'left':37,
'up':38,
'right':39,
'down':40,
'f1':112,
'f2':113,
'f3':114,
'f4':115,
'f5':116,
'f6':117,
'f7':118,
'f8':119,
'f9':120,
'f10':121,
'f11':122,
'f12':123
}
var modifiers = {
shift: { wanted:false, pressed:false},
ctrl : { wanted:false, pressed:false},
alt  : { wanted:false, pressed:false},
meta : { wanted:false, pressed:false}
};
if(e.ctrlKey)	modifiers.ctrl.pressed = true;
if(e.shiftKey)	modifiers.shift.pressed = true;
if(e.altKey)	modifiers.alt.pressed = true;
if(e.metaKey)   modifiers.meta.pressed = true;
for(var i=0; k=keys[i],i<keys.length; i++) {
if(k == 'ctrl' || k == 'control') {
kp++;
modifiers.ctrl.wanted = true;
} else if(k == 'shift') {
kp++;
modifiers.shift.wanted = true;
} else if(k == 'alt') {
kp++;
modifiers.alt.wanted = true;
} else if(k == 'meta') {
kp++;
modifiers.meta.wanted = true;
} else if(k.length > 1) {
if(special_keys[k] == code) kp++;
} else if(opt['keycode']) {
if(opt['keycode'] == code) kp++;
} else {
if(character == k) kp++;
else {
if(shift_nums[character] && e.shiftKey) {
character = shift_nums[character];
if(character == k) kp++;
}
}
}
}
if(kp == keys.length &&
modifiers.ctrl.pressed == modifiers.ctrl.wanted &&
modifiers.shift.pressed == modifiers.shift.wanted &&
modifiers.alt.pressed == modifiers.alt.wanted &&
modifiers.meta.pressed == modifiers.meta.wanted) {
callback(e);
if(!opt['propagate']) {
e.cancelBubble = true;
e.returnValue = false;
if (e.stopPropagation) {
e.stopPropagation();
e.preventDefault();
}
return false;
}
}
}
this.all_shortcuts[shortcut_combination] = {
'callback':func,
'target':ele,
'event': opt['type']
};
if(ele.addEventListener) ele.addEventListener(opt['type'], func, false);
else if(ele.attachEvent) ele.attachEvent('on'+opt['type'], func);
else ele['on'+opt['type']] = func;
},
'remove':function(shortcut_combination) {
shortcut_combination = shortcut_combination.toLowerCase();
var binding = this.all_shortcuts[shortcut_combination];
delete(this.all_shortcuts[shortcut_combination])
if(!binding) return;
var type = binding['event'];
var ele = binding['target'];
var callback = binding['callback'];
if(ele.detachEvent) ele.detachEvent('on'+type, callback);
else if(ele.removeEventListener) ele.removeEventListener(type, callback, false);
else ele['on'+type] = false;
}
}
/*! RESOURCE: NavFilterExtension */
function navFilterExtension(val, msg) {
if (val.endsWith('.dict')) {
val = val.replace(/ /g, '');
document.getElementById('gsft_main').src = "sys_dictionary_list.do?sysparm_query=name=" + val.replace('.dict','');
restoreFilterText(msg);
return true;
}
if (val.endsWith('?')) {
val = val.replace(/ /g, '');
var table = val.split(":")[0];
var query = val.split(":")[1].replace('?','');
document.getElementById('gsft_main').src = table + "_list.do?sysparm_query=" + query;
restoreFilterText(msg);
return true;
}
return false;
}
/*! RESOURCE: MoreBSMMap */
addLoadEvent(function() {
if (window["BSMMap"]) {
BSMMap.prototype._u_troubleMakers = BSMMap.prototype._troubleMakers;
BSMMap.prototype._troubleMakers = function(r) {
var ret = this._u_troubleMakers(r);
u_loadBSMMap();
return ret;
}
window.u_loadBSMMap = function() {
var nodes = bsmMap._getNodeIds();
if (!nodes) return;
var ga = new GlideAjax('u_BSMMapAjax');
ga.addParam('sysparm_value', nodes);
ga.getXML(u_loadBSMMapResponse);
}
window.u_loadBSMMapResponse = function(response) {
if (!response || !response.responseXML) return;
var actions = response.responseXML.getElementsByTagName('action');
for (var i = 0; i < actions.length; i++) {
var xmlnode = actions[i],
action = {
'id': xmlnode.getAttribute('id'),
'name': xmlnode.getAttribute('name'),
'icon': xmlnode.getAttribute('icon'),
'script': xmlnode.getAttribute('script')
}
node = bsmMap.getNode(action.id);
if (!node) continue;
if (!action.icon || action.icon == 'false') {
node._runAction(action);
} else {
node.addIconAction(action);
}
}
}
window.u_changeLinkColour = function(parent, child, colour, highlightColour) {
if (!bsmMap.nodes[parent] || !bsmMap.nodes[child]) return;
var n1 = bsmMap.getNode(parent);
var n2 = bsmMap.getNode(child);
var e = bsmMap.getEdgeBetween(n1, n2);
if (e) {
if (!colour) colour = 'red';
e.setColor(colour);
e.dimColor = colour;
if (highlightColour) e.highlightColor = highlightColour;
}
}
}
});
/*! RESOURCE: Chat Overlay Workaround */
addLateLoadEvent(function() {
if (window.CustomEvent && window.LiveEvents)
CustomEvent.unAll(LiveEvents.START_PROCESSING);
});
/*! RESOURCE: json2 */
if(typeof JSON!=="object"){JSON={}}(function(){function f(n){return n<10?"0"+n:n}if(typeof Date.prototype.toJSON!=="function"){Date.prototype.toJSON=function(key){return isFinite(this.valueOf())?this.getUTCFullYear()+"-"+f(this.getUTCMonth()+1)+"-"+f(this.getUTCDate())+"T"+f(this.getUTCHours())+":"+f(this.getUTCMinutes())+":"+f(this.getUTCSeconds())+"Z":null};String.prototype.toJSON=Number.prototype.toJSON=Boolean.prototype.toJSON=function(key){return this.valueOf()}}var cx=/[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,escapable=/[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,gap,indent,meta={"\b":"\\b","\t":"\\t","\n":"\\n","\f":"\\f","\r":"\\r",'"':'\\"',"\\":"\\\\"},rep;function quote(string){escapable.lastIndex=0;return escapable.test(string)?'"'+string.replace(escapable,function(a){var c=meta[a];return typeof c==="string"?c:"\\u"+("0000"+a.charCodeAt(0).toString(16)).slice(-4)})+'"':'"'+string+'"'}function str(key,holder){var i,k,v,length,mind=gap,partial,value=holder[key];if(value&&typeof value==="object"&&typeof value.toJSON==="function"){value=value.toJSON(key)}if(typeof rep==="function"){value=rep.call(holder,key,value)}switch(typeof value){case"string":return quote(value);case"number":return isFinite(value)?String(value):"null";case"boolean":case"null":return String(value);case"object":if(!value){return"null"}gap+=indent;partial=[];if(Object.prototype.toString.apply(value)==="[object Array]"){length=value.length;for(i=0;i<length;i+=1){partial[i]=str(i,value)||"null"}v=partial.length===0?"[]":gap?"[\n"+gap+partial.join(",\n"+gap)+"\n"+mind+"]":"["+partial.join(",")+"]";gap=mind;return v}if(rep&&typeof rep==="object"){length=rep.length;for(i=0;i<length;i+=1){if(typeof rep[i]==="string"){k=rep[i];v=str(k,value);if(v){partial.push(quote(k)+(gap?": ":":")+v)}}}}else{for(k in value){if(Object.prototype.hasOwnProperty.call(value,k)){v=str(k,value);if(v){partial.push(quote(k)+(gap?": ":":")+v)}}}}v=partial.length===0?"{}":gap?"{\n"+gap+partial.join(",\n"+gap)+"\n"+mind+"}":"{"+partial.join(",")+"}";gap=mind;return v}}if(typeof JSON.stringify!=="function"){JSON.stringify=function(value,replacer,space){var i;gap="";indent="";if(typeof space==="number"){for(i=0;i<space;i+=1){indent+=" "}}else{if(typeof space==="string"){indent=space}}rep=replacer;if(replacer&&typeof replacer!=="function"&&(typeof replacer!=="object"||typeof replacer.length!=="number")){throw new Error("JSON.stringify")}return str("",{"":value})}}if(typeof JSON.parse!=="function"){JSON.parse=function(text,reviver){var j;function walk(holder,key){var k,v,value=holder[key];if(value&&typeof value==="object"){for(k in value){if(Object.prototype.hasOwnProperty.call(value,k)){v=walk(value,k);if(v!==undefined){value[k]=v}else{delete value[k]}}}}return reviver.call(holder,key,value)}text=String(text);cx.lastIndex=0;if(cx.test(text)){text=text.replace(cx,function(a){return"\\u"+("0000"+a.charCodeAt(0).toString(16)).slice(-4)})}if(/^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,"@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,"]").replace(/(?:^|:|,)(?:\s*\[)+/g,""))){j=eval("("+text+")");return typeof reviver==="function"?walk({"":j},""):j}throw new SyntaxError("JSON.parse")}}}());
/*! RESOURCE: GlideJSONAjax */
var GlideJSONAjax = Class.create(GlideAjax, {
initialize : function($super,option){
$super(option);
this.contextPath = '_jsonHTTP.do';
},
wantJSONObject : true,
setWantJSONObject : function(b){
this.wantJSONObject = b;
},
getJSON : function(callback, additionalParams, responseParams){
this.wantAnswer = false;
this._callbackFunction = callback;
this.setWantRequestObject(true);
var jsonCallback = function(responseObj){
if(this.wantJSONObject)
this._callbackFunction( JSON.parse(responseObj.responseText) );
else
this._callbackFunction( responseObj.responseText );
}
this._getXML0(jsonCallback, additionalParams, responseParams);
}
});
/*! RESOURCE: Chat - setInterval */
setInterval(function() {
window.LiveMux && LiveMux.get() && 0 < LiveWindowManager.get().getWindowCount() && LiveMux.get().enable();
}, 1000);
/*! RESOURCE: Dialog */
var Dialog = Class.create({
initialize: function(format, title) {
this.callback = null;
this.dialog = new GlideDialogWindow('Dialog');
this.dialog._dialogParent = this;
this.format = format || Dialog.ALERT;
this.message = '';
this.title = title || 'Alert';
},
getCallback: function() { return this.callback; },
setCallback: function(fn) { this.callback = fn; },
getDialog: function() { return this.dialog; },
getFormat: function() { return this.format; },
setFormat: function(format) { this.format = format;},
getMessage: function() { return this.message; },
setMessage: function(message) {
this.message = message;
if (this.dialog) this.dialog.setBody(this.format.replace(/\$\{message\}/, this.message));
},
getTitle: function() { return this.title; },
setTitle: function(title) {
this.title = title;
if (this.dialog) this.dialog.setTitle(title);
},
destroy: function() {
if (this.dialog) this.dialog.destroy();
this.dialog = null;
},
render: function() {
this.dialog.setTitle(this.title);
this.dialog.setBody(this.format.replace(/\$\{message\}/, this.message));
var ok = $('Dialog_OK');
if (ok) ok.focus();
},
complete: function(result) {
var t = typeof this.callback;
if (t == 'string') {
eval(this.callback + '(result);');
} else if (t == 'function') {
this.callback(result);
}
this.destroy();
}
});
Dialog.MESSAGE = '$' + '{message}';
Dialog.STYLE = 'background-color: transparent; margin: 2px; table-layout: fixed; width: 340px; word-wrap: break-word;"';
Dialog.ALERT = '<table style="' + Dialog.STYLE + '">'
+ '<tr><td>' + Dialog.MESSAGE + '</td></tr>'
+ '<tr><td align="right">'
+ '<button id="Dialog_OK" onclick="Dialog.complete(this, true)">OK</button>'
+ '</td></tr>'
+ '</table>';
Dialog.PROMPT = '<table style="' + Dialog.STYLE + '">'
+ '<tr><td>' + Dialog.MESSAGE + '</td></tr>'
+ '<tr><td><input type="text" id="dialog_prompt" style="width: 100%" /></td></tr>'
+ '<tr><td align="right">'
+ '<button id="Dialog_OK" onclick="Dialog.complete(this, $(\'dialog_prompt\').value)">OK</button>'
+ '<button id="Dialog_Cancel" onclick="Dialog.complete(this, false)">Cancel</button>'
+ '</td></tr>'
+ '</table>';
Dialog.CONFIRM = '<table style="' + Dialog.STYLE + '">'
+ '<tr><td>' + Dialog.MESSAGE + '</td></tr>'
+ '<tr><td align="right">'
+ '<button id="Dialog_OK" onclick="Dialog.complete(this, true)">OK</button>'
+ '<button id="Dialog_Cancel" onclick="Dialog.complete(this, false)">Cancel</button>'
+ '</td></tr>'
+ '</table>';
Dialog.YES_NO = '<table style="' + Dialog.STYLE + '">'
+ '<tr><td>' + Dialog.MESSAGE + '</td></tr>'
+ '<tr><td align="right">'
+ '<button id="Dialog_Yes" onclick="Dialog.complete(this, \'yes\')">Yes</button>'
+ '<button id="Dialog_No" onclick="Dialog.complete(this, \'no\')">No</button>'
+ '<button id="Dialog_Cancel" onclick="Dialog.complete(this, false)">Cancel</button>'
+ '</td></tr>'
+ '</table>';
Dialog.complete = function(element, result) {
if (!element) return false;
var gdw = GlideDialogWindow.prototype.locate(element);
if (!gdw || !gdw._dialogParent) return false;
gdw._dialogParent.complete(result);
};
/*! RESOURCE: MoveTimezoneChanger */
addLoadEvent(moveUpdateSetPicker);
function moveUpdateSetPicker(){
try{
if($('navpage_header_control_button')){
$('timezone_changer_select').className = '';
$('timezone_changer_select').style.color ="#000";
$('timezone_changer_select').style.display ="";
$('timezone_changer_select').style.margin = "0px 10px 0px 0px";
$('timezone_changer_select').style.padding ="0px 3px";
$('timezone_changer_select').style.borderRadius="10px";
if($('timezone_changer').select('li')[0]){
$('timezone_changer').select('li')[0].select('a')[0].style.color ="#FFF";
$('timezone_changer').select('li')[0].select('a')[0].style.border ="none";
$$('.btn-icon').each(function(d){
d.style.lineHeight = 'inherit';
});
}
$('nav_header_stripe_decorations').insert({
top: $('timezone_changer')
});
$('timezone_changer').id = 'timezone_changer_new';
}
}catch(e){}
}
/*! RESOURCE: AddHelpIconsToApplications */
(function() {
try {
if (typeof window.parent.gsft_nav == 'object') {
var ga = new GlideAjax('SNCApplicationAjax');
ga.addParam('sysparm_name','getHelp');
ga.getXML(helpResponse);
}
} catch (e) { console.log(e.message); }
})();
function helpResponse(response) {
try {
var answer = response.responseXML.documentElement.getAttribute("answer");
console.log(answer);
var resp = JSON.parse(answer);
$j('.submenu',window.parent.gsft_nav.document).addClass('clearfix');
$j('.helpicon',window.parent.gsft_nav.document).remove();
if (resp && resp.length > 0) {
for (var i=0;i<resp.length;i++) {
$j(window.parent.gsft_nav.document.getElementById('div.'+resp[i].sysid),window.parent.gsft_nav.document).append('<a alt="get help with this feature" title="get help with this feature" target="_help" href="' + resp[i].helpurl + '" class="helpicon" id="help.'+resp[i].sysid+'" style="text-decoration:none;float:right;padding-right:10px;padding-left:10px;"><i class="icon icon-help"></i></a>');
}
}
} catch (e) { console.log(e.message); }
}
/*! RESOURCE: ChangeBannerIcons */
(function() {
try {
if ($j) {
$j('#show_loading_gif',window.parent.document).remove();
$j('.rightButtons',window.parent.document).prepend('<i id="show_loading_gif" style="color: rgb(255, 255, 255); height: 16px; visibility: hidden;" class="icon-loading"></i>');
}
} catch (e) {}
})();
/*! RESOURCE: GoogleAnalytics */
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
addLoadEvent(function(){
try {
var googleAnalyticsId = (typeof g_user == 'object' ? g_user.getClientData('ga_id') : '') ||  '';
if(googleAnalyticsId){
addGACode(googleAnalyticsId);
}
else{
var googleAnalyticsAjax = new GlideAjax("AJAXGetProperty");
googleAnalyticsAjax.addParam('sysparm_name','getProperty');
googleAnalyticsAjax.addParam("sysparm_prop", "google.analytics.id");
googleAnalyticsAjax.getXML(getGoogleAnalyticsCode);
}
} catch (e) { }
function addGACode(googleAnalyticsId) {
try {
if (googleAnalyticsId && googleAnalyticsId != '') {
ga('create', googleAnalyticsId, 'auto');
ga('send', 'pageview');
}
} catch (e) { }
}
function getGoogleAnalyticsCode(response) {
try {
var googleAnalyticsId = response.responseXML.documentElement.getAttribute("answer");
addGACode(googleAnalyticsId);
} catch (e) { }
}
});
/*! RESOURCE: CheckRelatedCICount */
function CheckRelatedCICount(id, impchk, fnc) {
if (impchk == 'false') {
var ga = new GlideAjax('CmdbCiAjaxFunctions');
ga.addParam('sysparm_name','getTaskCICount');
ga.addParam('sysparm_task',id);
ga.getXML(taskCICountResponse);
} else {
fnc();
}
function taskCICountResponse(resp) {
var answer = resp.responseXML.documentElement.getAttribute("answer");
if (answer > 50) {
g_form.addErrorMessage("Since there are more than 50 CIs added to this change request, you are required to run 'Calculate Impact' manually before running this function.  Please click the calculate impact button on the form.");
} else {
fnc();
}
}
}
/*! RESOURCE: mandatePIIAttestation */
addLoadEvent( function() {
if(window.location.href.toString().indexOf("/ess_getitasst/")>=0)
{
checkAttestation();
}
else
if(window.frameElement){
if(window.frameElement.id == 'gsft_main'){
checkAttestation();
}
}
else if(!window.frameElement){
if(!$('gsft_main')){
checkAttestation();
}
}
});
function checkAttestation() {
var restrictPopup = false;
try {
if (document.location.pathname.indexOf("login_redirect.do") >= 0 || document.location.pathname.indexOf("logout_redirect.do") >= 0) {
restrictPopup=true;
}
} catch (e) { }
if (!restrictPopup) {
var testUserAccess='26d751536fc68200bd06cc074f3ee4b4';
var attestationRequired,currentUser;
var attestData = g_user ? g_user.getClientData('PIIFLAG#'+g_user.userID) : null;
if (attestData!='undefined' && attestData !=null ) {
attestationRequired=attestData.toString().split('~')[0];
currentUser=attestData.toString().split('~')[1];
} else {
var ga = new GlideAjax('AttestationUtil');
ga.addParam('sysparm_name','checkAttestation');
ga.getXMLWait();
attestationRequired= ga.getAnswer().toString().split('~')[0];
}
if(attestationRequired=='INVALID' ) {
showTermsDialog(currentUser);
}
}
}
function showTermsDialog(ipCurrentUser){
if(window.location.href.toString().indexOf("/ess_getitasst/ui_page")<0)
{
if(window.location.href.toString().indexOf("/ess_getitasst/")>=0)
{
var dd = new GlideDialogWindow("PIIAttestation");
dd.setSize(800,900);
dd.removeCloseDecoration();
}
else
{
var dialogClass = window.GlideModal ? GlideModal : GlideDialogWindow;
var dd = new dialogClass("PIIAttestation",true, "40em", "10.5em");
}
dd.setTitle("PII Attestation");
dd.setPreference('ipCurrentUser',ipCurrentUser);
dd.render();
}
}
/*! RESOURCE: DEV ESS Frame Fix */
if (document.all && !getNavWindow()) {
addLateLoadEvent(function() {
createStyleSheet('.section_header_content_no_scroll { height: auto; }');
});
}
/*! RESOURCE: SurveyValidator */
(function(){
var sV = function surveyValidator(){}
sV.prototype.validate = function(pleasetext){
var found = false;
target = (event.currentTarget) ? event.currentTarget : event.srcElement;
if(target.id == "expert_next"){
target.disabled = true;
target.setAttribute("disabled", "disabled");
var elementsInputs = document.getElementsByClassName('io_table');
for (var intCounter = 0; intCounter < elementsInputs.length; intCounter++)
{
if( elementsInputs[intCounter].getStyle('display')  == 'none')
continue;
var radioElements =  elementsInputs[intCounter].select('[type="radio"]');
found = false;
for (var x = 0; x < radioElements.length; x++)
{
if(radioElements[x].checked)
found=true;
}
if(!found &&  radioElements.length > 0 ){
alert(pleasetext + " '" + elementsInputs[intCounter].getElementsByTagName('label')[0].innerHTML+"'" );
target.disabled = false;
return false;
}
}
}
};
window.surveyValidator = new sV();
})();
/*! RESOURCE: ActivityHeaderFix */
try {
addLateLoadEvent(function() {
try {
$j('.activity-detail > .activity_header').show();
} catch (e) { }
});
} catch(e) { }
/*! RESOURCE: GlideFormReadonlyDates */
addLateLoadEvent(function() {
addLateLoadEvent(function() {
if ("g_form" in this && g_form instanceof GlideForm) {
var eArr = g_form.elements;
var i = 0, e, el;
for (; i < eArr.length; i++) {
e = eArr[i];
if (e && e.type == 'glide_date_time') {
el = g_form.getDisplayBox(e.fieldName) || g_form.getControl(e.fieldName);
if (el && el.setAttribute) el.setAttribute('readonly', 'readonly');
}
}
}
});
});
/*! RESOURCE: DEV Set title bar to task number */
addLoadEvent(setTitle);
function setTitle(title) {
if (!title) title = '';
function getValue(field) {
return g_form.getGlideUIElement(field) ? g_form.getValue(field) + '' : null;
}
var dflt = 'Citi - IT Service Management Suite';
var el;
var env = '';
var host = '';
try {
if (!title && typeof g_form == 'object') {
title = getValue("u_vt_number")
|| getValue("number")
|| getValue('u_number')
|| getValue('u_id')
|| getValue('id')
|| getValue('name');
}
if (!title) {
el = $$('h2.form_header').first();
if (!el) {
el = $$('div.list_title').first();
}
if (el) {
title = el.innerText.trim();
}
}
host = window.top.location.hostname;
if (host.indexOf('servicemanagement.citigroup.net') > -1
|| host.indexOf('p.nam') > -1
|| host.indexOf('c.nam') > -1) {
env = '';
} else if (host.indexOf('u.nam') > -1) {
env = window.top.location.port;
} else if (host.indexOf('.dev.') > -1) {
env = 'DEV';
} else if (host.indexOf('.uat.') > -1) {
env = 'UAT';
} else if (host.indexOf('.sit.') > -1){
env = 'SIT';
} else if (host.indexOf('.training.') > -1) {
env = 'TRAIN';
} else if (host.indexOf('.sandbox.') > -1) {
env = 'SAND';
} else if (host.indexOf('.cscdev.') > -1) {
env = 'CSCDEV';
} else if (host.indexOf('.cscsit.') > -1) {
env = 'CSCSIT';
}
} catch (e) {
jslog('Error in UI Script "DEV Set title bar to task number": ' + e);
}
if (title && env) {
title = env + ': ' + title;
} else if (!title) {
title = (typeof g_user == 'object' ? g_user.getClientData('banner_text') : '') || dflt;
if (env && title.indexOf(env) == -1) {
title = env + ': ' + title;
}
}
top.document.title = title;
return title;
}
/*! RESOURCE: SurveyPopup */
addLoadEvent(function() {
if(window.frameElement){
if(window.frameElement.id == 'gsft_main'){
loadSurvey();
}
}
else if(!window.frameElement){
if(!$('gsft_main')){
loadSurvey();
}
}
});
function loadSurvey(){
if(window.opener == null && window.g_user && window.g_user.hasRole('group_admin') && getTopWindow().shownSurvey === undefined ){
window.g_user.u_getUserPreference('shown_survey', _displaySurvey);
}
}
function _displaySurvey(answer){
window.g_user.u_setUserPreference('shown_survey','true');
getTopWindow().shownSurvey = 'true';
if(answer == 'true') return;
var dialog = new GlideModal('sn_survey');
dialog.setTitle('Opinion Survey');
dialog.render();
}
/*! RESOURCE: ExtendG_user */
if(window['GlideUser']){
GlideUser.prototype.u_setUserPreference = function(n, v){
var ga = new GlideAjax('UserPreferenceAjax');
ga.addParam('sysparm_name','setPreferenceVariable');
ga.addParam('sysparm_preference', n);
ga.addParam('sysparm_value', v);
ga.getXML(_setUserPreferenceResponse);
};
GlideUser.prototype.u_getUserPreference = function(v, c){
var ga = new GlideAjax('UserPreferenceAjax');
ga.addParam('sysparm_name','getPreferenceVariable');
ga.addParam('sysparm_preference', v);
ga.getXMLAnswer(function(answer){
c(answer);
});
};
function _setUserPreferenceResponse(response){
var answer = response.responseXML.documentElement.getAttribute("answer");
if(answer != 'true')
console.log('Error setting user preference');
};
}
/*! RESOURCE: DisableEnableOption  */
function disableOption(fieldName, choiceValue) {
fieldName = g_form.removeCurrentPrefix(fieldName);
var control = g_form.getControl(fieldName);
if (control && !control.options) {
var name = 'sys_select.' + this.tableName + '.' + fieldName;
control = gel(name);
}
if (!control)
return;
if (!control.options)
return;
var options = control.options;
for (var i = 0; i < options.length; i++) {
var option = options[i];
if (option.value == choiceValue) {
control.options[i].disabled = 'true';
break;
}
}
}
function enableOption(fieldName, choiceValue) {
fieldName = g_form.removeCurrentPrefix(fieldName);
var control = g_form.getControl(fieldName);
if (control && !control.options) {
var name = 'sys_select.' + this.tableName + '.' + fieldName;
control = gel(name);
}
if (!control)
return;
if (!control.options)
return;
var options = control.options;
for (var i = 0; i < options.length; i++) {
var option = options[i];
if (option.value == choiceValue) {
control.options[i].disabled = '';
break;
}
}
}
/*! RESOURCE: ChangeButtonStyle */
function ChangeButtonStyle(btn, style) {
if (!style) {
style = 'default';
}
var elmt;
if ($j) {
elmt = $j('#'+btn);
elmt.removeClass('btn-default');
elmt.removeClass('btn-success');
elmt.removeClass('btn-warning');
elmt.removeClass('btn-info');
elmt.removeClass('btn-danger');
elmt.addClass('btn-'+style);
} else {
if (style == 'danger') {
elmt = $(btn);
elmt.style.backgroundColor='red';
}
}
}
/*! RESOURCE: UpdateCustomStyles */
(function() {
var css = "html[data-doctype=true].compact DIV.tabs2_strip .tabs2_tab {padding:3px 8px 2px 8px !Important;}";
css += "HTML[data-doctype=true].compact #nav_filter_controls {top:-1px !Important;}";
css += "td.list_decoration_cell {white-space:nowrap !Important;}";
css += ".is-filled .required-marker:before, span.changed:before {color:#efd9d7 !Important;}";
css += "span.tabs2_tab span.label_description {color:red !Important; line-height:normal !Important; font-size:2em !Important;}";
css += "#full-visualization-panel table .filter_row_condition td {padding:2px !Important;}";
css += "#full-visualization-panel table .filter_row_condition {margin-top:0px !Important;}";
css += ".btn-default:active, .btn-destructive-subdued:active, .btn-success-subdued:active, .nav-segmented > li:active, .btn-default:active:focus, .btn-destructive-subdued:active:focus, .btn-success-subdued:active:focus, .nav-segmented > li:active:focus, .btn-default:active.focus, .btn-destructive-subdued:active.focus, .btn-success-subdued:active.focus, .nav-segmented > li:active.focus, .btn-default.active, .active.btn-destructive-subdued, .active.btn-success-subdued, .nav-segmented > li.active, .btn-default.active:focus, .active.btn-destructive-subdued:focus, .active.btn-success-subdued:focus, .nav-segmented > li.active:focus, .btn-default.active.focus, .active.focus.btn-destructive-subdued, .active.focus.btn-success-subdued, .nav-segmented > li.active.focus, .open > .btn-default.dropdown-toggle, .open > .dropdown-toggle.btn-destructive-subdued, .open > .dropdown-toggle.btn-success-subdued, .nav-segmented.open > li.dropdown-toggle, .open > .btn-default.dropdown-toggle:focus, .open > .dropdown-toggle.btn-destructive-subdued:focus, .open > .dropdown-toggle.btn-success-subdued:focus, .nav-segmented.open > li.dropdown-toggle:focus, .open > .btn-default.dropdown-toggle.focus, .open > .dropdown-toggle.focus.btn-destructive-subdued, .open > .dropdown-toggle.focus.btn-success-subdued, .nav-segmented.open > li.dropdown-toggle.focus {box-shadow:inset 0px 1px 10px 0 rgba(0, 0, 0, 0.5) !Important;}";
css += "#GwtDateTimePicker {z-index:10000 !Important;}";
css += ".form-field .row {margin-left:0px;}";
createStyleSheet(css, 'citi_custom_css');
})();
/*! RESOURCE: ModalAlert */
function modalAlert(title,message,type) {
var dialog = new GlideModal('popup_message', true);
dialog.setTitle(title);
dialog.setPreference('message',message);
dialog.setPreference('type',type);
dialog.render();
}
function modalErrorAlert(title,message) {
var dialog = new GlideModal('popup_message', true);
dialog.setTitle(title);
dialog.setPreference('message',message);
dialog.setPreference('type','error');
dialog.render();
}
function modalInfoAlert(title,message) {
var dialog = new GlideModal('popup_message', true);
dialog.setTitle(title);
dialog.setPreference('message',message);
dialog.setPreference('type','info');
dialog.render();
}
function modalWarningAlert(title,message) {
var dialog = new GlideModal('popup_message', true);
dialog.setTitle(title);
dialog.setPreference('message',message);
dialog.setPreference('type','warn');
dialog.render();
}
/*! RESOURCE: /scripts/lib/jquery/jquery_clean.js */
(function() {
if (!window.jQuery)
return;
if (!window.$j_glide)
window.$j = jQuery.noConflict();
if (window.$j_glide && jQuery != window.$j_glide) {
if (window.$j_glide)
jQuery.noConflict(true);
window.$j = window.$j_glide;
}
})();
;
;
