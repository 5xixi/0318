/*! RESOURCE: /scripts/js_includes_navpage14.js */
/*! RESOURCE: /scripts/lib/glide_updates/prototype.js */
Object.extendsObject = function() {
return Class.create.apply(null, arguments).prototype;
}
Prototype.ScriptFragmentDetailed = '<script(?:[^>]*type=\"([^>]*?)\")?(?:[^>]*src=\"([^>]*?)\")?[^>]*>([\\S\\s]*?)<\/script>';
var g_evalScriptCache = {};
Object.extend(String.prototype, (function() {
function extractScriptsDetailed() {
var matchAll = new RegExp(Prototype.ScriptFragmentDetailed, 'img');
var matchOne = new RegExp(Prototype.ScriptFragmentDetailed, 'im');
return (this.match(matchAll) || []).map(function(scriptTag) {
var m = scriptTag.match(matchOne) || [ '', '', '', '' ];
if (m[1] == 'application/xml')
return;
if (m[1] == 'text/html')
return;
return {
script: m[3],
src: m[2]
};
});
}
function evalScripts(evalGlobal) {
(function _executer(scripts) {
if (!scripts || scripts.length == 0)
return;
var script = scripts.shift();
if (!script)
return _executer(scripts);
if (script.src) {
if (!g_evalScriptCache[script.src]) {
g_evalScriptCache[script.src] = {
state : 'loading',
scripts : scripts
};
ajaxRequest(script.src,	null, true,	function(r) {
g_evalScriptCache[script.src].state = 'loaded';
var toEvalScripts = g_evalScriptCache[script.src].scripts;
if (r && r.responseText)
evalScript(r.responseText, evalGlobal);
return _executer(toEvalScripts);
});
}
else if (g_evalScriptCache[script.src].state == 'loading') {
g_evalScriptCache[script.src].scripts = g_evalScriptCache[script.src].scripts.concat(scripts);
return;
} else if (g_evalScriptCache[script.src].state == 'loaded')
return _executer(scripts);
} else {
if (script.script)
evalScript(script.script, evalGlobal);
return _executer(scripts);
}
})(this.extractScriptsDetailed());
}
return {
evalScripts: evalScripts,
extractScriptsDetailed: extractScriptsDetailed
};
})());
function evalScript(s, evalGlobal) {
if (s.length == 0)
return;
if (!evalGlobal)
return eval(s);
if (window.execScript)
return window.execScript(s);
return window.eval ? window.eval(s) : eval(s);
}
if (document.getElementsByClassName && typeof Element.Methods.getElementsByClassName === "function")
document.getElementsByClassName = function(instanceMethods) {
function iter(name) {
return name.blank() ? null : "[contains(concat(' ', @class, ' '), ' " + name + " ')]";
}
instanceMethods.getElementsByClassName = Prototype.BrowserFeatures.XPath ? function(element, className) {
className = className.toString().strip();
var cond = /\s/.test(className) ? $w(className).map(iter).join('') : iter(className);
return cond ? document._getElementsByXPath('.//*' + cond, element) : [];
} : function(element, className) {
className = className.toString().strip();
var elements = [], classNames = (/\s/.test(className) ? $w(className) : null);
if (!classNames && !className)
return elements;
if (Object.isString(element))
element = document.getElementById(element);
Element.extend(element);
var nodes = element.getElementsByTagName('*');
className = ' ' + className + ' ';
for (var i = 0, child, cn; child = nodes[i]; i++) {
if (child.className && (cn = ' ' + child.className + ' ')
&& (cn.include(className) || (classNames && classNames.all(function(name) {
return !name.toString().blank() && cn.include(' ' + name + ' ');
}))))
elements.push(Element.extend(child));
}
return elements;
};
return function(className, parentElement) {
return $(parentElement || document.body).getElementsByClassName(className);
};
}(Element.Methods);
Object.equals = function(o1, o2) {
var i1 = 0, i2 = 0;
for (var p in o1) {
if (!o1 || !o2 || typeof o1[p] !== typeof o2[p] || ((o1[p] === null) !== (o2[p] === null)))
return false;
switch (typeof o1[p]) {
case 'undefined':
if (typeof o2[p] != 'undefined')
return false;
break;
case 'object':
if (o1[p] !== null && o2[p] !== null && (o1[p].constructor.toString() !== o2[p].constructor.toString() || !Object.equals(o1[p], o2[p])))
return false;
break;
case 'function':
if (p != 'equals' && o1[p].toString() != o2[p].toString())
return false;
break;
default:
if (o1[p] !== o2[p])
return false;
}
i1++;
}
for (var p in o2) i2++;
if (i1 != i2)
return false;
return true;
}
document.viewport['getDimensions'] = function() {
var el = window.document.compatMode === 'CSS1Compat' && (!Prototype.Browser.Opera ||
window.parseFloat(window.opera.version()) < 9.5) ? window.document.documentElement : window.document.body;
return { width: el.clientWidth, height: el.clientHeight };
};
;
/*! RESOURCE: /scripts/lib/glide_updates/prototype.element.js */
var elementPrototype = window.HTMLElement ? HTMLElement.prototype : Element.prototype;
elementPrototype.hide = function(elem) {
return !elem ? Element.Methods.hide.call(null, this) : window.hide(elem);
}
elementPrototype.show = function(elem) {
return !elem ? Element.Methods.show.call(null, this) : window.show(elem);
}
Element.addMethods({
getInnerText: function(element) {
element = $(element);
return element.innerText && !window.opera ? element.innerText : element.innerHTML.stripScripts().unescapeHTML().replace(/[\n\r\s]+/g, ' ');
},
writeTitle: function(element, title) {
element.title = title;
if (element.alt)
element.alt = title;
},
visible: function(element) {
if (element.getStyle('display') == 'none' || element.getStyle('visibility') == 'hidden')
return false;
return true;
},
visibleInViewport: function(element) {
if (!element.visible())
return false;
var offset = element.viewportOffset();
if (offset.left < 0 || offset.top < 0)
return false;
var vp = document.viewport.getDimensions();
if ((offset.left + element.getWidth()) > vp.width || (offset.top + element.getHeight()) > vp.height)
return false;
return true;
},
getDimensions: function(element) {
element = $(element);
var dimensions = {};
var display = Element.getStyle(element, 'display');
if (display && display !== 'none') {
dimensions = {
width: element.offsetWidth,
height: element.offsetHeight
};
}
if (dimensions.width > 0)
return dimensions;
var style = element.style;
var originalStyles = {
visibility: style.visibility,
position:   style.position,
display:    style.display
};
var newStyles = {
visibility: 'hidden',
display:    'block'
};
if (originalStyles.position !== 'fixed')
newStyles.position = 'absolute';
Element.setStyle(element, newStyles);
var dimensions = {
width:  element.offsetWidth,
height: element.offsetHeight
};
if (dimensions.width <= 0 && dimensions.height <= 0) {
dimensions.width = parseInt(element.getStyle('width') || 0, 10);
dimensions.height = parseInt(element.getStyle('height') || 0, 10);
}
Element.setStyle(element, originalStyles);
return dimensions;
}
});
;
/*! RESOURCE: /scripts/lib/glide_updates/prototype.template.js */
var Template = Class.create({
initialize: function (template) {
this.template = template.toString();
this.pattern = /(^|.|\r|\n)(#\{((JS|HTML):)?(.*?)\})/;
},
evaluate: function (object) {
if (object && Object.isFunction(object.toTemplateReplacements))
object = object.toTemplateReplacements();
return this.template.gsub(this.pattern, function (match) {
if (object === null)
return (match[1] + '');
var before = match[1] || '';
if (before ==='\\')
return match[2];
var ctx = object, expr = match[5], escape = match[4],
pattern = /^([^.[]+|\[((?:.*?[^\\])?)\])(\.|\[|$)/;
match = pattern.exec(expr);
if (match === null)
return before;
while (match != null) {
var comp = match[1].startsWith('[') ? match[2].replace(/\\\\]/g, ']') : match[1];
ctx = ctx[comp];
if (null === ctx || '' === match[3])
break;
expr = expr.substring('[' === match[3] ? match[1].length : match[0].length);
match = pattern.exec(expr);
}
ctx = ctx || '';
switch (escape || '') {
case 'HTML':
ctx = ctx.replace(/'/g, '&#39;').replace(/"/g, '&#34;').replace(/&(?![#|l|g])/g, '&amp;').replace(/\</g, '&lt;').replace(/\>/g, '&gt;');
break;
case 'JS':
ctx = ctx.replace(/'/g, '&#39;').replace(/"/g, '&#34;');
break;
}
return before + String.interpret(ctx);
});
}
});
var XMLTemplate = Class.create(Template, {
initialize: function ($super, id) {
var s = $(id);
$super(s && s.innerHTML ? s.innerHTML.replace(/%7B/g, '{').replace(/%7D/g, '}') : '');
},
toString: function () {
'XMLTemplate';
}
});
;
/*! RESOURCE: /scripts/lib/glide_updates/prototype.plugin.js */
var Plugin = (function() {
function create(name) {
var args = $A(arguments);
args.shift();
var klass = function(argumentArray) {
this.initialize.apply(this, argumentArray);
};
Object.extend(klass, Class.Methods);
Object.extend(klass.prototype, args[0] || {});
if (!klass.prototype.initialize)
klass.prototype.initialize = Prototype.emptyFunction;
klass.prototype.constructor = klass;
var methods = {};
methods[name] = function(elem) {
new klass(arguments);
return elem;
}.bind(this);
Element.addMethods(methods);
};
return {
create: create
};
})();
;
/*! RESOURCE: /scripts/lib/glide_updates/prototype.effects.js */
(function() {
var elemdisplay = {};
var rfxtypes = /^(?:toggle|show|hide)$/;
var ralpha = /alpha\([^)]*\)/i;
var rdigit = /\d/;
var ropacity = /opacity=([^)]*)/;
var rfxnum = /^([+\-]=)?([\d+.\-]+)(.*)$/;
var rnumpx = /^-?\d+(?:px)?$/i;
var rnum = /^-?\d/;
var timerId;
var fxAttrs = [
[ "height", "marginTop", "marginBottom", "paddingTop", "paddingBottom" ],
[ "width", "marginLeft", "marginRight", "paddingLeft", "paddingRight" ],
[ "opacity" ]
];
var shrinkWrapBlocks = false;
var inlineBlockNeedsLayout = false;
var cssFloat = false;
var curCSS;
var opacitySupport;
document.observe("dom:loaded", function() {
var div = document.createElement("div");
div.style.width = div.style.paddingLeft = "1px";
document.body.appendChild(div);
if ("zoom" in div.style) {
div.style.display = "inline";
div.style.zoom = 1;
inlineBlockNeedsLayout = div.offsetWidth === 2;
div.style.display = "";
div.innerHTML = "<div style='width:4px;'></div>";
shrinkWrapBlocks = div.offsetWidth !== 2;
document.body.removeChild(div);
}
div = document.createElement("div");
div.style.display = "none";
div.innerHTML = "<link/><table></table><a href='/a' style='color:red;float:left;opacity:.55;'>a</a><input type='checkbox'/>";
document.body.appendChild(div);
var a = div.getElementsByTagName("a")[0];
opacitySupport = /^0.55$/.test(a.style.opacity);
cssFloat =  !!a.style.cssFloat;
document.body.removeChild(div);
if (!opacitySupport) {
Prototype.cssHooks.opacity = {
get: function(elem, computed) {
return ropacity.test((computed && elem.currentStyle ? elem.currentStyle.filter : elem.style.filter) || "") ?
(parseFloat(RegExp.$1) / 100) + "" :
computed ? "1" : "";
},
set: function(elem, value) {
var style = elem.style;
style.zoom = 1;
var opacity = Prototype.isNaN(value) ?
"" :
"alpha(opacity=" + value * 100 + ")",
filter = style.filter || "";
style.filter = ralpha.test(filter) ?
filter.replace(ralpha, opacity) :
style.filter + ' ' + opacity;
}
};
}
});
if (document.defaultView && document.defaultView.getComputedStyle) {
curCSS = function(elem, newName, name) {
var ret;
var defaultView;
var computedStyle;
name = name.replace(rupper, "-$1").toLowerCase();
if (!(defaultView = elem.ownerDocument.defaultView))
return undefined;
if ((computedStyle = defaultView.getComputedStyle(elem, null))) {
ret = computedStyle.getPropertyValue(name);
if (ret === "" && !contains(elem.ownerDocument.documentElement, elem))
ret = style(elem, name);
}
return ret;
};
} else if (document.documentElement.currentStyle) {
curCSS = function(elem, name) {
var left;
var rsLeft;
var ret = elem.currentStyle && elem.currentStyle[name];
var style = elem.style;
if (!rnumpx.test(ret) && rnum.test(ret)) {
left = style.left;
rsLeft = elem.runtimeStyle.left;
elem.runtimeStyle.left = elem.currentStyle.left;
style.left = name === "fontSize" ? "1em" : (ret || 0);
ret = style.pixelLeft + "px";
style.left = left;
elem.runtimeStyle.left = rsLeft;
}
return ret === "" ? "auto" : ret;
};
}
function contains(a, b) {
return document.compareDocumentPosition ?  a.compareDocumentPosition(b) & 16 :
(a !== b && (a.contains ? a.contains(b) : true));
}
function style(elem, name, value, extra) {
if (!elem || elem.nodeType === 3 || elem.nodeType === 8 || !elem.style)
return;
var ret;
var origName = name.camelize();
var s = elem.style;
var hooks = Prototype.cssHooks[origName];
name = Prototype.cssProps[origName] || origName;
if (value !== undefined) {
if (typeof value === "number" && isNaN(value) || value == null)
return;
if (typeof value === "number" && !Prototype.cssNumber[origName])
value += "px";
if (!hooks || !("set" in hooks) || (value = hooks.set(elem, value)) !== undefined) {
try {
s[name] = value;
} catch(e) {}
}
} else {
if (hooks && "get" in hooks && (ret = hooks.get(elem, false, extra)) !== undefined)
return ret;
return s[name];
}
}
function isEmptyObject(obj) {
for (var name in obj)
return false;
return true;
}
function isWindow(obj) {
return obj && typeof obj === "object" && "setInterval" in obj;
}
function arrayMerge(first, second) {
var i = first.length;
var j = 0;
if (typeof second.length === "number") {
for (var l = second.length; j < l; j++)
first[ i++ ] = second[ j ];
} else {
while (second[j] !== undefined)
first[ i++ ] = second[ j++ ];
}
first.length = i;
return first;
}
function makeArray(array) {
var ret = [];
if (array != null) {
var type = typeof array;
if (array.length == null || type === "string" || type === "function" || type === "regexp" || isWindow(array))
Array.prototype.push.call(ret, array);
else
arrayMerge(ret, array);
}
return ret;
}
function genFx(type, num) {
var obj = {};
fxAttrs.concat.apply([], fxAttrs.slice(0, num)).each(function(context) {
obj[context] = type;
});
return obj;
}
function defaultDisplay(nodeName) {
if (elemdisplay[nodeName])
return elemdisplay[nodeName];
var e = $(document.createElement(nodeName));
document.body.appendChild(e);
var display = e.getStyle("display");
e.remove();
if (display === "none" || display === "")
display = "block";
elemdisplay[nodeName] = display;
return display;
}
Prototype.effects = {
speed: function(speed, easing, fn) {
var opt = speed && typeof speed === "object" ? Object.extend({}, speed) : {
complete: fn || !fn && easing || typeof speed == 'function' && speed,
duration: speed,
easing: fn && easing || easing && !(typeof easing == 'function') && easing
};
opt.duration = Prototype.effects.fx.off ? 0 : typeof opt.duration === "number" ? opt.duration :
opt.duration in Prototype.effects.fx.speeds ? Prototype.effects.fx.speeds[opt.duration] : Prototype.effects.fx.speeds._default;
opt.old = opt.complete;
opt.complete = function() {
if (opt.queue !== false)
$(this).dequeue();
if (typeof opt.old == 'function')
opt.old.call(this);
};
return opt;
},
easing: {
linear: function(p, n, firstNum, diff) {
return firstNum + diff * p;
},
swing: function(p, n, firstNum, diff) {
return ((-Math.cos(p*Math.PI)/2) + 0.5) * diff + firstNum;
}
},
timers: [],
fx: function(elem, options, prop) {
this.elem = elem;
this.options = options;
this.prop = prop;
if (!options.orig)
options.orig = {};
}
};
Prototype.effects.fx.prototype = {
update: function() {
if (this.options.step)
this.options.step.call(this.elem, this.now, this);
(Prototype.effects.fx.step[this.prop] || Prototype.effects.fx.step._default)(this);
},
cur: function() {
if (this.elem[this.prop] != null && (!this.elem.style || this.elem.style[this.prop] == null))
return this.elem[this.prop];
var r = parseFloat(this.elem.getStyle(this.prop));
return r || 0;
},
custom: function(from, to, unit) {
var self = this;
var fx = Prototype.effects.fx;
this.startTime = new Date().getTime()
this.start = from;
this.end = to;
this.unit = unit || this.unit || "px";
this.now = this.start;
this.pos = this.state = 0;
function t(gotoEnd) {
return self.step(gotoEnd);
}
t.elem = this.elem;
if (t() && Prototype.effects.timers.push(t) && !timerId)
timerId = setInterval(fx.tick, fx.interval);
},
show: function() {
this.options.orig[this.prop] = style(this.elem, this.prop);
this.options.show = true;
this.custom(this.prop === "width" || this.prop === "height" ? 1 : 0, this.cur());
$(this.elem).show();
},
hide: function() {
this.options.orig[this.prop] = style(this.elem, this.prop);
this.options.hide = true;
this.custom(this.cur(), 0);
},
step: function(gotoEnd) {
var t = new Date().getTime();
var done = true;
if (gotoEnd || t >= this.options.duration + this.startTime) {
this.now = this.end;
this.pos = this.state = 1;
this.update();
this.options.curAnim[this.prop] = true;
for (var i in this.options.curAnim) {
if (this.options.curAnim[i] !== true)
done = false;
}
if (done) {
if (this.options.overflow != null && !shrinkWrapBlocks) {
var elem = this.elem;
var options = this.options;
var overflowArray = ["", "X", "Y"];
for (var ii = 0, ll = overflowArray.length; ii < ll; ii++)
elem.style[ "overflow" + overflowArray[ii] ] = options.overflow[ii];
}
if (this.options.hide) {
$(this.elem).hide();
if (Prototype.Browser.IE)
$(this.elem).setStyle({filter: ''});
}
if (this.options.hide || this.options.show) {
for (var p in this.options.curAnim)
style(this.elem, p, this.options.orig[p]);
}
this.options.complete.call(this.elem);
}
return false;
} else {
var n = t - this.startTime;
this.state = n / this.options.duration;
var specialEasing = this.options.specialEasing && this.options.specialEasing[this.prop];
var defaultEasing = this.options.easing || (Prototype.effects.easing.swing ? "swing" : "linear");
this.pos = Prototype.effects.easing[specialEasing || defaultEasing](this.state, n, 0, 1, this.options.duration);
this.now = this.start + ((this.end - this.start) * this.pos);
this.update();
}
return true;
}
};
Object.extend(Prototype.effects.fx, {
tick: function() {
var timers = Prototype.effects.timers;
for (var i = 0; i < timers.length; i++) {
if (!timers[i]())
timers.splice(i--, 1);
}
if (!timers.length)
Prototype.effects.fx.stop();
},
interval: 13,
stop: function() {
clearInterval(timerId);
timerId = null;
},
speeds: {
slow: 600,
fast: 200,
_default: 400
},
step: {
opacity: function(fx) {
fx.elem.setStyle({opacity: fx.now});
},
_default: function(fx) {
if (fx.elem.style && fx.elem.style[fx.prop] != null)
fx.elem.style[fx.prop] = (fx.prop === "width" || fx.prop === "height" ? Math.max(0, fx.now) : fx.now) + fx.unit;
else
fx.elem[fx.prop] = fx.now;
}
}
});
Object.extend(Prototype, {
isNaN: function(obj) {
return obj == null || !rdigit.test(obj) || isNaN(obj);
},
queue: function(elem, type, data) {
if (!elem)
return;
type = (type || "fx") + "queue";
var q = elem.retrieve(type);
if (!data)
return q || [];
if (!q || Object.isArray(data))
q = elem.store(type, makeArray(data));
else
q.push(data);
return q;
},
dequeue: function(elem, type) {
type = type || "fx";
var queue = Prototype.queue(elem, type);
var fn = queue.shift();
if (fn === "inprogress")
fn = queue.shift();
if (fn) {
if (type === "fx")
queue.unshift("inprogress");
fn.call(elem, function() {
Prototype.dequeue(elem, type);
});
}
},
cssHooks: {
opacity: {
get: function(elem, computed) {
if (computed) {
var ret = curCSS(elem, "opacity", "opacity");
return ret === "" ? "1" : ret;
}
return elem.style.opacity;
}
}
},
cssProps: {
"float": cssFloat ? "cssFloat" : "styleFloat"
},
cssNumber: {
"zIndex": true,
"fontWeight": true,
"opacity": true,
"zoom": true,
"lineHeight": true
}
});
function show(elem, speed, easing, callback) {
if (speed || speed === 0)
return animate(elem, genFx("show", 3), speed, easing, callback);
var display = elem.style.display;
if (!elem.retrieve("olddisplay") && display === "none")
display = elem.style.display = "";
if (display === "" && elem.getStyle("display") === "none")
elem.store("olddisplay", defaultDisplay(elem.nodeName));
display = elem.style.display;
if (display === "" || display === "none")
elem.style.display = elem.retrieve("olddisplay") || "";
return elem;
}
function hide(elem, speed, easing, callback) {
if (speed || speed === 0)
return animate(elem, genFx("hide", 3), speed, easing, callback);
var display = elem.getStyle('display');
if (display !== "none")
elem.store("olddisplay", elem.getStyle('display'));
elem.style.display = "none";
return elem;
}
function toggle(elem, fn, fn2, callback) {
var bool = typeof fn === "boolean";
if (typeof fn == 'function' && typeof fn2 == 'function')
toggle.apply(this, arguments);
else if (fn == null || bool) {
var state = bool ? fn : !elem.visible();
elem[state ? "show" : "hide"]();
} else
animate(elem, genFx("toggle", 3), fn, fn2, callback);
return elem;
}
function fadeTo(elem, speed, to, easing, callback) {
elem.setStyle({opacity: 0});
if (!elem.visible())
elem.show();
return animate(elem, {opacity: to}, speed, easing, callback);
}
function animate(elem, prop, speed, easing, callback) {
var optall = Prototype.effects.speed(speed, easing, callback);
if (isEmptyObject(prop))
return optall.complete;
return elem[optall.queue === false ? "_execute" : "queue"](function() {
var opt = Object.extend({}, optall);
var p;
var isElement = elem.nodeType === 1;
var hidden = isElement && !elem.visible();
for (p in prop) {
var name = p.camelize();
if (p !== name) {
prop[name] = prop[p];
delete prop[p];
p = name;
}
if (prop[p] === "hide" && hidden || prop[p] === "show" && !hidden)
return opt.complete.call(this);
if (isElement && (p === "height" || p === "width")) {
opt.overflow = [elem.style.overflow, elem.style.overflowX, elem.style.overflowY];
if (elem.getStyle("display") === "inline" && elem.getStyle("float") === "none") {
if (!inlineBlockNeedsLayout)
elem.style.display = "inline-block";
else {
var display = defaultDisplay(this.nodeName);
if (display === "inline")
elem.style.display = "inline-block";
else {
elem.style.display = "inline";
elem.style.zoom = 1;
}
}
}
}
if (Object.isArray(prop[p])) {
(opt.specialEasing = opt.specialEasing || {})[p] = prop[p][1];
prop[p] = prop[p][0];
}
}
if (opt.overflow != null)
elem.style.overflow = "hidden";
opt.curAnim = Object.extend({}, prop);
for (var i in prop) {
var name = i;
var val = prop[i];
var e = new Prototype.effects.fx(elem, opt, name);
if (rfxtypes.test(val)) {
e[val === "toggle" ? hidden ? "show" : "hide" : val](prop);
} else {
var parts = rfxnum.exec(val);
var start = e.cur() || 0;
if (parts) {
var end = parseFloat(parts[2]);
var unit = parts[3] || "px";
if (unit !== "px") {
style(elem, name, (end || 1) + unit);
start = ((end || 1) / e.cur()) * start;
style(name, start + unit);
}
if (parts[1])
end = ((parts[1] === "-=" ? -1 : 1) * end) + start;
e.custom(start, end, unit);
} else {
e.custom(start, val, "");
}
}
}
return true;
});
}
function stop(elem, clearQueue, gotoEnd) {
var timers = Prototype.effects.timers;
if (clearQueue)
elem.queue([]);
for (var i = timers.length - 1; i >= 0; i--) {
if (timers[i].elem === elem) {
if (gotoEnd) {
timers[i](true);
}
timers.splice(i, 1);
}
}
if (!gotoEnd)
elem.dequeue();
return elem;
}
function queue(elem, type, data) {
if (typeof type !== "string") {
data = type;
type = "fx";
}
if (data === undefined)
return Prototype.queue(elem, type);
var queue = Prototype.queue(elem, type, data);
if (type === "fx" && queue[0] !== "inprogress")
Prototype.dequeue(elem, type);
return elem;
}
function dequeue(elem, type) {
Prototype.dequeue(elem, type);
return elem;
}
function delay(elem, time, type) {
time = Prototype.effects.fx ? Prototype.effects.fx.speeds[time] || time : time;
type = type || "fx";
return elem.queue(type, function() {
setTimeout(function() {
Prototype.dequeue(elem, type);
}, time);
});
}
function clearQueue(elem, type) {
return elem.queue(type || "fx", []);
}
return Element.addMethods({
show: show,
hide: hide,
toggle: toggle,
fadeTo: fadeTo,
animate: animate,
slideDown: function(elem, speed, easing, callback) {
return animate(elem, genFx('show', 1), speed, easing, callback);
},
slideUp: function(elem, speed, easing, callback) {
return animate(elem, genFx('hide', 1), speed, easing, callback);
},
slideToggle: function(elem, speed, easing, callback) {
return animate(elem, genFx('toggle', 1), speed, easing, callback);
},
fadeIn: function(elem, speed, easing, callback) {
return animate(elem, {opacity: 'show'}, speed, easing, callback);
},
fadeOut: function(elem, speed, easing, callback) {
return animate(elem, {opacity: 'hide'}, speed, easing, callback);
},
fadeToggle: function(elem, speed, easing, callback) {
return animate(elem, {opacity: 'toggle'}, speed, easing, callback);
},
stop: stop,
queue: queue,
dequeue: dequeue,
delay: delay,
clearQueue: clearQueue,
_execute: function(elem, f) {
f();
return elem;
}
});
}());
;
/*! RESOURCE: /scripts/plugins/Tooltip.js */
Plugin.create('tooltip', {
HOVER_X_OFFSET: 15,
HOVER_Y_OFFSET: 15,
WINDOW_PADDING_TOP: 30,
WINDOW_PADDING_RIGHT: 50,
WINDOW_PADDING_BOTTOM: 20,
initialize: function(elem, options) {
if (elem.retrieve('tooltip'))
return;
this.options = Object.extend({
load: false,
loadMouseEvent: null,
effect: 'toggle',
fadeOutSpeed: "fast",
predelay: 0,
delay: 30,
opacity: 1,
tip: null,
position: ['top', 'center'],
ensureVisibility: true,
offset: [0, 0],
relative: false,
cancelDefault: true,
events: {
def: 		'mouseenter,mouseleave',
input: 		'focus,blur',
widget:		'focus mouseenter,blur mouseleave',
tooltip:	'mouseenter,mouseleave'
},
onTipInit: function() {},
onBeforeHide: function() {},
onHide: function() {},
onBeforeShow: function() {},
onShow: function() {},
layoutElem: 'div',
tipClass: 'tooltip'
}, options || {});
this.trigger = elem;
this.shown = false;
this.overTip = false;
this.stopped = false;
this.effect = this._effects[this.options.effect];
if (typeof this.options.position == 'string')
this.options.position = this.options.position.split(/,?\s/);
var tn = this.trigger.tagName;
var type = this.trigger.readAttribute('type');
var isInput = tn == 'INPUT';
var isWidget = isInput && (type =='checkbox' || type == 'radio' || type == 'button' || type == 'submit' || tn == 'SELECT');
var evt = this.options.events[type] || this.options.events[isInput ? (isWidget ? 'widget' : 'input') : 'def'];
if (!this.effect)
throw 'Nonexistent effect "' + this.options.effect + '"';
evt = evt.split(/,\s*/);
if (evt.length != 2)
throw 'Tooltip: Bad events configuration for: ' + type;
this.showEvents = evt[0].split(' ');
this.hideEvents = evt[1].split(' ');
if (this.options.cancelDefault === true) {
this.title = this.trigger.readAttribute('title');
this.trigger.writeAttribute('title', '');
}
for (var i = 0, l = this.showEvents.length; i < l; i++) {
this.trigger.observe(this.showEvents[i], this._eventShow.bind(this));
}
for (var i = 0, l = this.hideEvents.length; i < l; i++) {
this.trigger.observe(this.hideEvents[i], this._eventHide.bind(this));
}
this.trigger.store('tooltip', this);
this.docDirection = $$('html')[0].dir === 'rtl' ? 'rtl' : 'ltr';
},
_eventShow: function(event) {
clearTimeout(this.pretimer);
clearTimeout(this.timer);
if (this.preventShowEvent === true)
return;
if (this.options.predelay) {
this.pretimer = setTimeout(function() {
this.show(event);
}.bind(this), this.options.predelay);
} else {
this.show(event);
}
},
_eventHide: function(event) {
this.overTip = false;
clearTimeout(this.pretimer);
clearTimeout(this.timer);
if (this.preventHideEvent === true)
return;
if (this.options.delay) {
this.timer = setTimeout(function() {
if (!this.overTip)
this.hide(event);
}.bind(this), this.options.delay);
} else if (!this.overTip) {
this.hide(event);
}
},
_effects: {
toggle: [
function(done) {
var o = this.options.opacity;
if (o < 1) { this.tip.setStyle({opacity: o}); }
this.tip.show();
done.call();
},
function(done) {
this.tip.hide();
done.call();
}
],
fade: [
function(done) {
this.tip.fadeTo(this.options.fadeInSpeed, this.options.opacity, done);
},
function(done) {
this.tip.fadeOut(this.options.fadeOutSpeed, done);
}
]
},
_getPosition: function(checkVisibility) {
var pos = this._getPosition0(this.options.relative ? this.trigger.positionedOffset() : this.trigger.cumulativeOffset());
if (checkVisibility === true) {
var tipHeight = this.tip.measure('border-box-height');
var tipWidth = this.tip.measure('border-box-width');
var dims = document.viewport.getDimensions();
var scrollTop = document.body.scrollTop;
var scrollLeft = document.body.scrollLeft;
if (this.options.relative) {
if (scrollTop > 0) {
if (pos.top - scrollTop < 0)
pos.top = scrollTop;
if (dims.height - (pos.top - scrollTop + tipHeight) < 0)
pos.top = pos.top - tipHeight;
} else {
if (pos.top + tipHeight > dims.height)
pos.top = pos.top - tipHeight;
}
if (scrollLeft > 0) {
if (pos.left - scrollLeft <= 0)
pos.left = scrollLeft;
if (this.docDirection !== "rtl") {
if (dims.width - (pos.left - scrollLeft + tipWidth) < 0)
pos.left = pos.left - tipWidth ;
} else {
pos.right = pos.left;
return { top: pos.top, right: pos.right };
}
} else {
if (this.docDirection !== "rtl") {
if (pos.left + tipWidth > dims.width)
pos.left = Math.max(0, pos.left - tipWidth);
} else {
pos.right = pos.left;
return { top: pos.top, right: pos.right };
}
}
} else {
if (pos.top + tipHeight > dims.height)
pos.top = dims.height - tipHeight;
else if (pos.top < 0)
pos.top = 0;
if (pos.left + tipWidth > dims.width) {
if (this.docDirection !== "rtl")
pos.left = dims.width - tipWidth;
else {
var edgeWest = document.getElementById("edge_west");
pos.right = edgeWest.style.width.split("px")[0];
return { top: pos.top, right: pos.right };
}
}
else if (pos.left < 0)
pos.left = 0;
}
}
return { top: pos.top, left: pos.left };
},
_getPosition0: function(offset) {
var o = this.options;
var top = offset.top,
left = offset.left,
pos = o.position[1],
tipHeight = this.tip.measure('border-box-height'),
triggerWidth = this.trigger.measure('border-box-width');
top  -= tipHeight - o.offset[1];
left += triggerWidth + o.offset[0];
if (/iPad/i.test(navigator.userAgent)) {
top -= document.viewport.getScrollOffsets().top;
} else {
top -= this.trigger.cumulativeScrollOffset().top;
}
var height = tipHeight + this.trigger.measure('border-box-height');
if (pos == 'top-baseline')	{ top += tipHeight }
if (pos == 'center') 		{ top += height / 2; }
if (pos == 'bottom') 		{ top += height; }
pos = o.position[0];
var width = this.tip.measure('border-box-width') + triggerWidth;
if (pos == 'center') 	{ left -= width / 2; }
if (pos == 'left')   	{ left -= width; }
return { top: top, left: left };
},
show: function(event) {
clearTimeout(this.timer);
if (this.shown)
return this;
if (!this.tip) {
var attr = this.trigger.readAttribute('data-tooltip');
if (attr) {
this.tip = $$(attr)[0] || null;
} else if (this.options.tip) {
this.tip = $$(this.options.tip)[0] || null;
} else if (this.title) {
this.tip = new Element(this.options.layoutElem);
this.tip.addClassName(this.options.tipClass);
this.tip.title = this.title;
document.body.appendChild(this.tip);
} else {
if (!this.trigger || !this.trigger.parentNode)
return;
this.tip = this.trigger.next() || this.trigger.up().next();
}
if (!this.tip)
throw 'Cannot find tooltip for: ' + this.trigger;
if (!this.options.relative && this.tip.parentNode != document.body) {
var tmp = this.tip.clone(true);
this.tip.remove();
this.tip = tmp;
document.body.appendChild(this.tip);
}
for (var i = 0, l = this.showEvents.length; i < l; i++) {
this.tip.observe(this.showEvents[i], function() {
this.overTip = true;
}.bind(this) );
}
for (var i = 0, l = this.hideEvents.length; i < l; i++)
this.tip.observe(this.hideEvents[i], this._eventHide.bind(this));
this.options.onTipInit.call(this);
}
this.tip.stop(true, true);
var pos = this._getPosition();
if (this.title)
this.tip.innerHTML = this.title;
if (this.options.onBeforeShow.call(this, event) === false)
return;
pos = this._getPosition(this.options.ensureVisibility);
if (pos.left)
this.tip.setStyle({position:'absolute', top: pos.top + 'px', left: pos.left + 'px'});
else
this.tip.setStyle({position:'absolute', top: pos.top + 'px', right: pos.right + 'px'});
if (isMSIE6 && !this._iframeShim) {
var dims = this.tip.getDimensions();
this._iframeShim = $(document.createElement('iframe'));
this._iframeShim.setStyle({
top: pos.top + 'px',
left: pos.left + 'px',
height: dims.height + 'px',
width: dims.width + 'px',
position: 'absolute',
zIndex: '10',
filter: 'alpha(opacity=0)',
opacity: 0
});
this._iframeShim.src = 'javascript:"<html></html>"';
document.body.appendChild(this._iframeShim);
}
this.effect[0].call(this, function() {
this.options.onShow.call(this, event);
this.shown = true;
}.bind(this));
return this;
},
preventShow: function() {
this.preventShowEvent = true;
},
hide: function(event) {
clearTimeout(this.pretimer);
if (!this.tip || !this.shown)
return this;
this.options.onBeforeHide.call(this, event);
this.shown = false;
this.overTip = false;
this.preventHideEvent = false;
if (isMSIE6 && this._iframeShim) {
this._iframeShim.remove();
this._iframeShim = null;
}
this.effect[1].call(this, function() {
this.options.onHide.call(this, event);
}.bind(this));
return this;
},
updateIframeShim: function() {
if (!this._iframeShim)
return;
var dims = this.tip.getDimensions();
this._iframeShim.setStyle({
height: dims.height + 'px',
width: dims.width + 'px'
});
return this;
},
allowHide: function() {
this.preventHideEvent = false;
},
preventHide: function() {
this.preventHideEvent = true;
},
isShown: function() {
return this.shown;
},
getOptions: function() {
return this.options;
},
getTip: function() {
return this.tip;
},
getTrigger: function() {
return this.trigger;
},
toString: function() { return 'Tooltip'; }
});
;
/*! RESOURCE: /scripts/plugins/GlideDraggable.js */
Plugin.create('glideDraggable', {
initialize: function(elem, options) {
this.options = Object.extend({
iframeFix: true,
observeTouch: false,
distance: 1,
cursor: 'move',
triggerElem: elem,
dragElem: elem,
clone: false,
onDragStart: function(event) {
this.options.dragElem.setStyle({position: 'absolute'});
this.options.onDrag.call(this, event);
},
onDrag: function(event) {
this.options.dragElem.setStyle({
top: (event.pageY - this._originalPos.offsetY) + 'px',
left: (event.pageX - this._originalPos.offsetX) + 'px'
});
},
onDragEnd: function(event) {}
}, options || {});
if (this.options.triggerElem.retrieve('draggable'))
return;
this._fDraggableMove = this._onDrag.bind(this);
this._fDraggableEnd = this._onEnd.bind(this);
this.options.triggerElem.observe('mousedown', this._onStart.bind(this));
if (this.options.observeTouch === true)
this.options.triggerElem.observe('touchdown', this._onStart.bind(this));
this.options.triggerElem.store('draggable', this);
},
getClone: function() {
return this._clone;
},
getOriginalPosition: function() {
return this._originalPos;
},
_fixEvent: function(event) {
event = event || window.event;
if (!event.pageX) {
event.pageX = event.clientX;
event.pageY = event.clientY;
}
return event;
},
_distanceRequirementMet: function(event) {
if (this.options.distance == 0 ||
Math.abs(event.pageX - this._originalPos.pageX) >= this.options.distance ||
Math.abs(event.pageY - this._originalPos.pageY) >= this.options.distance)
return true;
return false;
},
_onStart: function(event) {
event = this._fixEvent(event);
if (this.options.iframeFix === true) {
$$('iframe').each(function(iframe) {
if (!iframe.visible())
return;
var offset = iframe.cumulativeOffset();
var shim = $(document.createElement('div'));
shim.addClassName('glide-draggable-iframe');
shim.setStyle({
position: 'absolute',
top: offset.top + 'px',
left: offset.left + 'px',
width: iframe.measure('border-box-width') + 'px',
height: iframe.measure('border-box-height') + 'px',
display: 'block',
zIndex: 9998,
backgroundColor: (Prototype.Browser.IE && !isMSIE10) ? '#fff' : 'transparent',
opacity: '0',
filter: 'alpha(opacity=0)'
});
document.body.appendChild(shim);
});
}
this._originalPos = {
pageX: event.pageX,
pageY: event.pageY,
offsetX: event.layerX || event.offsetX,
offsetY: event.layerY || event.offsetY
};
document.body.focus();
document.onselectstart = function () { return false; };
document.observe('mousemove', this._fDraggableMove);
document.observe('mouseup', this._fDraggableEnd);
if (this.options.observeTouch === true) {
document.observe('touchmove', this._fDraggableMove);
document.observe('touchup', this._fDraggableEnd);
}
this._isDragging = false;
event.stop();
},
_onDrag: function(event) {
event = this._fixEvent(event);
if (!this._isDragging) {
if (this._distanceRequirementMet(event)) {
this._docOverlay = $(document.createElement('div'));
this._docOverlay.setStyle({
position: 'absolute',
top: '0',
left: '0',
width: '100%',
height: '100%',
display: 'block',
zIndex: 9999,
cursor: this.options.cursor,
backgroundColor: (Prototype.Browser.IE && !isMSIE10) ? '#fff' : 'transparent',
opacity: '0',
filter: 'alpha(opacity=0)'
});
document.body.appendChild(this._docOverlay);
if (this.options.clone) {
this._clone = Element.clone(this.options.dragElem, true);
var offsets = this.options.dragElem.cumulativeOffset();
this._clone.writeAttribute('id', '');
this._clone.setStyle({
position: 'absolute',
zIndex: 9999,
top: offsets.top + 'px',
left: offsets.left + 'px',
height: this.options.dragElem.getHeight() + 'px',
width: this.options.dragElem.getWidth() + 'px'
});
document.body.appendChild(this._clone);
}
if (this.options.cursor) {
this._origCursor = this.options.dragElem.style.cursor;
this.options.dragElem.style.cursor = this.options.cursor;
}
this._isDragging = true;
this.options.onDragStart.call(this, event);
}
return;
}
this.options.onDrag.call(this, event);
},
_onEnd: function(event) {
event = this._fixEvent(event);
if (this.options.iframeFix === true) {
$$('div.glide-draggable-iframe').each(function(elem) {
elem.remove();
});
}
document.onselectstart = null;
document.stopObserving('mousemove', this._fDraggableMove);
document.stopObserving('mouseup', this._fDraggableEnd);
if (this.options.observeTouch === true) {
document.stopObserving('touchmove', this._fDraggableMove);
document.stopObserving('touchup', this._fDraggableEnd);
}
if (this._isDragging) {
this._docOverlay.remove();
if (this._origCursor)
this.options.dragElem.style.cursor = this._origCursor;
this.options.onDragEnd.call(this, event);
if (this.options.clone && this._clone && this._clone.parentNode)
this._clone.remove();
}
this._isDragging = false;
},
toString: function() { return 'glideDraggable'; }
});
;
/*! RESOURCE: /scripts/plugins/InPlaceEdit.js */
Plugin.create('inPlaceEdit', {
initialize : function(elem, options) {
if (elem.retrieve('inPlaceEdit'))
return;
this.options = Object.extend( {
editOnSingleClick: false,
turnClickEditingOff: false,
onBeforeEdit: function() {},
onAfterEdit: function() {},
selectOnStart: false,
convertNbspToSpaces: true,
titleText: null
}, options || {});
this.elem = elem;
this.elem.setAttribute('class', 'content_editable');
var mouseEvent;
if (!this.options.turnClickEditingOff) {
if (this.options.editOnSingleClick)
mouseEvent = 'click';
else
mouseEvent = 'dblclick';
this.elem.observe(mouseEvent, this.beginEdit.bind(this));
}
this.elem.onselectstart = function() { return true; };
this.elem.style.MozUserSelect = 'text';
if (this.options.titleText)
this.elem.writeAttribute('title', this.options.titleText);
this.keyPressHandler = this.keyPress.bind(this);
this.keyDownHandler = this.keyDown.bind(this);
this.endEditHandler = this.endEdit.bind(this);
this.elem.beginEdit = this.beginEdit.bind(this);
this.elem.store('inPlaceEdit', this);
},
beginEdit: function(event) {
this.options.onBeforeEdit.call(this);
this.elem.writeAttribute("contentEditable", "true");
this.elem.addClassName("contentEditing");
this.elem.observe('keypress', this.keyPressHandler);
this.elem.observe('keydown', this.keyDownHandler);
this.elem.observe('blur', this.endEditHandler);
this.elem.focus();
if (this.options.selectOnStart) {
this.elem.select();
var range;
if ((range = document.createRange)) {
if (range.selectNodeContents) {
range.selectNodeContents(this.elem);
window.getSelection().addRange(range);
}
} else if (document.body.createTextRange) {
range = document.body.createTextRange();
if (range.moveToElementText) {
range.moveToElementText(this.elem);
range.collapse(true);
range.select();
}
}
}
this.oldValue = this.elem.innerHTML;
if (typeof event != 'undefined' && event)
Event.stop(event);
},
keyPress: function(event) {
return this._submitEdit(event);
},
keyDown: function(event) {
return this._submitEdit(event);
},
endEdit: function(event) {
this.elem.writeAttribute("contentEditable", "false");
this.elem.removeClassName("contentEditing");
this.elem.stopObserving('keypress', this.keyPressHandler);
this.elem.stopObserving('blur', this.endEditHandler);
var newValue = this.elem.innerHTML.replace(/<br>$/, '');
if (this.options.convertNbspToSpaces)
newValue = newValue.replace(/&nbsp;/g, ' ');
if (newValue != this.oldValue) {
newValue = newValue.replace(/^\s+|\s+$/g, '');
this.elem.update(newValue);
this.options.onAfterEdit.call(this, newValue);
}
return false;
},
_submitEdit: function(event) {
var key = event.which || event.keyCode;
var e = Event.element(event);
if (key == Event.KEY_RETURN) {
e.blur();
Event.stop(event);
return false;
}
if (key == Event.KEY_ESC) {
this.elem.innerHTML = this.oldValue;
e.blur();
return false;
}
return true;
}
});
;
/*! RESOURCE: /scripts/classes/ui/GlideBox.js */
var g_glideBoxes = {};
var GlideBox = Class.create({
QUIRKS_MODE: document.compatMode != 'CSS1Compat',
initialize: function(options) {
if (isMSIE9)
this.QUIRKS_MODE = this._isQuirksMode();
this.options = Object.extend({
id: typeof options == 'string' ? options : guid(),
title: 'Default Title',
boxClass: '',
body: '',
form: null,
iframe: null,
iframeId: null,
bodyPadding: 4,
fadeOutTime: 200,
draggable: true,
showClose: true,
parent: document.body,
boundingContainer: options.parent || document.body,
position: Prototype.Browser.IE || options.parent ? 'absolute' : 'fixed',
allowOverflowY: true,
allowOverflowX: true,
height: null,
maxHeight: null,
minHeight: 50,
width: null,
minWidth: 70,
maxWidth: null,
top: null,
bottom: null,
maxTop: null,
minBottom: null,
left: null,
right: null,
preferences: {},
onBeforeLoad: function() {},
onAfterLoad: function() {},
onBeforeHide: function() {},
onAfterHide: function() {},
onBeforeShow: function() {},
onAfterShow: function() {},
onBeforeClose: function() {},
onAfterClose: function() {},
onBeforeDrag: function() {},
onAfterDrag: function() {},
onBeforeResize: function() {},
onAfterResize: function() {},
onHeightAdjust: function() {},
onWidthAdjust: function() {},
autoDimensionOnPreLoad: true,
autoDimensionOnLoad: true,
autoPositionOnLoad: true,
fadeInTime: 250
}, options || {});
this.options.padding = Object.extend({
top: 15,
right: 15,
bottom: 15,
left: 15
}, this.options.padding || {});
this._iframeShim = null;
this._dataCache = {};
this._box = $(document.createElement('div'));
this._box.id = this.options.id;
this._box.className = (new Array('glide_box', 'gb_mw', trim(this.options.boxClass), this.options.iframe && this.options.iframe != '' ? 'iframe' : '').join(' '));
this._box.setAttribute('role', 'dialog');
this._box.innerHTML = gb_BoxTemplateInner;
if (this._box.hasClassName('frame'))
this.getBodyWrapperElement().update(gb_BodyFrameTemplate);
this.options.parent.appendChild(this._box);
this.setBody(this.options.body);
this.setBodyPadding(this.options.bodyPadding);
if (this.options.titleHtml)
this.setTitleHtml(this.options.titleHtml)
else
this.setTitle(this.options.title);
this.setDraggable(this.options.draggable);
this.setStyle({position: this.options.position});
if (this.options.maxWidth)
this.setMaxWidth(this.options.maxWidth);
if (this.options.showClose)
this.addToolbarCloseButton();
if (this.options.allowOverflowY === false)
this.getBodyElement().setStyle({overflowY:'hidden'});
if (this.options.allowOverflowX === false)
this.getBodyElement().setStyle({overflowX:'hidden'});
g_glideBoxes[this.options.id] = this;
},
getId: function() {
return this.options.id;
},
getBoxElement: function() {
return this._box;
},
getBoxWrapperElement: function() {
return this._box.select('.gb_wrapper')[0];
},
getIFrameElement: function() {
return this._box.select('iframe')[0];
},
isVisible: function() {
return this._box.visible();
},
isLoading: function() {
return this._isLoading;
},
setOnClick: function(f) {
this._box.observe('click', f.bind(this));
},
setOnBeforeLoad: function(f) {
this.options.onBeforeLoad = f;
},
setOnAfterLoad: function(f) {
this.options.onAfterLoad = f;
},
setOnBeforeClose: function(f) {
this.options.onBeforeClose = f;
},
setOnAfterClose: function(f) {
this.options.onAfterClose = f;
},
setOnBeforeDrag: function(f) {
this.options.onBeforeDrag = f;
},
setOnAfterDrag: function(f) {
this.options.onAfterDrag = f;
},
setOnBeforeResize: function(f) {
this.options.onBeforeResize = f;
},
setOnAfterResizes: function(f) {
this.options.onAfterResize = f;
},
setOnHeightAdjust: function(f) {
this.options.onHeightAdjust = f;
},
setOnWidthAdjust: function(f) {
this.options.onWidthAdjust = f;
},
addData: function(key, value) {
this._dataCache[key] = value;
},
getData: function(key) {
return this._dataCache[key];
},
getToolbar: function() {
return this._box.select('.gb_toolbar')[0];
},
addToolbarRow: function(html) {
var thead = this._box.select('.gb_table > thead')[0];
var td = thead.insertRow(thead.rows.length).insertCell(0);
td.className = 'gb_table_col_l1';
td.innerHTML = html;
return td;
},
setTitle: function(html) {
var titleZone = this._box.select('.gb_title_zone')[0];
titleZone.addClassName('gb_toolbar_text');
if (titleZone.firstChild)
titleZone.removeChild(titleZone.firstChild);
var text = document.createTextNode(html);
titleZone.appendChild(text);
this._box.setAttribute('aria-label', html);
},
setTitleHtml: function(html) {
this._box.select('.gb_title_zone')[0].removeClassName('gb_toolbar_text').innerHTML = html;
},
setWindowIcon: function(html) {
var tr = this._box.select('.gb_toolbar_left tr')[0];
for (var i = 0, l = tr.childNodes.length; i < l; i++)
tr.deleteCell(i);
this.addWindowIcon(html);
},
addWindowIcon: function(html) {
this.addToolbarLeftDecoration('<div style="margin-left:5px;">' + html + '</div>');
},
removeToolbarDecoration: function(objSelector) {
var e = this.getToolbar().select(objSelector);
if (!e || e.length == 0)
return;
if (e[0].tagName.toLowerCase() == 'td')
var td = e;
else if (e[0].parentNode.tagName.toLowerCase() == 'td')
var td = e[0].parentNode;
else
return;
var tr = td.parentNode;
for (var i = 0, l = tr.childNodes.length; i < l; i++) {
if (tr.childNodes[i] == td) {
tr.deleteCell(i);
break;
}
}
},
addToolbarLeftDecoration: function(html, boolPrepend) {
return this._addToolbarDecoration(html, boolPrepend || false, '.gb_toolbar_left');
},
addToolbarRightDecoration: function(html, boolPrepend) {
return this._addToolbarDecoration(html, boolPrepend || false, '.gb_toolbar_right');
},
addToolbarCloseButton: function() {
var arr = this._box.getElementsByClassName('gb_close');
if (arr.length == 1)
return;
var className = this._box.hasClassName('dark') || this._box.hasClassName('iframe')
? 'icon-cross-circle i12 i12_close'
: 'icon-cross-circle i16 i16_close2';
this.addToolbarRightDecoration('<span style="float:none;cursor:pointer;" ' +
'tabindex="0" aria-label="Close" role="button" class="gb_close ' + className + '"></span>');
this.setToolbarCloseOnClick(function(event) {
this.close();
}.bind(this));
},
removeToolbarCloseButton: function() {
this.removeToolbarDecoration('.gb_close');
},
setToolbarCloseOnClick: function(f) {
var arr = this._box.getElementsByClassName('gb_close');
if (arr.length == 0)
return;
arr[0].stopObserving('mousedown');
arr[0].observe('mousedown', function(event) {
f.call(this, event);
event.stop();
}.bind(this));
arr[0].stopObserving('keydown');
arr[0].observe('keydown', function(event) {
if (event.keyCode != 13)
return;
f.call(this, event);
event.stop();
}.bind(this));
},
_addToolbarDecoration: function(html, boolPrepend, tableClassSelector) {
var table = this._box.select(tableClassSelector)[0].show();
var tr = table.select('tr')[0];
var td = tr.insertCell(boolPrepend ? 0 : -1);
td.innerHTML = html;
return td;
},
getFooter: function() {
return this._box.select('.gb_footer')[0];
},
showFooter: function() {
if (this._isFooterVisible === true)
return;
this.getFooter().show();
this._box.select('.gb_table > tfoot')[0].setStyle({display: 'table-footer-group'});
this._isFooterVisible = true;
},
hideFooter: function() {
if (!this._isFooterVisible !== true)
return;
this.getFooter().hide();
this._box.select('.gb_table > tfoot')[0].setStyle({display: 'none'});
this._isFooterVisible = false;
},
showFooterResizeGrips: function() {
this.showFooter();
var footer = this.getFooter();
if (!footer.select('.i16_resize_grip_left'))
return;
footer.select('.gb_footer_left_resize')[0].innerHTML = '<span class="i16 i16_resize_grip_left" style="float:none;" />';
footer.select('.gb_footer_right_resize')[0].innerHTML = '<span class="i16 i16_resize_grip_right" style="float:none;" />';
this.leftResizeDragger = new GlideDraggable(footer.select('.i16_resize_grip_left')[0], footer);
this.leftResizeDragger.setHoverCursor('sw-resize');
this.leftResizeDragger.setDragCursor('sw-resize');
this.leftResizeDragger.setStartFunction(function(e, dragElem, pageCoords, shift, dragCoords) {
var dims = this._getViewportDimensions();
var offsets = document.viewport.getScrollOffsets();
this._currentOffset = this.getOffset();
this._currentOffset.right = this._currentOffset.left + this.getWidth();
this._isLeftPositioned = this.convertToRightPosition();
this._maxWidth = this._currentOffset.right - this.options.padding.left - offsets.left;
this._maxHeight = dims.height - this.options.padding.top - this._currentOffset.top + offsets.top;
this.options.onBeforeResize.call(this);
}.bind(this));
this.leftResizeDragger.setDragFunction(function(e, dragElem, pageCoords, shift, dragCoords) {
this.setWidth(Math.min(this._maxWidth, (this._currentOffset.right - pageCoords.x)));
this.setHeight(Math.min(this._maxHeight, (pageCoords.y - this._currentOffset.top)));
}.bind(this));
this.leftResizeDragger.setEndFunction(function() {
if (this._isLeftPositioned)
this.convertToLeftPosition();
this._isLeftPositioned = null;
this.options.onAfterResize.call(this);
}.bind(this));
this.rightResizeDragger = new GlideDraggable(footer.select('.i16_resize_grip_right')[0], footer);
this.rightResizeDragger.setHoverCursor('se-resize');
this.rightResizeDragger.setDragCursor('se-resize');
this.rightResizeDragger.setStartFunction(function(e, dragElem, pageCoords, shift, dragCoords) {
var dims = this._getViewportDimensions();
var offsets = document.viewport.getScrollOffsets();
this._currentOffset = this.getOffset();
this._isRightPositioned = this.convertToLeftPosition();
this._maxWidth = dims.width - this.options.padding.left - this._currentOffset.left + offsets.left;
this._maxHeight = dims.height - this.options.padding.top - this._currentOffset.top + offsets.top;
this.options.onBeforeResize.call(this);
}.bind(this));
this.rightResizeDragger.setDragFunction(function(e, dragElem, pageCoords, shift, dragCoords) {
this.setWidth(Math.min(this._maxWidth, (pageCoords.x - this._currentOffset.left)));
this.setHeight(Math.min(this._maxHeight, (pageCoords.y - this._currentOffset.top)));
}.bind(this));
this.rightResizeDragger.setEndFunction(function() {
if (this._isRightPositioned)
this.convertToRightPosition();
this._isRightPositioned = null;
this.options.onAfterResize.call(this);
}.bind(this));
},
hideFooterResizeGrips: function() {
this.leftResizeDragger.destroy();
this.rightResizeDragger.destroy();
this.leftResizeDragger = null;
this.rightResizeDragger = null;
this._box.select('.gb_footer_left_resize')[0].innerHTML = '';
this._box.select('.gb_footer_right_resize')[0].innerHTML = '';
},
getFooterContainer: function() {
return this._box.select('.gb_footer_body > div')[0];
},
setFooter: function(html) {
this.showFooter();
this._box.select('.gb_footer_body > div')[0].innerHTML = html;
},
prependFooterRow: function(html) {
return this._addFooterRow(0, html);
},
appendFooterRow: function(html) {
return this._addFooterRow(-1, html);
},
_addFooterRow: function(pos, html) {
var foot = this._box.select('.gb_table > tfoot')[0];
var td = foot.insertRow(pos == -1 ? foot.rows.length : pos).insertCell(0);
td.className = 'gb_table_col_l1';
td.innerHTML = html;
return td;
},
getMaxDimensions: function() {
var vp = this._getViewportDimensions();
if (this.options.parent == document.body || this.options.parent != this.options.boundingContainer)
var res = { width: vp.width, height: vp.height };
else
var res = this.options.parent.getDimensions();
if (this.options.boundingContainer == this.options.parent) {
res.height -= this.options.top !== null ? this.options.top : this.options.padding.top;
res.height -= this.options.bottom !== null ? this.options.bottom : this.options.padding.bottom;
res.width -= this.options.left !== null ? this.options.left : this.options.padding.left;
res.width -= this.options.right !== null ? this.options.right : this.options.padding.right;
} else if (this.options.boundingContainer == document.body && document.loaded == true) {
var o = this.options.parent.cumulativeOffset();
var dims = this.options.parent.getDimensions();
if (this.options.bottom !== null)
res.height -= vp.height - (o.top + dims.height) + this.options.padding.top;
else if (this.options.top !== null)
res.height -= o.top + this.options.padding.bottom;
if (this.options.right !== null)
res.width -= vp.width - (o.left + dims.width) + this.options.padding.left;
else if (this.options.left !== null)
res.width -= o.left + this.options.padding.right;
} else {
}
if (this.options.maxWidth)
res.width = Math.min(res.width, this.options.maxWidth);
if (this.options.maxHeight)
res.height = Math.min(res.height, this.options.maxHeight);
return res;
},
getDocumentHeight: function(doc) {
var D = doc || window.document;
return Math.max(
Math.max(D.body.scrollHeight, D.documentElement.scrollHeight),
Math.max(D.body.offsetHeight, D.documentElement.offsetHeight),
Math.max(D.body.clientHeight, D.documentElement.clientHeight)
);
},
getDocumentWidth: function(doc) {
var D = doc || window.document;
return Math.max(
Math.max(D.body.scrollWidth, D.documentElement.scrollWidth),
Math.max(D.body.offsetWidth, D.documentElement.offsetWidth),
Math.max(D.body.clientWidth, D.documentElement.clientWidth)
);
},
autoDimension: function() {
this._scrollBarWidth = this._scrollBarWidth || getScrollBarWidthPx();
var box = this._box;
var body = this.getBodyElement();
var bodyWrapper = this.getBodyWrapperElement();
var extraWidth = 0;
var innerHeight = null;
var innerWidth = null;
var maxDim = this.getMaxDimensions();
var clone = null;
box.setStyle({width:'', height:''});
bodyWrapper.setStyle({width:'', height:'', overflowY: 'hidden'});
body.setStyle({width:'', height:''});
var iframe = this.getIFrameElement();
if (this.options.iframe && iframe && !this.isLoading()) {
if (!this.options.width && !this.options.height) {
try {
var D = iframe.contentDocument || iframe.contentWindow.document;
innerWidth = (this.getDocumentWidth(D) + 4);
innerHeight = (this.getDocumentHeight(D) + 4);
if (isMacintosh && Prototype.Browser.Gecko)
innerHeight++;
} catch (e) {
innerWidth = 500;
innerHeight = 500;
}
} else {
if (this.options.height) {
var p = (this.options.height + '').match(/([0-9]*)%/);
var diff = box.measure('border-box-height') - body.measure('border-box-height');
if (!this.QUIRKS_MODE)
diff = diff - box.measure('border-top') - box.measure('border-bottom');
if (typeof this.options.height == 'number')
innerHeight = this.options.height - diff;
else if (typeof this.options.height == 'string' && p)
innerHeight = (maxDim.height * (parseInt(p[1], 10)/100)) - diff;
} if (this.options.width) {
var p = (this.options.width + '').match(/([0-9]*)%/);
var diff = box.measure('border-box-width') - body.measure('border-box-width');
if (!this.QUIRKS_MODE)
diff = diff - box.measure('border-left') - box.measure('border-right');
if (typeof this.options.width == 'number')
innerWidth = this.options.width - diff;
else if (typeof this.options.width == 'string' && p)
innerWidth = (maxDim.width * (parseInt(p[1], 10)/100)) - diff;
}
}
iframe.writeAttribute('height', 0);
iframe.writeAttribute('width', 0);
} else {
clone = Element.clone(box, true);
clone.id = '';
clone.setStyle({
position: 'absolute',
top: '-1999px',
left: '-1999px',
right: '',
bottom: '',
width: '',
height: '',
display: 'block',
visibility: 'hidden'
});
if (Prototype.Browser.WebKit)
clone.innerHTML = clone.innerHTML;
document.body.appendChild(clone);
var cloneBody = clone.select('.gb_body:first')[0];
var diff = clone.measure('border-box-width') - cloneBody.measure('border-box-width');
if (this.QUIRKS_MODE)
diff = diff - clone.measure('border-left') - clone.measure('border-right');
if (!this.options.width)
innerWidth = Math.min(maxDim.width - diff, cloneBody.getWidth() + 1);
else {
var p = (this.options.width + '').match(/([0-9]*)%/);
if (typeof this.options.width == 'number')
innerWidth = Math.min(maxDim.width, this.options.width) - diff;
else if (typeof this.options.width == 'string' && p)
innerWidth = (maxDim.width * (parseInt(p[1], 10)/100)) - diff;
}
cloneBody.setStyle({width: innerWidth + 'px'});
if (!this.options.height) {
innerHeight = cloneBody.getHeight();
cloneBody.setStyle({width: innerWidth + 'px'});
} else {
var p = (this.options.height + '').match(/([0-9]*)%/);
var diff = clone.measure('border-box-height') - cloneBody.measure('border-box-height');
if (this.QUIRKS_MODE)
diff = diff - box.measure('border-top') - box.measure('border-bottom');
if (typeof this.options.height == 'number')
innerHeight = this.options.height - diff;
else if (typeof this.options.height == 'string' && p)
innerHeight = (maxDim.height * (parseInt(p[1], 10)/100)) - diff;
cloneBody.setStyle({height: innerHeight + 'px'});
}
}
if (clone && this.options.width && typeof this.options.width == 'string') {
var per = (this.options.width + '').match(/([0-9]*)%/);
clone.setStyle({width: (maxDim.width * (parseInt(per[1], 10)/100)) + 'px'});
} else if (clone && this.options.width && typeof this.options.width == 'number')
clone.setStyle({width: this.options.width + 'px'});
if (this.options.allowOverflowY === true)
bodyWrapper.setStyle({overflowY: ''});
body.style.width = innerWidth + 'px';
body.style.height = innerHeight + 'px';
var dims = clone ? clone.getDimensions() : box.getDimensions();
var diffHeight = dims.height - maxDim.height;
if (dims.height > maxDim.height) {
extraWidth = this.options.allowOverflowY === true ? this._scrollBarWidth : 0;
body.style.height = Math.max(0, innerHeight - diffHeight) + 'px';
this.setHeight(maxDim.height, clone);
}
else
this.setHeight(dims.height, clone);
if (dims.width > maxDim.width) {
this.setWidth(maxDim.width);
this.setHeight(Math.min(maxDim.height, dims.height + this._scrollBarWidth), clone);
} else
this.setWidth(Math.min(dims.width, this.options.width && typeof this.options.width == 'number' ? this.options.width : dims.width) + extraWidth);
if (clone)
clone.remove();
this._resizeIframeShim();
},
size: function(w, h) {
if (w) this.setWidth(w);
if (h) this.setHeight(h);
},
setMaxWidth: function(mw) {
this.options.maxWidth = parseInt(mw, 10);
this._box.setStyle({maxWidth: this.options.maxWidth + 'px'});
},
setWidth: function(w) {
w = typeof w == 'string' ? parseInt(w, 10) : w;
var box = this._box;
var boxBorder = box.measure('border-left') + box.measure('border-right');
var gbWrapper = box.select('.gb_wrapper')[0];
var wrapperBorder = gbWrapper.measure('border-left') + gbWrapper.measure('border-right');
var wrapper = this.getBodyWrapperElement();
var body = this.getBodyElement();
var iframe = this.options.iframe ? this.getIFrameElement() : null;
w = Math.max(w, this.options.minWidth);
var wrapperWidth = w;
if (!this.QUIRKS_MODE || (this.QUIRKS_MODE && !Prototype.Browser.IE))
wrapperWidth -= (boxBorder + wrapperBorder);
if (!this.QUIRKS_MODE || (this.QUIRKS_MODE && !Prototype.Browser.IE))
wrapperWidth -= wrapper.measure('padding-left') + wrapper.measure('padding-right');
var ww = wrapperWidth;
if (this.QUIRKS_MODE && Prototype.Browser.IE)
ww += wrapperBorder + wrapper.measure('padding-left') + wrapper.measure('padding-right');
var boxSizing = wrapper.getStyle('box-sizing');
var bsw = ww;
if (boxSizing == 'border-box') {
bsw += wrapperBorder + wrapper.measure('padding-left') + wrapper.measure('padding-right');
} else if (boxSizing == 'padding-box') {
bsw += wrapper.measure('padding-left') + wrapper.measure('padding-right');
}
wrapper.setStyle({width:bsw + 'px'});
body.setStyle({width:ww + 'px'});
if (!this.QUIRKS_MODE || (this.QUIRKS_MODE && !Prototype.Browser.IE))
w = w - boxBorder;
if (this.QUIRKS_MODE && Prototype.Browser.IE) {
w = ww - (wrapperBorder + wrapper.measure('padding-left') + wrapper.measure('padding-right'));
body.setStyle({width:w + 'px'});
}
box.setStyle({width:w + 'px'});
if (iframe) {
var iframeWrap2 = iframe.up();
var iframeContainer = iframeWrap2.up();
var iframeWidth = (wrapperWidth -
iframeWrap2.measure('border-left') - iframeWrap2.measure('border-right') -
iframeContainer.measure('border-left') - iframeContainer.measure('border-right'));
iframe.writeAttribute('width', iframeWidth);
}
var table = box.select('.gb_table')[0];
var tw = table.getWidth();
var realWrapperWidth = wrapper.getWidth();
if (realWrapperWidth < tw) {
var bodyPadding = wrapper.measure('padding-left') + wrapper.measure('padding-right');
var nw = tw - bodyPadding;
wrapper.setStyle({width:nw + 'px'});
box.setStyle({width: (w+(tw-realWrapperWidth)) + 'px'});
if (iframe)
iframe.writeAttribute('width', nw);
}
this.options.onWidthAdjust.call(this);
},
setMinWidth: function(mw) {
this.options.minWidth = typeof mw == 'string' ? parseInt(mw, 10) : mw;
},
setHeight: function(h, clone) {
h = typeof h == 'string' ? parseInt(h, 10) : h;
var box = clone || this._box;
var gbWrapper = box.select('.gb_wrapper')[0];
var boxBorder = box.measure('border-top') + box.measure('border-bottom');
var wrapperBorder = gbWrapper.measure('border-top') + gbWrapper.measure('border-bottom');
var bodyWrapper = box.select('.gb_body_wrapper')[0];
var body = box.select('.gb_body')[0];
var iframe = this.options.iframe ? this.getIFrameElement() : null;
var table = box.select('.gb_table')[0];
if (this.options.minHeight)
h = Math.max(h, this.options.minHeight);
if (iframe)
var wrapperHeight = h - (box.getHeight() - Math.max(body.getHeight(), parseInt(body.getStyle('height'), 10)));
else {
var wrapperHeight = h - wrapperBorder - boxBorder - table.select('thead')[0].getHeight() - table.select('tfoot > tr')[0].getHeight();
if (!this.QUIRKS_MODE || (this.QUIRKS_MODE && !Prototype.Browser.IE))
wrapperHeight -= bodyWrapper.measure('padding-top') + bodyWrapper.measure('padding-bottom');
}
wrapperHeight = Math.max(wrapperHeight, 0);
wh = wrapperHeight;
if (this.QUIRKS_MODE && Prototype.Browser.IE)
wh += wrapperBorder + bodyWrapper.measure('padding-top') + bodyWrapper.measure('padding-bottom');
var boxSizing = bodyWrapper.getStyle('box-sizing');
if (boxSizing == 'border-box') {
wh += wrapperBorder + bodyWrapper.measure('padding-top') + bodyWrapper.measure('padding-bottom');
} else if (boxSizing == 'padding-box') {
wh += bodyWrapper.measure('padding-top') + bodyWrapper.measure('padding-bottom');
}
this.getBodyWrapperElement().setStyle({height:wh + 'px'});
if (iframe) {
var iframeWrap2 = iframe.up();
var iframeContainer = iframeWrap2.up();
var iframeHeight = (wrapperHeight -
iframeWrap2.measure('border-top') - iframeWrap2.measure('border-bottom') -
iframeContainer.measure('border-top') - iframeContainer.measure('border-bottom'));
iframe.writeAttribute('height', iframeHeight);
}
h = h - boxBorder;
this._box.setStyle({height:h + 'px'});
this.options.onHeightAdjust.call(this);
},
setMinHeight: function(mh) {
this.options.minHeight = typeof mh == 'string' ? parseInt(mh, 10) : mh;
this._box.setStyle({minHeight: this.options.minHeight +'px'});
},
getMaxPositions: function() {
if (this.options.parent == document.body) {
var winDimensions = this._getViewportDimensions();
var parent = { width: winDimensions.width, height: winDimensions.height };
} else {
var parent = { width: this.options.parent.getWidth(), height: this.options.parent.getHeight() };
}
return {
minTop: this.options.padding.top,
minLeft: this.options.padding.left,
maxTop: parent.height - this.getHeight() - this.options.padding.bottom,
maxLeft: parent.width - this.getWidth() - this.options.padding.right
};
},
autoPosition: function() {
if ((this.options.left !== null || this.options.right !== null) &&
(this.options.top !== null || this.options.bottom !== null)) {
if (this.options.left !== null)
this.positionLeft(this.options.left);
else
this.positionRight(this.options.right);
if (this.options.top !== null)
this.positionTop(this.options.top);
else
this.positionBottom(this.options.bottom);
}
else {
if (this.options.parent == document.body) {
var winScrollOffsets = document.viewport.getScrollOffsets();
var winDimensions = this._getViewportDimensions();
var height = winDimensions.height;
var width = winDimensions.width;
var offset = this.getStyle('position') == 'absolute' ? { left: winScrollOffsets.left, top: winScrollOffsets.top } : { left: 0, top: 0};
} else {
var height = this.options.parent.getHeight();
var width = this.options.parent.getWidth();
var offset = {left: 0, top: 0};
}
if (this.options.left !== null)
this.positionLeft(this.options.left);
else if (this.options.right !== null)
this.positionRight(this.options.right);
else
this.positionLeft(width/2 - this.getWidth()/2 + offset.left)
if (this.options.top !== null)
this.positionTop(this.options.top);
else if (this.options.bottom !== null)
this.positionBottom(this.options.bottom);
else
this.positionTop(height/2 - this.getHeight()/2 + offset.top);
}
},
center: function() {
if (this.options.parent == document.body) {
var offsets = document.viewport.getScrollOffsets();
var winDimensions = this._getViewportDimensions();
var height = winDimensions.height;
var width = winDimensions.width;
} else {
var height = this.options.parent.getHeight();
var width = this.options.parent.getWidth();
var offsets = {left: 0, top: 0};
}
if (this.getStyle('position') == 'absolute') {
this.positionLeft(width/2 - this.getWidth()/2 + offsets.left);
this.positionTop(height/2 - this.getHeight()/2 + offsets.top);
} else {
this.positionLeft(width/2 - this.getWidth()/2);
this.positionTop(height/2 - this.getHeight()/2);
}
},
setMaxTop: function(p) {
this.options.maxTop = p;
},
setMinBottom: function(p) {
this.options.minBottom = p;
},
positionTop: function(top) {
if (top === null)
return;
top = parseInt(top, 10);
if (this.options.maxTop)
top = Math.min(top, this.options.maxTop);
if (this.options.minBottom) {
var h = this.getHeight();
if (top + h < this.options.minBottom)
top = this.options.minBottom - h;
}
this.setStyle({top: top + 'px'});
},
positionLeft: function(left) {
if (!left)
return;
this.setStyle({left: left + 'px', right: ''});
},
positionRight: function(right) {
if (right === null)
return;
this.setStyle({right:right + 'px', left: ''});
},
positionBottom: function(bottom) {
if (bottom === null)
return;
bottom = parseInt(bottom, 10);
this.setStyle({bottom: bottom + 'px', top: ''});
},
convertToLeftPosition: function() {
if (!this._box.style.right)
return false;
this.setStyle({
right: '',
left: (this.getOffset().left - (this.getStyle('position') == 'fixed' ? document.viewport.getScrollOffsets().left : 0)) + 'px'
});
return true;
},
convertToRightPosition: function() {
var l = this._box.style.left;
if (!l)
return false;
this.setStyle({
left: '',
right: (this._getViewportDimensions().width - parseInt(l, 10) - this.getWidth()) + 'px'
});
return true;
},
setStyle: function(o, value) {
if (typeof o == 'string')
o = {o: value};
else if (typeof o != 'object')
o = {};
this._box.setStyle(o);
},
getWidth: function() {
return this._box.getWidth();
},
getHeight: function() {
return this._box.getHeight();
},
getStyle: function(s) {
return this._box.getStyle(s);
},
getOffset: function() {
return this._box.cumulativeOffset();
},
getBodyElement: function() {
return this._box.select('.gb_body')[0];
},
getBodyWrapperElement: function() {
return this._box.select('.gb_body_wrapper')[0];
},
setBody: function(html) {
this.getBodyElement().innerHTML = html;
},
setBodyFromForm: function(template) {
this.options.form = template;
},
setBodyPadding: function(pad) {
if (!this.options.iframe)
this.getBodyWrapperElement().setStyle({padding: pad + (isNaN(pad) ? '' : 'px')});
},
_getViewportDimensions: function() {
if (!this.QUIRKS_MODE || !Prototype.Browser.IE)
return document.viewport.getDimensions();
return {
height: getBrowserWindowHeight(),
width: getBrowserWindowWidth()
};
},
setDraggable: function(b) {
if (b) {
this.toolbarDragger = new GlideDraggable(this.getToolbar(), this._box);
this.toolbarDragger.setHoverCursor('move');
this.toolbarDragger.setStartFunction(function(e, dragElem, pageCoords, shift, dragCoords) {
this._tmpDim = this.getMaxPositions();
this.options.onBeforeDrag.call(this, e, dragElem, pageCoords, shift, dragCoords);
}.bind(this));
this.toolbarDragger.setDragFunction(function(e, dragElem, pageCoords, shift, dragCoords) {
dragElem.style.left = Math.min(Math.max(this._tmpDim.minLeft, dragCoords.x), this._tmpDim.maxLeft) + 'px';
dragElem.style.top = Math.min(Math.max(this._tmpDim.minTop, dragCoords.y), this._tmpDim.maxTop) + 'px';
}.bind(this));
this.toolbarDragger.setEndFunction(function(e, dragElem, pageCoords, shift, dragCoords) {
this.options.onAfterDrag.call(this, e, dragElem, pageCoords, shift, dragCoords);
}.bind(this));
} else if (this.toolbarDragger) {
this.toolbarDragger.destroy();
this.toolbarDragger = null;
}
},
isDraggable: function(b) {
return this.toolbarDragger ? true : false;
},
setPreferences : function(preferences) {
this.options.preferences = preferences;
},
setPreference: function(name, value) {
if (typeof(value) == 'string')
value = value.replace(/</g, "&lt;").replace(/>/g, "&gt;");
this.options.preferences[name] = value;
},
getPreferences: function() {
return this.options.preferences;
},
removePreference: function(name, value) {
delete this.options.preferences[name];
},
getDescribingXML : function() {
var section = document.createElement('section');
section.setAttribute('name', this.getId());
for (var name in this.options.preferences) {
var p = document.createElement('preference');
var v = this.options.preferences[name];
p.setAttribute('name', name);
if (typeof v == 'object') {
if (typeof v.join == 'function') {
v = v.join(',');
} else if (typeof v.toString == 'function') {
v = v.toString();
}
}
if (v)
p.setAttribute('value', v);
section.appendChild(p);
}
return section;
},
getDescribingText : function() {
var gxml = document.createElement("gxml");
var x = this.getDescribingXML();
gxml.appendChild(x);
return gxml.innerHTML;
},
hide: function(fadeOutTime) {
this.options.onBeforeHide.call(this);
this._removeIFrameShim();
fadeOutTime = fadeOutTime || fadeOutTime === 0 ? fadeOutTime : this.options.fadeOutTime
if (fadeOutTime !== 0)
this.getBoxElement().fadeOut(fadeOutTime, function() {
this.options.onAfterHide.call(this);
}.bind(this));
else {
this.getBoxElement().hide();
this.options.onAfterHide.call(this);
}
},
show: function(fadeInTime) {
this.options.onBeforeShow.call(this);
fadeInTime = 0;
if (this._iframeNeedsAutoDimension === true) {
this._box.setStyle({opacity: '0', filter: 'alpha(opacity=0)', visibility: 'hidden', display: 'block'});
this.autoDimension();
this.autoPosition();
this._box.setStyle({opacity: '', filter: '', visibility: '', display: 'none'});
}
if (fadeInTime !== 0)
this.getBoxElement().fadeIn(fadeInTime, function() {
this.options.onAfterShow.call(this);
}.bind(this));
else {
this.getBoxElement().show();
this.options.onAfterShow.call(this);
}
this._iframeNeedsAutoDimension = false;
this._createIframeShim();
},
render: function(options) {
options = Object.extend({
autoDimensionOnPreLoad: this.options.autoDimensionOnPreLoad,
autoDimensionOnLoad: this.options.autoDimensionOnLoad,
autoPositionOnLoad: this.options.autoPositionOnLoad,
fadeInTime: 0
}, options || {});
this._isClosing = false;
var bw = this.getBodyWrapperElement();
if (!this.getToolbar().visible())
bw.addClassName('no_toolbar');
if (!this.getFooter().visible())
bw.addClassName('no_footer');
if (this.options.form)
this._renderForm(options);
else if (this.options.iframe)
this._renderIFrame(options);
else
this._renderStatic(options);
},
_renderStatic: function(opts) {
this.options.onBeforeLoad.call(this);
if (opts.autoDimensionOnLoad)
this.autoDimension();
if (opts.autoPositionOnLoad)
this.autoPosition();
if (opts.fadeInTime !== 0)
this._box.fadeIn(opts.fadeInTime);
else
this._box.style.display = 'block';
this.options.onAfterShow.call(this);
this.options.onAfterLoad.call(this);
},
_renderForm: function(opts) {
this._isLoading = true;
this.options.onBeforeLoad.call(this);
this.setBody(gb_LoadingBody);
this._box.addClassName('form');
this._box.setStyle({display:'block'});
if (opts.autoDimensionOnPreLoad) {
this.autoDimension();
this.center();
}
this.setPreference('renderer', 'RenderForm');
this.setPreference('type', 'direct');
this.setPreference('table', this.options.form);
var ga = new GlideAjaxForm(this.options.form);
ga.addParam('sysparm_value', this.getDescribingText());
ga.addParam('sysparm_name', this.options.form);
ga.getRenderedBodyText(function() {
this.setBody(s);
s.evalScripts(true);
this._isLoading = false;
this.options.onAfterShow.call(this);
this.options.onAfterLoad.call(this);
if (opts.autoDimensionOnLoad)
this.autoDimension();
if (opts.autoPositionOnLoad)
this.autoPosition();
}.bind(this));
},
_renderIFrame: function(opts) {
this._isLoading = true;
this.setBody(gb_BoxIFrameBody);
this._box.setStyle({display:'block'});
if (opts.autoDimensionOnPreLoad)
this.autoDimension();
this.autoPosition();
if (opts.autoDimensionOnLoad !== true) {
var tmpIFrame = this.getIFrameElement();
if (tmpIFrame) {
var oldHeight = tmpIFrame.readAttribute('height');
var oldWidth = tmpIFrame.readAttribute('width');
}
}
var loading = this._box.select('.gb_loading')[0];
var wrapper = loading.up('.gb_body_wrapper');
loading.setStyle({height: (wrapper.measure('height') - loading.measure('padding-top') - loading.measure('padding-bottom') - 4) + 'px'});
loading.up('.loading_wrap_outer').setStyle({width: (wrapper.measure('width') - 2) + 'px' });
var f = function() {
var iframe = this.getIFrameElement();
iframe.stopObserving('load', f);
iframe.up().up().show().previous().remove();
this._isLoading = false;
if (opts.autoDimensionOnLoad || (!opts.autoDimensionOnLoad && !oldHeight && !oldWidth)) {
if (!this.isVisible())
this._iframeNeedsAutoDimension = true;
else
this.autoDimension();
} else if (oldHeight && oldWidth) {
iframe.writeAttribute('height', oldHeight);
iframe.writeAttribute('width', oldWidth);
}
this.autoPosition();
this._createIframeShim();
this.options.onAfterShow.call(this);
this.options.onAfterLoad.call(this);
}.bind(this);
var iframe = this.getIFrameElement();
iframe.id = this.options.iframeId || guid();
iframe.observe('load', f);
this.options.onBeforeLoad.call(this);
iframe.src = this.options.iframe;
},
_createIframeShim: function() {
if (!this.options.iframe || !isMSIE6 || this._iframeShim)
return;
var box = this.getBoxElement();
this._iframeShim = $(document.createElement('iframe'));
this._iframeShim.setStyle({
top: box.getStyle('top'),
left: box.getStyle('left'),
height: box.getHeight() + 'px',
width: box.getWidth() + 'px',
position: 'absolute',
zIndex: '10',
filter: 'alpha(opacity=0)',
opacity: 0
});
this._iframeShim.src = 'javascript:"<html></html>"';
document.body.appendChild(this._iframeShim);
},
_resizeIframeShim: function() {
if (!Object.isElement(this._iframeShim))
return;
var box = this.getBoxElement();
this._iframeShim.setStyle({width: box.getWidth() + 'px', height: box.getHeight() + 'px',
top: box.getStyle('top'), left: box.getStyle('left') });
},
_removeIFrameShim: function() {
if (this._iframeShim && Object.isElement(this._iframeShim)) {
this._iframeShim.remove();
this._iframeShim = null;
}
},
close: function(timeout) {
if (this._isClosing === true)
return;
this._isClosing = true;
this.options.onBeforeClose.call(this);
timeout = !timeout && timeout !== 0 ? this.options.fadeOutTime : parseInt(timeout, 10);
if (timeout !== 0)
this._box.fadeOut(timeout, function() {
this._box.remove();
}.bind(this));
else
this._box.remove();
this.options.onAfterClose.call(this);
delete g_glideBoxes[this.getId()];
},
_isQuirksMode: function() {
var i = 0;
var d = document;
while (d) {
if (++i == 10)
return true;
if (d.compatMode != 'BackCompat')
return false;
if (d.parentWindow.parent.document == d)
return true;
d = d.parentWindow.parent.document;
}
return true;
},
toString: function() { return 'GlideBox'; }
});
GlideBox.get = function(objIdOrElem) {
if (typeof objIdOrElem == 'object' && objIdOrElem.toString() == 'GlideBox') {
var o = g_glideBoxes[objIdOrElem.options.id];
return o || null;
} else if (typeof objIdOrElem == 'string') {
var o = g_glideBoxes[objIdOrElem];
if (o) return o;
}
var e = $(objIdOrElem);
if (!e)
return null;
var box = e.up('.glide_box');
if (box)
return g_glideBoxes[box.getAttribute('id')] || null;
return null;
}
GlideBox.close = function(objIdOrElem, timeout) {
var o = GlideBox.get(objIdOrElem);
if (o)
o.close(timeout);
return false;
}
var gb_LoadingBody = '<div style="padding:6px 5px 5px 3px;" class="gb_loading"><span class="ia_loading"></span><span class="fontsmall" style="padding-left:6px;padding-top:4px;">Loading ...</span></div>';
var gb_ToolbarTemplate = '<table class="gb_toolbar"><tbody><tr><td class="gb_toolbar_col_l1">' +
'<table class="gb_toolbar_left gb_toolbar_decoration"><tr></tr></table>' +
'</td><td class="gb_toolbar_col_l1 gb_title_zone"></td><td class="gb_toolbar_col_l1">' +
'<table class="gb_toolbar_right gb_toolbar_decoration"><tbody><tr></tr></tbody></table>' +
'</td></tr></tbody></table><div class="gb_toolbar_bottom_border">&nbsp;</div>';
var gb_FooterTemplate = '<div class="gb_footer_sep"></div><table class="gb_footer"><tbody><tr><td class="gb_footer_left_resize"></td><td class="gb_footer_body"><div></div></td><td class="gb_footer_right_resize"></td></tr></tbody></table>';
var gb_BodyTemplate = '<div class="gb_body_wrapper gb_mw"><div class="gb_body"></div></div>';
var gb_BodyFrameTemplate = '<div class="inner_wrap_outer"><div class="inner_wrap_inner"><div class="gb_body"></div></div></div>';
var gb_BoxTemplateInner = '<div class="gb_wrapper"><table class="gb_table"><thead><tr><td class="gb_table_col_l1" style="vertical-align:top;">' + gb_ToolbarTemplate + '</td></tr></thead><tbody><tr><td class="gb_table_col_l1">' + gb_BodyTemplate + '</td></tr></tbody><tfoot class="gb_table_tfoot"><tr><td class="gb_table_col_l1">' + gb_FooterTemplate + '</td></tr></tfoot></table></div>';
var gb_BoxIFrameBody = '<div class="loading_wrap_outer"><div class="loading_wrap_inner">' + gb_LoadingBody + '</div></div><div class="iframe_container inner_wrap_outer"><div class="inner_wrap_inner"><iframe class="gb_iframe" frameborder="0" marginheight="0" marginwidth="0" src="javascript:\'<html></html>\'"></iframe></div></div><div class="clear"></div>';
;
/*! RESOURCE: /scripts/classes/ui/GlideOverlay.js */
var GlideOverlay = Class.create(GlideBox, {
initialize: function($super, options) {
var opts = Object.extend({
closeOnEscape: true,
isModal: true,
id: typeof options == 'string' ? options : guid()
}, options || {});
opts.boxClass = [options.boxClass || '', 'glide_overlay'].join(' ');
$super(opts);
GlideOverlay.showMask();
this.getBoxElement().observe('click', function(event) {
event.stopPropagation();
CustomEvent.fire(GlideEvent.WINDOW_CLICKED, event, window);
});
this.closeOnEscape(this.options.closeOnEscape);
},
isModal: function(b) {
return this.options.isModal;
},
closeOnEscape: function(b) {
if (!b && this._escapeCloseHandler) {
$(document).stopObserving('keydown', this._escapeCloseHandler);
} else if (b && !this._escapeCloseHandler) {
this._escapeCloseHandler = function(event) {
if (event.keyCode === Event.KEY_ESC)
this.close();
}.bind(this);
$(document).observe('keydown', this._escapeCloseHandler);
}
},
close: function($super, options) {
if (this._isClosing === true)
return;
if (this._escapeCloseHandler) {
$(document).stopObserving('keydown', this._escapeCloseHandler);
this._escapeCloseHandler = null;
}
var opts = {
timeout: this.options.fadeOutTime,
closeMask: true
};
if (typeof options == 'number')
opts.timeout = options;
else
Object.extend(opts, options || {});
var mask = $('glide_expose_mask');
if (this.isModal() && mask && opts.closeMask === true) {
if (opts.timeout !== 0)
mask.fadeOut(opts.timeout, function() {
this.remove();
});
else
mask.remove();
}
$super(opts.timeout);
},
toString: function() { return 'GlideOverlay'; }
});
GlideOverlay.get = function(objIdOrElem) {
if (objIdOrElem)
return GlideBox.get(objIdOrElem);
for (var i in g_glideBoxes) {
var box = g_glideBoxes[i];
if (box.toString() == 'GlideOverlay')
return box;
}
}
GlideOverlay.close = function(objIdOrElem, options) {
if (objIdOrElem)
return GlideBox.close(objIdOrElem, options);
for (var i in g_glideBoxes) {
var box = g_glideBoxes[i];
if (box.toString() == 'GlideOverlay')
return box.close(options);
}
}
GlideOverlay.showMask = function() {
if ($('grayBackground'))
return;
var mask = $('glide_expose_mask');
if (!mask) {
mask = $(document.createElement('div'));
mask.id = 'glide_expose_mask';
mask.className = 'glide_mask';
document.body.appendChild(mask);
mask.observe('click', function(event) {
event.stopPropagation();
CustomEvent.fire(GlideEvent.WINDOW_CLICKED, event, window);
});
}
mask.show();
return mask;
}
GlideOverlay.hideMask = function(boolRemove) {
var mask = $('glide_expose_mask');
if (mask)
mask[boolRemove === true ? 'remove' : 'hide']();
}
;
/*! RESOURCE: /scripts/lib/jquery/jquery_clean.js */
(function() {
if (!window.jQuery)
return;
if (!window.$j_glide)
window.$j = jQuery.noConflict();
if (window.$j_glide && jQuery != window.$j_glide) {
if (window.$j_glide)
jQuery.noConflict(true);
window.$j = window.$j_glide;
}
})();
;
/*! RESOURCE: /scripts/lib/jquery/jquery-1.8.2.min.js */
/*! jQuery v1.8.2 jquery.com | jquery.org/license */
(function(a,b){function G(a){var b=F[a]={};return p.each(a.split(s),function(a,c){b[c]=!0}),b}function J(a,c,d){if(d===b&&a.nodeType===1){var e="data-"+c.replace(I,"-$1").toLowerCase();d=a.getAttribute(e);if(typeof d=="string"){try{d=d==="true"?!0:d==="false"?!1:d==="null"?null:+d+""===d?+d:H.test(d)?p.parseJSON(d):d}catch(f){}p.data(a,c,d)}else d=b}return d}function K(a){var b;for(b in a){if(b==="data"&&p.isEmptyObject(a[b]))continue;if(b!=="toJSON")return!1}return!0}function ba(){return!1}function bb(){return!0}function bh(a){return!a||!a.parentNode||a.parentNode.nodeType===11}function bi(a,b){do a=a[b];while(a&&a.nodeType!==1);return a}function bj(a,b,c){b=b||0;if(p.isFunction(b))return p.grep(a,function(a,d){var e=!!b.call(a,d,a);return e===c});if(b.nodeType)return p.grep(a,function(a,d){return a===b===c});if(typeof b=="string"){var d=p.grep(a,function(a){return a.nodeType===1});if(be.test(b))return p.filter(b,d,!c);b=p.filter(b,d)}return p.grep(a,function(a,d){return p.inArray(a,b)>=0===c})}function bk(a){var b=bl.split("|"),c=a.createDocumentFragment();if(c.createElement)while(b.length)c.createElement(b.pop());return c}function bC(a,b){return a.getElementsByTagName(b)[0]||a.appendChild(a.ownerDocument.createElement(b))}function bD(a,b){if(b.nodeType!==1||!p.hasData(a))return;var c,d,e,f=p._data(a),g=p._data(b,f),h=f.events;if(h){delete g.handle,g.events={};for(c in h)for(d=0,e=h[c].length;d<e;d++)p.event.add(b,c,h[c][d])}g.data&&(g.data=p.extend({},g.data))}function bE(a,b){var c;if(b.nodeType!==1)return;b.clearAttributes&&b.clearAttributes(),b.mergeAttributes&&b.mergeAttributes(a),c=b.nodeName.toLowerCase(),c==="object"?(b.parentNode&&(b.outerHTML=a.outerHTML),p.support.html5Clone&&a.innerHTML&&!p.trim(b.innerHTML)&&(b.innerHTML=a.innerHTML)):c==="input"&&bv.test(a.type)?(b.defaultChecked=b.checked=a.checked,b.value!==a.value&&(b.value=a.value)):c==="option"?b.selected=a.defaultSelected:c==="input"||c==="textarea"?b.defaultValue=a.defaultValue:c==="script"&&b.text!==a.text&&(b.text=a.text),b.removeAttribute(p.expando)}function bF(a){return typeof a.getElementsByTagName!="undefined"?a.getElementsByTagName("*"):typeof a.querySelectorAll!="undefined"?a.querySelectorAll("*"):[]}function bG(a){bv.test(a.type)&&(a.defaultChecked=a.checked)}function bY(a,b){if(b in a)return b;var c=b.charAt(0).toUpperCase()+b.slice(1),d=b,e=bW.length;while(e--){b=bW[e]+c;if(b in a)return b}return d}function bZ(a,b){return a=b||a,p.css(a,"display")==="none"||!p.contains(a.ownerDocument,a)}function b$(a,b){var c,d,e=[],f=0,g=a.length;for(;f<g;f++){c=a[f];if(!c.style)continue;e[f]=p._data(c,"olddisplay"),b?(!e[f]&&c.style.display==="none"&&(c.style.display=""),c.style.display===""&&bZ(c)&&(e[f]=p._data(c,"olddisplay",cc(c.nodeName)))):(d=bH(c,"display"),!e[f]&&d!=="none"&&p._data(c,"olddisplay",d))}for(f=0;f<g;f++){c=a[f];if(!c.style)continue;if(!b||c.style.display==="none"||c.style.display==="")c.style.display=b?e[f]||"":"none"}return a}function b_(a,b,c){var d=bP.exec(b);return d?Math.max(0,d[1]-(c||0))+(d[2]||"px"):b}function ca(a,b,c,d){var e=c===(d?"border":"content")?4:b==="width"?1:0,f=0;for(;e<4;e+=2)c==="margin"&&(f+=p.css(a,c+bV[e],!0)),d?(c==="content"&&(f-=parseFloat(bH(a,"padding"+bV[e]))||0),c!=="margin"&&(f-=parseFloat(bH(a,"border"+bV[e]+"Width"))||0)):(f+=parseFloat(bH(a,"padding"+bV[e]))||0,c!=="padding"&&(f+=parseFloat(bH(a,"border"+bV[e]+"Width"))||0));return f}function cb(a,b,c){var d=b==="width"?a.offsetWidth:a.offsetHeight,e=!0,f=p.support.boxSizing&&p.css(a,"boxSizing")==="border-box";if(d<=0||d==null){d=bH(a,b);if(d<0||d==null)d=a.style[b];if(bQ.test(d))return d;e=f&&(p.support.boxSizingReliable||d===a.style[b]),d=parseFloat(d)||0}return d+ca(a,b,c||(f?"border":"content"),e)+"px"}function cc(a){if(bS[a])return bS[a];var b=p("<"+a+">").appendTo(e.body),c=b.css("display");b.remove();if(c==="none"||c===""){bI=e.body.appendChild(bI||p.extend(e.createElement("iframe"),{frameBorder:0,width:0,height:0}));if(!bJ||!bI.createElement)bJ=(bI.contentWindow||bI.contentDocument).document,bJ.write("<!doctype html><html><body>"),bJ.close();b=bJ.body.appendChild(bJ.createElement(a)),c=bH(b,"display"),e.body.removeChild(bI)}return bS[a]=c,c}function ci(a,b,c,d){var e;if(p.isArray(b))p.each(b,function(b,e){c||ce.test(a)?d(a,e):ci(a+"["+(typeof e=="object"?b:"")+"]",e,c,d)});else if(!c&&p.type(b)==="object")for(e in b)ci(a+"["+e+"]",b[e],c,d);else d(a,b)}function cz(a){return function(b,c){typeof b!="string"&&(c=b,b="*");var d,e,f,g=b.toLowerCase().split(s),h=0,i=g.length;if(p.isFunction(c))for(;h<i;h++)d=g[h],f=/^\+/.test(d),f&&(d=d.substr(1)||"*"),e=a[d]=a[d]||[],e[f?"unshift":"push"](c)}}function cA(a,c,d,e,f,g){f=f||c.dataTypes[0],g=g||{},g[f]=!0;var h,i=a[f],j=0,k=i?i.length:0,l=a===cv;for(;j<k&&(l||!h);j++)h=i[j](c,d,e),typeof h=="string"&&(!l||g[h]?h=b:(c.dataTypes.unshift(h),h=cA(a,c,d,e,h,g)));return(l||!h)&&!g["*"]&&(h=cA(a,c,d,e,"*",g)),h}function cB(a,c){var d,e,f=p.ajaxSettings.flatOptions||{};for(d in c)c[d]!==b&&((f[d]?a:e||(e={}))[d]=c[d]);e&&p.extend(!0,a,e)}function cC(a,c,d){var e,f,g,h,i=a.contents,j=a.dataTypes,k=a.responseFields;for(f in k)f in d&&(c[k[f]]=d[f]);while(j[0]==="*")j.shift(),e===b&&(e=a.mimeType||c.getResponseHeader("content-type"));if(e)for(f in i)if(i[f]&&i[f].test(e)){j.unshift(f);break}if(j[0]in d)g=j[0];else{for(f in d){if(!j[0]||a.converters[f+" "+j[0]]){g=f;break}h||(h=f)}g=g||h}if(g)return g!==j[0]&&j.unshift(g),d[g]}function cD(a,b){var c,d,e,f,g=a.dataTypes.slice(),h=g[0],i={},j=0;a.dataFilter&&(b=a.dataFilter(b,a.dataType));if(g[1])for(c in a.converters)i[c.toLowerCase()]=a.converters[c];for(;e=g[++j];)if(e!=="*"){if(h!=="*"&&h!==e){c=i[h+" "+e]||i["* "+e];if(!c)for(d in i){f=d.split(" ");if(f[1]===e){c=i[h+" "+f[0]]||i["* "+f[0]];if(c){c===!0?c=i[d]:i[d]!==!0&&(e=f[0],g.splice(j--,0,e));break}}}if(c!==!0)if(c&&a["throws"])b=c(b);else try{b=c(b)}catch(k){return{state:"parsererror",error:c?k:"No conversion from "+h+" to "+e}}}h=e}return{state:"success",data:b}}function cL(){try{return new a.XMLHttpRequest}catch(b){}}function cM(){try{return new a.ActiveXObject("Microsoft.XMLHTTP")}catch(b){}}function cU(){return setTimeout(function(){cN=b},0),cN=p.now()}function cV(a,b){p.each(b,function(b,c){var d=(cT[b]||[]).concat(cT["*"]),e=0,f=d.length;for(;e<f;e++)if(d[e].call(a,b,c))return})}function cW(a,b,c){var d,e=0,f=0,g=cS.length,h=p.Deferred().always(function(){delete i.elem}),i=function(){var b=cN||cU(),c=Math.max(0,j.startTime+j.duration-b),d=1-(c/j.duration||0),e=0,f=j.tweens.length;for(;e<f;e++)j.tweens[e].run(d);return h.notifyWith(a,[j,d,c]),d<1&&f?c:(h.resolveWith(a,[j]),!1)},j=h.promise({elem:a,props:p.extend({},b),opts:p.extend(!0,{specialEasing:{}},c),originalProperties:b,originalOptions:c,startTime:cN||cU(),duration:c.duration,tweens:[],createTween:function(b,c,d){var e=p.Tween(a,j.opts,b,c,j.opts.specialEasing[b]||j.opts.easing);return j.tweens.push(e),e},stop:function(b){var c=0,d=b?j.tweens.length:0;for(;c<d;c++)j.tweens[c].run(1);return b?h.resolveWith(a,[j,b]):h.rejectWith(a,[j,b]),this}}),k=j.props;cX(k,j.opts.specialEasing);for(;e<g;e++){d=cS[e].call(j,a,k,j.opts);if(d)return d}return cV(j,k),p.isFunction(j.opts.start)&&j.opts.start.call(a,j),p.fx.timer(p.extend(i,{anim:j,queue:j.opts.queue,elem:a})),j.progress(j.opts.progress).done(j.opts.done,j.opts.complete).fail(j.opts.fail).always(j.opts.always)}function cX(a,b){var c,d,e,f,g;for(c in a){d=p.camelCase(c),e=b[d],f=a[c],p.isArray(f)&&(e=f[1],f=a[c]=f[0]),c!==d&&(a[d]=f,delete a[c]),g=p.cssHooks[d];if(g&&"expand"in g){f=g.expand(f),delete a[d];for(c in f)c in a||(a[c]=f[c],b[c]=e)}else b[d]=e}}function cY(a,b,c){var d,e,f,g,h,i,j,k,l=this,m=a.style,n={},o=[],q=a.nodeType&&bZ(a);c.queue||(j=p._queueHooks(a,"fx"),j.unqueued==null&&(j.unqueued=0,k=j.empty.fire,j.empty.fire=function(){j.unqueued||k()}),j.unqueued++,l.always(function(){l.always(function(){j.unqueued--,p.queue(a,"fx").length||j.empty.fire()})})),a.nodeType===1&&("height"in b||"width"in b)&&(c.overflow=[m.overflow,m.overflowX,m.overflowY],p.css(a,"display")==="inline"&&p.css(a,"float")==="none"&&(!p.support.inlineBlockNeedsLayout||cc(a.nodeName)==="inline"?m.display="inline-block":m.zoom=1)),c.overflow&&(m.overflow="hidden",p.support.shrinkWrapBlocks||l.done(function(){m.overflow=c.overflow[0],m.overflowX=c.overflow[1],m.overflowY=c.overflow[2]}));for(d in b){f=b[d];if(cP.exec(f)){delete b[d];if(f===(q?"hide":"show"))continue;o.push(d)}}g=o.length;if(g){h=p._data(a,"fxshow")||p._data(a,"fxshow",{}),q?p(a).show():l.done(function(){p(a).hide()}),l.done(function(){var b;p.removeData(a,"fxshow",!0);for(b in n)p.style(a,b,n[b])});for(d=0;d<g;d++)e=o[d],i=l.createTween(e,q?h[e]:0),n[e]=h[e]||p.style(a,e),e in h||(h[e]=i.start,q&&(i.end=i.start,i.start=e==="width"||e==="height"?1:0))}}function cZ(a,b,c,d,e){return new cZ.prototype.init(a,b,c,d,e)}function c$(a,b){var c,d={height:a},e=0;b=b?1:0;for(;e<4;e+=2-b)c=bV[e],d["margin"+c]=d["padding"+c]=a;return b&&(d.opacity=d.width=a),d}function da(a){return p.isWindow(a)?a:a.nodeType===9?a.defaultView||a.parentWindow:!1}var c,d,e=a.document,f=a.location,g=a.navigator,h=a.jQuery,i=a.$,j=Array.prototype.push,k=Array.prototype.slice,l=Array.prototype.indexOf,m=Object.prototype.toString,n=Object.prototype.hasOwnProperty,o=String.prototype.trim,p=function(a,b){return new p.fn.init(a,b,c)},q=/[\-+]?(?:\d*\.|)\d+(?:[eE][\-+]?\d+|)/.source,r=/\S/,s=/\s+/,t=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,u=/^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,v=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,w=/^[\],:{}\s]*$/,x=/(?:^|:|,)(?:\s*\[)+/g,y=/\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,z=/"[^"\\\r\n]*"|true|false|null|-?(?:\d\d*\.|)\d+(?:[eE][\-+]?\d+|)/g,A=/^-ms-/,B=/-([\da-z])/gi,C=function(a,b){return(b+"").toUpperCase()},D=function(){e.addEventListener?(e.removeEventListener("DOMContentLoaded",D,!1),p.ready()):e.readyState==="complete"&&(e.detachEvent("onreadystatechange",D),p.ready())},E={};p.fn=p.prototype={constructor:p,init:function(a,c,d){var f,g,h,i;if(!a)return this;if(a.nodeType)return this.context=this[0]=a,this.length=1,this;if(typeof a=="string"){a.charAt(0)==="<"&&a.charAt(a.length-1)===">"&&a.length>=3?f=[null,a,null]:f=u.exec(a);if(f&&(f[1]||!c)){if(f[1])return c=c instanceof p?c[0]:c,i=c&&c.nodeType?c.ownerDocument||c:e,a=p.parseHTML(f[1],i,!0),v.test(f[1])&&p.isPlainObject(c)&&this.attr.call(a,c,!0),p.merge(this,a);g=e.getElementById(f[2]);if(g&&g.parentNode){if(g.id!==f[2])return d.find(a);this.length=1,this[0]=g}return this.context=e,this.selector=a,this}return!c||c.jquery?(c||d).find(a):this.constructor(c).find(a)}return p.isFunction(a)?d.ready(a):(a.selector!==b&&(this.selector=a.selector,this.context=a.context),p.makeArray(a,this))},selector:"",jquery:"1.8.2",length:0,size:function(){return this.length},toArray:function(){return k.call(this)},get:function(a){return a==null?this.toArray():a<0?this[this.length+a]:this[a]},pushStack:function(a,b,c){var d=p.merge(this.constructor(),a);return d.prevObject=this,d.context=this.context,b==="find"?d.selector=this.selector+(this.selector?" ":"")+c:b&&(d.selector=this.selector+"."+b+"("+c+")"),d},each:function(a,b){return p.each(this,a,b)},ready:function(a){return p.ready.promise().done(a),this},eq:function(a){return a=+a,a===-1?this.slice(a):this.slice(a,a+1)},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},slice:function(){return this.pushStack(k.apply(this,arguments),"slice",k.call(arguments).join(","))},map:function(a){return this.pushStack(p.map(this,function(b,c){return a.call(b,c,b)}))},end:function(){return this.prevObject||this.constructor(null)},push:j,sort:[].sort,splice:[].splice},p.fn.init.prototype=p.fn,p.extend=p.fn.extend=function(){var a,c,d,e,f,g,h=arguments[0]||{},i=1,j=arguments.length,k=!1;typeof h=="boolean"&&(k=h,h=arguments[1]||{},i=2),typeof h!="object"&&!p.isFunction(h)&&(h={}),j===i&&(h=this,--i);for(;i<j;i++)if((a=arguments[i])!=null)for(c in a){d=h[c],e=a[c];if(h===e)continue;k&&e&&(p.isPlainObject(e)||(f=p.isArray(e)))?(f?(f=!1,g=d&&p.isArray(d)?d:[]):g=d&&p.isPlainObject(d)?d:{},h[c]=p.extend(k,g,e)):e!==b&&(h[c]=e)}return h},p.extend({noConflict:function(b){return a.$===p&&(a.$=i),b&&a.jQuery===p&&(a.jQuery=h),p},isReady:!1,readyWait:1,holdReady:function(a){a?p.readyWait++:p.ready(!0)},ready:function(a){if(a===!0?--p.readyWait:p.isReady)return;if(!e.body)return setTimeout(p.ready,1);p.isReady=!0;if(a!==!0&&--p.readyWait>0)return;d.resolveWith(e,[p]),p.fn.trigger&&p(e).trigger("ready").off("ready")},isFunction:function(a){return p.type(a)==="function"},isArray:Array.isArray||function(a){return p.type(a)==="array"},isWindow:function(a){return a!=null&&a==a.window},isNumeric:function(a){return!isNaN(parseFloat(a))&&isFinite(a)},type:function(a){return a==null?String(a):E[m.call(a)]||"object"},isPlainObject:function(a){if(!a||p.type(a)!=="object"||a.nodeType||p.isWindow(a))return!1;try{if(a.constructor&&!n.call(a,"constructor")&&!n.call(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}var d;for(d in a);return d===b||n.call(a,d)},isEmptyObject:function(a){var b;for(b in a)return!1;return!0},error:function(a){throw new Error(a)},parseHTML:function(a,b,c){var d;return!a||typeof a!="string"?null:(typeof b=="boolean"&&(c=b,b=0),b=b||e,(d=v.exec(a))?[b.createElement(d[1])]:(d=p.buildFragment([a],b,c?null:[]),p.merge([],(d.cacheable?p.clone(d.fragment):d.fragment).childNodes)))},parseJSON:function(b){if(!b||typeof b!="string")return null;b=p.trim(b);if(a.JSON&&a.JSON.parse)return a.JSON.parse(b);if(w.test(b.replace(y,"@").replace(z,"]").replace(x,"")))return(new Function("return "+b))();p.error("Invalid JSON: "+b)},parseXML:function(c){var d,e;if(!c||typeof c!="string")return null;try{a.DOMParser?(e=new DOMParser,d=e.parseFromString(c,"text/xml")):(d=new ActiveXObject("Microsoft.XMLDOM"),d.async="false",d.loadXML(c))}catch(f){d=b}return(!d||!d.documentElement||d.getElementsByTagName("parsererror").length)&&p.error("Invalid XML: "+c),d},noop:function(){},globalEval:function(b){b&&r.test(b)&&(a.execScript||function(b){a.eval.call(a,b)})(b)},camelCase:function(a){return a.replace(A,"ms-").replace(B,C)},nodeName:function(a,b){return a.nodeName&&a.nodeName.toLowerCase()===b.toLowerCase()},each:function(a,c,d){var e,f=0,g=a.length,h=g===b||p.isFunction(a);if(d){if(h){for(e in a)if(c.apply(a[e],d)===!1)break}else for(;f<g;)if(c.apply(a[f++],d)===!1)break}else if(h){for(e in a)if(c.call(a[e],e,a[e])===!1)break}else for(;f<g;)if(c.call(a[f],f,a[f++])===!1)break;return a},trim:o&&!o.call("﻿ ")?function(a){return a==null?"":o.call(a)}:function(a){return a==null?"":(a+"").replace(t,"")},makeArray:function(a,b){var c,d=b||[];return a!=null&&(c=p.type(a),a.length==null||c==="string"||c==="function"||c==="regexp"||p.isWindow(a)?j.call(d,a):p.merge(d,a)),d},inArray:function(a,b,c){var d;if(b){if(l)return l.call(b,a,c);d=b.length,c=c?c<0?Math.max(0,d+c):c:0;for(;c<d;c++)if(c in b&&b[c]===a)return c}return-1},merge:function(a,c){var d=c.length,e=a.length,f=0;if(typeof d=="number")for(;f<d;f++)a[e++]=c[f];else while(c[f]!==b)a[e++]=c[f++];return a.length=e,a},grep:function(a,b,c){var d,e=[],f=0,g=a.length;c=!!c;for(;f<g;f++)d=!!b(a[f],f),c!==d&&e.push(a[f]);return e},map:function(a,c,d){var e,f,g=[],h=0,i=a.length,j=a instanceof p||i!==b&&typeof i=="number"&&(i>0&&a[0]&&a[i-1]||i===0||p.isArray(a));if(j)for(;h<i;h++)e=c(a[h],h,d),e!=null&&(g[g.length]=e);else for(f in a)e=c(a[f],f,d),e!=null&&(g[g.length]=e);return g.concat.apply([],g)},guid:1,proxy:function(a,c){var d,e,f;return typeof c=="string"&&(d=a[c],c=a,a=d),p.isFunction(a)?(e=k.call(arguments,2),f=function(){return a.apply(c,e.concat(k.call(arguments)))},f.guid=a.guid=a.guid||p.guid++,f):b},access:function(a,c,d,e,f,g,h){var i,j=d==null,k=0,l=a.length;if(d&&typeof d=="object"){for(k in d)p.access(a,c,k,d[k],1,g,e);f=1}else if(e!==b){i=h===b&&p.isFunction(e),j&&(i?(i=c,c=function(a,b,c){return i.call(p(a),c)}):(c.call(a,e),c=null));if(c)for(;k<l;k++)c(a[k],d,i?e.call(a[k],k,c(a[k],d)):e,h);f=1}return f?a:j?c.call(a):l?c(a[0],d):g},now:function(){return(new Date).getTime()}}),p.ready.promise=function(b){if(!d){d=p.Deferred();if(e.readyState==="complete")setTimeout(p.ready,1);else if(e.addEventListener)e.addEventListener("DOMContentLoaded",D,!1),a.addEventListener("load",p.ready,!1);else{e.attachEvent("onreadystatechange",D),a.attachEvent("onload",p.ready);var c=!1;try{c=a.frameElement==null&&e.documentElement}catch(f){}c&&c.doScroll&&function g(){if(!p.isReady){try{c.doScroll("left")}catch(a){return setTimeout(g,50)}p.ready()}}()}}return d.promise(b)},p.each("Boolean Number String Function Array Date RegExp Object".split(" "),function(a,b){E["[object "+b+"]"]=b.toLowerCase()}),c=p(e);var F={};p.Callbacks=function(a){a=typeof a=="string"?F[a]||G(a):p.extend({},a);var c,d,e,f,g,h,i=[],j=!a.once&&[],k=function(b){c=a.memory&&b,d=!0,h=f||0,f=0,g=i.length,e=!0;for(;i&&h<g;h++)if(i[h].apply(b[0],b[1])===!1&&a.stopOnFalse){c=!1;break}e=!1,i&&(j?j.length&&k(j.shift()):c?i=[]:l.disable())},l={add:function(){if(i){var b=i.length;(function d(b){p.each(b,function(b,c){var e=p.type(c);e==="function"&&(!a.unique||!l.has(c))?i.push(c):c&&c.length&&e!=="string"&&d(c)})})(arguments),e?g=i.length:c&&(f=b,k(c))}return this},remove:function(){return i&&p.each(arguments,function(a,b){var c;while((c=p.inArray(b,i,c))>-1)i.splice(c,1),e&&(c<=g&&g--,c<=h&&h--)}),this},has:function(a){return p.inArray(a,i)>-1},empty:function(){return i=[],this},disable:function(){return i=j=c=b,this},disabled:function(){return!i},lock:function(){return j=b,c||l.disable(),this},locked:function(){return!j},fireWith:function(a,b){return b=b||[],b=[a,b.slice?b.slice():b],i&&(!d||j)&&(e?j.push(b):k(b)),this},fire:function(){return l.fireWith(this,arguments),this},fired:function(){return!!d}};return l},p.extend({Deferred:function(a){var b=[["resolve","done",p.Callbacks("once memory"),"resolved"],["reject","fail",p.Callbacks("once memory"),"rejected"],["notify","progress",p.Callbacks("memory")]],c="pending",d={state:function(){return c},always:function(){return e.done(arguments).fail(arguments),this},then:function(){var a=arguments;return p.Deferred(function(c){p.each(b,function(b,d){var f=d[0],g=a[b];e[d[1]](p.isFunction(g)?function(){var a=g.apply(this,arguments);a&&p.isFunction(a.promise)?a.promise().done(c.resolve).fail(c.reject).progress(c.notify):c[f+"With"](this===e?c:this,[a])}:c[f])}),a=null}).promise()},promise:function(a){return a!=null?p.extend(a,d):d}},e={};return d.pipe=d.then,p.each(b,function(a,f){var g=f[2],h=f[3];d[f[1]]=g.add,h&&g.add(function(){c=h},b[a^1][2].disable,b[2][2].lock),e[f[0]]=g.fire,e[f[0]+"With"]=g.fireWith}),d.promise(e),a&&a.call(e,e),e},when:function(a){var b=0,c=k.call(arguments),d=c.length,e=d!==1||a&&p.isFunction(a.promise)?d:0,f=e===1?a:p.Deferred(),g=function(a,b,c){return function(d){b[a]=this,c[a]=arguments.length>1?k.call(arguments):d,c===h?f.notifyWith(b,c):--e||f.resolveWith(b,c)}},h,i,j;if(d>1){h=new Array(d),i=new Array(d),j=new Array(d);for(;b<d;b++)c[b]&&p.isFunction(c[b].promise)?c[b].promise().done(g(b,j,c)).fail(f.reject).progress(g(b,i,h)):--e}return e||f.resolveWith(j,c),f.promise()}}),p.support=function(){var b,c,d,f,g,h,i,j,k,l,m,n=e.createElement("div");n.setAttribute("className","t"),n.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",c=n.getElementsByTagName("*"),d=n.getElementsByTagName("a")[0],d.style.cssText="top:1px;float:left;opacity:.5";if(!c||!c.length)return{};f=e.createElement("select"),g=f.appendChild(e.createElement("option")),h=n.getElementsByTagName("input")[0],b={leadingWhitespace:n.firstChild.nodeType===3,tbody:!n.getElementsByTagName("tbody").length,htmlSerialize:!!n.getElementsByTagName("link").length,style:/top/.test(d.getAttribute("style")),hrefNormalized:d.getAttribute("href")==="/a",opacity:/^0.5/.test(d.style.opacity),cssFloat:!!d.style.cssFloat,checkOn:h.value==="on",optSelected:g.selected,getSetAttribute:n.className!=="t",enctype:!!e.createElement("form").enctype,html5Clone:e.createElement("nav").cloneNode(!0).outerHTML!=="<:nav></:nav>",boxModel:e.compatMode==="CSS1Compat",submitBubbles:!0,changeBubbles:!0,focusinBubbles:!1,deleteExpando:!0,noCloneEvent:!0,inlineBlockNeedsLayout:!1,shrinkWrapBlocks:!1,reliableMarginRight:!0,boxSizingReliable:!0,pixelPosition:!1},h.checked=!0,b.noCloneChecked=h.cloneNode(!0).checked,f.disabled=!0,b.optDisabled=!g.disabled;try{delete n.test}catch(o){b.deleteExpando=!1}!n.addEventListener&&n.attachEvent&&n.fireEvent&&(n.attachEvent("onclick",m=function(){b.noCloneEvent=!1}),n.cloneNode(!0).fireEvent("onclick"),n.detachEvent("onclick",m)),h=e.createElement("input"),h.value="t",h.setAttribute("type","radio"),b.radioValue=h.value==="t",h.setAttribute("checked","checked"),h.setAttribute("name","t"),n.appendChild(h),i=e.createDocumentFragment(),i.appendChild(n.lastChild),b.checkClone=i.cloneNode(!0).cloneNode(!0).lastChild.checked,b.appendChecked=h.checked,i.removeChild(h),i.appendChild(n);if(n.attachEvent)for(k in{submit:!0,change:!0,focusin:!0})j="on"+k,l=j in n,l||(n.setAttribute(j,"return;"),l=typeof n[j]=="function"),b[k+"Bubbles"]=l;return p(function(){var c,d,f,g,h="padding:0;margin:0;border:0;display:block;overflow:hidden;",i=e.getElementsByTagName("body")[0];if(!i)return;c=e.createElement("div"),c.style.cssText="visibility:hidden;border:0;width:0;height:0;position:static;top:0;margin-top:1px",i.insertBefore(c,i.firstChild),d=e.createElement("div"),c.appendChild(d),d.innerHTML="<table><tr><td></td><td>t</td></tr></table>",f=d.getElementsByTagName("td"),f[0].style.cssText="padding:0;margin:0;border:0;display:none",l=f[0].offsetHeight===0,f[0].style.display="",f[1].style.display="none",b.reliableHiddenOffsets=l&&f[0].offsetHeight===0,d.innerHTML="",d.style.cssText="box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;",b.boxSizing=d.offsetWidth===4,b.doesNotIncludeMarginInBodyOffset=i.offsetTop!==1,a.getComputedStyle&&(b.pixelPosition=(a.getComputedStyle(d,null)||{}).top!=="1%",b.boxSizingReliable=(a.getComputedStyle(d,null)||{width:"4px"}).width==="4px",g=e.createElement("div"),g.style.cssText=d.style.cssText=h,g.style.marginRight=g.style.width="0",d.style.width="1px",d.appendChild(g),b.reliableMarginRight=!parseFloat((a.getComputedStyle(g,null)||{}).marginRight)),typeof d.style.zoom!="undefined"&&(d.innerHTML="",d.style.cssText=h+"width:1px;padding:1px;display:inline;zoom:1",b.inlineBlockNeedsLayout=d.offsetWidth===3,d.style.display="block",d.style.overflow="visible",d.innerHTML="<div></div>",d.firstChild.style.width="5px",b.shrinkWrapBlocks=d.offsetWidth!==3,c.style.zoom=1),i.removeChild(c),c=d=f=g=null}),i.removeChild(n),c=d=f=g=h=i=n=null,b}();var H=/(?:\{[\s\S]*\}|\[[\s\S]*\])$/,I=/([A-Z])/g;p.extend({cache:{},deletedIds:[],uuid:0,expando:"jQuery"+(p.fn.jquery+Math.random()).replace(/\D/g,""),noData:{embed:!0,object:"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",applet:!0},hasData:function(a){return a=a.nodeType?p.cache[a[p.expando]]:a[p.expando],!!a&&!K(a)},data:function(a,c,d,e){if(!p.acceptData(a))return;var f,g,h=p.expando,i=typeof c=="string",j=a.nodeType,k=j?p.cache:a,l=j?a[h]:a[h]&&h;if((!l||!k[l]||!e&&!k[l].data)&&i&&d===b)return;l||(j?a[h]=l=p.deletedIds.pop()||p.guid++:l=h),k[l]||(k[l]={},j||(k[l].toJSON=p.noop));if(typeof c=="object"||typeof c=="function")e?k[l]=p.extend(k[l],c):k[l].data=p.extend(k[l].data,c);return f=k[l],e||(f.data||(f.data={}),f=f.data),d!==b&&(f[p.camelCase(c)]=d),i?(g=f[c],g==null&&(g=f[p.camelCase(c)])):g=f,g},removeData:function(a,b,c){if(!p.acceptData(a))return;var d,e,f,g=a.nodeType,h=g?p.cache:a,i=g?a[p.expando]:p.expando;if(!h[i])return;if(b){d=c?h[i]:h[i].data;if(d){p.isArray(b)||(b in d?b=[b]:(b=p.camelCase(b),b in d?b=[b]:b=b.split(" ")));for(e=0,f=b.length;e<f;e++)delete d[b[e]];if(!(c?K:p.isEmptyObject)(d))return}}if(!c){delete h[i].data;if(!K(h[i]))return}g?p.cleanData([a],!0):p.support.deleteExpando||h!=h.window?delete h[i]:h[i]=null},_data:function(a,b,c){return p.data(a,b,c,!0)},acceptData:function(a){var b=a.nodeName&&p.noData[a.nodeName.toLowerCase()];return!b||b!==!0&&a.getAttribute("classid")===b}}),p.fn.extend({data:function(a,c){var d,e,f,g,h,i=this[0],j=0,k=null;if(a===b){if(this.length){k=p.data(i);if(i.nodeType===1&&!p._data(i,"parsedAttrs")){f=i.attributes;for(h=f.length;j<h;j++)g=f[j].name,g.indexOf("data-")||(g=p.camelCase(g.substring(5)),J(i,g,k[g]));p._data(i,"parsedAttrs",!0)}}return k}return typeof a=="object"?this.each(function(){p.data(this,a)}):(d=a.split(".",2),d[1]=d[1]?"."+d[1]:"",e=d[1]+"!",p.access(this,function(c){if(c===b)return k=this.triggerHandler("getData"+e,[d[0]]),k===b&&i&&(k=p.data(i,a),k=J(i,a,k)),k===b&&d[1]?this.data(d[0]):k;d[1]=c,this.each(function(){var b=p(this);b.triggerHandler("setData"+e,d),p.data(this,a,c),b.triggerHandler("changeData"+e,d)})},null,c,arguments.length>1,null,!1))},removeData:function(a){return this.each(function(){p.removeData(this,a)})}}),p.extend({queue:function(a,b,c){var d;if(a)return b=(b||"fx")+"queue",d=p._data(a,b),c&&(!d||p.isArray(c)?d=p._data(a,b,p.makeArray(c)):d.push(c)),d||[]},dequeue:function(a,b){b=b||"fx";var c=p.queue(a,b),d=c.length,e=c.shift(),f=p._queueHooks(a,b),g=function(){p.dequeue(a,b)};e==="inprogress"&&(e=c.shift(),d--),e&&(b==="fx"&&c.unshift("inprogress"),delete f.stop,e.call(a,g,f)),!d&&f&&f.empty.fire()},_queueHooks:function(a,b){var c=b+"queueHooks";return p._data(a,c)||p._data(a,c,{empty:p.Callbacks("once memory").add(function(){p.removeData(a,b+"queue",!0),p.removeData(a,c,!0)})})}}),p.fn.extend({queue:function(a,c){var d=2;return typeof a!="string"&&(c=a,a="fx",d--),arguments.length<d?p.queue(this[0],a):c===b?this:this.each(function(){var b=p.queue(this,a,c);p._queueHooks(this,a),a==="fx"&&b[0]!=="inprogress"&&p.dequeue(this,a)})},dequeue:function(a){return this.each(function(){p.dequeue(this,a)})},delay:function(a,b){return a=p.fx?p.fx.speeds[a]||a:a,b=b||"fx",this.queue(b,function(b,c){var d=setTimeout(b,a);c.stop=function(){clearTimeout(d)}})},clearQueue:function(a){return this.queue(a||"fx",[])},promise:function(a,c){var d,e=1,f=p.Deferred(),g=this,h=this.length,i=function(){--e||f.resolveWith(g,[g])};typeof a!="string"&&(c=a,a=b),a=a||"fx";while(h--)d=p._data(g[h],a+"queueHooks"),d&&d.empty&&(e++,d.empty.add(i));return i(),f.promise(c)}});var L,M,N,O=/[\t\r\n]/g,P=/\r/g,Q=/^(?:button|input)$/i,R=/^(?:button|input|object|select|textarea)$/i,S=/^a(?:rea|)$/i,T=/^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,U=p.support.getSetAttribute;p.fn.extend({attr:function(a,b){return p.access(this,p.attr,a,b,arguments.length>1)},removeAttr:function(a){return this.each(function(){p.removeAttr(this,a)})},prop:function(a,b){return p.access(this,p.prop,a,b,arguments.length>1)},removeProp:function(a){return a=p.propFix[a]||a,this.each(function(){try{this[a]=b,delete this[a]}catch(c){}})},addClass:function(a){var b,c,d,e,f,g,h;if(p.isFunction(a))return this.each(function(b){p(this).addClass(a.call(this,b,this.className))});if(a&&typeof a=="string"){b=a.split(s);for(c=0,d=this.length;c<d;c++){e=this[c];if(e.nodeType===1)if(!e.className&&b.length===1)e.className=a;else{f=" "+e.className+" ";for(g=0,h=b.length;g<h;g++)f.indexOf(" "+b[g]+" ")<0&&(f+=b[g]+" ");e.className=p.trim(f)}}}return this},removeClass:function(a){var c,d,e,f,g,h,i;if(p.isFunction(a))return this.each(function(b){p(this).removeClass(a.call(this,b,this.className))});if(a&&typeof a=="string"||a===b){c=(a||"").split(s);for(h=0,i=this.length;h<i;h++){e=this[h];if(e.nodeType===1&&e.className){d=(" "+e.className+" ").replace(O," ");for(f=0,g=c.length;f<g;f++)while(d.indexOf(" "+c[f]+" ")>=0)d=d.replace(" "+c[f]+" "," ");e.className=a?p.trim(d):""}}}return this},toggleClass:function(a,b){var c=typeof a,d=typeof b=="boolean";return p.isFunction(a)?this.each(function(c){p(this).toggleClass(a.call(this,c,this.className,b),b)}):this.each(function(){if(c==="string"){var e,f=0,g=p(this),h=b,i=a.split(s);while(e=i[f++])h=d?h:!g.hasClass(e),g[h?"addClass":"removeClass"](e)}else if(c==="undefined"||c==="boolean")this.className&&p._data(this,"__className__",this.className),this.className=this.className||a===!1?"":p._data(this,"__className__")||""})},hasClass:function(a){var b=" "+a+" ",c=0,d=this.length;for(;c<d;c++)if(this[c].nodeType===1&&(" "+this[c].className+" ").replace(O," ").indexOf(b)>=0)return!0;return!1},val:function(a){var c,d,e,f=this[0];if(!arguments.length){if(f)return c=p.valHooks[f.type]||p.valHooks[f.nodeName.toLowerCase()],c&&"get"in c&&(d=c.get(f,"value"))!==b?d:(d=f.value,typeof d=="string"?d.replace(P,""):d==null?"":d);return}return e=p.isFunction(a),this.each(function(d){var f,g=p(this);if(this.nodeType!==1)return;e?f=a.call(this,d,g.val()):f=a,f==null?f="":typeof f=="number"?f+="":p.isArray(f)&&(f=p.map(f,function(a){return a==null?"":a+""})),c=p.valHooks[this.type]||p.valHooks[this.nodeName.toLowerCase()];if(!c||!("set"in c)||c.set(this,f,"value")===b)this.value=f})}}),p.extend({valHooks:{option:{get:function(a){var b=a.attributes.value;return!b||b.specified?a.value:a.text}},select:{get:function(a){var b,c,d,e,f=a.selectedIndex,g=[],h=a.options,i=a.type==="select-one";if(f<0)return null;c=i?f:0,d=i?f+1:h.length;for(;c<d;c++){e=h[c];if(e.selected&&(p.support.optDisabled?!e.disabled:e.getAttribute("disabled")===null)&&(!e.parentNode.disabled||!p.nodeName(e.parentNode,"optgroup"))){b=p(e).val();if(i)return b;g.push(b)}}return i&&!g.length&&h.length?p(h[f]).val():g},set:function(a,b){var c=p.makeArray(b);return p(a).find("option").each(function(){this.selected=p.inArray(p(this).val(),c)>=0}),c.length||(a.selectedIndex=-1),c}}},attrFn:{},attr:function(a,c,d,e){var f,g,h,i=a.nodeType;if(!a||i===3||i===8||i===2)return;if(e&&p.isFunction(p.fn[c]))return p(a)[c](d);if(typeof a.getAttribute=="undefined")return p.prop(a,c,d);h=i!==1||!p.isXMLDoc(a),h&&(c=c.toLowerCase(),g=p.attrHooks[c]||(T.test(c)?M:L));if(d!==b){if(d===null){p.removeAttr(a,c);return}return g&&"set"in g&&h&&(f=g.set(a,d,c))!==b?f:(a.setAttribute(c,d+""),d)}return g&&"get"in g&&h&&(f=g.get(a,c))!==null?f:(f=a.getAttribute(c),f===null?b:f)},removeAttr:function(a,b){var c,d,e,f,g=0;if(b&&a.nodeType===1){d=b.split(s);for(;g<d.length;g++)e=d[g],e&&(c=p.propFix[e]||e,f=T.test(e),f||p.attr(a,e,""),a.removeAttribute(U?e:c),f&&c in a&&(a[c]=!1))}},attrHooks:{type:{set:function(a,b){if(Q.test(a.nodeName)&&a.parentNode)p.error("type property can't be changed");else if(!p.support.radioValue&&b==="radio"&&p.nodeName(a,"input")){var c=a.value;return a.setAttribute("type",b),c&&(a.value=c),b}}},value:{get:function(a,b){return L&&p.nodeName(a,"button")?L.get(a,b):b in a?a.value:null},set:function(a,b,c){if(L&&p.nodeName(a,"button"))return L.set(a,b,c);a.value=b}}},propFix:{tabindex:"tabIndex",readonly:"readOnly","for":"htmlFor","class":"className",maxlength:"maxLength",cellspacing:"cellSpacing",cellpadding:"cellPadding",rowspan:"rowSpan",colspan:"colSpan",usemap:"useMap",frameborder:"frameBorder",contenteditable:"contentEditable"},prop:function(a,c,d){var e,f,g,h=a.nodeType;if(!a||h===3||h===8||h===2)return;return g=h!==1||!p.isXMLDoc(a),g&&(c=p.propFix[c]||c,f=p.propHooks[c]),d!==b?f&&"set"in f&&(e=f.set(a,d,c))!==b?e:a[c]=d:f&&"get"in f&&(e=f.get(a,c))!==null?e:a[c]},propHooks:{tabIndex:{get:function(a){var c=a.getAttributeNode("tabindex");return c&&c.specified?parseInt(c.value,10):R.test(a.nodeName)||S.test(a.nodeName)&&a.href?0:b}}}}),M={get:function(a,c){var d,e=p.prop(a,c);return e===!0||typeof e!="boolean"&&(d=a.getAttributeNode(c))&&d.nodeValue!==!1?c.toLowerCase():b},set:function(a,b,c){var d;return b===!1?p.removeAttr(a,c):(d=p.propFix[c]||c,d in a&&(a[d]=!0),a.setAttribute(c,c.toLowerCase())),c}},U||(N={name:!0,id:!0,coords:!0},L=p.valHooks.button={get:function(a,c){var d;return d=a.getAttributeNode(c),d&&(N[c]?d.value!=="":d.specified)?d.value:b},set:function(a,b,c){var d=a.getAttributeNode(c);return d||(d=e.createAttribute(c),a.setAttributeNode(d)),d.value=b+""}},p.each(["width","height"],function(a,b){p.attrHooks[b]=p.extend(p.attrHooks[b],{set:function(a,c){if(c==="")return a.setAttribute(b,"auto"),c}})}),p.attrHooks.contenteditable={get:L.get,set:function(a,b,c){b===""&&(b="false"),L.set(a,b,c)}}),p.support.hrefNormalized||p.each(["href","src","width","height"],function(a,c){p.attrHooks[c]=p.extend(p.attrHooks[c],{get:function(a){var d=a.getAttribute(c,2);return d===null?b:d}})}),p.support.style||(p.attrHooks.style={get:function(a){return a.style.cssText.toLowerCase()||b},set:function(a,b){return a.style.cssText=b+""}}),p.support.optSelected||(p.propHooks.selected=p.extend(p.propHooks.selected,{get:function(a){var b=a.parentNode;return b&&(b.selectedIndex,b.parentNode&&b.parentNode.selectedIndex),null}})),p.support.enctype||(p.propFix.enctype="encoding"),p.support.checkOn||p.each(["radio","checkbox"],function(){p.valHooks[this]={get:function(a){return a.getAttribute("value")===null?"on":a.value}}}),p.each(["radio","checkbox"],function(){p.valHooks[this]=p.extend(p.valHooks[this],{set:function(a,b){if(p.isArray(b))return a.checked=p.inArray(p(a).val(),b)>=0}})});var V=/^(?:textarea|input|select)$/i,W=/^([^\.]*|)(?:\.(.+)|)$/,X=/(?:^|\s)hover(\.\S+|)\b/,Y=/^key/,Z=/^(?:mouse|contextmenu)|click/,$=/^(?:focusinfocus|focusoutblur)$/,_=function(a){return p.event.special.hover?a:a.replace(X,"mouseenter$1 mouseleave$1")};p.event={add:function(a,c,d,e,f){var g,h,i,j,k,l,m,n,o,q,r;if(a.nodeType===3||a.nodeType===8||!c||!d||!(g=p._data(a)))return;d.handler&&(o=d,d=o.handler,f=o.selector),d.guid||(d.guid=p.guid++),i=g.events,i||(g.events=i={}),h=g.handle,h||(g.handle=h=function(a){return typeof p!="undefined"&&(!a||p.event.triggered!==a.type)?p.event.dispatch.apply(h.elem,arguments):b},h.elem=a),c=p.trim(_(c)).split(" ");for(j=0;j<c.length;j++){k=W.exec(c[j])||[],l=k[1],m=(k[2]||"").split(".").sort(),r=p.event.special[l]||{},l=(f?r.delegateType:r.bindType)||l,r=p.event.special[l]||{},n=p.extend({type:l,origType:k[1],data:e,handler:d,guid:d.guid,selector:f,needsContext:f&&p.expr.match.needsContext.test(f),namespace:m.join(".")},o),q=i[l];if(!q){q=i[l]=[],q.delegateCount=0;if(!r.setup||r.setup.call(a,e,m,h)===!1)a.addEventListener?a.addEventListener(l,h,!1):a.attachEvent&&a.attachEvent("on"+l,h)}r.add&&(r.add.call(a,n),n.handler.guid||(n.handler.guid=d.guid)),f?q.splice(q.delegateCount++,0,n):q.push(n),p.event.global[l]=!0}a=null},global:{},remove:function(a,b,c,d,e){var f,g,h,i,j,k,l,m,n,o,q,r=p.hasData(a)&&p._data(a);if(!r||!(m=r.events))return;b=p.trim(_(b||"")).split(" ");for(f=0;f<b.length;f++){g=W.exec(b[f])||[],h=i=g[1],j=g[2];if(!h){for(h in m)p.event.remove(a,h+b[f],c,d,!0);continue}n=p.event.special[h]||{},h=(d?n.delegateType:n.bindType)||h,o=m[h]||[],k=o.length,j=j?new RegExp("(^|\\.)"+j.split(".").sort().join("\\.(?:.*\\.|)")+"(\\.|$)"):null;for(l=0;l<o.length;l++)q=o[l],(e||i===q.origType)&&(!c||c.guid===q.guid)&&(!j||j.test(q.namespace))&&(!d||d===q.selector||d==="**"&&q.selector)&&(o.splice(l--,1),q.selector&&o.delegateCount--,n.remove&&n.remove.call(a,q));o.length===0&&k!==o.length&&((!n.teardown||n.teardown.call(a,j,r.handle)===!1)&&p.removeEvent(a,h,r.handle),delete m[h])}p.isEmptyObject(m)&&(delete r.handle,p.removeData(a,"events",!0))},customEvent:{getData:!0,setData:!0,changeData:!0},trigger:function(c,d,f,g){if(!f||f.nodeType!==3&&f.nodeType!==8){var h,i,j,k,l,m,n,o,q,r,s=c.type||c,t=[];if($.test(s+p.event.triggered))return;s.indexOf("!")>=0&&(s=s.slice(0,-1),i=!0),s.indexOf(".")>=0&&(t=s.split("."),s=t.shift(),t.sort());if((!f||p.event.customEvent[s])&&!p.event.global[s])return;c=typeof c=="object"?c[p.expando]?c:new p.Event(s,c):new p.Event(s),c.type=s,c.isTrigger=!0,c.exclusive=i,c.namespace=t.join("."),c.namespace_re=c.namespace?new RegExp("(^|\\.)"+t.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,m=s.indexOf(":")<0?"on"+s:"";if(!f){h=p.cache;for(j in h)h[j].events&&h[j].events[s]&&p.event.trigger(c,d,h[j].handle.elem,!0);return}c.result=b,c.target||(c.target=f),d=d!=null?p.makeArray(d):[],d.unshift(c),n=p.event.special[s]||{};if(n.trigger&&n.trigger.apply(f,d)===!1)return;q=[[f,n.bindType||s]];if(!g&&!n.noBubble&&!p.isWindow(f)){r=n.delegateType||s,k=$.test(r+s)?f:f.parentNode;for(l=f;k;k=k.parentNode)q.push([k,r]),l=k;l===(f.ownerDocument||e)&&q.push([l.defaultView||l.parentWindow||a,r])}for(j=0;j<q.length&&!c.isPropagationStopped();j++)k=q[j][0],c.type=q[j][1],o=(p._data(k,"events")||{})[c.type]&&p._data(k,"handle"),o&&o.apply(k,d),o=m&&k[m],o&&p.acceptData(k)&&o.apply&&o.apply(k,d)===!1&&c.preventDefault();return c.type=s,!g&&!c.isDefaultPrevented()&&(!n._default||n._default.apply(f.ownerDocument,d)===!1)&&(s!=="click"||!p.nodeName(f,"a"))&&p.acceptData(f)&&m&&f[s]&&(s!=="focus"&&s!=="blur"||c.target.offsetWidth!==0)&&!p.isWindow(f)&&(l=f[m],l&&(f[m]=null),p.event.triggered=s,f[s](),p.event.triggered=b,l&&(f[m]=l)),c.result}return},dispatch:function(c){c=p.event.fix(c||a.event);var d,e,f,g,h,i,j,l,m,n,o=(p._data(this,"events")||{})[c.type]||[],q=o.delegateCount,r=k.call(arguments),s=!c.exclusive&&!c.namespace,t=p.event.special[c.type]||{},u=[];r[0]=c,c.delegateTarget=this;if(t.preDispatch&&t.preDispatch.call(this,c)===!1)return;if(q&&(!c.button||c.type!=="click"))for(f=c.target;f!=this;f=f.parentNode||this)if(f.disabled!==!0||c.type!=="click"){h={},j=[];for(d=0;d<q;d++)l=o[d],m=l.selector,h[m]===b&&(h[m]=l.needsContext?p(m,this).index(f)>=0:p.find(m,this,null,[f]).length),h[m]&&j.push(l);j.length&&u.push({elem:f,matches:j})}o.length>q&&u.push({elem:this,matches:o.slice(q)});for(d=0;d<u.length&&!c.isPropagationStopped();d++){i=u[d],c.currentTarget=i.elem;for(e=0;e<i.matches.length&&!c.isImmediatePropagationStopped();e++){l=i.matches[e];if(s||!c.namespace&&!l.namespace||c.namespace_re&&c.namespace_re.test(l.namespace))c.data=l.data,c.handleObj=l,g=((p.event.special[l.origType]||{}).handle||l.handler).apply(i.elem,r),g!==b&&(c.result=g,g===!1&&(c.preventDefault(),c.stopPropagation()))}}return t.postDispatch&&t.postDispatch.call(this,c),c.result},props:"attrChange attrName relatedNode srcElement altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(a,b){return a.which==null&&(a.which=b.charCode!=null?b.charCode:b.keyCode),a}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(a,c){var d,f,g,h=c.button,i=c.fromElement;return a.pageX==null&&c.clientX!=null&&(d=a.target.ownerDocument||e,f=d.documentElement,g=d.body,a.pageX=c.clientX+(f&&f.scrollLeft||g&&g.scrollLeft||0)-(f&&f.clientLeft||g&&g.clientLeft||0),a.pageY=c.clientY+(f&&f.scrollTop||g&&g.scrollTop||0)-(f&&f.clientTop||g&&g.clientTop||0)),!a.relatedTarget&&i&&(a.relatedTarget=i===a.target?c.toElement:i),!a.which&&h!==b&&(a.which=h&1?1:h&2?3:h&4?2:0),a}},fix:function(a){if(a[p.expando])return a;var b,c,d=a,f=p.event.fixHooks[a.type]||{},g=f.props?this.props.concat(f.props):this.props;a=p.Event(d);for(b=g.length;b;)c=g[--b],a[c]=d[c];return a.target||(a.target=d.srcElement||e),a.target.nodeType===3&&(a.target=a.target.parentNode),a.metaKey=!!a.metaKey,f.filter?f.filter(a,d):a},special:{load:{noBubble:!0},focus:{delegateType:"focusin"},blur:{delegateType:"focusout"},beforeunload:{setup:function(a,b,c){p.isWindow(this)&&(this.onbeforeunload=c)},teardown:function(a,b){this.onbeforeunload===b&&(this.onbeforeunload=null)}}},simulate:function(a,b,c,d){var e=p.extend(new p.Event,c,{type:a,isSimulated:!0,originalEvent:{}});d?p.event.trigger(e,null,b):p.event.dispatch.call(b,e),e.isDefaultPrevented()&&c.preventDefault()}},p.event.handle=p.event.dispatch,p.removeEvent=e.removeEventListener?function(a,b,c){a.removeEventListener&&a.removeEventListener(b,c,!1)}:function(a,b,c){var d="on"+b;a.detachEvent&&(typeof a[d]=="undefined"&&(a[d]=null),a.detachEvent(d,c))},p.Event=function(a,b){if(this instanceof p.Event)a&&a.type?(this.originalEvent=a,this.type=a.type,this.isDefaultPrevented=a.defaultPrevented||a.returnValue===!1||a.getPreventDefault&&a.getPreventDefault()?bb:ba):this.type=a,b&&p.extend(this,b),this.timeStamp=a&&a.timeStamp||p.now(),this[p.expando]=!0;else return new p.Event(a,b)},p.Event.prototype={preventDefault:function(){this.isDefaultPrevented=bb;var a=this.originalEvent;if(!a)return;a.preventDefault?a.preventDefault():a.returnValue=!1},stopPropagation:function(){this.isPropagationStopped=bb;var a=this.originalEvent;if(!a)return;a.stopPropagation&&a.stopPropagation(),a.cancelBubble=!0},stopImmediatePropagation:function(){this.isImmediatePropagationStopped=bb,this.stopPropagation()},isDefaultPrevented:ba,isPropagationStopped:ba,isImmediatePropagationStopped:ba},p.each({mouseenter:"mouseover",mouseleave:"mouseout"},function(a,b){p.event.special[a]={delegateType:b,bindType:b,handle:function(a){var c,d=this,e=a.relatedTarget,f=a.handleObj,g=f.selector;if(!e||e!==d&&!p.contains(d,e))a.type=f.origType,c=f.handler.apply(this,arguments),a.type=b;return c}}}),p.support.submitBubbles||(p.event.special.submit={setup:function(){if(p.nodeName(this,"form"))return!1;p.event.add(this,"click._submit keypress._submit",function(a){var c=a.target,d=p.nodeName(c,"input")||p.nodeName(c,"button")?c.form:b;d&&!p._data(d,"_submit_attached")&&(p.event.add(d,"submit._submit",function(a){a._submit_bubble=!0}),p._data(d,"_submit_attached",!0))})},postDispatch:function(a){a._submit_bubble&&(delete a._submit_bubble,this.parentNode&&!a.isTrigger&&p.event.simulate("submit",this.parentNode,a,!0))},teardown:function(){if(p.nodeName(this,"form"))return!1;p.event.remove(this,"._submit")}}),p.support.changeBubbles||(p.event.special.change={setup:function(){if(V.test(this.nodeName)){if(this.type==="checkbox"||this.type==="radio")p.event.add(this,"propertychange._change",function(a){a.originalEvent.propertyName==="checked"&&(this._just_changed=!0)}),p.event.add(this,"click._change",function(a){this._just_changed&&!a.isTrigger&&(this._just_changed=!1),p.event.simulate("change",this,a,!0)});return!1}p.event.add(this,"beforeactivate._change",function(a){var b=a.target;V.test(b.nodeName)&&!p._data(b,"_change_attached")&&(p.event.add(b,"change._change",function(a){this.parentNode&&!a.isSimulated&&!a.isTrigger&&p.event.simulate("change",this.parentNode,a,!0)}),p._data(b,"_change_attached",!0))})},handle:function(a){var b=a.target;if(this!==b||a.isSimulated||a.isTrigger||b.type!=="radio"&&b.type!=="checkbox")return a.handleObj.handler.apply(this,arguments)},teardown:function(){return p.event.remove(this,"._change"),!V.test(this.nodeName)}}),p.support.focusinBubbles||p.each({focus:"focusin",blur:"focusout"},function(a,b){var c=0,d=function(a){p.event.simulate(b,a.target,p.event.fix(a),!0)};p.event.special[b]={setup:function(){c++===0&&e.addEventListener(a,d,!0)},teardown:function(){--c===0&&e.removeEventListener(a,d,!0)}}}),p.fn.extend({on:function(a,c,d,e,f){var g,h;if(typeof a=="object"){typeof c!="string"&&(d=d||c,c=b);for(h in a)this.on(h,c,d,a[h],f);return this}d==null&&e==null?(e=c,d=c=b):e==null&&(typeof c=="string"?(e=d,d=b):(e=d,d=c,c=b));if(e===!1)e=ba;else if(!e)return this;return f===1&&(g=e,e=function(a){return p().off(a),g.apply(this,arguments)},e.guid=g.guid||(g.guid=p.guid++)),this.each(function(){p.event.add(this,a,e,d,c)})},one:function(a,b,c,d){return this.on(a,b,c,d,1)},off:function(a,c,d){var e,f;if(a&&a.preventDefault&&a.handleObj)return e=a.handleObj,p(a.delegateTarget).off(e.namespace?e.origType+"."+e.namespace:e.origType,e.selector,e.handler),this;if(typeof a=="object"){for(f in a)this.off(f,c,a[f]);return this}if(c===!1||typeof c=="function")d=c,c=b;return d===!1&&(d=ba),this.each(function(){p.event.remove(this,a,d,c)})},bind:function(a,b,c){return this.on(a,null,b,c)},unbind:function(a,b){return this.off(a,null,b)},live:function(a,b,c){return p(this.context).on(a,this.selector,b,c),this},die:function(a,b){return p(this.context).off(a,this.selector||"**",b),this},delegate:function(a,b,c,d){return this.on(b,a,c,d)},undelegate:function(a,b,c){return arguments.length===1?this.off(a,"**"):this.off(b,a||"**",c)},trigger:function(a,b){return this.each(function(){p.event.trigger(a,b,this)})},triggerHandler:function(a,b){if(this[0])return p.event.trigger(a,b,this[0],!0)},toggle:function(a){var b=arguments,c=a.guid||p.guid++,d=0,e=function(c){var e=(p._data(this,"lastToggle"+a.guid)||0)%d;return p._data(this,"lastToggle"+a.guid,e+1),c.preventDefault(),b[e].apply(this,arguments)||!1};e.guid=c;while(d<b.length)b[d++].guid=c;return this.click(e)},hover:function(a,b){return this.mouseenter(a).mouseleave(b||a)}}),p.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(a,b){p.fn[b]=function(a,c){return c==null&&(c=a,a=null),arguments.length>0?this.on(b,null,a,c):this.trigger(b)},Y.test(b)&&(p.event.fixHooks[b]=p.event.keyHooks),Z.test(b)&&(p.event.fixHooks[b]=p.event.mouseHooks)}),function(a,b){function bc(a,b,c,d){c=c||[],b=b||r;var e,f,i,j,k=b.nodeType;if(!a||typeof a!="string")return c;if(k!==1&&k!==9)return[];i=g(b);if(!i&&!d)if(e=P.exec(a))if(j=e[1]){if(k===9){f=b.getElementById(j);if(!f||!f.parentNode)return c;if(f.id===j)return c.push(f),c}else if(b.ownerDocument&&(f=b.ownerDocument.getElementById(j))&&h(b,f)&&f.id===j)return c.push(f),c}else{if(e[2])return w.apply(c,x.call(b.getElementsByTagName(a),0)),c;if((j=e[3])&&_&&b.getElementsByClassName)return w.apply(c,x.call(b.getElementsByClassName(j),0)),c}return bp(a.replace(L,"$1"),b,c,d,i)}function bd(a){return function(b){var c=b.nodeName.toLowerCase();return c==="input"&&b.type===a}}function be(a){return function(b){var c=b.nodeName.toLowerCase();return(c==="input"||c==="button")&&b.type===a}}function bf(a){return z(function(b){return b=+b,z(function(c,d){var e,f=a([],c.length,b),g=f.length;while(g--)c[e=f[g]]&&(c[e]=!(d[e]=c[e]))})})}function bg(a,b,c){if(a===b)return c;var d=a.nextSibling;while(d){if(d===b)return-1;d=d.nextSibling}return 1}function bh(a,b){var c,d,f,g,h,i,j,k=C[o][a];if(k)return b?0:k.slice(0);h=a,i=[],j=e.preFilter;while(h){if(!c||(d=M.exec(h)))d&&(h=h.slice(d[0].length)),i.push(f=[]);c=!1;if(d=N.exec(h))f.push(c=new q(d.shift())),h=h.slice(c.length),c.type=d[0].replace(L," ");for(g in e.filter)(d=W[g].exec(h))&&(!j[g]||(d=j[g](d,r,!0)))&&(f.push(c=new q(d.shift())),h=h.slice(c.length),c.type=g,c.matches=d);if(!c)break}return b?h.length:h?bc.error(a):C(a,i).slice(0)}function bi(a,b,d){var e=b.dir,f=d&&b.dir==="parentNode",g=u++;return b.first?function(b,c,d){while(b=b[e])if(f||b.nodeType===1)return a(b,c,d)}:function(b,d,h){if(!h){var i,j=t+" "+g+" ",k=j+c;while(b=b[e])if(f||b.nodeType===1){if((i=b[o])===k)return b.sizset;if(typeof i=="string"&&i.indexOf(j)===0){if(b.sizset)return b}else{b[o]=k;if(a(b,d,h))return b.sizset=!0,b;b.sizset=!1}}}else while(b=b[e])if(f||b.nodeType===1)if(a(b,d,h))return b}}function bj(a){return a.length>1?function(b,c,d){var e=a.length;while(e--)if(!a[e](b,c,d))return!1;return!0}:a[0]}function bk(a,b,c,d,e){var f,g=[],h=0,i=a.length,j=b!=null;for(;h<i;h++)if(f=a[h])if(!c||c(f,d,e))g.push(f),j&&b.push(h);return g}function bl(a,b,c,d,e,f){return d&&!d[o]&&(d=bl(d)),e&&!e[o]&&(e=bl(e,f)),z(function(f,g,h,i){if(f&&e)return;var j,k,l,m=[],n=[],o=g.length,p=f||bo(b||"*",h.nodeType?[h]:h,[],f),q=a&&(f||!b)?bk(p,m,a,h,i):p,r=c?e||(f?a:o||d)?[]:g:q;c&&c(q,r,h,i);if(d){l=bk(r,n),d(l,[],h,i),j=l.length;while(j--)if(k=l[j])r[n[j]]=!(q[n[j]]=k)}if(f){j=a&&r.length;while(j--)if(k=r[j])f[m[j]]=!(g[m[j]]=k)}else r=bk(r===g?r.splice(o,r.length):r),e?e(null,g,r,i):w.apply(g,r)})}function bm(a){var b,c,d,f=a.length,g=e.relative[a[0].type],h=g||e.relative[" "],i=g?1:0,j=bi(function(a){return a===b},h,!0),k=bi(function(a){return y.call(b,a)>-1},h,!0),m=[function(a,c,d){return!g&&(d||c!==l)||((b=c).nodeType?j(a,c,d):k(a,c,d))}];for(;i<f;i++)if(c=e.relative[a[i].type])m=[bi(bj(m),c)];else{c=e.filter[a[i].type].apply(null,a[i].matches);if(c[o]){d=++i;for(;d<f;d++)if(e.relative[a[d].type])break;return bl(i>1&&bj(m),i>1&&a.slice(0,i-1).join("").replace(L,"$1"),c,i<d&&bm(a.slice(i,d)),d<f&&bm(a=a.slice(d)),d<f&&a.join(""))}m.push(c)}return bj(m)}function bn(a,b){var d=b.length>0,f=a.length>0,g=function(h,i,j,k,m){var n,o,p,q=[],s=0,u="0",x=h&&[],y=m!=null,z=l,A=h||f&&e.find.TAG("*",m&&i.parentNode||i),B=t+=z==null?1:Math.E;y&&(l=i!==r&&i,c=g.el);for(;(n=A[u])!=null;u++){if(f&&n){for(o=0;p=a[o];o++)if(p(n,i,j)){k.push(n);break}y&&(t=B,c=++g.el)}d&&((n=!p&&n)&&s--,h&&x.push(n))}s+=u;if(d&&u!==s){for(o=0;p=b[o];o++)p(x,q,i,j);if(h){if(s>0)while(u--)!x[u]&&!q[u]&&(q[u]=v.call(k));q=bk(q)}w.apply(k,q),y&&!h&&q.length>0&&s+b.length>1&&bc.uniqueSort(k)}return y&&(t=B,l=z),x};return g.el=0,d?z(g):g}function bo(a,b,c,d){var e=0,f=b.length;for(;e<f;e++)bc(a,b[e],c,d);return c}function bp(a,b,c,d,f){var g,h,j,k,l,m=bh(a),n=m.length;if(!d&&m.length===1){h=m[0]=m[0].slice(0);if(h.length>2&&(j=h[0]).type==="ID"&&b.nodeType===9&&!f&&e.relative[h[1].type]){b=e.find.ID(j.matches[0].replace(V,""),b,f)[0];if(!b)return c;a=a.slice(h.shift().length)}for(g=W.POS.test(a)?-1:h.length-1;g>=0;g--){j=h[g];if(e.relative[k=j.type])break;if(l=e.find[k])if(d=l(j.matches[0].replace(V,""),R.test(h[0].type)&&b.parentNode||b,f)){h.splice(g,1),a=d.length&&h.join("");if(!a)return w.apply(c,x.call(d,0)),c;break}}}return i(a,m)(d,b,f,c,R.test(a)),c}function bq(){}var c,d,e,f,g,h,i,j,k,l,m=!0,n="undefined",o=("sizcache"+Math.random()).replace(".",""),q=String,r=a.document,s=r.documentElement,t=0,u=0,v=[].pop,w=[].push,x=[].slice,y=[].indexOf||function(a){var b=0,c=this.length;for(;b<c;b++)if(this[b]===a)return b;return-1},z=function(a,b){return a[o]=b==null||b,a},A=function(){var a={},b=[];return z(function(c,d){return b.push(c)>e.cacheLength&&delete a[b.shift()],a[c]=d},a)},B=A(),C=A(),D=A(),E="[\\x20\\t\\r\\n\\f]",F="(?:\\\\.|[-\\w]|[^\\x00-\\xa0])+",G=F.replace("w","w#"),H="([*^$|!~]?=)",I="\\["+E+"*("+F+")"+E+"*(?:"+H+E+"*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|("+G+")|)|)"+E+"*\\]",J=":("+F+")(?:\\((?:(['\"])((?:\\\\.|[^\\\\])*?)\\2|([^()[\\]]*|(?:(?:"+I+")|[^:]|\\\\.)*|.*))\\)|)",K=":(even|odd|eq|gt|lt|nth|first|last)(?:\\("+E+"*((?:-\\d)?\\d*)"+E+"*\\)|)(?=[^-]|$)",L=new RegExp("^"+E+"+|((?:^|[^\\\\])(?:\\\\.)*)"+E+"+$","g"),M=new RegExp("^"+E+"*,"+E+"*"),N=new RegExp("^"+E+"*([\\x20\\t\\r\\n\\f>+~])"+E+"*"),O=new RegExp(J),P=/^(?:#([\w\-]+)|(\w+)|\.([\w\-]+))$/,Q=/^:not/,R=/[\x20\t\r\n\f]*[+~]/,S=/:not\($/,T=/h\d/i,U=/input|select|textarea|button/i,V=/\\(?!\\)/g,W={ID:new RegExp("^#("+F+")"),CLASS:new RegExp("^\\.("+F+")"),NAME:new RegExp("^\\[name=['\"]?("+F+")['\"]?\\]"),TAG:new RegExp("^("+F.replace("w","w*")+")"),ATTR:new RegExp("^"+I),PSEUDO:new RegExp("^"+J),POS:new RegExp(K,"i"),CHILD:new RegExp("^:(only|nth|first|last)-child(?:\\("+E+"*(even|odd|(([+-]|)(\\d*)n|)"+E+"*(?:([+-]|)"+E+"*(\\d+)|))"+E+"*\\)|)","i"),needsContext:new RegExp("^"+E+"*[>+~]|"+K,"i")},X=function(a){var b=r.createElement("div");try{return a(b)}catch(c){return!1}finally{b=null}},Y=X(function(a){return a.appendChild(r.createComment("")),!a.getElementsByTagName("*").length}),Z=X(function(a){return a.innerHTML="<a href='#'></a>",a.firstChild&&typeof a.firstChild.getAttribute!==n&&a.firstChild.getAttribute("href")==="#"}),$=X(function(a){a.innerHTML="<select></select>";var b=typeof a.lastChild.getAttribute("multiple");return b!=="boolean"&&b!=="string"}),_=X(function(a){return a.innerHTML="<div class='hidden e'></div><div class='hidden'></div>",!a.getElementsByClassName||!a.getElementsByClassName("e").length?!1:(a.lastChild.className="e",a.getElementsByClassName("e").length===2)}),ba=X(function(a){a.id=o+0,a.innerHTML="<a name='"+o+"'></a><div name='"+o+"'></div>",s.insertBefore(a,s.firstChild);var b=r.getElementsByName&&r.getElementsByName(o).length===2+r.getElementsByName(o+0).length;return d=!r.getElementById(o),s.removeChild(a),b});try{x.call(s.childNodes,0)[0].nodeType}catch(bb){x=function(a){var b,c=[];for(;b=this[a];a++)c.push(b);return c}}bc.matches=function(a,b){return bc(a,null,null,b)},bc.matchesSelector=function(a,b){return bc(b,null,null,[a]).length>0},f=bc.getText=function(a){var b,c="",d=0,e=a.nodeType;if(e){if(e===1||e===9||e===11){if(typeof a.textContent=="string")return a.textContent;for(a=a.firstChild;a;a=a.nextSibling)c+=f(a)}else if(e===3||e===4)return a.nodeValue}else for(;b=a[d];d++)c+=f(b);return c},g=bc.isXML=function(a){var b=a&&(a.ownerDocument||a).documentElement;return b?b.nodeName!=="HTML":!1},h=bc.contains=s.contains?function(a,b){var c=a.nodeType===9?a.documentElement:a,d=b&&b.parentNode;return a===d||!!(d&&d.nodeType===1&&c.contains&&c.contains(d))}:s.compareDocumentPosition?function(a,b){return b&&!!(a.compareDocumentPosition(b)&16)}:function(a,b){while(b=b.parentNode)if(b===a)return!0;return!1},bc.attr=function(a,b){var c,d=g(a);return d||(b=b.toLowerCase()),(c=e.attrHandle[b])?c(a):d||$?a.getAttribute(b):(c=a.getAttributeNode(b),c?typeof a[b]=="boolean"?a[b]?b:null:c.specified?c.value:null:null)},e=bc.selectors={cacheLength:50,createPseudo:z,match:W,attrHandle:Z?{}:{href:function(a){return a.getAttribute("href",2)},type:function(a){return a.getAttribute("type")}},find:{ID:d?function(a,b,c){if(typeof b.getElementById!==n&&!c){var d=b.getElementById(a);return d&&d.parentNode?[d]:[]}}:function(a,c,d){if(typeof c.getElementById!==n&&!d){var e=c.getElementById(a);return e?e.id===a||typeof e.getAttributeNode!==n&&e.getAttributeNode("id").value===a?[e]:b:[]}},TAG:Y?function(a,b){if(typeof b.getElementsByTagName!==n)return b.getElementsByTagName(a)}:function(a,b){var c=b.getElementsByTagName(a);if(a==="*"){var d,e=[],f=0;for(;d=c[f];f++)d.nodeType===1&&e.push(d);return e}return c},NAME:ba&&function(a,b){if(typeof b.getElementsByName!==n)return b.getElementsByName(name)},CLASS:_&&function(a,b,c){if(typeof b.getElementsByClassName!==n&&!c)return b.getElementsByClassName(a)}},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(a){return a[1]=a[1].replace(V,""),a[3]=(a[4]||a[5]||"").replace(V,""),a[2]==="~="&&(a[3]=" "+a[3]+" "),a.slice(0,4)},CHILD:function(a){return a[1]=a[1].toLowerCase(),a[1]==="nth"?(a[2]||bc.error(a[0]),a[3]=+(a[3]?a[4]+(a[5]||1):2*(a[2]==="even"||a[2]==="odd")),a[4]=+(a[6]+a[7]||a[2]==="odd")):a[2]&&bc.error(a[0]),a},PSEUDO:function(a){var b,c;if(W.CHILD.test(a[0]))return null;if(a[3])a[2]=a[3];else if(b=a[4])O.test(b)&&(c=bh(b,!0))&&(c=b.indexOf(")",b.length-c)-b.length)&&(b=b.slice(0,c),a[0]=a[0].slice(0,c)),a[2]=b;return a.slice(0,3)}},filter:{ID:d?function(a){return a=a.replace(V,""),function(b){return b.getAttribute("id")===a}}:function(a){return a=a.replace(V,""),function(b){var c=typeof b.getAttributeNode!==n&&b.getAttributeNode("id");return c&&c.value===a}},TAG:function(a){return a==="*"?function(){return!0}:(a=a.replace(V,"").toLowerCase(),function(b){return b.nodeName&&b.nodeName.toLowerCase()===a})},CLASS:function(a){var b=B[o][a];return b||(b=B(a,new RegExp("(^|"+E+")"+a+"("+E+"|$)"))),function(a){return b.test(a.className||typeof a.getAttribute!==n&&a.getAttribute("class")||"")}},ATTR:function(a,b,c){return function(d,e){var f=bc.attr(d,a);return f==null?b==="!=":b?(f+="",b==="="?f===c:b==="!="?f!==c:b==="^="?c&&f.indexOf(c)===0:b==="*="?c&&f.indexOf(c)>-1:b==="$="?c&&f.substr(f.length-c.length)===c:b==="~="?(" "+f+" ").indexOf(c)>-1:b==="|="?f===c||f.substr(0,c.length+1)===c+"-":!1):!0}},CHILD:function(a,b,c,d){return a==="nth"?function(a){var b,e,f=a.parentNode;if(c===1&&d===0)return!0;if(f){e=0;for(b=f.firstChild;b;b=b.nextSibling)if(b.nodeType===1){e++;if(a===b)break}}return e-=d,e===c||e%c===0&&e/c>=0}:function(b){var c=b;switch(a){case"only":case"first":while(c=c.previousSibling)if(c.nodeType===1)return!1;if(a==="first")return!0;c=b;case"last":while(c=c.nextSibling)if(c.nodeType===1)return!1;return!0}}},PSEUDO:function(a,b){var c,d=e.pseudos[a]||e.setFilters[a.toLowerCase()]||bc.error("unsupported pseudo: "+a);return d[o]?d(b):d.length>1?(c=[a,a,"",b],e.setFilters.hasOwnProperty(a.toLowerCase())?z(function(a,c){var e,f=d(a,b),g=f.length;while(g--)e=y.call(a,f[g]),a[e]=!(c[e]=f[g])}):function(a){return d(a,0,c)}):d}},pseudos:{not:z(function(a){var b=[],c=[],d=i(a.replace(L,"$1"));return d[o]?z(function(a,b,c,e){var f,g=d(a,null,e,[]),h=a.length;while(h--)if(f=g[h])a[h]=!(b[h]=f)}):function(a,e,f){return b[0]=a,d(b,null,f,c),!c.pop()}}),has:z(function(a){return function(b){return bc(a,b).length>0}}),contains:z(function(a){return function(b){return(b.textContent||b.innerText||f(b)).indexOf(a)>-1}}),enabled:function(a){return a.disabled===!1},disabled:function(a){return a.disabled===!0},checked:function(a){var b=a.nodeName.toLowerCase();return b==="input"&&!!a.checked||b==="option"&&!!a.selected},selected:function(a){return a.parentNode&&a.parentNode.selectedIndex,a.selected===!0},parent:function(a){return!e.pseudos.empty(a)},empty:function(a){var b;a=a.firstChild;while(a){if(a.nodeName>"@"||(b=a.nodeType)===3||b===4)return!1;a=a.nextSibling}return!0},header:function(a){return T.test(a.nodeName)},text:function(a){var b,c;return a.nodeName.toLowerCase()==="input"&&(b=a.type)==="text"&&((c=a.getAttribute("type"))==null||c.toLowerCase()===b)},radio:bd("radio"),checkbox:bd("checkbox"),file:bd("file"),password:bd("password"),image:bd("image"),submit:be("submit"),reset:be("reset"),button:function(a){var b=a.nodeName.toLowerCase();return b==="input"&&a.type==="button"||b==="button"},input:function(a){return U.test(a.nodeName)},focus:function(a){var b=a.ownerDocument;return a===b.activeElement&&(!b.hasFocus||b.hasFocus())&&(!!a.type||!!a.href)},active:function(a){return a===a.ownerDocument.activeElement},first:bf(function(a,b,c){return[0]}),last:bf(function(a,b,c){return[b-1]}),eq:bf(function(a,b,c){return[c<0?c+b:c]}),even:bf(function(a,b,c){for(var d=0;d<b;d+=2)a.push(d);return a}),odd:bf(function(a,b,c){for(var d=1;d<b;d+=2)a.push(d);return a}),lt:bf(function(a,b,c){for(var d=c<0?c+b:c;--d>=0;)a.push(d);return a}),gt:bf(function(a,b,c){for(var d=c<0?c+b:c;++d<b;)a.push(d);return a})}},j=s.compareDocumentPosition?function(a,b){return a===b?(k=!0,0):(!a.compareDocumentPosition||!b.compareDocumentPosition?a.compareDocumentPosition:a.compareDocumentPosition(b)&4)?-1:1}:function(a,b){if(a===b)return k=!0,0;if(a.sourceIndex&&b.sourceIndex)return a.sourceIndex-b.sourceIndex;var c,d,e=[],f=[],g=a.parentNode,h=b.parentNode,i=g;if(g===h)return bg(a,b);if(!g)return-1;if(!h)return 1;while(i)e.unshift(i),i=i.parentNode;i=h;while(i)f.unshift(i),i=i.parentNode;c=e.length,d=f.length;for(var j=0;j<c&&j<d;j++)if(e[j]!==f[j])return bg(e[j],f[j]);return j===c?bg(a,f[j],-1):bg(e[j],b,1)},[0,0].sort(j),m=!k,bc.uniqueSort=function(a){var b,c=1;k=m,a.sort(j);if(k)for(;b=a[c];c++)b===a[c-1]&&a.splice(c--,1);return a},bc.error=function(a){throw new Error("Syntax error, unrecognized expression: "+a)},i=bc.compile=function(a,b){var c,d=[],e=[],f=D[o][a];if(!f){b||(b=bh(a)),c=b.length;while(c--)f=bm(b[c]),f[o]?d.push(f):e.push(f);f=D(a,bn(e,d))}return f},r.querySelectorAll&&function(){var a,b=bp,c=/'|\\/g,d=/\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g,e=[":focus"],f=[":active",":focus"],h=s.matchesSelector||s.mozMatchesSelector||s.webkitMatchesSelector||s.oMatchesSelector||s.msMatchesSelector;X(function(a){a.innerHTML="<select><option selected=''></option></select>",a.querySelectorAll("[selected]").length||e.push("\\["+E+"*(?:checked|disabled|ismap|multiple|readonly|selected|value)"),a.querySelectorAll(":checked").length||e.push(":checked")}),X(function(a){a.innerHTML="<p test=''></p>",a.querySelectorAll("[test^='']").length&&e.push("[*^$]="+E+"*(?:\"\"|'')"),a.innerHTML="<input type='hidden'/>",a.querySelectorAll(":enabled").length||e.push(":enabled",":disabled")}),e=new RegExp(e.join("|")),bp=function(a,d,f,g,h){if(!g&&!h&&(!e||!e.test(a))){var i,j,k=!0,l=o,m=d,n=d.nodeType===9&&a;if(d.nodeType===1&&d.nodeName.toLowerCase()!=="object"){i=bh(a),(k=d.getAttribute("id"))?l=k.replace(c,"\\$&"):d.setAttribute("id",l),l="[id='"+l+"'] ",j=i.length;while(j--)i[j]=l+i[j].join("");m=R.test(a)&&d.parentNode||d,n=i.join(",")}if(n)try{return w.apply(f,x.call(m.querySelectorAll(n),0)),f}catch(p){}finally{k||d.removeAttribute("id")}}return b(a,d,f,g,h)},h&&(X(function(b){a=h.call(b,"div");try{h.call(b,"[test!='']:sizzle"),f.push("!=",J)}catch(c){}}),f=new RegExp(f.join("|")),bc.matchesSelector=function(b,c){c=c.replace(d,"='$1']");if(!g(b)&&!f.test(c)&&(!e||!e.test(c)))try{var i=h.call(b,c);if(i||a||b.document&&b.document.nodeType!==11)return i}catch(j){}return bc(c,null,null,[b]).length>0})}(),e.pseudos.nth=e.pseudos.eq,e.filters=bq.prototype=e.pseudos,e.setFilters=new bq,bc.attr=p.attr,p.find=bc,p.expr=bc.selectors,p.expr[":"]=p.expr.pseudos,p.unique=bc.uniqueSort,p.text=bc.getText,p.isXMLDoc=bc.isXML,p.contains=bc.contains}(a);var bc=/Until$/,bd=/^(?:parents|prev(?:Until|All))/,be=/^.[^:#\[\.,]*$/,bf=p.expr.match.needsContext,bg={children:!0,contents:!0,next:!0,prev:!0};p.fn.extend({find:function(a){var b,c,d,e,f,g,h=this;if(typeof a!="string")return p(a).filter(function(){for(b=0,c=h.length;b<c;b++)if(p.contains(h[b],this))return!0});g=this.pushStack("","find",a);for(b=0,c=this.length;b<c;b++){d=g.length,p.find(a,this[b],g);if(b>0)for(e=d;e<g.length;e++)for(f=0;f<d;f++)if(g[f]===g[e]){g.splice(e--,1);break}}return g},has:function(a){var b,c=p(a,this),d=c.length;return this.filter(function(){for(b=0;b<d;b++)if(p.contains(this,c[b]))return!0})},not:function(a){return this.pushStack(bj(this,a,!1),"not",a)},filter:function(a){return this.pushStack(bj(this,a,!0),"filter",a)},is:function(a){return!!a&&(typeof a=="string"?bf.test(a)?p(a,this.context).index(this[0])>=0:p.filter(a,this).length>0:this.filter(a).length>0)},closest:function(a,b){var c,d=0,e=this.length,f=[],g=bf.test(a)||typeof a!="string"?p(a,b||this.context):0;for(;d<e;d++){c=this[d];while(c&&c.ownerDocument&&c!==b&&c.nodeType!==11){if(g?g.index(c)>-1:p.find.matchesSelector(c,a)){f.push(c);break}c=c.parentNode}}return f=f.length>1?p.unique(f):f,this.pushStack(f,"closest",a)},index:function(a){return a?typeof a=="string"?p.inArray(this[0],p(a)):p.inArray(a.jquery?a[0]:a,this):this[0]&&this[0].parentNode?this.prevAll().length:-1},add:function(a,b){var c=typeof a=="string"?p(a,b):p.makeArray(a&&a.nodeType?[a]:a),d=p.merge(this.get(),c);return this.pushStack(bh(c[0])||bh(d[0])?d:p.unique(d))},addBack:function(a){return this.add(a==null?this.prevObject:this.prevObject.filter(a))}}),p.fn.andSelf=p.fn.addBack,p.each({parent:function(a){var b=a.parentNode;return b&&b.nodeType!==11?b:null},parents:function(a){return p.dir(a,"parentNode")},parentsUntil:function(a,b,c){return p.dir(a,"parentNode",c)},next:function(a){return bi(a,"nextSibling")},prev:function(a){return bi(a,"previousSibling")},nextAll:function(a){return p.dir(a,"nextSibling")},prevAll:function(a){return p.dir(a,"previousSibling")},nextUntil:function(a,b,c){return p.dir(a,"nextSibling",c)},prevUntil:function(a,b,c){return p.dir(a,"previousSibling",c)},siblings:function(a){return p.sibling((a.parentNode||{}).firstChild,a)},children:function(a){return p.sibling(a.firstChild)},contents:function(a){return p.nodeName(a,"iframe")?a.contentDocument||a.contentWindow.document:p.merge([],a.childNodes)}},function(a,b){p.fn[a]=function(c,d){var e=p.map(this,b,c);return bc.test(a)||(d=c),d&&typeof d=="string"&&(e=p.filter(d,e)),e=this.length>1&&!bg[a]?p.unique(e):e,this.length>1&&bd.test(a)&&(e=e.reverse()),this.pushStack(e,a,k.call(arguments).join(","))}}),p.extend({filter:function(a,b,c){return c&&(a=":not("+a+")"),b.length===1?p.find.matchesSelector(b[0],a)?[b[0]]:[]:p.find.matches(a,b)},dir:function(a,c,d){var e=[],f=a[c];while(f&&f.nodeType!==9&&(d===b||f.nodeType!==1||!p(f).is(d)))f.nodeType===1&&e.push(f),f=f[c];return e},sibling:function(a,b){var c=[];for(;a;a=a.nextSibling)a.nodeType===1&&a!==b&&c.push(a);return c}});var bl="abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",bm=/ jQuery\d+="(?:null|\d+)"/g,bn=/^\s+/,bo=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,bp=/<([\w:]+)/,bq=/<tbody/i,br=/<|&#?\w+;/,bs=/<(?:script|style|link)/i,bt=/<(?:script|object|embed|option|style)/i,bu=new RegExp("<(?:"+bl+")[\\s/>]","i"),bv=/^(?:checkbox|radio)$/,bw=/checked\s*(?:[^=]|=\s*.checked.)/i,bx=/\/(java|ecma)script/i,by=/^\s*<!(?:\[CDATA\[|\-\-)|[\]\-]{2}>\s*$/g,bz={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],area:[1,"<map>","</map>"],_default:[0,"",""]},bA=bk(e),bB=bA.appendChild(e.createElement("div"));bz.optgroup=bz.option,bz.tbody=bz.tfoot=bz.colgroup=bz.caption=bz.thead,bz.th=bz.td,p.support.htmlSerialize||(bz._default=[1,"X<div>","</div>"]),p.fn.extend({text:function(a){return p.access(this,function(a){return a===b?p.text(this):this.empty().append((this[0]&&this[0].ownerDocument||e).createTextNode(a))},null,a,arguments.length)},wrapAll:function(a){if(p.isFunction(a))return this.each(function(b){p(this).wrapAll(a.call(this,b))});if(this[0]){var b=p(a,this[0].ownerDocument).eq(0).clone(!0);this[0].parentNode&&b.insertBefore(this[0]),b.map(function(){var a=this;while(a.firstChild&&a.firstChild.nodeType===1)a=a.firstChild;return a}).append(this)}return this},wrapInner:function(a){return p.isFunction(a)?this.each(function(b){p(this).wrapInner(a.call(this,b))}):this.each(function(){var b=p(this),c=b.contents();c.length?c.wrapAll(a):b.append(a)})},wrap:function(a){var b=p.isFunction(a);return this.each(function(c){p(this).wrapAll(b?a.call(this,c):a)})},unwrap:function(){return this.parent().each(function(){p.nodeName(this,"body")||p(this).replaceWith(this.childNodes)}).end()},append:function(){return this.domManip(arguments,!0,function(a){(this.nodeType===1||this.nodeType===11)&&this.appendChild(a)})},prepend:function(){return this.domManip(arguments,!0,function(a){(this.nodeType===1||this.nodeType===11)&&this.insertBefore(a,this.firstChild)})},before:function(){if(!bh(this[0]))return this.domManip(arguments,!1,function(a){this.parentNode.insertBefore(a,this)});if(arguments.length){var a=p.clean(arguments);return this.pushStack(p.merge(a,this),"before",this.selector)}},after:function(){if(!bh(this[0]))return this.domManip(arguments,!1,function(a){this.parentNode.insertBefore(a,this.nextSibling)});if(arguments.length){var a=p.clean(arguments);return this.pushStack(p.merge(this,a),"after",this.selector)}},remove:function(a,b){var c,d=0;for(;(c=this[d])!=null;d++)if(!a||p.filter(a,[c]).length)!b&&c.nodeType===1&&(p.cleanData(c.getElementsByTagName("*")),p.cleanData([c])),c.parentNode&&c.parentNode.removeChild(c);return this},empty:function(){var a,b=0;for(;(a=this[b])!=null;b++){a.nodeType===1&&p.cleanData(a.getElementsByTagName("*"));while(a.firstChild)a.removeChild(a.firstChild)}return this},clone:function(a,b){return a=a==null?!1:a,b=b==null?a:b,this.map(function(){return p.clone(this,a,b)})},html:function(a){return p.access(this,function(a){var c=this[0]||{},d=0,e=this.length;if(a===b)return c.nodeType===1?c.innerHTML.replace(bm,""):b;if(typeof a=="string"&&!bs.test(a)&&(p.support.htmlSerialize||!bu.test(a))&&(p.support.leadingWhitespace||!bn.test(a))&&!bz[(bp.exec(a)||["",""])[1].toLowerCase()]){a=a.replace(bo,"<$1></$2>");try{for(;d<e;d++)c=this[d]||{},c.nodeType===1&&(p.cleanData(c.getElementsByTagName("*")),c.innerHTML=a);c=0}catch(f){}}c&&this.empty().append(a)},null,a,arguments.length)},replaceWith:function(a){return bh(this[0])?this.length?this.pushStack(p(p.isFunction(a)?a():a),"replaceWith",a):this:p.isFunction(a)?this.each(function(b){var c=p(this),d=c.html();c.replaceWith(a.call(this,b,d))}):(typeof a!="string"&&(a=p(a).detach()),this.each(function(){var b=this.nextSibling,c=this.parentNode;p(this).remove(),b?p(b).before(a):p(c).append(a)}))},detach:function(a){return this.remove(a,!0)},domManip:function(a,c,d){a=[].concat.apply([],a);var e,f,g,h,i=0,j=a[0],k=[],l=this.length;if(!p.support.checkClone&&l>1&&typeof j=="string"&&bw.test(j))return this.each(function(){p(this).domManip(a,c,d)});if(p.isFunction(j))return this.each(function(e){var f=p(this);a[0]=j.call(this,e,c?f.html():b),f.domManip(a,c,d)});if(this[0]){e=p.buildFragment(a,this,k),g=e.fragment,f=g.firstChild,g.childNodes.length===1&&(g=f);if(f){c=c&&p.nodeName(f,"tr");for(h=e.cacheable||l-1;i<l;i++)d.call(c&&p.nodeName(this[i],"table")?bC(this[i],"tbody"):this[i],i===h?g:p.clone(g,!0,!0))}g=f=null,k.length&&p.each(k,function(a,b){b.src?p.ajax?p.ajax({url:b.src,type:"GET",dataType:"script",async:!1,global:!1,"throws":!0}):p.error("no ajax"):p.globalEval((b.text||b.textContent||b.innerHTML||"").replace(by,"")),b.parentNode&&b.parentNode.removeChild(b)})}return this}}),p.buildFragment=function(a,c,d){var f,g,h,i=a[0];return c=c||e,c=!c.nodeType&&c[0]||c,c=c.ownerDocument||c,a.length===1&&typeof i=="string"&&i.length<512&&c===e&&i.charAt(0)==="<"&&!bt.test(i)&&(p.support.checkClone||!bw.test(i))&&(p.support.html5Clone||!bu.test(i))&&(g=!0,f=p.fragments[i],h=f!==b),f||(f=c.createDocumentFragment(),p.clean(a,c,f,d),g&&(p.fragments[i]=h&&f)),{fragment:f,cacheable:g}},p.fragments={},p.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(a,b){p.fn[a]=function(c){var d,e=0,f=[],g=p(c),h=g.length,i=this.length===1&&this[0].parentNode;if((i==null||i&&i.nodeType===11&&i.childNodes.length===1)&&h===1)return g[b](this[0]),this;for(;e<h;e++)d=(e>0?this.clone(!0):this).get(),p(g[e])[b](d),f=f.concat(d);return this.pushStack(f,a,g.selector)}}),p.extend({clone:function(a,b,c){var d,e,f,g;p.support.html5Clone||p.isXMLDoc(a)||!bu.test("<"+a.nodeName+">")?g=a.cloneNode(!0):(bB.innerHTML=a.outerHTML,bB.removeChild(g=bB.firstChild));if((!p.support.noCloneEvent||!p.support.noCloneChecked)&&(a.nodeType===1||a.nodeType===11)&&!p.isXMLDoc(a)){bE(a,g),d=bF(a),e=bF(g);for(f=0;d[f];++f)e[f]&&bE(d[f],e[f])}if(b){bD(a,g);if(c){d=bF(a),e=bF(g);for(f=0;d[f];++f)bD(d[f],e[f])}}return d=e=null,g},clean:function(a,b,c,d){var f,g,h,i,j,k,l,m,n,o,q,r,s=b===e&&bA,t=[];if(!b||typeof b.createDocumentFragment=="undefined")b=e;for(f=0;(h=a[f])!=null;f++){typeof h=="number"&&(h+="");if(!h)continue;if(typeof h=="string")if(!br.test(h))h=b.createTextNode(h);else{s=s||bk(b),l=b.createElement("div"),s.appendChild(l),h=h.replace(bo,"<$1></$2>"),i=(bp.exec(h)||["",""])[1].toLowerCase(),j=bz[i]||bz._default,k=j[0],l.innerHTML=j[1]+h+j[2];while(k--)l=l.lastChild;if(!p.support.tbody){m=bq.test(h),n=i==="table"&&!m?l.firstChild&&l.firstChild.childNodes:j[1]==="<table>"&&!m?l.childNodes:[];for(g=n.length-1;g>=0;--g)p.nodeName(n[g],"tbody")&&!n[g].childNodes.length&&n[g].parentNode.removeChild(n[g])}!p.support.leadingWhitespace&&bn.test(h)&&l.insertBefore(b.createTextNode(bn.exec(h)[0]),l.firstChild),h=l.childNodes,l.parentNode.removeChild(l)}h.nodeType?t.push(h):p.merge(t,h)}l&&(h=l=s=null);if(!p.support.appendChecked)for(f=0;(h=t[f])!=null;f++)p.nodeName(h,"input")?bG(h):typeof h.getElementsByTagName!="undefined"&&p.grep(h.getElementsByTagName("input"),bG);if(c){q=function(a){if(!a.type||bx.test(a.type))return d?d.push(a.parentNode?a.parentNode.removeChild(a):a):c.appendChild(a)};for(f=0;(h=t[f])!=null;f++)if(!p.nodeName(h,"script")||!q(h))c.appendChild(h),typeof h.getElementsByTagName!="undefined"&&(r=p.grep(p.merge([],h.getElementsByTagName("script")),q),t.splice.apply(t,[f+1,0].concat(r)),f+=r.length)}return t},cleanData:function(a,b){var c,d,e,f,g=0,h=p.expando,i=p.cache,j=p.support.deleteExpando,k=p.event.special;for(;(e=a[g])!=null;g++)if(b||p.acceptData(e)){d=e[h],c=d&&i[d];if(c){if(c.events)for(f in c.events)k[f]?p.event.remove(e,f):p.removeEvent(e,f,c.handle);i[d]&&(delete i[d],j?delete e[h]:e.removeAttribute?e.removeAttribute(h):e[h]=null,p.deletedIds.push(d))}}}}),function(){var a,b;p.uaMatch=function(a){a=a.toLowerCase();var b=/(chrome)[ \/]([\w.]+)/.exec(a)||/(webkit)[ \/]([\w.]+)/.exec(a)||/(opera)(?:.*version|)[ \/]([\w.]+)/.exec(a)||/(msie) ([\w.]+)/.exec(a)||a.indexOf("compatible")<0&&/(mozilla)(?:.*? rv:([\w.]+)|)/.exec(a)||[];return{browser:b[1]||"",version:b[2]||"0"}},a=p.uaMatch(g.userAgent),b={},a.browser&&(b[a.browser]=!0,b.version=a.version),b.chrome?b.webkit=!0:b.webkit&&(b.safari=!0),p.browser=b,p.sub=function(){function a(b,c){return new a.fn.init(b,c)}p.extend(!0,a,this),a.superclass=this,a.fn=a.prototype=this(),a.fn.constructor=a,a.sub=this.sub,a.fn.init=function c(c,d){return d&&d instanceof p&&!(d instanceof a)&&(d=a(d)),p.fn.init.call(this,c,d,b)},a.fn.init.prototype=a.fn;var b=a(e);return a}}();var bH,bI,bJ,bK=/alpha\([^)]*\)/i,bL=/opacity=([^)]*)/,bM=/^(top|right|bottom|left)$/,bN=/^(none|table(?!-c[ea]).+)/,bO=/^margin/,bP=new RegExp("^("+q+")(.*)$","i"),bQ=new RegExp("^("+q+")(?!px)[a-z%]+$","i"),bR=new RegExp("^([-+])=("+q+")","i"),bS={},bT={position:"absolute",visibility:"hidden",display:"block"},bU={letterSpacing:0,fontWeight:400},bV=["Top","Right","Bottom","Left"],bW=["Webkit","O","Moz","ms"],bX=p.fn.toggle;p.fn.extend({css:function(a,c){return p.access(this,function(a,c,d){return d!==b?p.style(a,c,d):p.css(a,c)},a,c,arguments.length>1)},show:function(){return b$(this,!0)},hide:function(){return b$(this)},toggle:function(a,b){var c=typeof a=="boolean";return p.isFunction(a)&&p.isFunction(b)?bX.apply(this,arguments):this.each(function(){(c?a:bZ(this))?p(this).show():p(this).hide()})}}),p.extend({cssHooks:{opacity:{get:function(a,b){if(b){var c=bH(a,"opacity");return c===""?"1":c}}}},cssNumber:{fillOpacity:!0,fontWeight:!0,lineHeight:!0,opacity:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":p.support.cssFloat?"cssFloat":"styleFloat"},style:function(a,c,d,e){if(!a||a.nodeType===3||a.nodeType===8||!a.style)return;var f,g,h,i=p.camelCase(c),j=a.style;c=p.cssProps[i]||(p.cssProps[i]=bY(j,i)),h=p.cssHooks[c]||p.cssHooks[i];if(d===b)return h&&"get"in h&&(f=h.get(a,!1,e))!==b?f:j[c];g=typeof d,g==="string"&&(f=bR.exec(d))&&(d=(f[1]+1)*f[2]+parseFloat(p.css(a,c)),g="number");if(d==null||g==="number"&&isNaN(d))return;g==="number"&&!p.cssNumber[i]&&(d+="px");if(!h||!("set"in h)||(d=h.set(a,d,e))!==b)try{j[c]=d}catch(k){}},css:function(a,c,d,e){var f,g,h,i=p.camelCase(c);return c=p.cssProps[i]||(p.cssProps[i]=bY(a.style,i)),h=p.cssHooks[c]||p.cssHooks[i],h&&"get"in h&&(f=h.get(a,!0,e)),f===b&&(f=bH(a,c)),f==="normal"&&c in bU&&(f=bU[c]),d||e!==b?(g=parseFloat(f),d||p.isNumeric(g)?g||0:f):f},swap:function(a,b,c){var d,e,f={};for(e in b)f[e]=a.style[e],a.style[e]=b[e];d=c.call(a);for(e in b)a.style[e]=f[e];return d}}),a.getComputedStyle?bH=function(b,c){var d,e,f,g,h=a.getComputedStyle(b,null),i=b.style;return h&&(d=h[c],d===""&&!p.contains(b.ownerDocument,b)&&(d=p.style(b,c)),bQ.test(d)&&bO.test(c)&&(e=i.width,f=i.minWidth,g=i.maxWidth,i.minWidth=i.maxWidth=i.width=d,d=h.width,i.width=e,i.minWidth=f,i.maxWidth=g)),d}:e.documentElement.currentStyle&&(bH=function(a,b){var c,d,e=a.currentStyle&&a.currentStyle[b],f=a.style;return e==null&&f&&f[b]&&(e=f[b]),bQ.test(e)&&!bM.test(b)&&(c=f.left,d=a.runtimeStyle&&a.runtimeStyle.left,d&&(a.runtimeStyle.left=a.currentStyle.left),f.left=b==="fontSize"?"1em":e,e=f.pixelLeft+"px",f.left=c,d&&(a.runtimeStyle.left=d)),e===""?"auto":e}),p.each(["height","width"],function(a,b){p.cssHooks[b]={get:function(a,c,d){if(c)return a.offsetWidth===0&&bN.test(bH(a,"display"))?p.swap(a,bT,function(){return cb(a,b,d)}):cb(a,b,d)},set:function(a,c,d){return b_(a,c,d?ca(a,b,d,p.support.boxSizing&&p.css(a,"boxSizing")==="border-box"):0)}}}),p.support.opacity||(p.cssHooks.opacity={get:function(a,b){return bL.test((b&&a.currentStyle?a.currentStyle.filter:a.style.filter)||"")?.01*parseFloat(RegExp.$1)+"":b?"1":""},set:function(a,b){var c=a.style,d=a.currentStyle,e=p.isNumeric(b)?"alpha(opacity="+b*100+")":"",f=d&&d.filter||c.filter||"";c.zoom=1;if(b>=1&&p.trim(f.replace(bK,""))===""&&c.removeAttribute){c.removeAttribute("filter");if(d&&!d.filter)return}c.filter=bK.test(f)?f.replace(bK,e):f+" "+e}}),p(function(){p.support.reliableMarginRight||(p.cssHooks.marginRight={get:function(a,b){return p.swap(a,{display:"inline-block"},function(){if(b)return bH(a,"marginRight")})}}),!p.support.pixelPosition&&p.fn.position&&p.each(["top","left"],function(a,b){p.cssHooks[b]={get:function(a,c){if(c){var d=bH(a,b);return bQ.test(d)?p(a).position()[b]+"px":d}}}})}),p.expr&&p.expr.filters&&(p.expr.filters.hidden=function(a){return a.offsetWidth===0&&a.offsetHeight===0||!p.support.reliableHiddenOffsets&&(a.style&&a.style.display||bH(a,"display"))==="none"},p.expr.filters.visible=function(a){return!p.expr.filters.hidden(a)}),p.each({margin:"",padding:"",border:"Width"},function(a,b){p.cssHooks[a+b]={expand:function(c){var d,e=typeof c=="string"?c.split(" "):[c],f={};for(d=0;d<4;d++)f[a+bV[d]+b]=e[d]||e[d-2]||e[0];return f}},bO.test(a)||(p.cssHooks[a+b].set=b_)});var cd=/%20/g,ce=/\[\]$/,cf=/\r?\n/g,cg=/^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,ch=/^(?:select|textarea)/i;p.fn.extend({serialize:function(){return p.param(this.serializeArray())},serializeArray:function(){return this.map(function(){return this.elements?p.makeArray(this.elements):this}).filter(function(){return this.name&&!this.disabled&&(this.checked||ch.test(this.nodeName)||cg.test(this.type))}).map(function(a,b){var c=p(this).val();return c==null?null:p.isArray(c)?p.map(c,function(a,c){return{name:b.name,value:a.replace(cf,"\r\n")}}):{name:b.name,value:c.replace(cf,"\r\n")}}).get()}}),p.param=function(a,c){var d,e=[],f=function(a,b){b=p.isFunction(b)?b():b==null?"":b,e[e.length]=encodeURIComponent(a)+"="+encodeURIComponent(b)};c===b&&(c=p.ajaxSettings&&p.ajaxSettings.traditional);if(p.isArray(a)||a.jquery&&!p.isPlainObject(a))p.each(a,function(){f(this.name,this.value)});else for(d in a)ci(d,a[d],c,f);return e.join("&").replace(cd,"+")};var cj,ck,cl=/#.*$/,cm=/^(.*?):[ \t]*([^\r\n]*)\r?$/mg,cn=/^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/,co=/^(?:GET|HEAD)$/,cp=/^\/\//,cq=/\?/,cr=/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,cs=/([?&])_=[^&]*/,ct=/^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,cu=p.fn.load,cv={},cw={},cx=["*/"]+["*"];try{ck=f.href}catch(cy){ck=e.createElement("a"),ck.href="",ck=ck.href}cj=ct.exec(ck.toLowerCase())||[],p.fn.load=function(a,c,d){if(typeof a!="string"&&cu)return cu.apply(this,arguments);if(!this.length)return this;var e,f,g,h=this,i=a.indexOf(" ");return i>=0&&(e=a.slice(i,a.length),a=a.slice(0,i)),p.isFunction(c)?(d=c,c=b):c&&typeof c=="object"&&(f="POST"),p.ajax({url:a,type:f,dataType:"html",data:c,complete:function(a,b){d&&h.each(d,g||[a.responseText,b,a])}}).done(function(a){g=arguments,h.html(e?p("<div>").append(a.replace(cr,"")).find(e):a)}),this},p.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "),function(a,b){p.fn[b]=function(a){return this.on(b,a)}}),p.each(["get","post"],function(a,c){p[c]=function(a,d,e,f){return p.isFunction(d)&&(f=f||e,e=d,d=b),p.ajax({type:c,url:a,data:d,success:e,dataType:f})}}),p.extend({getScript:function(a,c){return p.get(a,b,c,"script")},getJSON:function(a,b,c){return p.get(a,b,c,"json")},ajaxSetup:function(a,b){return b?cB(a,p.ajaxSettings):(b=a,a=p.ajaxSettings),cB(a,b),a},ajaxSettings:{url:ck,isLocal:cn.test(cj[1]),global:!0,type:"GET",contentType:"application/x-www-form-urlencoded; charset=UTF-8",processData:!0,async:!0,accepts:{xml:"application/xml, text/xml",html:"text/html",text:"text/plain",json:"application/json, text/javascript","*":cx},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText"},converters:{"* text":a.String,"text html":!0,"text json":p.parseJSON,"text xml":p.parseXML},flatOptions:{context:!0,url:!0}},ajaxPrefilter:cz(cv),ajaxTransport:cz(cw),ajax:function(a,c){function y(a,c,f,i){var k,s,t,u,w,y=c;if(v===2)return;v=2,h&&clearTimeout(h),g=b,e=i||"",x.readyState=a>0?4:0,f&&(u=cC(l,x,f));if(a>=200&&a<300||a===304)l.ifModified&&(w=x.getResponseHeader("Last-Modified"),w&&(p.lastModified[d]=w),w=x.getResponseHeader("Etag"),w&&(p.etag[d]=w)),a===304?(y="notmodified",k=!0):(k=cD(l,u),y=k.state,s=k.data,t=k.error,k=!t);else{t=y;if(!y||a)y="error",a<0&&(a=0)}x.status=a,x.statusText=(c||y)+"",k?o.resolveWith(m,[s,y,x]):o.rejectWith(m,[x,y,t]),x.statusCode(r),r=b,j&&n.trigger("ajax"+(k?"Success":"Error"),[x,l,k?s:t]),q.fireWith(m,[x,y]),j&&(n.trigger("ajaxComplete",[x,l]),--p.active||p.event.trigger("ajaxStop"))}typeof a=="object"&&(c=a,a=b),c=c||{};var d,e,f,g,h,i,j,k,l=p.ajaxSetup({},c),m=l.context||l,n=m!==l&&(m.nodeType||m instanceof p)?p(m):p.event,o=p.Deferred(),q=p.Callbacks("once memory"),r=l.statusCode||{},t={},u={},v=0,w="canceled",x={readyState:0,setRequestHeader:function(a,b){if(!v){var c=a.toLowerCase();a=u[c]=u[c]||a,t[a]=b}return this},getAllResponseHeaders:function(){return v===2?e:null},getResponseHeader:function(a){var c;if(v===2){if(!f){f={};while(c=cm.exec(e))f[c[1].toLowerCase()]=c[2]}c=f[a.toLowerCase()]}return c===b?null:c},overrideMimeType:function(a){return v||(l.mimeType=a),this},abort:function(a){return a=a||w,g&&g.abort(a),y(0,a),this}};o.promise(x),x.success=x.done,x.error=x.fail,x.complete=q.add,x.statusCode=function(a){if(a){var b;if(v<2)for(b in a)r[b]=[r[b],a[b]];else b=a[x.status],x.always(b)}return this},l.url=((a||l.url)+"").replace(cl,"").replace(cp,cj[1]+"//"),l.dataTypes=p.trim(l.dataType||"*").toLowerCase().split(s),l.crossDomain==null&&(i=ct.exec(l.url.toLowerCase())||!1,l.crossDomain=i&&i.join(":")+(i[3]?"":i[1]==="http:"?80:443)!==cj.join(":")+(cj[3]?"":cj[1]==="http:"?80:443)),l.data&&l.processData&&typeof l.data!="string"&&(l.data=p.param(l.data,l.traditional)),cA(cv,l,c,x);if(v===2)return x;j=l.global,l.type=l.type.toUpperCase(),l.hasContent=!co.test(l.type),j&&p.active++===0&&p.event.trigger("ajaxStart");if(!l.hasContent){l.data&&(l.url+=(cq.test(l.url)?"&":"?")+l.data,delete l.data),d=l.url;if(l.cache===!1){var z=p.now(),A=l.url.replace(cs,"$1_="+z);l.url=A+(A===l.url?(cq.test(l.url)?"&":"?")+"_="+z:"")}}(l.data&&l.hasContent&&l.contentType!==!1||c.contentType)&&x.setRequestHeader("Content-Type",l.contentType),l.ifModified&&(d=d||l.url,p.lastModified[d]&&x.setRequestHeader("If-Modified-Since",p.lastModified[d]),p.etag[d]&&x.setRequestHeader("If-None-Match",p.etag[d])),x.setRequestHeader("Accept",l.dataTypes[0]&&l.accepts[l.dataTypes[0]]?l.accepts[l.dataTypes[0]]+(l.dataTypes[0]!=="*"?", "+cx+"; q=0.01":""):l.accepts["*"]);for(k in l.headers)x.setRequestHeader(k,l.headers[k]);if(!l.beforeSend||l.beforeSend.call(m,x,l)!==!1&&v!==2){w="abort";for(k in{success:1,error:1,complete:1})x[k](l[k]);g=cA(cw,l,c,x);if(!g)y(-1,"No Transport");else{x.readyState=1,j&&n.trigger("ajaxSend",[x,l]),l.async&&l.timeout>0&&(h=setTimeout(function(){x.abort("timeout")},l.timeout));try{v=1,g.send(t,y)}catch(B){if(v<2)y(-1,B);else throw B}}return x}return x.abort()},active:0,lastModified:{},etag:{}});var cE=[],cF=/\?/,cG=/(=)\?(?=&|$)|\?\?/,cH=p.now();p.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var a=cE.pop()||p.expando+"_"+cH++;return this[a]=!0,a}}),p.ajaxPrefilter("json jsonp",function(c,d,e){var f,g,h,i=c.data,j=c.url,k=c.jsonp!==!1,l=k&&cG.test(j),m=k&&!l&&typeof i=="string"&&!(c.contentType||"").indexOf("application/x-www-form-urlencoded")&&cG.test(i);if(c.dataTypes[0]==="jsonp"||l||m)return f=c.jsonpCallback=p.isFunction(c.jsonpCallback)?c.jsonpCallback():c.jsonpCallback,g=a[f],l?c.url=j.replace(cG,"$1"+f):m?c.data=i.replace(cG,"$1"+f):k&&(c.url+=(cF.test(j)?"&":"?")+c.jsonp+"="+f),c.converters["script json"]=function(){return h||p.error(f+" was not called"),h[0]},c.dataTypes[0]="json",a[f]=function(){h=arguments},e.always(function(){a[f]=g,c[f]&&(c.jsonpCallback=d.jsonpCallback,cE.push(f)),h&&p.isFunction(g)&&g(h[0]),h=g=b}),"script"}),p.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/javascript|ecmascript/},converters:{"text script":function(a){return p.globalEval(a),a}}}),p.ajaxPrefilter("script",function(a){a.cache===b&&(a.cache=!1),a.crossDomain&&(a.type="GET",a.global=!1)}),p.ajaxTransport("script",function(a){if(a.crossDomain){var c,d=e.head||e.getElementsByTagName("head")[0]||e.documentElement;return{send:function(f,g){c=e.createElement("script"),c.async="async",a.scriptCharset&&(c.charset=a.scriptCharset),c.src=a.url,c.onload=c.onreadystatechange=function(a,e){if(e||!c.readyState||/loaded|complete/.test(c.readyState))c.onload=c.onreadystatechange=null,d&&c.parentNode&&d.removeChild(c),c=b,e||g(200,"success")},d.insertBefore(c,d.firstChild)},abort:function(){c&&c.onload(0,1)}}}});var cI,cJ=a.ActiveXObject?function(){for(var a in cI)cI[a](0,1)}:!1,cK=0;p.ajaxSettings.xhr=a.ActiveXObject?function(){return!this.isLocal&&cL()||cM()}:cL,function(a){p.extend(p.support,{ajax:!!a,cors:!!a&&"withCredentials"in a})}(p.ajaxSettings.xhr()),p.support.ajax&&p.ajaxTransport(function(c){if(!c.crossDomain||p.support.cors){var d;return{send:function(e,f){var g,h,i=c.xhr();c.username?i.open(c.type,c.url,c.async,c.username,c.password):i.open(c.type,c.url,c.async);if(c.xhrFields)for(h in c.xhrFields)i[h]=c.xhrFields[h];c.mimeType&&i.overrideMimeType&&i.overrideMimeType(c.mimeType),!c.crossDomain&&!e["X-Requested-With"]&&(e["X-Requested-With"]="XMLHttpRequest");try{for(h in e)i.setRequestHeader(h,e[h])}catch(j){}i.send(c.hasContent&&c.data||null),d=function(a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cJ&&delete cI[g]);if(e)i.readyState!==4&&i.abort();else{h=i.status,k=i.getAllResponseHeaders(),l={},m=i.responseXML,m&&m.documentElement&&(l.xml=m);try{l.text=i.responseText}catch(a){}try{j=i.statusText}catch(n){j=""}!h&&c.isLocal&&!c.crossDomain?h=l.text?200:404:h===1223&&(h=204)}}}catch(o){e||f(-1,o)}l&&f(h,j,l,k)},c.async?i.readyState===4?setTimeout(d,0):(g=++cK,cJ&&(cI||(cI={},p(a).unload(cJ)),cI[g]=d),i.onreadystatechange=d):d()},abort:function(){d&&d(0,1)}}}});var cN,cO,cP=/^(?:toggle|show|hide)$/,cQ=new RegExp("^(?:([-+])=|)("+q+")([a-z%]*)$","i"),cR=/queueHooks$/,cS=[cY],cT={"*":[function(a,b){var c,d,e=this.createTween(a,b),f=cQ.exec(b),g=e.cur(),h=+g||0,i=1,j=20;if(f){c=+f[2],d=f[3]||(p.cssNumber[a]?"":"px");if(d!=="px"&&h){h=p.css(e.elem,a,!0)||c||1;do i=i||".5",h=h/i,p.style(e.elem,a,h+d);while(i!==(i=e.cur()/g)&&i!==1&&--j)}e.unit=d,e.start=h,e.end=f[1]?h+(f[1]+1)*c:c}return e}]};p.Animation=p.extend(cW,{tweener:function(a,b){p.isFunction(a)?(b=a,a=["*"]):a=a.split(" ");var c,d=0,e=a.length;for(;d<e;d++)c=a[d],cT[c]=cT[c]||[],cT[c].unshift(b)},prefilter:function(a,b){b?cS.unshift(a):cS.push(a)}}),p.Tween=cZ,cZ.prototype={constructor:cZ,init:function(a,b,c,d,e,f){this.elem=a,this.prop=c,this.easing=e||"swing",this.options=b,this.start=this.now=this.cur(),this.end=d,this.unit=f||(p.cssNumber[c]?"":"px")},cur:function(){var a=cZ.propHooks[this.prop];return a&&a.get?a.get(this):cZ.propHooks._default.get(this)},run:function(a){var b,c=cZ.propHooks[this.prop];return this.options.duration?this.pos=b=p.easing[this.easing](a,this.options.duration*a,0,1,this.options.duration):this.pos=b=a,this.now=(this.end-this.start)*b+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),c&&c.set?c.set(this):cZ.propHooks._default.set(this),this}},cZ.prototype.init.prototype=cZ.prototype,cZ.propHooks={_default:{get:function(a){var b;return a.elem[a.prop]==null||!!a.elem.style&&a.elem.style[a.prop]!=null?(b=p.css(a.elem,a.prop,!1,""),!b||b==="auto"?0:b):a.elem[a.prop]},set:function(a){p.fx.step[a.prop]?p.fx.step[a.prop](a):a.elem.style&&(a.elem.style[p.cssProps[a.prop]]!=null||p.cssHooks[a.prop])?p.style(a.elem,a.prop,a.now+a.unit):a.elem[a.prop]=a.now}}},cZ.propHooks.scrollTop=cZ.propHooks.scrollLeft={set:function(a){a.elem.nodeType&&a.elem.parentNode&&(a.elem[a.prop]=a.now)}},p.each(["toggle","show","hide"],function(a,b){var c=p.fn[b];p.fn[b]=function(d,e,f){return d==null||typeof d=="boolean"||!a&&p.isFunction(d)&&p.isFunction(e)?c.apply(this,arguments):this.animate(c$(b,!0),d,e,f)}}),p.fn.extend({fadeTo:function(a,b,c,d){return this.filter(bZ).css("opacity",0).show().end().animate({opacity:b},a,c,d)},animate:function(a,b,c,d){var e=p.isEmptyObject(a),f=p.speed(b,c,d),g=function(){var b=cW(this,p.extend({},a),f);e&&b.stop(!0)};return e||f.queue===!1?this.each(g):this.queue(f.queue,g)},stop:function(a,c,d){var e=function(a){var b=a.stop;delete a.stop,b(d)};return typeof a!="string"&&(d=c,c=a,a=b),c&&a!==!1&&this.queue(a||"fx",[]),this.each(function(){var b=!0,c=a!=null&&a+"queueHooks",f=p.timers,g=p._data(this);if(c)g[c]&&g[c].stop&&e(g[c]);else for(c in g)g[c]&&g[c].stop&&cR.test(c)&&e(g[c]);for(c=f.length;c--;)f[c].elem===this&&(a==null||f[c].queue===a)&&(f[c].anim.stop(d),b=!1,f.splice(c,1));(b||!d)&&p.dequeue(this,a)})}}),p.each({slideDown:c$("show"),slideUp:c$("hide"),slideToggle:c$("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(a,b){p.fn[a]=function(a,c,d){return this.animate(b,a,c,d)}}),p.speed=function(a,b,c){var d=a&&typeof a=="object"?p.extend({},a):{complete:c||!c&&b||p.isFunction(a)&&a,duration:a,easing:c&&b||b&&!p.isFunction(b)&&b};d.duration=p.fx.off?0:typeof d.duration=="number"?d.duration:d.duration in p.fx.speeds?p.fx.speeds[d.duration]:p.fx.speeds._default;if(d.queue==null||d.queue===!0)d.queue="fx";return d.old=d.complete,d.complete=function(){p.isFunction(d.old)&&d.old.call(this),d.queue&&p.dequeue(this,d.queue)},d},p.easing={linear:function(a){return a},swing:function(a){return.5-Math.cos(a*Math.PI)/2}},p.timers=[],p.fx=cZ.prototype.init,p.fx.tick=function(){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.stop()},p.fx.timer=function(a){a()&&p.timers.push(a)&&!cO&&(cO=setInterval(p.fx.tick,p.fx.interval))},p.fx.interval=13,p.fx.stop=function(){clearInterval(cO),cO=null},p.fx.speeds={slow:600,fast:200,_default:400},p.fx.step={},p.expr&&p.expr.filters&&(p.expr.filters.animated=function(a){return p.grep(p.timers,function(b){return a===b.elem}).length});var c_=/^(?:body|html)$/i;p.fn.offset=function(a){if(arguments.length)return a===b?this:this.each(function(b){p.offset.setOffset(this,a,b)});var c,d,e,f,g,h,i,j={top:0,left:0},k=this[0],l=k&&k.ownerDocument;if(!l)return;return(d=l.body)===k?p.offset.bodyOffset(k):(c=l.documentElement,p.contains(c,k)?(typeof k.getBoundingClientRect!="undefined"&&(j=k.getBoundingClientRect()),e=da(l),f=c.clientTop||d.clientTop||0,g=c.clientLeft||d.clientLeft||0,h=e.pageYOffset||c.scrollTop,i=e.pageXOffset||c.scrollLeft,{top:j.top+h-f,left:j.left+i-g}):j)},p.offset={bodyOffset:function(a){var b=a.offsetTop,c=a.offsetLeft;return p.support.doesNotIncludeMarginInBodyOffset&&(b+=parseFloat(p.css(a,"marginTop"))||0,c+=parseFloat(p.css(a,"marginLeft"))||0),{top:b,left:c}},setOffset:function(a,b,c){var d=p.css(a,"position");d==="static"&&(a.style.position="relative");var e=p(a),f=e.offset(),g=p.css(a,"top"),h=p.css(a,"left"),i=(d==="absolute"||d==="fixed")&&p.inArray("auto",[g,h])>-1,j={},k={},l,m;i?(k=e.position(),l=k.top,m=k.left):(l=parseFloat(g)||0,m=parseFloat(h)||0),p.isFunction(b)&&(b=b.call(a,c,f)),b.top!=null&&(j.top=b.top-f.top+l),b.left!=null&&(j.left=b.left-f.left+m),"using"in b?b.using.call(a,j):e.css(j)}},p.fn.extend({position:function(){if(!this[0])return;var a=this[0],b=this.offsetParent(),c=this.offset(),d=c_.test(b[0].nodeName)?{top:0,left:0}:b.offset();return c.top-=parseFloat(p.css(a,"marginTop"))||0,c.left-=parseFloat(p.css(a,"marginLeft"))||0,d.top+=parseFloat(p.css(b[0],"borderTopWidth"))||0,d.left+=parseFloat(p.css(b[0],"borderLeftWidth"))||0,{top:c.top-d.top,left:c.left-d.left}},offsetParent:function(){return this.map(function(){var a=this.offsetParent||e.body;while(a&&!c_.test(a.nodeName)&&p.css(a,"position")==="static")a=a.offsetParent;return a||e.body})}}),p.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(a,c){var d=/Y/.test(c);p.fn[a]=function(e){return p.access(this,function(a,e,f){var g=da(a);if(f===b)return g?c in g?g[c]:g.document.documentElement[e]:a[e];g?g.scrollTo(d?p(g).scrollLeft():f,d?f:p(g).scrollTop()):a[e]=f},a,e,arguments.length,null)}}),p.each({Height:"height",Width:"width"},function(a,c){p.each({padding:"inner"+a,content:c,"":"outer"+a},function(d,e){p.fn[e]=function(e,f){var g=arguments.length&&(d||typeof e!="boolean"),h=d||(e===!0||f===!0?"margin":"border");return p.access(this,function(c,d,e){var f;return p.isWindow(c)?c.document.documentElement["client"+a]:c.nodeType===9?(f=c.documentElement,Math.max(c.body["scroll"+a],f["scroll"+a],c.body["offset"+a],f["offset"+a],f["client"+a])):e===b?p.css(c,d,e,h):p.style(c,d,e,h)},c,g?e:b,g,null)}})}),a.jQuery=a.$=p,typeof define=="function"&&define.amd&&define.amd.jQuery&&define("jquery",[],function(){return p})})(window);
/*! RESOURCE: /scripts/lib/jquery/jquery_no_conflict.js */
(function() {
if (window.$j_glide) {
jQuery.noConflict(true);
window.jQuery = $j_glide;
}
window.$j = window.$j_glide = jQuery.noConflict();
})();
;
/*! RESOURCE: /scripts/core/jquery.ui.custom.min.js */
/*! jQuery UI - v1.9.0 - 2012-10-19
* http://jqueryui.com
* Includes: jquery.ui.core.js, jquery.ui.widget.js, jquery.ui.mouse.js, jquery.ui.draggable.js
* Copyright (c) 2012 jQuery Foundation and other contributors Licensed MIT */

(function(e,t){function i(t,n){var r,i,o,u=t.nodeName.toLowerCase();return"area"===u?(r=t.parentNode,i=r.name,!t.href||!i||r.nodeName.toLowerCase()!=="map"?!1:(o=e("img[usemap=#"+i+"]")[0],!!o&&s(o))):(/input|select|textarea|button|object/.test(u)?!t.disabled:"a"===u?t.href||n:n)&&s(t)}function s(t){return!e(t).parents().andSelf().filter(function(){return e.css(this,"visibility")==="hidden"||e.expr.filters.hidden(this)}).length}var n=0,r=/^ui-id-\d+$/;e.ui=e.ui||{};if(e.ui.version)return;e.extend(e.ui,{version:"1.9.0",keyCode:{BACKSPACE:8,COMMA:188,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,NUMPAD_ADD:107,NUMPAD_DECIMAL:110,NUMPAD_DIVIDE:111,NUMPAD_ENTER:108,NUMPAD_MULTIPLY:106,NUMPAD_SUBTRACT:109,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SPACE:32,TAB:9,UP:38}}),e.fn.extend({_focus:e.fn.focus,focus:function(t,n){return typeof t=="number"?this.each(function(){var r=this;setTimeout(function(){e(r).focus(),n&&n.call(r)},t)}):this._focus.apply(this,arguments)},scrollParent:function(){var t;return e.browser.msie&&/(static|relative)/.test(this.css("position"))||/absolute/.test(this.css("position"))?t=this.parents().filter(function(){return/(relative|absolute|fixed)/.test(e.css(this,"position"))&&/(auto|scroll)/.test(e.css(this,"overflow")+e.css(this,"overflow-y")+e.css(this,"overflow-x"))}).eq(0):t=this.parents().filter(function(){return/(auto|scroll)/.test(e.css(this,"overflow")+e.css(this,"overflow-y")+e.css(this,"overflow-x"))}).eq(0),/fixed/.test(this.css("position"))||!t.length?e(document):t},zIndex:function(n){if(n!==t)return this.css("zIndex",n);if(this.length){var r=e(this[0]),i,s;while(r.length&&r[0]!==document){i=r.css("position");if(i==="absolute"||i==="relative"||i==="fixed"){s=parseInt(r.css("zIndex"),10);if(!isNaN(s)&&s!==0)return s}r=r.parent()}}return 0},uniqueId:function(){return this.each(function(){this.id||(this.id="ui-id-"+ ++n)})},removeUniqueId:function(){return this.each(function(){r.test(this.id)&&e(this).removeAttr("id")})}}),e("<a>").outerWidth(1).jquery||e.each(["Width","Height"],function(n,r){function u(t,n,r,s){return e.each(i,function(){n-=parseFloat(e.css(t,"padding"+this))||0,r&&(n-=parseFloat(e.css(t,"border"+this+"Width"))||0),s&&(n-=parseFloat(e.css(t,"margin"+this))||0)}),n}var i=r==="Width"?["Left","Right"]:["Top","Bottom"],s=r.toLowerCase(),o={innerWidth:e.fn.innerWidth,innerHeight:e.fn.innerHeight,outerWidth:e.fn.outerWidth,outerHeight:e.fn.outerHeight};e.fn["inner"+r]=function(n){return n===t?o["inner"+r].call(this):this.each(function(){e(this).css(s,u(this,n)+"px")})},e.fn["outer"+r]=function(t,n){return typeof t!="number"?o["outer"+r].call(this,t):this.each(function(){e(this).css(s,u(this,t,!0,n)+"px")})}}),e.extend(e.expr[":"],{data:e.expr.createPseudo?e.expr.createPseudo(function(t){return function(n){return!!e.data(n,t)}}):function(t,n,r){return!!e.data(t,r[3])},focusable:function(t){return i(t,!isNaN(e.attr(t,"tabindex")))},tabbable:function(t){var n=e.attr(t,"tabindex"),r=isNaN(n);return(r||n>=0)&&i(t,!r)}}),e(function(){var t=document.body,n=t.appendChild(n=document.createElement("div"));n.offsetHeight,e.extend(n.style,{minHeight:"100px",height:"auto",padding:0,borderWidth:0}),e.support.minHeight=n.offsetHeight===100,e.support.selectstart="onselectstart"in n,t.removeChild(n).style.display="none"}),e.fn.extend({disableSelection:function(){return this.bind((e.support.selectstart?"selectstart":"mousedown")+".ui-disableSelection",function(e){e.preventDefault()})},enableSelection:function(){return this.unbind(".ui-disableSelection")}}),e.extend(e.ui,{plugin:{add:function(t,n,r){var i,s=e.ui[t].prototype;for(i in r)s.plugins[i]=s.plugins[i]||[],s.plugins[i].push([n,r[i]])},call:function(e,t,n){var r,i=e.plugins[t];if(!i||!e.element[0].parentNode||e.element[0].parentNode.nodeType===11)return;for(r=0;r<i.length;r++)e.options[i[r][0]]&&i[r][1].apply(e.element,n)}},contains:e.contains,hasScroll:function(t,n){if(e(t).css("overflow")==="hidden")return!1;var r=n&&n==="left"?"scrollLeft":"scrollTop",i=!1;return t[r]>0?!0:(t[r]=1,i=t[r]>0,t[r]=0,i)},isOverAxis:function(e,t,n){return e>t&&e<t+n},isOver:function(t,n,r,i,s,o){return e.ui.isOverAxis(t,r,s)&&e.ui.isOverAxis(n,i,o)}})})(jQuery);(function(e,t){var n=0,r=Array.prototype.slice,i=e.cleanData;e.cleanData=function(t){for(var n=0,r;(r=t[n])!=null;n++)try{e(r).triggerHandler("remove")}catch(s){}i(t)},e.widget=function(t,n,r){var i,s,o,u,a=t.split(".")[0];t=t.split(".")[1],i=a+"-"+t,r||(r=n,n=e.Widget),e.expr[":"][i.toLowerCase()]=function(t){return!!e.data(t,i)},e[a]=e[a]||{},s=e[a][t],o=e[a][t]=function(e,t){if(!this._createWidget)return new o(e,t);arguments.length&&this._createWidget(e,t)},e.extend(o,s,{version:r.version,_proto:e.extend({},r),_childConstructors:[]}),u=new n,u.options=e.widget.extend({},u.options),e.each(r,function(t,i){e.isFunction(i)&&(r[t]=function(){var e=function(){return n.prototype[t].apply(this,arguments)},r=function(e){return n.prototype[t].apply(this,e)};return function(){var t=this._super,n=this._superApply,s;return this._super=e,this._superApply=r,s=i.apply(this,arguments),this._super=t,this._superApply=n,s}}())}),o.prototype=e.widget.extend(u,{widgetEventPrefix:t},r,{constructor:o,namespace:a,widgetName:t,widgetBaseClass:i,widgetFullName:i}),s?(e.each(s._childConstructors,function(t,n){var r=n.prototype;e.widget(r.namespace+"."+r.widgetName,o,n._proto)}),delete s._childConstructors):n._childConstructors.push(o),e.widget.bridge(t,o)},e.widget.extend=function(n){var i=r.call(arguments,1),s=0,o=i.length,u,a;for(;s<o;s++)for(u in i[s])a=i[s][u],i[s].hasOwnProperty(u)&&a!==t&&(n[u]=e.isPlainObject(a)?e.widget.extend({},n[u],a):a);return n},e.widget.bridge=function(n,i){var s=i.prototype.widgetFullName;e.fn[n]=function(o){var u=typeof o=="string",a=r.call(arguments,1),f=this;return o=!u&&a.length?e.widget.extend.apply(null,[o].concat(a)):o,u?this.each(function(){var r,i=e.data(this,s);if(!i)return e.error("cannot call methods on "+n+" prior to initialization; "+"attempted to call method '"+o+"'");if(!e.isFunction(i[o])||o.charAt(0)==="_")return e.error("no such method '"+o+"' for "+n+" widget instance");r=i[o].apply(i,a);if(r!==i&&r!==t)return f=r&&r.jquery?f.pushStack(r.get()):r,!1}):this.each(function(){var t=e.data(this,s);t?t.option(o||{})._init():new i(o,this)}),f}},e.Widget=function(e,t){},e.Widget._childConstructors=[],e.Widget.prototype={widgetName:"widget",widgetEventPrefix:"",defaultElement:"<div>",options:{disabled:!1,create:null},_createWidget:function(t,r){r=e(r||this.defaultElement||this)[0],this.element=e(r),this.uuid=n++,this.eventNamespace="."+this.widgetName+this.uuid,this.options=e.widget.extend({},this.options,this._getCreateOptions(),t),this.bindings=e(),this.hoverable=e(),this.focusable=e(),r!==this&&(e.data(r,this.widgetName,this),e.data(r,this.widgetFullName,this),this._on({remove:"destroy"}),this.document=e(r.style?r.ownerDocument:r.document||r),this.window=e(this.document[0].defaultView||this.document[0].parentWindow)),this._create(),this._trigger("create",null,this._getCreateEventData()),this._init()},_getCreateOptions:e.noop,_getCreateEventData:e.noop,_create:e.noop,_init:e.noop,destroy:function(){this._destroy(),this.element.unbind(this.eventNamespace).removeData(this.widgetName).removeData(this.widgetFullName).removeData(e.camelCase(this.widgetFullName)),this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName+"-disabled "+"ui-state-disabled"),this.bindings.unbind(this.eventNamespace),this.hoverable.removeClass("ui-state-hover"),this.focusable.removeClass("ui-state-focus")},_destroy:e.noop,widget:function(){return this.element},option:function(n,r){var i=n,s,o,u;if(arguments.length===0)return e.widget.extend({},this.options);if(typeof n=="string"){i={},s=n.split("."),n=s.shift();if(s.length){o=i[n]=e.widget.extend({},this.options[n]);for(u=0;u<s.length-1;u++)o[s[u]]=o[s[u]]||{},o=o[s[u]];n=s.pop();if(r===t)return o[n]===t?null:o[n];o[n]=r}else{if(r===t)return this.options[n]===t?null:this.options[n];i[n]=r}}return this._setOptions(i),this},_setOptions:function(e){var t;for(t in e)this._setOption(t,e[t]);return this},_setOption:function(e,t){return this.options[e]=t,e==="disabled"&&(this.widget().toggleClass(this.widgetFullName+"-disabled ui-state-disabled",!!t).attr("aria-disabled",t),this.hoverable.removeClass("ui-state-hover"),this.focusable.removeClass("ui-state-focus")),this},enable:function(){return this._setOption("disabled",!1)},disable:function(){return this._setOption("disabled",!0)},_on:function(t,n){n?(t=e(t),this.bindings=this.bindings.add(t)):(n=t,t=this.element);var r=this;e.each(n,function(n,i){function s(){if(r.options.disabled===!0||e(this).hasClass("ui-state-disabled"))return;return(typeof i=="string"?r[i]:i).apply(r,arguments)}typeof i!="string"&&(s.guid=i.guid=i.guid||s.guid||e.guid++);var o=n.match(/^(\w+)\s*(.*)$/),u=o[1]+r.eventNamespace,a=o[2];a?r.widget().delegate(a,u,s):t.bind(u,s)})},_off:function(e,t){t=(t||"").split(" ").join(this.eventNamespace+" ")+this.eventNamespace,e.unbind(t).undelegate(t)},_delay:function(e,t){function n(){return(typeof e=="string"?r[e]:e).apply(r,arguments)}var r=this;return setTimeout(n,t||0)},_hoverable:function(t){this.hoverable=this.hoverable.add(t),this._on(t,{mouseenter:function(t){e(t.currentTarget).addClass("ui-state-hover")},mouseleave:function(t){e(t.currentTarget).removeClass("ui-state-hover")}})},_focusable:function(t){this.focusable=this.focusable.add(t),this._on(t,{focusin:function(t){e(t.currentTarget).addClass("ui-state-focus")},focusout:function(t){e(t.currentTarget).removeClass("ui-state-focus")}})},_trigger:function(t,n,r){var i,s,o=this.options[t];r=r||{},n=e.Event(n),n.type=(t===this.widgetEventPrefix?t:this.widgetEventPrefix+t).toLowerCase(),n.target=this.element[0],s=n.originalEvent;if(s)for(i in s)i in n||(n[i]=s[i]);return this.element.trigger(n,r),!(e.isFunction(o)&&o.apply(this.element[0],[n].concat(r))===!1||n.isDefaultPrevented())}},e.each({show:"fadeIn",hide:"fadeOut"},function(t,n){e.Widget.prototype["_"+t]=function(r,i,s){typeof i=="string"&&(i={effect:i});var o,u=i?i===!0||typeof i=="number"?n:i.effect||n:t;i=i||{},typeof i=="number"&&(i={duration:i}),o=!e.isEmptyObject(i),i.complete=s,i.delay&&r.delay(i.delay),o&&e.effects&&(e.effects.effect[u]||e.uiBackCompat!==!1&&e.effects[u])?r[t](i):u!==t&&r[u]?r[u](i.duration,i.easing,s):r.queue(function(n){e(this)[t](),s&&s.call(r[0]),n()})}}),e.uiBackCompat!==!1&&(e.Widget.prototype._getCreateOptions=function(){return e.metadata&&e.metadata.get(this.element[0])[this.widgetName]})})(jQuery);(function(e,t){var n=!1;e(document).mouseup(function(e){n=!1}),e.widget("ui.mouse",{version:"1.9.0",options:{cancel:"input,textarea,button,select,option",distance:1,delay:0},_mouseInit:function(){var t=this;this.element.bind("mousedown."+this.widgetName,function(e){return t._mouseDown(e)}).bind("click."+this.widgetName,function(n){if(!0===e.data(n.target,t.widgetName+".preventClickEvent"))return e.removeData(n.target,t.widgetName+".preventClickEvent"),n.stopImmediatePropagation(),!1}),this.started=!1},_mouseDestroy:function(){this.element.unbind("."+this.widgetName),this._mouseMoveDelegate&&e(document).unbind("mousemove."+this.widgetName,this._mouseMoveDelegate).unbind("mouseup."+this.widgetName,this._mouseUpDelegate)},_mouseDown:function(t){if(n)return;this._mouseStarted&&this._mouseUp(t),this._mouseDownEvent=t;var r=this,i=t.which===1,s=typeof this.options.cancel=="string"&&t.target.nodeName?e(t.target).closest(this.options.cancel).length:!1;if(!i||s||!this._mouseCapture(t))return!0;this.mouseDelayMet=!this.options.delay,this.mouseDelayMet||(this._mouseDelayTimer=setTimeout(function(){r.mouseDelayMet=!0},this.options.delay));if(this._mouseDistanceMet(t)&&this._mouseDelayMet(t)){this._mouseStarted=this._mouseStart(t)!==!1;if(!this._mouseStarted)return t.preventDefault(),!0}return!0===e.data(t.target,this.widgetName+".preventClickEvent")&&e.removeData(t.target,this.widgetName+".preventClickEvent"),this._mouseMoveDelegate=function(e){return r._mouseMove(e)},this._mouseUpDelegate=function(e){return r._mouseUp(e)},e(document).bind("mousemove."+this.widgetName,this._mouseMoveDelegate).bind("mouseup."+this.widgetName,this._mouseUpDelegate),t.preventDefault(),n=!0,!0},_mouseMove:function(t){return!e.browser.msie||document.documentMode>=9||!!t.button?this._mouseStarted?(this._mouseDrag(t),t.preventDefault()):(this._mouseDistanceMet(t)&&this._mouseDelayMet(t)&&(this._mouseStarted=this._mouseStart(this._mouseDownEvent,t)!==!1,this._mouseStarted?this._mouseDrag(t):this._mouseUp(t)),!this._mouseStarted):this._mouseUp(t)},_mouseUp:function(t){return e(document).unbind("mousemove."+this.widgetName,this._mouseMoveDelegate).unbind("mouseup."+this.widgetName,this._mouseUpDelegate),this._mouseStarted&&(this._mouseStarted=!1,t.target===this._mouseDownEvent.target&&e.data(t.target,this.widgetName+".preventClickEvent",!0),this._mouseStop(t)),!1},_mouseDistanceMet:function(e){return Math.max(Math.abs(this._mouseDownEvent.pageX-e.pageX),Math.abs(this._mouseDownEvent.pageY-e.pageY))>=this.options.distance},_mouseDelayMet:function(e){return this.mouseDelayMet},_mouseStart:function(e){},_mouseDrag:function(e){},_mouseStop:function(e){},_mouseCapture:function(e){return!0}})})(jQuery);(function(e,t){e.widget("ui.draggable",e.ui.mouse,{version:"1.9.0",widgetEventPrefix:"drag",options:{addClasses:!0,appendTo:"parent",axis:!1,connectToSortable:!1,containment:!1,cursor:"auto",cursorAt:!1,grid:!1,handle:!1,helper:"original",iframeFix:!1,opacity:!1,refreshPositions:!1,revert:!1,revertDuration:500,scope:"default",scroll:!0,scrollSensitivity:20,scrollSpeed:20,snap:!1,snapMode:"both",snapTolerance:20,stack:!1,zIndex:!1},_create:function(){this.options.helper=="original"&&!/^(?:r|a|f)/.test(this.element.css("position"))&&(this.element[0].style.position="relative"),this.options.addClasses&&this.element.addClass("ui-draggable"),this.options.disabled&&this.element.addClass("ui-draggable-disabled"),this._mouseInit()},_destroy:function(){this.element.removeClass("ui-draggable ui-draggable-dragging ui-draggable-disabled"),this._mouseDestroy()},_mouseCapture:function(t){var n=this.options;return this.helper||n.disabled||e(t.target).is(".ui-resizable-handle")?!1:(this.handle=this._getHandle(t),this.handle?(e(n.iframeFix===!0?"iframe":n.iframeFix).each(function(){e('<div class="ui-draggable-iframeFix" style="background: #fff;"></div>').css({width:this.offsetWidth+"px",height:this.offsetHeight+"px",position:"absolute",opacity:"0.001",zIndex:1e3}).css(e(this).offset()).appendTo("body")}),!0):!1)},_mouseStart:function(t){var n=this.options;return this.helper=this._createHelper(t),this.helper.addClass("ui-draggable-dragging"),this._cacheHelperProportions(),e.ui.ddmanager&&(e.ui.ddmanager.current=this),this._cacheMargins(),this.cssPosition=this.helper.css("position"),this.scrollParent=this.helper.scrollParent(),this.offset=this.positionAbs=this.element.offset(),this.offset={top:this.offset.top-this.margins.top,left:this.offset.left-this.margins.left},e.extend(this.offset,{click:{left:t.pageX-this.offset.left,top:t.pageY-this.offset.top},parent:this._getParentOffset(),relative:this._getRelativeOffset()}),this.originalPosition=this.position=this._generatePosition(t),this.originalPageX=t.pageX,this.originalPageY=t.pageY,n.cursorAt&&this._adjustOffsetFromHelper(n.cursorAt),n.containment&&this._setContainment(),this._trigger("start",t)===!1?(this._clear(),!1):(this._cacheHelperProportions(),e.ui.ddmanager&&!n.dropBehaviour&&e.ui.ddmanager.prepareOffsets(this,t),this._mouseDrag(t,!0),e.ui.ddmanager&&e.ui.ddmanager.dragStart(this,t),!0)},_mouseDrag:function(t,n){this.position=this._generatePosition(t),this.positionAbs=this._convertPositionTo("absolute");if(!n){var r=this._uiHash();if(this._trigger("drag",t,r)===!1)return this._mouseUp({}),!1;this.position=r.position}if(!this.options.axis||this.options.axis!="y")this.helper[0].style.left=this.position.left+"px";if(!this.options.axis||this.options.axis!="x")this.helper[0].style.top=this.position.top+"px";return e.ui.ddmanager&&e.ui.ddmanager.drag(this,t),!1},_mouseStop:function(t){var n=!1;e.ui.ddmanager&&!this.options.dropBehaviour&&(n=e.ui.ddmanager.drop(this,t)),this.dropped&&(n=this.dropped,this.dropped=!1);var r=this.element[0],i=!1;while(r&&(r=r.parentNode))r==document&&(i=!0);if(!i&&this.options.helper==="original")return!1;if(this.options.revert=="invalid"&&!n||this.options.revert=="valid"&&n||this.options.revert===!0||e.isFunction(this.options.revert)&&this.options.revert.call(this.element,n)){var s=this;e(this.helper).animate(this.originalPosition,parseInt(this.options.revertDuration,10),function(){s._trigger("stop",t)!==!1&&s._clear()})}else this._trigger("stop",t)!==!1&&this._clear();return!1},_mouseUp:function(t){return e("div.ui-draggable-iframeFix").each(function(){this.parentNode.removeChild(this)}),e.ui.ddmanager&&e.ui.ddmanager.dragStop(this,t),e.ui.mouse.prototype._mouseUp.call(this,t)},cancel:function(){return this.helper.is(".ui-draggable-dragging")?this._mouseUp({}):this._clear(),this},_getHandle:function(t){var n=!this.options.handle||!e(this.options.handle,this.element).length?!0:!1;return e(this.options.handle,this.element).find("*").andSelf().each(function(){this==t.target&&(n=!0)}),n},_createHelper:function(t){var n=this.options,r=e.isFunction(n.helper)?e(n.helper.apply(this.element[0],[t])):n.helper=="clone"?this.element.clone().removeAttr("id"):this.element;return r.parents("body").length||r.appendTo(n.appendTo=="parent"?this.element[0].parentNode:n.appendTo),r[0]!=this.element[0]&&!/(fixed|absolute)/.test(r.css("position"))&&r.css("position","absolute"),r},_adjustOffsetFromHelper:function(t){typeof t=="string"&&(t=t.split(" ")),e.isArray(t)&&(t={left:+t[0],top:+t[1]||0}),"left"in t&&(this.offset.click.left=t.left+this.margins.left),"right"in t&&(this.offset.click.left=this.helperProportions.width-t.right+this.margins.left),"top"in t&&(this.offset.click.top=t.top+this.margins.top),"bottom"in t&&(this.offset.click.top=this.helperProportions.height-t.bottom+this.margins.top)},_getParentOffset:function(){this.offsetParent=this.helper.offsetParent();var t=this.offsetParent.offset();this.cssPosition=="absolute"&&this.scrollParent[0]!=document&&e.contains(this.scrollParent[0],this.offsetParent[0])&&(t.left+=this.scrollParent.scrollLeft(),t.top+=this.scrollParent.scrollTop());if(this.offsetParent[0]==document.body||this.offsetParent[0].tagName&&this.offsetParent[0].tagName.toLowerCase()=="html"&&e.browser.msie)t={top:0,left:0};return{top:t.top+(parseInt(this.offsetParent.css("borderTopWidth"),10)||0),left:t.left+(parseInt(this.offsetParent.css("borderLeftWidth"),10)||0)}},_getRelativeOffset:function(){if(this.cssPosition=="relative"){var e=this.element.position();return{top:e.top-(parseInt(this.helper.css("top"),10)||0)+this.scrollParent.scrollTop(),left:e.left-(parseInt(this.helper.css("left"),10)||0)+this.scrollParent.scrollLeft()}}return{top:0,left:0}},_cacheMargins:function(){this.margins={left:parseInt(this.element.css("marginLeft"),10)||0,top:parseInt(this.element.css("marginTop"),10)||0,right:parseInt(this.element.css("marginRight"),10)||0,bottom:parseInt(this.element.css("marginBottom"),10)||0}},_cacheHelperProportions:function(){this.helperProportions={width:this.helper.outerWidth(),height:this.helper.outerHeight()}},_setContainment:function(){var t=this.options;t.containment=="parent"&&(t.containment=this.helper[0].parentNode);if(t.containment=="document"||t.containment=="window")this.containment=[t.containment=="document"?0:e(window).scrollLeft()-this.offset.relative.left-this.offset.parent.left,t.containment=="document"?0:e(window).scrollTop()-this.offset.relative.top-this.offset.parent.top,(t.containment=="document"?0:e(window).scrollLeft())+e(t.containment=="document"?document:window).width()-this.helperProportions.width-this.margins.left,(t.containment=="document"?0:e(window).scrollTop())+(e(t.containment=="document"?document:window).height()||document.body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top];if(!/^(document|window|parent)$/.test(t.containment)&&t.containment.constructor!=Array){var n=e(t.containment),r=n[0];if(!r)return;var i=n.offset(),s=e(r).css("overflow")!="hidden";this.containment=[(parseInt(e(r).css("borderLeftWidth"),10)||0)+(parseInt(e(r).css("paddingLeft"),10)||0),(parseInt(e(r).css("borderTopWidth"),10)||0)+(parseInt(e(r).css("paddingTop"),10)||0),(s?Math.max(r.scrollWidth,r.offsetWidth):r.offsetWidth)-(parseInt(e(r).css("borderLeftWidth"),10)||0)-(parseInt(e(r).css("paddingRight"),10)||0)-this.helperProportions.width-this.margins.left-this.margins.right,(s?Math.max(r.scrollHeight,r.offsetHeight):r.offsetHeight)-(parseInt(e(r).css("borderTopWidth"),10)||0)-(parseInt(e(r).css("paddingBottom"),10)||0)-this.helperProportions.height-this.margins.top-this.margins.bottom],this.relative_container=n}else t.containment.constructor==Array&&(this.containment=t.containment)},_convertPositionTo:function(t,n){n||(n=this.position);var r=t=="absolute"?1:-1,i=this.options,s=this.cssPosition!="absolute"||this.scrollParent[0]!=document&&!!e.contains(this.scrollParent[0],this.offsetParent[0])?this.scrollParent:this.offsetParent,o=/(html|body)/i.test(s[0].tagName);return{top:n.top+this.offset.relative.top*r+this.offset.parent.top*r-(this.cssPosition=="fixed"?-this.scrollParent.scrollTop():o?0:s.scrollTop())*r,left:n.left+this.offset.relative.left*r+this.offset.parent.left*r-(this.cssPosition=="fixed"?-this.scrollParent.scrollLeft():o?0:s.scrollLeft())*r}},_generatePosition:function(t){var n=this.options,r=this.cssPosition!="absolute"||this.scrollParent[0]!=document&&!!e.contains(this.scrollParent[0],this.offsetParent[0])?this.scrollParent:this.offsetParent,i=/(html|body)/i.test(r[0].tagName),s=t.pageX,o=t.pageY;if(this.originalPosition){var u;if(this.containment){if(this.relative_container){var a=this.relative_container.offset();u=[this.containment[0]+a.left,this.containment[1]+a.top,this.containment[2]+a.left,this.containment[3]+a.top]}else u=this.containment;t.pageX-this.offset.click.left<u[0]&&(s=u[0]+this.offset.click.left),t.pageY-this.offset.click.top<u[1]&&(o=u[1]+this.offset.click.top),t.pageX-this.offset.click.left>u[2]&&(s=u[2]+this.offset.click.left),t.pageY-this.offset.click.top>u[3]&&(o=u[3]+this.offset.click.top)}if(n.grid){var f=n.grid[1]?this.originalPageY+Math.round((o-this.originalPageY)/n.grid[1])*n.grid[1]:this.originalPageY;o=u?f-this.offset.click.top<u[1]||f-this.offset.click.top>u[3]?f-this.offset.click.top<u[1]?f+n.grid[1]:f-n.grid[1]:f:f;var l=n.grid[0]?this.originalPageX+Math.round((s-this.originalPageX)/n.grid[0])*n.grid[0]:this.originalPageX;s=u?l-this.offset.click.left<u[0]||l-this.offset.click.left>u[2]?l-this.offset.click.left<u[0]?l+n.grid[0]:l-n.grid[0]:l:l}}return{top:o-this.offset.click.top-this.offset.relative.top-this.offset.parent.top+(this.cssPosition=="fixed"?-this.scrollParent.scrollTop():i?0:r.scrollTop()),left:s-this.offset.click.left-this.offset.relative.left-this.offset.parent.left+(this.cssPosition=="fixed"?-this.scrollParent.scrollLeft():i?0:r.scrollLeft())}},_clear:function(){this.helper.removeClass("ui-draggable-dragging"),this.helper[0]!=this.element[0]&&!this.cancelHelperRemoval&&this.helper.remove(),this.helper=null,this.cancelHelperRemoval=!1},_trigger:function(t,n,r){return r=r||this._uiHash(),e.ui.plugin.call(this,t,[n,r]),t=="drag"&&(this.positionAbs=this._convertPositionTo("absolute")),e.Widget.prototype._trigger.call(this,t,n,r)},plugins:{},_uiHash:function(e){return{helper:this.helper,position:this.position,originalPosition:this.originalPosition,offset:this.positionAbs}}}),e.ui.plugin.add("draggable","connectToSortable",{start:function(t,n){var r=e(this).data("draggable"),i=r.options,s=e.extend({},n,{item:r.element});r.sortables=[],e(i.connectToSortable).each(function(){var n=e.data(this,"sortable");n&&!n.options.disabled&&(r.sortables.push({instance:n,shouldRevert:n.options.revert}),n.refreshPositions(),n._trigger("activate",t,s))})},stop:function(t,n){var r=e(this).data("draggable"),i=e.extend({},n,{item:r.element});e.each(r.sortables,function(){this.instance.isOver?(this.instance.isOver=0,r.cancelHelperRemoval=!0,this.instance.cancelHelperRemoval=!1,this.shouldRevert&&(this.instance.options.revert=!0),this.instance._mouseStop(t),this.instance.options.helper=this.instance.options._helper,r.options.helper=="original"&&this.instance.currentItem.css({top:"auto",left:"auto"})):(this.instance.cancelHelperRemoval=!1,this.instance._trigger("deactivate",t,i))})},drag:function(t,n){var r=e(this).data("draggable"),i=this,s=function(t){var n=this.offset.click.top,r=this.offset.click.left,i=this.positionAbs.top,s=this.positionAbs.left,o=t.height,u=t.width,a=t.top,f=t.left;return e.ui.isOver(i+n,s+r,a,f,o,u)};e.each(r.sortables,function(s){this.instance.positionAbs=r.positionAbs,this.instance.helperProportions=r.helperProportions,this.instance.offset.click=r.offset.click,this.instance._intersectsWith(this.instance.containerCache)?(this.instance.isOver||(this.instance.isOver=1,this.instance.currentItem=e(i).clone().removeAttr("id").appendTo(this.instance.element).data("sortable-item",!0),this.instance.options._helper=this.instance.options.helper,this.instance.options.helper=function(){return n.helper[0]},t.target=this.instance.currentItem[0],this.instance._mouseCapture(t,!0),this.instance._mouseStart(t,!0,!0),this.instance.offset.click.top=r.offset.click.top,this.instance.offset.click.left=r.offset.click.left,this.instance.offset.parent.left-=r.offset.parent.left-this.instance.offset.parent.left,this.instance.offset.parent.top-=r.offset.parent.top-this.instance.offset.parent.top,r._trigger("toSortable",t),r.dropped=this.instance.element,r.currentItem=r.element,this.instance.fromOutside=r),this.instance.currentItem&&this.instance._mouseDrag(t)):this.instance.isOver&&(this.instance.isOver=0,this.instance.cancelHelperRemoval=!0,this.instance.options.revert=!1,this.instance._trigger("out",t,this.instance._uiHash(this.instance)),this.instance._mouseStop(t,!0),this.instance.options.helper=this.instance.options._helper,this.instance.currentItem.remove(),this.instance.placeholder&&this.instance.placeholder.remove(),r._trigger("fromSortable",t),r.dropped=!1)})}}),e.ui.plugin.add("draggable","cursor",{start:function(t,n){var r=e("body"),i=e(this).data("draggable").options;r.css("cursor")&&(i._cursor=r.css("cursor")),r.css("cursor",i.cursor)},stop:function(t,n){var r=e(this).data("draggable").options;r._cursor&&e("body").css("cursor",r._cursor)}}),e.ui.plugin.add("draggable","opacity",{start:function(t,n){var r=e(n.helper),i=e(this).data("draggable").options;r.css("opacity")&&(i._opacity=r.css("opacity")),r.css("opacity",i.opacity)},stop:function(t,n){var r=e(this).data("draggable").options;r._opacity&&e(n.helper).css("opacity",r._opacity)}}),e.ui.plugin.add("draggable","scroll",{start:function(t,n){var r=e(this).data("draggable");r.scrollParent[0]!=document&&r.scrollParent[0].tagName!="HTML"&&(r.overflowOffset=r.scrollParent.offset())},drag:function(t,n){var r=e(this).data("draggable"),i=r.options,s=!1;if(r.scrollParent[0]!=document&&r.scrollParent[0].tagName!="HTML"){if(!i.axis||i.axis!="x")r.overflowOffset.top+r.scrollParent[0].offsetHeight-t.pageY<i.scrollSensitivity?r.scrollParent[0].scrollTop=s=r.scrollParent[0].scrollTop+i.scrollSpeed:t.pageY-r.overflowOffset.top<i.scrollSensitivity&&(r.scrollParent[0].scrollTop=s=r.scrollParent[0].scrollTop-i.scrollSpeed);if(!i.axis||i.axis!="y")r.overflowOffset.left+r.scrollParent[0].offsetWidth-t.pageX<i.scrollSensitivity?r.scrollParent[0].scrollLeft=s=r.scrollParent[0].scrollLeft+i.scrollSpeed:t.pageX-r.overflowOffset.left<i.scrollSensitivity&&(r.scrollParent[0].scrollLeft=s=r.scrollParent[0].scrollLeft-i.scrollSpeed)}else{if(!i.axis||i.axis!="x")t.pageY-e(document).scrollTop()<i.scrollSensitivity?s=e(document).scrollTop(e(document).scrollTop()-i.scrollSpeed):e(window).height()-(t.pageY-e(document).scrollTop())<i.scrollSensitivity&&(s=e(document).scrollTop(e(document).scrollTop()+i.scrollSpeed));if(!i.axis||i.axis!="y")t.pageX-e(document).scrollLeft()<i.scrollSensitivity?s=e(document).scrollLeft(e(document).scrollLeft()-i.scrollSpeed):e(window).width()-(t.pageX-e(document).scrollLeft())<i.scrollSensitivity&&(s=e(document).scrollLeft(e(document).scrollLeft()+i.scrollSpeed))}s!==!1&&e.ui.ddmanager&&!i.dropBehaviour&&e.ui.ddmanager.prepareOffsets(r,t)}}),e.ui.plugin.add("draggable","snap",{start:function(t,n){var r=e(this).data("draggable"),i=r.options;r.snapElements=[],e(i.snap.constructor!=String?i.snap.items||":data(draggable)":i.snap).each(function(){var t=e(this),n=t.offset();this!=r.element[0]&&r.snapElements.push({item:this,width:t.outerWidth(),height:t.outerHeight(),top:n.top,left:n.left})})},drag:function(t,n){var r=e(this).data("draggable"),i=r.options,s=i.snapTolerance,o=n.offset.left,u=o+r.helperProportions.width,a=n.offset.top,f=a+r.helperProportions.height;for(var l=r.snapElements.length-1;l>=0;l--){var c=r.snapElements[l].left,h=c+r.snapElements[l].width,p=r.snapElements[l].top,d=p+r.snapElements[l].height;if(!(c-s<o&&o<h+s&&p-s<a&&a<d+s||c-s<o&&o<h+s&&p-s<f&&f<d+s||c-s<u&&u<h+s&&p-s<a&&a<d+s||c-s<u&&u<h+s&&p-s<f&&f<d+s)){r.snapElements[l].snapping&&r.options.snap.release&&r.options.snap.release.call(r.element,t,e.extend(r._uiHash(),{snapItem:r.snapElements[l].item})),r.snapElements[l].snapping=!1;continue}if(i.snapMode!="inner"){var v=Math.abs(p-f)<=s,m=Math.abs(d-a)<=s,g=Math.abs(c-u)<=s,y=Math.abs(h-o)<=s;v&&(n.position.top=r._convertPositionTo("relative",{top:p-r.helperProportions.height,left:0}).top-r.margins.top),m&&(n.position.top=r._convertPositionTo("relative",{top:d,left:0}).top-r.margins.top),g&&(n.position.left=r._convertPositionTo("relative",{top:0,left:c-r.helperProportions.width}).left-r.margins.left),y&&(n.position.left=r._convertPositionTo("relative",{top:0,left:h}).left-r.margins.left)}var b=v||m||g||y;if(i.snapMode!="outer"){var v=Math.abs(p-a)<=s,m=Math.abs(d-f)<=s,g=Math.abs(c-o)<=s,y=Math.abs(h-u)<=s;v&&(n.position.top=r._convertPositionTo("relative",{top:p,left:0}).top-r.margins.top),m&&(n.position.top=r._convertPositionTo("relative",{top:d-r.helperProportions.height,left:0}).top-r.margins.top),g&&(n.position.left=r._convertPositionTo("relative",{top:0,left:c}).left-r.margins.left),y&&(n.position.left=r._convertPositionTo("relative",{top:0,left:h-r.helperProportions.width}).left-r.margins.left)}!r.snapElements[l].snapping&&(v||m||g||y||b)&&r.options.snap.snap&&r.options.snap.snap.call(r.element,t,e.extend(r._uiHash(),{snapItem:r.snapElements[l].item})),r.snapElements[l].snapping=v||m||g||y||b}}}),e.ui.plugin.add("draggable","stack",{start:function(t,n){var r=e(this).data("draggable").options,i=e.makeArray(e(r.stack)).sort(function(t,n){return(parseInt(e(t).css("zIndex"),10)||0)-(parseInt(e(n).css("zIndex"),10)||0)});if(!i.length)return;var s=parseInt(i[0].style.zIndex)||0;e(i).each(function(e){this.style.zIndex=s+e}),this[0].style.zIndex=s+i.length}}),e.ui.plugin.add("draggable","zIndex",{start:function(t,n){var r=e(n.helper),i=e(this).data("draggable").options;r.css("zIndex")&&(i._zIndex=r.css("zIndex")),r.css("zIndex",i.zIndex)},stop:function(t,n){var r=e(this).data("draggable").options;r._zIndex&&e(n.helper).css("zIndex",r._zIndex)}})})(jQuery);
/*! RESOURCE: /scripts/core/jquery.layout.min.js */
/*

 jquery.layout 1.3.0 - Release Candidate 30.72
 $Date: 2012-24-13 08:00:00 (Wed, 24 Oct 2012) $
 $Rev: 303007 $

 Copyright (c) 2012 
   Fabrizio Balliano (http://www.fabrizioballiano.net)
   Kevin Dalman (http://allpro.net)

 Dual licensed under the GPL (http://www.gnu.org/licenses/gpl.html)
 and MIT (http://www.opensource.org/licenses/mit-license.php) licenses.

 Changelog: http://layout.jquery-dev.net/changelog.cfm#1.3.0.rc30.71

 Docs: http://layout.jquery-dev.net/documentation.html
 Tips: http://layout.jquery-dev.net/tips.html
 Help: http://groups.google.com/group/jquery-ui-layout
*/
(function(b){var a=Math.min,f=Math.max,c=Math.floor,e=function(i){return"string"===b.type(i)},h=function(i,a){if(b.isArray(a))for(var f=0,c=a.length;f<c;f++){var h=a[f];try{e(h)&&(h=eval(h)),b.isFunction(h)&&h(i)}catch(j){}}};b.layout={version:"1.3.rc30.72",revision:0.033007,browser:{mozilla:!!b.browser.mozilla,webkit:!!b.browser.webkit||!!b.browser.safari,msie:!!b.browser.msie,isIE6:b.browser.msie&&6==b.browser.version,boxModel:!1!==b.support.boxModel||!b.browser.msie,version:b.browser.version},
effects:{slide:{all:{duration:"fast"},north:{direction:"up"},south:{direction:"down"},east:{direction:"right"},west:{direction:"left"}},drop:{all:{duration:"slow"},north:{direction:"up"},south:{direction:"down"},east:{direction:"right"},west:{direction:"left"}},scale:{all:{duration:"fast"}},blind:{},clip:{},explode:{},fade:{},fold:{},puff:{},size:{all:{easing:"swing"}}},config:{optionRootKeys:"effects panes north south west east center".split(" "),allPanes:["north","south","west","east","center"],
borderPanes:["north","south","west","east"],oppositeEdge:{north:"south",south:"north",east:"west",west:"east"},offscreenCSS:{left:"-99999px",right:"auto"},offscreenReset:"offscreenReset",hidden:{visibility:"hidden"},visible:{visibility:"visible"},resizers:{cssReq:{position:"absolute",padding:0,margin:0,fontSize:"1px",textAlign:"left",overflow:"hidden"},cssDemo:{background:"#DDD",border:"none"}},togglers:{cssReq:{position:"absolute",display:"block",padding:0,margin:0,overflow:"hidden",textAlign:"center",
fontSize:"1px",cursor:"pointer",zIndex:1},cssDemo:{background:"#AAA"}},content:{cssReq:{position:"relative"},cssDemo:{overflow:"auto",padding:"10px"},cssDemoPane:{overflow:"hidden",padding:0}},panes:{cssReq:{position:"absolute",margin:0},cssDemo:{padding:"10px",background:"#FFF",border:"1px solid #BBB",overflow:"auto"}},north:{side:"top",sizeType:"Height",dir:"horz",cssReq:{top:0,bottom:"auto",left:0,right:0,width:"auto"}},south:{side:"bottom",sizeType:"Height",dir:"horz",cssReq:{top:"auto",bottom:0,
left:0,right:0,width:"auto"}},east:{side:"right",sizeType:"Width",dir:"vert",cssReq:{left:"auto",right:0,top:"auto",bottom:"auto",height:"auto"}},west:{side:"left",sizeType:"Width",dir:"vert",cssReq:{left:0,right:"auto",top:"auto",bottom:"auto",height:"auto"}},center:{dir:"center",cssReq:{left:"auto",right:"auto",top:"auto",bottom:"auto",height:"auto",width:"auto"}}},callbacks:{},getParentPaneElem:function(i){i=b(i);if(i=i.data("layout")||i.data("parentLayout")){i=i.container;if(i.data("layoutPane"))return i;
i=i.closest("."+b.layout.defaults.panes.paneClass);if(i.data("layoutPane"))return i}return null},getParentPaneInstance:function(i){return(i=b.layout.getParentPaneElem(i))?i.data("layoutPane"):null},getParentLayoutInstance:function(i){return(i=b.layout.getParentPaneElem(i))?i.data("parentLayout"):null},getEventObject:function(b){return"object"===typeof b&&b.stopPropagation?b:null},parsePaneName:function(i){var a=b.layout.getEventObject(i);return a?(a.stopPropagation(),b(this).data("layoutEdge")):i},
plugins:{draggable:!!b.fn.draggable,effects:{core:!!b.effects,slide:b.effects&&(b.effects.slide||b.effects.effect.slide)}},onCreate:[],onLoad:[],onReady:[],onDestroy:[],onUnload:[],afterOpen:[],afterClose:[],scrollbarWidth:function(){return window.scrollbarWidth||b.layout.getScrollbarSize("width")},scrollbarHeight:function(){return window.scrollbarHeight||b.layout.getScrollbarSize("height")},getScrollbarSize:function(i){var a=b('<div style="position: absolute; top: -10000px; left: -10000px; width: 100px; height: 100px; overflow: scroll;"></div>').appendTo("body"),
f={width:a.css("width")-a[0].clientWidth,height:a.height()-a[0].clientHeight};a.remove();window.scrollbarWidth=f.width;window.scrollbarHeight=f.height;return i.match(/^(width|height)$/)?f[i]:f},showInvisibly:function(b,a){if(b&&b.length&&(a||"none"===b.css("display"))){var f=b[0].style,f={display:f.display||"",visibility:f.visibility||""};b.css({display:"block",visibility:"hidden"});return f}return{}},getElementDimensions:function(i,a){var c={css:{},inset:{}},e=c.css,h={bottom:0},j=b.layout.cssNum,
B=i.offset(),w,C,D;c.offsetLeft=B.left;c.offsetTop=B.top;a||(a={});b.each(["Left","Right","Top","Bottom"],function(f,j){w=e["border"+j]=b.layout.borderWidth(i,j);C=e["padding"+j]=b.layout.cssNum(i,"padding"+j);D=j.toLowerCase();c.inset[D]=0<=a[D]?a[D]:C;h[D]=c.inset[D]+w});e.width=i.css("width");e.height=i.height();e.top=j(i,"top",!0);e.bottom=j(i,"bottom",!0);e.left=j(i,"left",!0);e.right=j(i,"right",!0);c.outerWidth=i.outerWidth();c.outerHeight=i.outerHeight();c.innerWidth=f(0,c.outerWidth-h.left-
h.right);c.innerHeight=f(0,c.outerHeight-h.top-h.bottom);c.layoutWidth=i.innerWidth();c.layoutHeight=i.innerHeight();return c},getElementStyles:function(b,a){var f={},c=b[0].style,e=a.split(","),j=["Top","Bottom","Left","Right"],h=["Color","Style","Width"],w,C,D,U,y,r;for(U=0;U<e.length;U++)if(w=e[U],w.match(/(border|padding|margin)$/))for(y=0;4>y;y++)if(C=j[y],"border"===w)for(r=0;3>r;r++)D=h[r],f[w+C+D]=c[w+C+D];else f[w+C]=c[w+C];else f[w]=c[w];return f},cssWidth:function(a,c){if(0>=c)return 0;
if(!b.layout.browser.boxModel)return c;var e=b.layout.borderWidth,h=b.layout.cssNum,e=c-e(a,"Left")-e(a,"Right")-h(a,"paddingLeft")-h(a,"paddingRight");return f(0,e)},cssHeight:function(a,c){if(0>=c)return 0;if(!b.layout.browser.boxModel)return c;var e=b.layout.borderWidth,h=b.layout.cssNum,e=c-e(a,"Top")-e(a,"Bottom")-h(a,"paddingTop")-h(a,"paddingBottom");return f(0,e)},cssNum:function(a,f,c){a.jquery||(a=b(a));var e=b.layout.showInvisibly(a),f=b.css(a[0],f,!0),c=c&&"auto"==f?f:Math.round(parseFloat(f)||
0);a.css(e);return c},borderWidth:function(a,f){a.jquery&&(a=a[0]);var c="border"+f.substr(0,1).toUpperCase()+f.substr(1);return"none"===b.css(a,c+"Style",!0)?0:Math.round(parseFloat(b.css(a,c+"Width",!0))||0)},isMouseOverElem:function(a,f){var c=b(f||this),e=c.offset(),h=e.top,e=e.left,j=e+c.outerWidth(),c=h+c.outerHeight(),B=a.pageX,w=a.pageY;return b.layout.browser.msie&&0>B&&0>w||B>=e&&B<=j&&w>=h&&w<=c},msg:function(a,f,c,e){b.isPlainObject(a)&&window.debugData?("string"===typeof f?(e=c,c=f):
"object"===typeof c&&(e=c,c=null),c=c||"log( <object> )",e=b.extend({sort:!1,returnHTML:!1,display:!1},e),!0===f||e.display?debugData(a,c,e):window.console&&console.log(debugData(a,c,e))):f?alert(a):window.console?console.log(a):(f=b("#layoutLogger"),f.length||(f=b('<div id="layoutLogger" style="position: '+(b.support.fixedPosition?"fixed":"absolute")+'; top: 5px; z-index: 999999; max-width: 25%; overflow: hidden; border: 1px solid #000; border-radius: 5px; background: #FBFBFB; box-shadow: 0 2px 10px rgba(0,0,0,0.3);"><div style="font-size: 13px; font-weight: bold; padding: 5px 10px; background: #F6F6F6; border-radius: 5px 5px 0 0; cursor: move;"><span style="float: right; padding-left: 7px; cursor: pointer;" title="Remove Console" onclick="$(this).closest(\'#layoutLogger\').remove()">X</span>Layout console.log</div><ul style="font-size: 13px; font-weight: none; list-style: none; margin: 0; padding: 0 0 2px;"></ul></div>').appendTo("body"),
f.css("left",b(window).width()-f.outerWidth()-5),b.ui.draggable&&f.draggable({handle:":first-child"})),f.children("ul").append('<li style="padding: 4px 10px; margin: 0; border-top: 1px solid #CCC;">'+a.replace(/\</g,"&lt;").replace(/\>/g,"&gt;")+"</li>"))}};b.layout.defaults={name:"",containerClass:"ui-layout-container",inset:null,scrollToBookmarkOnLoad:!0,resizeWithWindow:!0,resizeWithWindowDelay:200,resizeWithWindowMaxDelay:0,maskPanesEarly:!1,onresizeall_start:null,onresizeall_end:null,onload_start:null,
onload_end:null,onunload_start:null,onunload_end:null,initPanes:!0,showErrorMessages:!0,showDebugMessages:!1,zIndex:null,zIndexes:{pane_normal:0,content_mask:1,resizer_normal:2,pane_sliding:100,pane_animate:1E3,resizer_drag:1E4},errors:{pane:"pane",selector:"selector",addButtonError:"Error Adding Button \n\nInvalid ",containerMissing:"UI Layout Initialization Error\n\nThe specified layout-container does not exist.",centerPaneMissing:"UI Layout Initialization Error\n\nThe center-pane element does not exist.\n\nThe center-pane is a required element.",
noContainerHeight:"UI Layout Initialization Warning\n\nThe layout-container \"CONTAINER\" has no height.\n\nTherefore the layout is 0-height and hence 'invisible'!",callbackError:"UI Layout Callback Error\n\nThe EVENT callback is not a valid function."},panes:{applyDemoStyles:!1,closable:!0,resizable:!0,slidable:!0,initClosed:!1,initHidden:!1,contentSelector:".ui-layout-content",contentIgnoreSelector:".ui-layout-ignore",findNestedContent:!1,paneClass:"ui-layout-pane",resizerClass:"ui-layout-resizer",
togglerClass:"ui-layout-toggler",buttonClass:"ui-layout-button",minSize:0,maxSize:0,spacing_open:6,spacing_closed:6,togglerLength_open:50,togglerLength_closed:50,togglerAlign_open:"center",togglerAlign_closed:"center",togglerContent_open:"",togglerContent_closed:"",resizerDblClickToggle:!0,autoResize:!0,autoReopen:!0,resizerDragOpacity:1,maskContents:!1,maskObjects:!1,maskZindex:null,resizingGrid:!1,livePaneResizing:!1,liveContentResizing:!1,liveResizingTolerance:1,sliderCursor:"pointer",slideTrigger_open:"click",
slideTrigger_close:"mouseleave",slideDelay_open:300,slideDelay_close:300,hideTogglerOnSlide:!1,preventQuickSlideClose:b.layout.browser.webkit,preventPrematureSlideClose:!1,tips:{Open:"Open",Close:"Close",Resize:"Resize",Slide:"Slide Open",Pin:"Pin",Unpin:"Un-Pin",noRoomToOpen:"Not enough room to show this panel.",minSizeWarning:"Panel has reached its minimum size",maxSizeWarning:"Panel has reached its maximum size"},showOverflowOnHover:!1,enableCursorHotkey:!0,customHotkeyModifier:"SHIFT",fxName:"slide",
fxSpeed:null,fxSettings:{},fxOpacityFix:!0,animatePaneSizing:!1,children:null,containerSelector:"",initChildren:!0,destroyChildren:!0,resizeChildren:!0,triggerEventsOnLoad:!1,triggerEventsDuringLiveResize:!0,onshow_start:null,onshow_end:null,onhide_start:null,onhide_end:null,onopen_start:null,onopen_end:null,onclose_start:null,onclose_end:null,onresize_start:null,onresize_end:null,onsizecontent_start:null,onsizecontent_end:null,onswap_start:null,onswap_end:null,ondrag_start:null,ondrag_end:null},
north:{paneSelector:".ui-layout-north",size:"auto",resizerCursor:"n-resize",customHotkey:""},south:{paneSelector:".ui-layout-south",size:"auto",resizerCursor:"s-resize",customHotkey:""},east:{paneSelector:".ui-layout-east",size:200,resizerCursor:"e-resize",customHotkey:""},west:{paneSelector:".ui-layout-west",size:200,resizerCursor:"w-resize",customHotkey:""},center:{paneSelector:".ui-layout-center",minWidth:0,minHeight:0}};b.layout.optionsMap={layout:"name instanceKey stateManagement effects inset zIndexes errors zIndex scrollToBookmarkOnLoad showErrorMessages maskPanesEarly outset resizeWithWindow resizeWithWindowDelay resizeWithWindowMaxDelay onresizeall onresizeall_start onresizeall_end onload onunload".split(" "),
center:"paneClass contentSelector contentIgnoreSelector findNestedContent applyDemoStyles triggerEventsOnLoad showOverflowOnHover maskContents maskObjects liveContentResizing containerSelector children initChildren resizeChildren destroyChildren onresize onresize_start onresize_end onsizecontent onsizecontent_start onsizecontent_end".split(" "),noDefault:["paneSelector","resizerCursor","customHotkey"]};b.layout.transformData=function(a,f){var c=f?{panes:{},center:{}}:{},e,h,j,B,w,C,D;if("object"!==
typeof a)return c;for(h in a){e=c;w=a[h];j=h.split("__");D=j.length-1;for(C=0;C<=D;C++)B=j[C],C===D?e[B]=b.isPlainObject(w)?b.layout.transformData(w):w:(e[B]||(e[B]={}),e=e[B])}return c};b.layout.backwardCompatibility={map:{applyDefaultStyles:"applyDemoStyles",childOptions:"children",initChildLayout:"initChildren",destroyChildLayout:"destroyChildren",resizeChildLayout:"resizeChildren",resizeNestedLayout:"resizeChildren",resizeWhileDragging:"livePaneResizing",resizeContentWhileDragging:"liveContentResizing",
triggerEventsWhileDragging:"triggerEventsDuringLiveResize",maskIframesOnResize:"maskContents",useStateCookie:"stateManagement.enabled","cookie.autoLoad":"stateManagement.autoLoad","cookie.autoSave":"stateManagement.autoSave","cookie.keys":"stateManagement.stateKeys","cookie.name":"stateManagement.cookie.name","cookie.domain":"stateManagement.cookie.domain","cookie.path":"stateManagement.cookie.path","cookie.expires":"stateManagement.cookie.expires","cookie.secure":"stateManagement.cookie.secure",
noRoomToOpenTip:"tips.noRoomToOpen",togglerTip_open:"tips.Close",togglerTip_closed:"tips.Open",resizerTip:"tips.Resize",sliderTip:"tips.Slide"},renameOptions:function(a){function f(b,c){for(var e=b.split("."),h=e.length-1,j={branch:a,key:e[h]},r=0,n;r<h;r++)n=e[r],j.branch=void 0==j.branch[n]?c?j.branch[n]={}:{}:j.branch[n];return j}var c=b.layout.backwardCompatibility.map,e,h,j,B;for(B in c)e=f(B),j=e.branch[e.key],void 0!==j&&(h=f(c[B],!0),h.branch[h.key]=j,delete e.branch[e.key])},renameAllOptions:function(a){var c=
b.layout.backwardCompatibility.renameOptions;c(a);a.defaults&&("object"!==typeof a.panes&&(a.panes={}),b.extend(!0,a.panes,a.defaults),delete a.defaults);a.panes&&c(a.panes);b.each(b.layout.config.allPanes,function(b,f){a[f]&&c(a[f])});return a}};b.fn.layout=function(i){function v(d){if(!d)return!0;var m=d.keyCode;if(33>m)return!0;var l={38:"north",40:"south",37:"west",39:"east"},F=d.shiftKey,g=d.ctrlKey,a,t,c,f;g&&(37<=m&&40>=m)&&r[l[m]].enableCursorHotkey?f=l[m]:(g||F)&&b.each(j.borderPanes,function(d,
b){a=r[b];t=a.customHotkey;c=a.customHotkeyModifier;if(F&&"SHIFT"==c||g&&"CTRL"==c||g&&F)if(t&&m===(isNaN(t)||9>=t?t.toUpperCase().charCodeAt(0):t))return f=b,!1});if(!f||!u[f]||!r[f].closable||n[f].isHidden)return!0;ka(f);d.stopPropagation();return d.returnValue=!1}function O(d){if(H()){this&&this.tagName&&(d=this);var m;e(d)?m=u[d]:b(d).data("layoutRole")?m=b(d):b(d).parents().each(function(){if(b(this).data("layoutRole"))return m=b(this),!1});if(m&&m.length){var l=m.data("layoutEdge"),d=n[l];d.cssSaved&&
I(l);if(d.isSliding||d.isResizing||d.isClosed)d.cssSaved=!1;else{var F={zIndex:r.zIndexes.resizer_normal+1},g={},a=m.css("overflow"),t=m.css("overflowX"),f=m.css("overflowY");"visible"!=a&&(g.overflow=a,F.overflow="visible");t&&!t.match(/(visible|auto)/)&&(g.overflowX=t,F.overflowX="visible");f&&!f.match(/(visible|auto)/)&&(g.overflowY=t,F.overflowY="visible");d.cssSaved=g;m.css(F);b.each(j.allPanes,function(d,b){b!=l&&I(b)})}}}}function I(d){if(H()){this&&this.tagName&&(d=this);var m;e(d)?m=u[d]:
b(d).data("layoutRole")?m=b(d):b(d).parents().each(function(){if(b(this).data("layoutRole"))return m=b(this),!1});if(m&&m.length){var d=m.data("layoutEdge"),d=n[d],l=d.cssSaved||{};!d.isSliding&&!d.isResizing&&m.css("zIndex",r.zIndexes.pane_normal);m.css(l);d.cssSaved=!1}}}var M=b.layout.browser,j=b.layout.config,B=b.layout.cssWidth,w=b.layout.cssHeight,C=b.layout.getElementDimensions,D=b.layout.getElementStyles,U=b.layout.getEventObject,y=b.layout.parsePaneName,r=b.extend(!0,{},b.layout.defaults);
r.effects=b.extend(!0,{},b.layout.effects);var n={id:"layout"+b.now(),initialized:!1,paneResizing:!1,panesSliding:{},container:{innerWidth:0,innerHeight:0,outerWidth:0,outerHeight:0,layoutWidth:0,layoutHeight:0},north:{childIdx:0},south:{childIdx:0},east:{childIdx:0},west:{childIdx:0},center:{childIdx:0}},Y={north:null,south:null,east:null,west:null,center:null},L={data:{},set:function(d,b,l){L.clear(d);L.data[d]=setTimeout(b,l)},clear:function(d){var b=L.data;b[d]&&(clearTimeout(b[d]),delete b[d])}},
Z=function(d,m,l){var a=r;(a.showErrorMessages&&!l||l&&a.showDebugMessages)&&b.layout.msg(a.name+" / "+d,!1!==m);return!1},E=function(d,m,l){var a=m&&e(m),g=a?n[m]:n,z=a?r[m]:r,t=r.name,f=d+(d.match(/_/)?"":"_end"),c=f.match(/_end$/)?f.substr(0,f.length-4):"",q=z[f]||z[c],h="NC",i=[];!a&&"boolean"===b.type(m)&&(l=m,m="");if(q)try{e(q)&&(q.match(/,/)?(i=q.split(","),q=eval(i[0])):q=eval(q)),b.isFunction(q)&&(h=i.length?q(i[1]):a?q(m,u[m],g,z,t):q(x,g,z,t))}catch(j){Z(r.errors.callbackError.replace(/EVENT/,
b.trim((m||"")+" "+f)),!1),"string"===b.type(j)&&string.length&&Z("Exception:  "+j,!1)}!l&&!1!==h&&(a?(l=u[m],z=r[m],g=n[m],l.triggerHandler("layoutpane"+f,[m,l,g,z,t]),c&&l.triggerHandler("layoutpane"+c,[m,l,g,z,t])):(p.triggerHandler("layout"+f,[x,g,z,t]),c&&p.triggerHandler("layout"+c,[x,g,z,t])));a&&"onresize_end"===d&&Za(m+"",!0);return h},$a=function(d){if(!M.mozilla){var b=u[d];"IFRAME"===n[d].tagName?b.css(j.hidden).css(j.visible):b.find("IFRAME").css(j.hidden).css(j.visible)}},va=function(d){var b=
u[d],d=j[d].dir,b={minWidth:1001-B(b,1E3),minHeight:1001-w(b,1E3)};"horz"===d&&(b.minSize=b.minHeight);"vert"===d&&(b.minSize=b.minWidth);return b},ba=function(d,m,l){l||(l=j[d].dir);e(m)&&m.match(/%/)&&(m="100%"===m?-1:parseInt(m,10)/100);if(0===m)return 0;if(1<=m)return parseInt(m,10);var a=r,g=0;"horz"==l?g=s.innerHeight-(u.north?a.north.spacing_open:0)-(u.south?a.south.spacing_open:0):"vert"==l&&(g=s.innerWidth-(u.west?a.west.spacing_open:0)-(u.east?a.east.spacing_open:0));if(-1===m)return g;
if(0<m)return c(g*m);if("center"==d)return 0;var l="horz"===l?"height":"width",a=u[d],d="height"===l?R[d]:!1,g=b.layout.showInvisibly(a),z=a.css(l),t=d?d.css(l):0;a.css(l,"auto");d&&d.css(l,"auto");m="height"===l?a.outerHeight():a.outerWidth();a.css(l,z).css(g);d&&d.css(l,t);return m},ca=function(d,b){var l=u[d],a=r[d],g=n[d],z=b?a.spacing_open:0,a=b?a.spacing_closed:0;return!l||g.isHidden?0:g.isClosed||g.isSliding&&b?a:"horz"===j[d].dir?l.outerHeight()+z:l.outerWidth()+z},V=function(d,b){if(H()){var l=
r[d],F=n[d],g=j[d],z=g.dir;g.sizeType.toLowerCase();var g=void 0!=b?b:F.isSliding,t=l.spacing_open,c=j.oppositeEdge[d],k=n[c],q=u[c],e=!q||!1===k.isVisible||k.isSliding?0:"horz"==z?q.outerHeight():q.outerWidth(),c=(!q||k.isHidden?0:r[c][!1!==k.isClosed?"spacing_closed":"spacing_open"])||0,k="horz"==z?s.innerHeight:s.innerWidth,q=va("center"),q="horz"==z?f(r.center.minHeight,q.minHeight):f(r.center.minWidth,q.minWidth),g=k-t-(g?0:ba("center",q,z)+e+c),z=F.minSize=f(ba(d,l.minSize),va(d).minSize),g=
F.maxSize=a(l.maxSize?ba(d,l.maxSize):1E5,g),F=F.resizerPosition={},t=s.inset.top,e=s.inset.left,c=s.innerWidth,k=s.innerHeight,l=l.spacing_open;switch(d){case "north":F.min=t+z;F.max=t+g;break;case "west":F.min=e+z;F.max=e+g;break;case "south":F.min=t+k-g-l;F.max=t+k-z-l;break;case "east":F.min=e+c-g-l,F.max=e+c-z-l}}},Ia=function(d,m){var l=b(d),a=l.data("layoutRole"),g=l.data("layoutEdge"),z=r[g][a+"Class"],g="-"+g,c=l.hasClass(z+"-closed")?"-closed":"-open",f="-closed"===c?"-open":"-closed",c=
z+"-hover "+(z+g+"-hover ")+(z+c+"-hover ")+(z+g+c+"-hover ");m&&(c+=z+f+"-hover "+(z+g+f+"-hover "));"resizer"==a&&l.hasClass(z+"-sliding")&&(c+=z+"-sliding-hover "+(z+g+"-sliding-hover "));return b.trim(c)},Ja=function(d,m){var l=b(m||this);d&&"toggler"===l.data("layoutRole")&&d.stopPropagation();l.addClass(Ia(l))},$=function(d,m){var l=b(m||this);l.removeClass(Ia(l,!0))},ab=function(){var d=b(this).data("layoutEdge"),m=n[d];!m.isClosed&&(!m.isResizing&&!n.paneResizing)&&(b.fn.disableSelection&&
b("body").disableSelection(),r.maskPanesEarly&&sa(d,{resizing:!0}))},bb=function(d,m){var l=m||this,a=b(l).data("layoutEdge"),g=a+"ResizerLeave";L.clear(a+"_openSlider");L.clear(g);m?n.paneResizing||(b.fn.enableSelection&&b("body").enableSelection(),r.maskPanesEarly&&wa()):L.set(g,function(){bb(d,l)},200)},H=function(){return n.initialized||n.creatingLayout?!0:xa()},xa=function(d){var m=r;if(!p.is(":visible"))return!d&&(M.webkit&&"BODY"===p[0].tagName)&&setTimeout(function(){xa(!0)},50),!1;if(!cb("center").length)return Z(m.errors.centerPaneMissing);
n.creatingLayout=!0;b.extend(s,C(p,m.inset));y(void 0);b.each(j.allPanes,function(d,b){db(b,!0)});Ka();b.each(j.borderPanes,function(d,b){u[b]&&n[b].isVisible&&(V(b),da(b))});ea("center");b.each(j.allPanes,function(d,b){eb(b)});m.scrollToBookmarkOnLoad&&(d=self.location,d.hash&&d.replace(d.hash));x.hasParentLayout?m.resizeWithWindow=!1:m.resizeWithWindow&&b(window).bind("resize."+J,vb);delete n.creatingLayout;n.initialized=!0;h(x,b.layout.onReady);E("onload_end");return!0},La=function(d,m){var l=
y.call(this,d),a=u[l];if(a){var g=R[l],z=n[l],c=r[l],f=r.stateManagement||{},c=m?c.children=m:c.children;if(b.isPlainObject(c))c=[c];else if(!c||!b.isArray(c))return;b.each(c,function(d,m){b.isPlainObject(m)&&(m.containerSelector?a.find(m.containerSelector):g||a).each(function(){var d=b(this),g=d.data("layout");if(!g){fb({container:d,options:m},z);if(f.includeChildren&&n.stateData[l]){var g=(n.stateData[l].children||{})[m.instanceKey],a=m.stateManagement||(m.stateManagement={autoLoad:!0});!0===a.autoLoad&&
g&&(a.autoSave=!1,a.includeChildren=!0,a.autoLoad=b.extend(!0,{},g))}(g=d.layout(m))&&ya(l,g)}})})}},fb=function(d,b){var l=d.container,a=d.options,g=a.stateManagement,c=a.instanceKey||l.data("layoutInstanceKey");c||(c=(g&&g.cookie?g.cookie.name:"")||a.name);c=c?c.replace(/[^\w-]/gi,"_").replace(/_{2,}/g,"_"):"layout"+ ++b.childIdx;a.instanceKey=c;l.data("layoutInstanceKey",c);return c},ya=function(d,m){var l=u[d],a=Y[d],g=n[d];b.isPlainObject(a)&&(b.each(a,function(d,b){b.destroyed&&delete a[d]}),
b.isEmptyObject(a)&&(a=Y[d]=null));!m&&!a&&(m=l.data("layout"));m&&(m.hasParentLayout=!0,l=m.options,fb(m,g),a||(a=Y[d]={}),a[l.instanceKey]=m.container.data("layout"));x[d].children=Y[d];m||La(d)},vb=function(){var d=r,b=Number(d.resizeWithWindowDelay);10>b&&(b=100);L.clear("winResize");L.set("winResize",function(){L.clear("winResize");L.clear("winResizeRepeater");var b=C(p,d.inset);(b.innerWidth!==s.innerWidth||b.innerHeight!==s.innerHeight)&&la()},b);L.data.winResizeRepeater||gb()},gb=function(){var d=
Number(r.resizeWithWindowMaxDelay);0<d&&L.set("winResizeRepeater",function(){gb();la()},d)},hb=function(){E("onunload_start");h(x,b.layout.onUnload);E("onunload_end")},ib=function(d){d=d?d.split(","):j.borderPanes;b.each(d,function(d,a){var c=r[a];if(c.enableCursorHotkey||c.customHotkey)return b(document).bind("keydown."+J,v),!1})},cb=function(d){d=r[d].paneSelector;if("#"===d.substr(0,1))return p.find(d).eq(0);var b=p.children(d).eq(0);return b.length?b:p.children("form:first").children(d).eq(0)},
db=function(d,b){if(b||H()){var l=r[d],c=n[d],g=j[d],z=g.dir,t="center"===d,e={},k=u[d],q,h;k?Ma(d,!1,!0,!1):R[d]=!1;k=u[d]=cb(d);if(k.length){k.data("layoutCSS")||k.data("layoutCSS",D(k,"position,top,left,bottom,right,width,height,overflow,zIndex,display,backgroundColor,padding,margin,border"));x[d]={name:d,pane:u[d],content:R[d],options:r[d],state:n[d],children:Y[d]};k.data({parentLayout:x,layoutPane:x[d],layoutEdge:d,layoutRole:"pane"}).css(g.cssReq).css("zIndex",r.zIndexes.pane_normal).css(l.applyDemoStyles?
g.cssDemo:{}).addClass(l.paneClass+" "+l.paneClass+"-"+d).bind("mouseenter."+J,Ja).bind("mouseleave."+J,$);g={hide:"",show:"",toggle:"",close:"",open:"",slideOpen:"",slideClose:"",slideToggle:"",size:"sizePane",sizePane:"sizePane",sizeContent:"",sizeHandles:"",enableClosable:"",disableClosable:"",enableSlideable:"",disableSlideable:"",enableResizable:"",disableResizable:"",swapPanes:"swapPanes",swap:"swapPanes",move:"swapPanes",removePane:"removePane",remove:"removePane",createChildren:"",resizeChildren:"",
resizeAll:"resizeAll",resizeLayout:"resizeAll"};for(h in g)k.bind("layoutpane"+h.toLowerCase()+"."+J,x[g[h]||h]);Na(d,!1);t||(q=c.size=ba(d,l.size),t=ba(d,l.minSize)||1,h=ba(d,l.maxSize)||1E5,0<q&&(q=f(a(q,h),t)),c.autoResize=l.autoResize,c.isClosed=!1,c.isSliding=!1,c.isResizing=!1,c.isHidden=!1,c.pins||(c.pins=[]));c.tagName=k[0].tagName;c.edge=d;c.noRoom=!1;c.isVisible=!0;jb(d);"horz"===z?e.height=w(k,q):"vert"===z&&(e.width=B(k,q));k.css(e);"horz"!=z&&ea(d,!0);n.initialized&&(Ka(d),ib(d));l.initClosed&&
l.closable&&!l.initHidden?fa(d,!0,!0):l.initHidden||l.initClosed?Oa(d):c.noRoom||k.css("display","block");k.css("visibility","visible");l.showOverflowOnHover&&k.hover(O,I);n.initialized&&eb(d)}else u[d]=!1}},eb=function(d){var b=u[d],a=n[d],c=r[d];b&&(b.data("layout")&&ya(d,b.data("layout")),a.isVisible&&(n.initialized?la():ma(d),c.triggerEventsOnLoad?E("onresize_end",d):Za(d,!0)),c.initChildren&&c.children&&La(d))},jb=function(d){d=d?d.split(","):j.borderPanes;b.each(d,function(d,b){var a=u[b],g=
G[b],c=n[b],f=j[b].side,e={};if(a){switch(b){case "north":e.top=s.inset.top;e.left=s.inset.left;e.right=s.inset.right;break;case "south":e.bottom=s.inset.bottom;e.left=s.inset.left;e.right=s.inset.right;break;case "west":e.left=s.inset.left;break;case "east":e.right=s.inset.right}a.css(e);g&&c.isClosed?g.css(f,s.inset[f]):g&&!c.isHidden&&g.css(f,s.inset[f]+ca(b))}})},Ka=function(d){d=d?d.split(","):j.borderPanes;b.each(d,function(d,a){var c=u[a];G[a]=!1;P[a]=!1;if(c){var g=r[a],c=n[a],f="#"===g.paneSelector.substr(0,
1)?g.paneSelector.substr(1):"",e=g.resizerClass,h=g.togglerClass,k="-"+a,q=x[a],i=q.resizer=G[a]=b("<div></div>"),q=q.toggler=g.closable?P[a]=b("<div></div>"):!1;!c.isVisible&&g.slidable&&i.attr("title",g.tips.Slide).css("cursor",g.sliderCursor);i.attr("id",f?f+"-resizer":"").data({parentLayout:x,layoutPane:x[a],layoutEdge:a,layoutRole:"resizer"}).css(j.resizers.cssReq).css("zIndex",r.zIndexes.resizer_normal).css(g.applyDemoStyles?j.resizers.cssDemo:{}).addClass(e+" "+e+k).hover(Ja,$).hover(ab,bb).appendTo(p);
g.resizerDblClickToggle&&i.bind("dblclick."+J,ka);q&&(q.attr("id",f?f+"-toggler":"").data({parentLayout:x,layoutPane:x[a],layoutEdge:a,layoutRole:"toggler"}).css(j.togglers.cssReq).css(g.applyDemoStyles?j.togglers.cssDemo:{}).addClass(h+" "+h+k).hover(Ja,$).bind("mouseenter",ab).appendTo(i),g.togglerContent_open&&b("<span>"+g.togglerContent_open+"</span>").data({layoutEdge:a,layoutRole:"togglerContent"}).data("layoutRole","togglerContent").data("layoutEdge",a).addClass("content content-open").css("display",
"none").appendTo(q),g.togglerContent_closed&&b("<span>"+g.togglerContent_closed+"</span>").data({layoutEdge:a,layoutRole:"togglerContent"}).addClass("content content-closed").css("display","none").appendTo(q),kb(a));var g=a,A=b.layout.plugins.draggable,g=g?g.split(","):j.borderPanes;b.each(g,function(d,a){var g=r[a];if(!A||!u[a]||!g.resizable)return g.resizable=!1,!0;var m=n[a],l=r.zIndexes,c=j[a],f="horz"==c.dir?"top":"left",z=G[a],e=g.resizerClass,t=0,q,k,F=e+"-drag",h=e+"-"+a+"-drag",i=e+"-dragging",
ia=e+"-"+a+"-dragging",ra=e+"-dragging-limit",s=e+"-"+a+"-dragging-limit",w=!1;m.isClosed||z.attr("title",g.tips.Resize).css("cursor",g.resizerCursor);z.draggable({containment:p[0],axis:"horz"==c.dir?"y":"x",delay:0,distance:1,grid:g.resizingGrid,helper:"clone",opacity:g.resizerDragOpacity,addClasses:!1,zIndex:l.resizer_drag,start:function(d,l){g=r[a];m=n[a];k=g.livePaneResizing;if(!1===E("ondrag_start",a))return!1;m.isResizing=!0;n.paneResizing=a;L.clear(a+"_closeSlider");V(a);q=m.resizerPosition;
t=l.position[f];z.addClass(F+" "+h);w=!1;b("body").disableSelection();sa(a,{resizing:!0})},drag:function(d,b){w||(b.helper.addClass(i+" "+ia).css({right:"auto",bottom:"auto"}).children().css("visibility","hidden"),w=!0,m.isSliding&&u[a].css("zIndex",l.pane_sliding));var c=0;b.position[f]<q.min?(b.position[f]=q.min,c=-1):b.position[f]>q.max&&(b.position[f]=q.max,c=1);c?(b.helper.addClass(ra+" "+s),window.defaultStatus=0<c&&a.match(/(north|west)/)||0>c&&a.match(/(south|east)/)?g.tips.maxSizeWarning:
g.tips.minSizeWarning):(b.helper.removeClass(ra+" "+s),window.defaultStatus="");k&&Math.abs(b.position[f]-t)>=g.liveResizingTolerance&&(t=b.position[f],Q(d,b,a))},stop:function(d,g){b("body").enableSelection();window.defaultStatus="";z.removeClass(F+" "+h);m.isResizing=!1;n.paneResizing=!1;Q(d,g,a,!0)}})});var Q=function(d,b,a,g){var m=b.position,l=j[a],d=r[a],b=n[a],c;switch(a){case "north":c=m.top;break;case "west":c=m.left;break;case "south":c=s.layoutHeight-m.top-d.spacing_open;break;case "east":c=
s.layoutWidth-m.left-d.spacing_open}c-=s.inset[l.side];g?(!1!==E("ondrag_end",a)&&za(a,c,!1,!0),wa(!0),b.isSliding&&sa(a,{resizing:!0})):Math.abs(c-b.size)<d.liveResizingTolerance||(za(a,c,!1,!0),aa.each(mb))};c.isVisible?Pa(a):(Qa(a),ja(a,!0))}});na()},Na=function(d,b){if(H()){var a=r[d],c=a.contentSelector,g=x[d],f=u[d],e;c&&(e=g.content=R[d]=a.findNestedContent?f.find(c).eq(0):f.children(c).eq(0));e&&e.length?(e.data("layoutRole","content"),e.data("layoutCSS")||e.data("layoutCSS",D(e,"height")),
e.css(j.content.cssReq),a.applyDemoStyles&&(e.css(j.content.cssDemo),f.css(j.content.cssDemoPane)),f.css("overflowX").match(/(scroll|auto)/)&&f.css("overflow","hidden"),n[d].content={},!1!==b&&ma(d)):g.content=R[d]=!1}},mb=function(){var d=b(this),a=d.data("layoutMask"),a=n[a];"IFRAME"==a.tagName&&a.isVisible&&d.css({top:a.offsetTop,left:a.offsetLeft,width:a.outerWidth,height:a.outerHeight})},sa=function(d,a){var c=j[d],f=["center"],g=r.zIndexes,e=b.extend({objectsOnly:!1,animation:!1,resizing:!0,
sliding:n[d].isSliding},a),t,h;e.resizing&&f.push(d);e.sliding&&f.push(j.oppositeEdge[d]);"horz"===c.dir&&(f.push("west"),f.push("east"));b.each(f,function(d,a){h=n[a];t=r[a];if(h.isVisible&&(t.maskObjects||!e.objectsOnly&&t.maskContents)){for(var m=b([]),c,l=0,f=aa.length;l<f;l++)c=aa.eq(l),c.data("layoutMask")===a&&(m=m.add(c));if(!m.length){m=u[a];c=n[a];var l=r[a],f=r.zIndexes,F=b([]),i,j,s,w,B;if(l.maskContents||l.maskObjects)for(B=0;B<(l.maskObjects?2:1);B++)i=l.maskObjects&&0==B,j=document.createElement(i?
"iframe":"div"),s=b(j).data("layoutMask",a),j.className="ui-layout-mask ui-layout-mask-"+a,w=j.style,w.display="block",w.position="absolute",w.background="#FFF",i&&(j.frameborder=0,j.src="about:blank",w.opacity=0,w.filter="Alpha(Opacity='0')",w.border=0),"IFRAME"==c.tagName?(w.zIndex=f.pane_normal+1,p.append(j)):(s.addClass("ui-layout-mask-inside-pane"),w.zIndex=l.maskZindex||f.content_mask,w.top=0,w.left=0,w.width="100%",w.height="100%",m.append(j)),F=F.add(j),aa=aa.add(j);m=F}m.each(function(){mb.call(this);
this.style.zIndex=h.isSliding?g.pane_sliding+1:g.pane_normal+1;this.style.display="block"})}})},wa=function(d){if(d||!n.paneResizing)aa.hide();else if(!d&&!b.isEmptyObject(n.panesSliding))for(var d=aa.length-1,a,c;0<=d;d--)c=aa.eq(d),a=c.data("layoutMask"),r[a].maskObjects||c.hide()},Ma=function(d,a,c,f){if(H()){var d=y.call(this,d),g=u[d],e=R[d],t=G[d],h=P[d];g&&b.isEmptyObject(g.data())&&(g=!1);e&&b.isEmptyObject(e.data())&&(e=!1);t&&b.isEmptyObject(t.data())&&(t=!1);h&&b.isEmptyObject(h.data())&&
(h=!1);g&&g.stop(!0,!0);var k=r[d],q=Y[d],i=b.isPlainObject(q)&&!b.isEmptyObject(q),f=void 0!==f?f:k.destroyChildren;i&&f&&(b.each(q,function(d,b){b.destroyed||b.destroy(!0);b.destroyed&&delete q[d]}),b.isEmptyObject(q)&&(q=Y[d]=null,i=!1));g&&a&&!i?g.remove():g&&g[0]&&(a=k.paneClass,f=a+"-"+d,a=[a,a+"-open",a+"-closed",a+"-sliding",f,f+"-open",f+"-closed",f+"-sliding"],b.merge(a,Ia(g,!0)),g.removeClass(a.join(" ")).removeData("parentLayout").removeData("layoutPane").removeData("layoutRole").removeData("layoutEdge").removeData("autoHidden").unbind("."+
J),i&&e?(e.width(e.width()),b.each(q,function(d,b){b.resizeAll()})):e&&e.css(e.data("layoutCSS")).removeData("layoutCSS").removeData("layoutRole"),g.data("layout")||g.css(g.data("layoutCSS")).removeData("layoutCSS"));h&&h.remove();t&&t.remove();x[d]=u[d]=R[d]=G[d]=P[d]=!1;c||la()}},Aa=function(b){var a=u[b],c=a[0].style;r[b].useOffscreenClose?(a.data(j.offscreenReset)||a.data(j.offscreenReset,{left:c.left,right:c.right}),a.css(j.offscreenCSS)):a.hide().removeData(j.offscreenReset)},nb=function(b){var a=
u[b],b=r[b],c=j.offscreenCSS,f=a.data(j.offscreenReset),g=a[0].style;a.show().removeData(j.offscreenReset);b.useOffscreenClose&&f&&(g.left==c.left&&(g.left=f.left),g.right==c.right&&(g.right=f.right))},Oa=function(b,a){if(H()){var c=y.call(this,b),f=r[c],g=n[c],e=G[c];u[c]&&!g.isHidden&&!(n.initialized&&!1===E("onhide_start",c))&&(g.isSliding=!1,delete n.panesSliding[c],e&&e.hide(),!n.initialized||g.isClosed?(g.isClosed=!0,g.isHidden=!0,g.isVisible=!1,n.initialized||Aa(c),ea("horz"===j[c].dir?"":
"center"),(n.initialized||f.triggerEventsOnLoad)&&E("onhide_end",c)):(g.isHiding=!0,fa(c,!1,a)))}},Ba=function(b,a,c,f){if(H()){var b=y.call(this,b),g=n[b];u[b]&&g.isHidden&&!1!==E("onshow_start",b)&&(g.isShowing=!0,g.isSliding=!1,delete n.panesSliding[b],!1===a?fa(b,!0):oa(b,!1,c,f))}},ka=function(b,a){if(H()){var c=U(b),f=y.call(this,b),g=n[f];c&&c.stopImmediatePropagation();g.isHidden?Ba(f):g.isClosed?oa(f,!!a):fa(f)}},fa=function(b,a,c,f){function g(){k.isMoving=!1;ja(e,!0);var b=j.oppositeEdge[e];
n[b].noRoom&&(V(b),da(b));if(!f&&(n.initialized||h.triggerEventsOnLoad))i||E("onclose_end",e),i&&E("onshow_end",e),A&&E("onhide_end",e)}var e=y.call(this,b);if(!n.initialized&&u[e])b=n[e],Aa(e),b.isClosed=!0,b.isVisible=!1;else if(H()){var t=u[e],h=r[e],k=n[e],q,i,A;p.queue(function(b){if(!t||!h.closable&&!k.isShowing&&!k.isHiding||!a&&k.isClosed&&!k.isShowing)return b();var d=!k.isShowing&&!1===E("onclose_start",e);i=k.isShowing;A=k.isHiding;delete k.isShowing;delete k.isHiding;if(d)return b();q=
!c&&!k.isClosed&&"none"!=h.fxName_close;k.isMoving=!0;k.isClosed=!0;k.isVisible=!1;A?k.isHidden=!0:i&&(k.isHidden=!1);k.isSliding?ta(e,!1):ea("horz"===j[e].dir?"":"center",!1);Qa(e);q?(Ca(e,!0),t.hide(h.fxName_close,h.fxSettings_close,h.fxSpeed_close,function(){Ca(e,!1);k.isClosed&&g();b()})):(Aa(e),g(),b())})}},Qa=function(d){var a=G[d],c=P[d],f=r[d],g=j[d].side,e=f.resizerClass,t=f.togglerClass,h="-"+d;a.css(g,s.inset[g]).removeClass(e+"-open "+e+h+"-open").removeClass(e+"-sliding "+e+h+"-sliding").addClass(e+
"-closed "+e+h+"-closed");f.resizable&&b.layout.plugins.draggable&&a.draggable("disable").removeClass("ui-state-disabled").css("cursor","default").attr("title","");c&&(c.removeClass(t+"-open "+t+h+"-open").addClass(t+"-closed "+t+h+"-closed").attr("title",f.tips.Open),c.children(".content-open").hide(),c.children(".content-closed").css("display","block"));Ra(d,!1);n.initialized&&na()},oa=function(b,a,c,f){function g(){k.isMoving=!1;$a(e);k.isSliding||ea("vert"==j[e].dir?"center":"",!1);Pa(e)}if(H()){var e=
y.call(this,b),h=u[e],i=r[e],k=n[e],q,s;p.queue(function(b){if(!h||!i.resizable&&!i.closable&&!k.isShowing||k.isVisible&&!k.isSliding)return b();if(k.isHidden&&!k.isShowing)b(),Ba(e,!0);else{k.autoResize&&k.size!=i.size?ga(e,i.size,!0,!0,!0):V(e,a);var d=E("onopen_start",e);if("abort"===d)return b();"NC"!==d&&V(e,a);if(k.minSize>k.maxSize)return Ra(e,!1),!f&&i.tips.noRoomToOpen&&alert(i.tips.noRoomToOpen),b();a?ta(e,!0):k.isSliding?ta(e,!1):i.slidable&&ja(e,!1);k.noRoom=!1;da(e);s=k.isShowing;delete k.isShowing;
q=!c&&k.isClosed&&"none"!=i.fxName_open;k.isMoving=!0;k.isVisible=!0;k.isClosed=!1;s&&(k.isHidden=!1);q?(Ca(e,!0),h.show(i.fxName_open,i.fxSettings_open,i.fxSpeed_open,function(){Ca(e,!1);k.isVisible&&g();b()})):(nb(e),g(),b())}})}},Pa=function(d,a){var c=u[d],f=G[d],g=P[d],e=r[d],h=n[d],i=j[d].side,k=e.resizerClass,q=e.togglerClass,p="-"+d;f.css(i,s.inset[i]+ca(d)).removeClass(k+"-closed "+k+p+"-closed").addClass(k+"-open "+k+p+"-open");h.isSliding?f.addClass(k+"-sliding "+k+p+"-sliding"):f.removeClass(k+
"-sliding "+k+p+"-sliding");$(0,f);e.resizable&&b.layout.plugins.draggable?f.draggable("enable").css("cursor",e.resizerCursor).attr("title",e.tips.Resize):h.isSliding||f.css("cursor","default");g&&(g.removeClass(q+"-closed "+q+p+"-closed").addClass(q+"-open "+q+p+"-open").attr("title",e.tips.Close),$(0,g),g.children(".content-closed").hide(),g.children(".content-open").css("display","block"));Ra(d,!h.isSliding);b.extend(h,C(c));n.initialized&&(na(),ma(d,!0));if(!a&&(n.initialized||e.triggerEventsOnLoad)&&
c.is(":visible"))E("onopen_end",d),h.isShowing&&E("onshow_end",d),n.initialized&&E("onresize_end",d)},ob=function(b){function a(){g.isClosed?g.isMoving||oa(f,!0):ta(f,!0)}if(H()){var c=U(b),f=y.call(this,b),g=n[f],b=r[f].slideDelay_open;c&&c.stopImmediatePropagation();g.isClosed&&c&&"mouseenter"===c.type&&0<b?L.set(f+"_openSlider",a,b):a()}},Sa=function(a){function c(){g.isClosed?ta(h,!1):g.isMoving||fa(h)}if(H()){var e=U(a),h=y.call(this,a),a=r[h],g=n[h],i=g.isMoving?1E3:300;!g.isClosed&&!g.isResizing&&
("click"===a.slideTrigger_close?c():a.preventQuickSlideClose&&g.isMoving||a.preventPrematureSlideClose&&e&&b.layout.isMouseOverElem(e,u[h])||(e?L.set(h+"_closeSlider",c,f(a.slideDelay_close,i)):c()))}},Ca=function(b,a){var c=u[b],f=n[b],g=r[b],e=r.zIndexes;a?(sa(b,{animation:!0,objectsOnly:!0}),c.css({zIndex:e.pane_animate}),"south"==b?c.css({top:s.inset.top+s.innerHeight-c.outerHeight()}):"east"==b&&c.css({left:s.inset.left+s.innerWidth-c.outerWidth()})):(wa(),c.css({zIndex:f.isSliding?e.pane_sliding:
e.pane_normal}),"south"==b?c.css({top:"auto"}):"east"==b&&!c.css("left").match(/\-99999/)&&c.css({left:"auto"}),M.msie&&(g.fxOpacityFix&&"slide"!=g.fxName_open&&c.css("filter")&&1==c.css("opacity"))&&c[0].style.removeAttribute("filter"))},ja=function(b,a){var c=r[b],f=G[b],g=c.slideTrigger_open.toLowerCase();if(f&&(!a||c.slidable)){g.match(/mouseover/)?g=c.slideTrigger_open="mouseenter":g.match(/(click|dblclick|mouseenter)/)||(g=c.slideTrigger_open="click");if(c.resizerDblClickToggle&&g.match(/click/))f[a?
"unbind":"bind"]("dblclick."+J,ka);f[a?"bind":"unbind"](g+"."+J,ob).css("cursor",a?c.sliderCursor:"default").attr("title",a?c.tips.Slide:"")}},ta=function(b,a){function c(a){L.clear(b+"_closeSlider");a.stopPropagation()}var f=r[b],g=n[b],e=r.zIndexes,h=f.slideTrigger_close.toLowerCase(),i=a?"bind":"unbind",k=u[b],q=G[b];L.clear(b+"_closeSlider");a?(g.isSliding=!0,n.panesSliding[b]=!0,ja(b,!1)):(g.isSliding=!1,delete n.panesSliding[b]);k.css("zIndex",a?e.pane_sliding:e.pane_normal);q.css("zIndex",
a?e.pane_sliding+2:e.resizer_normal);h.match(/(click|mouseleave)/)||(h=f.slideTrigger_close="mouseleave");q[i](h,Sa);"mouseleave"===h&&(k[i]("mouseleave."+J,Sa),q[i]("mouseenter."+J,c),k[i]("mouseenter."+J,c));a?"click"===h&&!f.resizable&&(q.css("cursor",a?f.sliderCursor:"default"),q.attr("title",a?f.tips.Close:"")):L.clear(b+"_closeSlider")},da=function(a,c,f,e){var c=r[a],g=n[a],h=j[a],i=u[a],p=G[a],k="vert"===h.dir,q=!1;if("center"===a||k&&g.noVerticalRoom)(q=0<=g.maxHeight)&&g.noRoom?(nb(a),p&&
p.show(),g.isVisible=!0,g.noRoom=!1,k&&(g.noVerticalRoom=!1),$a(a)):!q&&!g.noRoom&&(Aa(a),p&&p.hide(),g.isVisible=!1,g.noRoom=!0);"center"!==a&&(g.minSize<=g.maxSize?(g.size>g.maxSize?ga(a,g.maxSize,f,!0,e):g.size<g.minSize?ga(a,g.minSize,f,!0,e):p&&(g.isVisible&&i.is(":visible"))&&(f=g.size+s.inset[h.side],b.layout.cssNum(p,h.side)!=f&&p.css(h.side,f)),g.noRoom&&(g.wasOpen&&c.closable?c.autoReopen?oa(a,!1,!0,!0):g.noRoom=!1:Ba(a,g.wasOpen,!0,!0))):g.noRoom||(g.noRoom=!0,g.wasOpen=!g.isClosed&&!g.isSliding,
g.isClosed||(c.closable?fa(a,!0,!0):Oa(a,!0))))},za=function(b,a,c,f,g){if(H()){var b=y.call(this,b),e=r[b],h=n[b],g=g||e.livePaneResizing&&!h.isResizing;h.autoResize=!1;ga(b,a,c,f,g)}},ga=function(c,e,l,h,g){function i(){for(var a="width"===Q?q.outerWidth():q.outerHeight(),a=[{pane:t,count:1,target:e,actual:a,correct:e===a,attempt:e,cssSize:D}],c=a[0],d={},h="Inaccurate size after resizing the "+t+"-pane.";!c.correct;){d={pane:t,count:c.count+1,target:e};d.attempt=c.actual>e?f(0,c.attempt-(c.actual-
e)):f(0,c.attempt+(e-c.actual));d.cssSize=("horz"==j[t].dir?w:B)(u[t],d.attempt);q.css(Q,d.cssSize);d.actual="width"==Q?q.outerWidth():q.outerHeight();d.correct=e===d.actual;1===a.length&&(Z(h,!1,!0),Z(c,!1,!0));Z(d,!1,!0);if(3<a.length)break;a.push(d);c=a[a.length-1]}k.size=e;b.extend(k,C(q));k.isVisible&&q.is(":visible")&&(ra&&ra.css(A,e+s.inset[A]),ma(t));!l&&(!lb&&n.initialized&&k.isVisible)&&E("onresize_end",t);l||(k.isSliding||ea("horz"==j[t].dir?"":"center",lb,g),na());c=j.oppositeEdge[t];
e<v&&n[c].noRoom&&(V(c),da(c,!1,l));1<a.length&&Z(h+"\nSee the Error Console for details.",!0,!0)}if(H()){var t=y.call(this,c),ia=r[t],k=n[t],q=u[t],ra=G[t],A=j[t].side,Q=j[t].sizeType.toLowerCase(),lb=k.isResizing&&!ia.triggerEventsDuringLiveResize,x=!0!==h&&ia.animatePaneSizing,v,D;p.queue(function(c){V(t);v=k.size;e=ba(t,e);e=f(e,ba(t,ia.minSize));e=a(e,k.maxSize);if(e<k.minSize)c(),da(t,!1,l);else{if(!g&&e===v)return c();!l&&(n.initialized&&k.isVisible)&&E("onresize_start",t);D=("horz"==j[t].dir?
w:B)(u[t],e);if(x&&q.is(":visible")){var d=b.layout.effects.size[t]||b.layout.effects.size.all,d=ia.fxSettings_size.easing||d.easing,h=r.zIndexes,p={};p[Q]=D+"px";k.isMoving=!0;q.css({zIndex:h.pane_animate}).show().animate(p,ia.fxSpeed_size,d,function(){q.css({zIndex:k.isSliding?h.pane_sliding:h.pane_normal});k.isMoving=!1;i();c()})}else q.css(Q,D),q.is(":visible")?i():(k.size=e,b.extend(k,C(q))),c()}})}},ea=function(a,c,e){a=(a?a:"east,west,center").split(",");b.each(a,function(a,d){if(u[d]){var h=
r[d],i=n[d],j=u[d],k=!0,q={},p=b.layout.showInvisibly(j),A={top:ca("north",!0),bottom:ca("south",!0),left:ca("west",!0),right:ca("east",!0),width:0,height:0};A.width=s.innerWidth-A.left-A.right;A.height=s.innerHeight-A.bottom-A.top;A.top+=s.inset.top;A.bottom+=s.inset.bottom;A.left+=s.inset.left;A.right+=s.inset.right;b.extend(i,C(j));if("center"===d){if(!e&&i.isVisible&&A.width===i.outerWidth&&A.height===i.outerHeight)return j.css(p),!0;b.extend(i,va(d),{maxWidth:A.width,maxHeight:A.height});q=A;
q.width=B(j,q.width);q.height=w(j,q.height);k=0<=q.width&&0<=q.height;if(!n.initialized&&h.minWidth>A.width){var h=h.minWidth-i.outerWidth,A=r.east.minSize||0,Q=r.west.minSize||0,v=n.east.size,x=n.west.size,y=v,D=x;0<h&&(n.east.isVisible&&v>A)&&(y=f(v-A,v-h),h-=v-y);0<h&&(n.west.isVisible&&x>Q)&&(D=f(x-Q,x-h),h-=x-D);if(0===h){v&&v!=A&&ga("east",y,!0,!0,e);x&&x!=Q&&ga("west",D,!0,!0,e);ea("center",c,e);j.css(p);return}}}else{i.isVisible&&!i.noVerticalRoom&&b.extend(i,C(j),va(d));if(!e&&!i.noVerticalRoom&&
A.height===i.outerHeight)return j.css(p),!0;q.top=A.top;q.bottom=A.bottom;q.height=w(j,A.height);i.maxHeight=q.height;k=0<=i.maxHeight;k||(i.noVerticalRoom=!0)}k?(!c&&n.initialized&&E("onresize_start",d),j.css(q),"center"!==d&&na(d),i.noRoom&&(!i.isClosed&&!i.isHidden)&&da(d),i.isVisible&&(b.extend(i,C(j)),n.initialized&&ma(d))):!i.noRoom&&i.isVisible&&da(d);j.css(p);if(!i.isVisible)return!0;"center"===d&&(i=M.isIE6||!M.boxModel,u.north&&(i||"IFRAME"==n.north.tagName)&&u.north.css("width",B(u.north,
s.innerWidth)),u.south&&(i||"IFRAME"==n.south.tagName)&&u.south.css("width",B(u.south,s.innerWidth)));!c&&n.initialized&&E("onresize_end",d)}})},la=function(a){y(a);if(p.is(":visible"))if(n.initialized){if(!0===a&&b.isPlainObject(r.outset)&&p.css(r.outset),b.extend(s,C(p,r.inset)),s.outerHeight){!0===a&&jb();if(!1===E("onresizeall_start"))return!1;var c,e,f;b.each(["south","north","east","west"],function(b,a){u[a]&&(e=r[a],f=n[a],f.autoResize&&f.size!=e.size?ga(a,e.size,!0,!0,!0):(V(a),da(a,!1,!0,
!0)))});ea("",!0,!0);na();b.each(j.allPanes,function(b,a){(c=u[a])&&n[a].isVisible&&E("onresize_end",a)});E("onresizeall_end")}}else xa()},Za=function(a,c){var e=y.call(this,a);r[e].resizeChildren&&(c||ya(e),e=Y[e],b.isPlainObject(e)&&b.each(e,function(b,a){a.resizeAll()}))},ma=function(a,c){if(H()){var h=y.call(this,a),h=h?h.split(","):j.allPanes;b.each(h,function(a,d){function h(b){return f(p.css.paddingBottom,parseInt(b.css("marginBottom"),10)||0)}function i(){var b=r[d].contentIgnoreSelector,
b=k.nextAll().not(".ui-layout-mask").not(b||":lt(0)"),a=b.filter(":visible"),c=a.filter(":last");s={top:k[0].offsetTop,height:k.outerHeight(),numFooters:b.length,hiddenFooters:b.length-a.length,spaceBelow:0};s.spaceAbove=s.top;s.bottom=s.top+s.height;s.spaceBelow=c.length?c[0].offsetTop+c.outerHeight()-s.bottom+h(c):h(k)}var l=u[d],k=R[d],q=r[d],p=n[d],s=p.content;if(!l||!k||!l.is(":visible"))return!0;if(!k.length&&(Na(d,!1),!k))return;if(!1!==E("onsizecontent_start",d)){if(!p.isMoving&&!p.isResizing||
q.liveContentResizing||c||void 0==s.top)i(),0<s.hiddenFooters&&"hidden"===l.css("overflow")&&(l.css("overflow","visible"),i(),l.css("overflow","hidden"));l=p.innerHeight-(s.spaceAbove-p.css.paddingTop)-(s.spaceBelow-p.css.paddingBottom);if(!k.is(":visible")||s.height!=l){var v=k,q=v;e(v)?q=u[v]:v.jquery||(q=b(v));v=w(q,l);q.css({height:v,visibility:"visible"});0<v&&0<q.innerWidth()?q.data("autoHidden")&&(q.show().data("autoHidden",!1),M.mozilla||q.css(j.hidden).css(j.visible)):q.data("autoHidden")||
q.hide().data("autoHidden",!0);s.height=l}n.initialized&&E("onsizecontent_end",d)}})}},na=function(a){a=(a=y.call(this,a))?a.split(","):j.borderPanes;b.each(a,function(a,d){var f=r[d],g=n[d],h=u[d],i=G[d],p=P[d],k;if(h&&i){var q=j[d].dir,v=g.isClosed?"_closed":"_open",A=f["spacing"+v],x=f["togglerAlign"+v],v=f["togglerLength"+v],y;if(0===A)i.hide();else{!g.noRoom&&!g.isHidden&&i.show();"horz"===q?(y=s.innerWidth,g.resizerLength=y,h=b.layout.cssNum(h,"left"),i.css({width:B(i,y),height:w(i,A),left:-9999<
h?h:s.inset.left})):(y=h.outerHeight(),g.resizerLength=y,i.css({height:w(i,y),width:B(i,A),top:s.inset.top+ca("north",!0)}));$(f,i);if(p){if(0===v||g.isSliding&&f.hideTogglerOnSlide){p.hide();return}p.show();if(!(0<v)||"100%"===v||v>y)v=y,x=0;else if(e(x))switch(x){case "top":case "left":x=0;break;case "bottom":case "right":x=y-v;break;default:x=c((y-v)/2)}else h=parseInt(x,10),x=0<=x?h:y-v+h;if("horz"===q){var C=B(p,v);p.css({width:C,height:w(p,A),left:x,top:0});p.children(".content").each(function(){k=
b(this);k.css("marginLeft",c((C-k.outerWidth())/2))})}else{var D=w(p,v);p.css({height:D,width:B(p,A),top:x,left:0});p.children(".content").each(function(){k=b(this);k.css("marginTop",c((D-k.outerHeight())/2))})}$(0,p)}if(!n.initialized&&(f.initHidden||g.noRoom))i.hide(),p&&p.hide()}}})},kb=function(b){if(H()){var a=y.call(this,b),b=P[a],c=r[a];b&&(c.closable=!0,b.bind("click."+J,function(b){b.stopPropagation();ka(a)}).css("visibility","visible").css("cursor","pointer").attr("title",n[a].isClosed?
c.tips.Open:c.tips.Close).show())}},Ra=function(a,c){b.layout.plugins.buttons&&b.each(n[a].pins,function(e,f){b.layout.buttons.setPinState(x,b(f),a,c)})},p=b(this).eq(0);if(!p.length)return Z(r.errors.containerMissing);if(p.data("layoutContainer")&&p.data("layout"))return p.data("layout");var u={},R={},G={},P={},aa=b([]),s=n.container,J=n.id,x={options:r,state:n,container:p,panes:u,contents:R,resizers:G,togglers:P,hide:Oa,show:Ba,toggle:ka,open:oa,close:fa,slideOpen:ob,slideClose:Sa,slideToggle:function(b){b=
y.call(this,b);ka(b,!0)},setSizeLimits:V,_sizePane:ga,sizePane:za,sizeContent:ma,swapPanes:function(a,c){function e(a){var c=u[a],d=R[a];return!c?!1:{pane:a,P:c?c[0]:!1,C:d?d[0]:!1,state:b.extend(!0,{},n[a]),options:b.extend(!0,{},r[a])}}function h(a,c){if(a){var d=a.P,e=a.C,g=a.pane,i=j[c],l=b.extend(!0,{},n[c]),m=r[c],p={resizerCursor:m.resizerCursor};b.each(["fxName","fxSpeed","fxSettings"],function(b,a){p[a+"_open"]=m[a+"_open"];p[a+"_close"]=m[a+"_close"];p[a+"_size"]=m[a+"_size"]});u[c]=b(d).data({layoutPane:x[c],
layoutEdge:c}).css(j.hidden).css(i.cssReq);R[c]=e?b(e):!1;r[c]=b.extend(!0,{},a.options,p);n[c]=b.extend(!0,{},a.state);d.className=d.className.replace(RegExp(m.paneClass+"-"+g,"g"),m.paneClass+"-"+c);Ka(c);i.dir!=j[g].dir?(d=v[c]||0,V(c),d=f(d,n[c].minSize),za(c,d,!0,!0)):G[c].css(i.side,s.inset[i.side]+(n[c].isVisible?ca(c):0));a.state.isVisible&&!l.isVisible?Pa(c,!0):(Qa(c),ja(c,!0));a=null}}if(H()){var g=y.call(this,a);n[g].edge=c;n[c].edge=g;if(!1===E("onswap_start",g)||!1===E("onswap_start",
c))n[g].edge=g,n[c].edge=c;else{var i=e(g),p=e(c),v={};v[g]=i?i.state.size:0;v[c]=p?p.state.size:0;u[g]=!1;u[c]=!1;n[g]={};n[c]={};P[g]&&P[g].remove();P[c]&&P[c].remove();G[g]&&G[g].remove();G[c]&&G[c].remove();G[g]=G[c]=P[g]=P[c]=!1;h(i,c);h(p,g);i=p=v=null;u[g]&&u[g].css(j.visible);u[c]&&u[c].css(j.visible);la();E("onswap_end",g);E("onswap_end",c)}}},showMasks:sa,hideMasks:wa,initContent:Na,addPane:db,removePane:Ma,createChildren:La,refreshChildren:ya,enableClosable:kb,disableClosable:function(a,
b){if(H()){var c=y.call(this,a),e=P[c];e&&(r[c].closable=!1,n[c].isClosed&&oa(c,!1,!0),e.unbind("."+J).css("visibility",b?"hidden":"visible").css("cursor","default").attr("title",""))}},enableSlidable:function(a){if(H()){var a=y.call(this,a),b=G[a];b&&b.data("draggable")&&(r[a].slidable=!0,n[a].isClosed&&ja(a,!0))}},disableSlidable:function(a){if(H()){var a=y.call(this,a),b=G[a];b&&(r[a].slidable=!1,n[a].isSliding?fa(a,!1,!0):(ja(a,!1),b.css("cursor","default").attr("title",""),$(null,b[0])))}},enableResizable:function(a){if(H()){var a=
y.call(this,a),b=G[a],c=r[a];b&&b.data("draggable")&&(c.resizable=!0,b.draggable("enable"),n[a].isClosed||b.css("cursor",c.resizerCursor).attr("title",c.tips.Resize))}},disableResizable:function(a){if(H()){var a=y.call(this,a),b=G[a];b&&b.data("draggable")&&(r[a].resizable=!1,b.draggable("disable").css("cursor","default").attr("title",""),$(null,b[0]))}},allowOverflow:O,resetOverflow:I,destroy:function(a,c){b(window).unbind("."+J);b(document).unbind("."+J);"object"===typeof a?y(a):c=a;p.clearQueue().removeData("layout").removeData("layoutContainer").removeClass(r.containerClass).unbind("."+
J);aa.remove();b.each(j.allPanes,function(a,b){Ma(b,!1,!0,c)});p.data("layoutCSS")&&!p.data("layoutRole")&&p.css(p.data("layoutCSS")).removeData("layoutCSS");"BODY"===s.tagName&&(p=b("html")).data("layoutCSS")&&p.css(p.data("layoutCSS")).removeData("layoutCSS");h(x,b.layout.onDestroy);hb();for(var e in x)e.match(/^(container|options)$/)||delete x[e];x.destroyed=!0;return x},initPanes:H,resizeAll:la,runCallbacks:E,hasParentLayout:!1,children:Y,north:!1,south:!1,west:!1,east:!1,center:!1},Ta;var S,
Ua,N,Da,ha,pa,T,i=b.layout.transformData(i,!0),i=b.layout.backwardCompatibility.renameAllOptions(i);if(!b.isEmptyObject(i.panes)){S=b.layout.optionsMap.noDefault;ha=0;for(pa=S.length;ha<pa;ha++)N=S[ha],delete i.panes[N];S=b.layout.optionsMap.layout;ha=0;for(pa=S.length;ha<pa;ha++)N=S[ha],delete i.panes[N]}S=b.layout.optionsMap.layout;var wb=b.layout.config.optionRootKeys;for(N in i)Da=i[N],0>b.inArray(N,wb)&&0>b.inArray(N,S)&&(i.panes[N]||(i.panes[N]=b.isPlainObject(Da)?b.extend(!0,{},Da):Da),delete i[N]);
b.extend(!0,r,i);b.each(j.allPanes,function(a,c){j[c]=b.extend(!0,{},j.panes,j[c]);Ua=r.panes;T=r[c];if("center"===c){S=b.layout.optionsMap.center;a=0;for(pa=S.length;a<pa;a++)if(N=S[a],!i.center[N]&&(i.panes[N]||!T[N]))T[N]=Ua[N]}else{T=r[c]=b.extend(!0,{},Ua,T);var e=r[c],f=r.panes;e.fxSettings||(e.fxSettings={});f.fxSettings||(f.fxSettings={});b.each(["_open","_close","_size"],function(a,d){var h="fxName"+d,i="fxSpeed"+d,k="fxSettings"+d,j=e[h]=e[h]||f[h]||e.fxName||f.fxName||"none";if("none"===
j||!r.effects[j]||!b.effects||!b.effects[j]&&!b.effects.effect[j])j=e[h]="none";j=r.effects[j]||{};h=j.all||null;j=j[c]||null;e[i]=e[i]||f[i]||e.fxSpeed||f.fxSpeed||null;e[k]=b.extend(!0,{},h,j,f.fxSettings,e.fxSettings,f[k],e[k])});delete e.fxName;delete e.fxSpeed;delete e.fxSettings;T.resizerClass||(T.resizerClass="ui-layout-resizer");T.togglerClass||(T.togglerClass="ui-layout-toggler")}T.paneClass||(T.paneClass="ui-layout-pane")});var Ea=i.zIndex,ua=r.zIndexes;0<Ea&&(ua.pane_normal=Ea,ua.content_mask=
f(Ea+1,ua.content_mask),ua.resizer_normal=f(Ea+2,ua.resizer_normal));delete r.panes;var xb=r,pb=n;pb.creatingLayout=!0;h(x,b.layout.onCreate);if(!1===E("onload_start"))Ta="cancel";else{var Va=p[0],W=b("html"),qb=s.tagName=Va.tagName,rb=s.id=Va.id,sb=s.className=Va.className,K=r,Fa=K.name,Wa={},Ga=p.data("parentLayout"),Ha=p.data("layoutEdge"),Xa=Ga&&Ha,qa=b.layout.cssNum,Ya,X;s.selector=p.selector.split(".slice")[0];s.ref=(K.name?K.name+" layout / ":"")+qb+(rb?"#"+rb:sb?".["+sb+"]":"");s.isBody="BODY"===
qb;!Xa&&!s.isBody&&(Ya=p.closest("."+b.layout.defaults.panes.paneClass),Ga=Ya.data("parentLayout"),Ha=Ya.data("layoutEdge"),Xa=Ga&&Ha);p.data({layout:x,layoutContainer:J}).addClass(K.containerClass);var tb={destroy:"",initPanes:"",resizeAll:"resizeAll",resize:"resizeAll"};for(Fa in tb)p.bind("layout"+Fa.toLowerCase()+"."+J,x[tb[Fa]||Fa]);Xa&&(x.hasParentLayout=!0,Ga.refreshChildren(Ha,x));p.data("layoutCSS")||(s.isBody?(p.data("layoutCSS",b.extend(D(p,"position,margin,padding,border"),{height:p.css("height"),
overflow:p.css("overflow"),overflowX:p.css("overflowX"),overflowY:p.css("overflowY")})),W.data("layoutCSS",b.extend(D(W,"padding"),{height:"auto",overflow:W.css("overflow"),overflowX:W.css("overflowX"),overflowY:W.css("overflowY")}))):p.data("layoutCSS",D(p,"position,margin,padding,border,top,bottom,left,right,width,height,overflow,overflowX,overflowY")));try{Wa={overflow:"hidden",overflowX:"hidden",overflowY:"hidden"};p.css(Wa);K.inset&&!b.isPlainObject(K.inset)&&(X=parseInt(K.inset,10)||0,K.inset=
{top:X,bottom:X,left:X,right:X});if(s.isBody)K.outset?b.isPlainObject(K.outset)||(X=parseInt(K.outset,10)||0,K.outset={top:X,bottom:X,left:X,right:X}):K.outset={top:qa(W,"paddingTop"),bottom:qa(W,"paddingBottom"),left:qa(W,"paddingLeft"),right:qa(W,"paddingRight")},W.css(Wa).css({height:"100%",border:"none",padding:0,margin:0}),M.isIE6?(p.css({width:"100%",height:"100%",border:"none",padding:0,margin:0,position:"relative"}),K.inset||(K.inset=C(p).inset)):(p.css({width:"auto",height:"auto",margin:0,
position:"absolute"}),p.css(K.outset)),b.extend(s,C(p,K.inset));else{var ub=p.css("position");(!ub||!ub.match(/(fixed|absolute|relative)/))&&p.css("position","relative");p.is(":visible")&&(b.extend(s,C(p,K.inset)),1>s.innerHeight&&Z(K.errors.noContainerHeight.replace(/CONTAINER/,s.ref)))}qa(p,"minWidth")&&p.parent().css("overflowX","auto");qa(p,"minHeight")&&p.parent().css("overflowY","auto")}catch(yb){}ib();b(window).bind("unload."+J,hb);h(x,b.layout.onLoad);xb.initPanes&&xa();delete pb.creatingLayout;
Ta=n.initialized}return"cancel"===Ta?null:x};b(function(){var a=b.layout.browser;a.msie&&(a.boxModel=b.support.boxModel)})})(jQuery);
(function(b){b.ui||(b.ui={});b.ui.cookie={acceptsCookies:!!navigator.cookieEnabled,read:function(a){for(var f=document.cookie,f=f?f.split(";"):[],c,e=0,h=f.length;e<h;e++)if(c=b.trim(f[e]).split("="),c[0]==a)return decodeURIComponent(c[1]);return null},write:function(a,b,c){var e="",h="",i=!1,c=c||{},v=c.expires;if(v&&v.toUTCString)h=v;else if(null===v||"number"===typeof v)h=new Date,0<v?h.setDate(h.getDate()+v):(h.setFullYear(1970),i=!0);h&&(e+=";expires="+h.toUTCString());c.path&&(e+=";path="+c.path);
c.domain&&(e+=";domain="+c.domain);c.secure&&(e+=";secure");document.cookie=a+"="+(i?"":encodeURIComponent(b))+e},clear:function(a){b.ui.cookie.write(a,"",{expires:-1})}};b.cookie||(b.cookie=function(a,f,c){var e=b.ui.cookie;if(null===f)e.clear(a);else{if(void 0===f)return e.read(a);e.write(a,f,c)}});b.layout.plugins.stateManagement=!0;b.layout.config.optionRootKeys.push("stateManagement");b.layout.defaults.stateManagement={enabled:!1,autoSave:!0,autoLoad:!0,includeChildren:!0,stateKeys:"north.size,south.size,east.size,west.size,north.isClosed,south.isClosed,east.isClosed,west.isClosed,north.isHidden,south.isHidden,east.isHidden,west.isHidden",
cookie:{name:"",domain:"",path:"",expires:"",secure:!1}};b.layout.optionsMap.layout.push("stateManagement");b.layout.state={saveCookie:function(a,f,c){var e=a.options,h=e.stateManagement,c=b.extend(!0,{},h.cookie,c||null),a=a.state.stateData=a.readState(f||h.stateKeys);b.ui.cookie.write(c.name||e.name||"Layout",b.layout.state.encodeJSON(a),c);return b.extend(!0,{},a)},deleteCookie:function(a){a=a.options;b.ui.cookie.clear(a.stateManagement.cookie.name||a.name||"Layout")},readCookie:function(a){a=
a.options;return(a=b.ui.cookie.read(a.stateManagement.cookie.name||a.name||"Layout"))?b.layout.state.decodeJSON(a):{}},loadCookie:function(a){var f=b.layout.state.readCookie(a);f&&(a.state.stateData=b.extend(!0,{},f),a.loadState(f));return f},loadState:function(a,f){f=b.layout.transformData(f);if(b.isPlainObject(f)&&!b.isEmptyObject(f)){a.state.stateData=f;var c=b.extend(!0,{},f);b.each(b.layout.config.allPanes,function(a,b){c[b]&&delete c[b].children});b.extend(!0,a.options,c)}},readState:function(a,
f){"string"===b.type(f)&&(f={keys:f});f||(f={});var c=a.options.stateManagement,e=f.includeChildren,e=void 0!==e?e:c.includeChildren,c=f.stateKeys||c.stateKeys,h={isClosed:"initClosed",isHidden:"initHidden"},i=a.state,v=b.layout.config.allPanes,O={},I,M,j,B,w,C;b.isArray(c)&&(c=c.join(","));for(var c=c.replace(/__/g,".").split(","),D=0,U=c.length;D<U;D++)I=c[D].split("."),M=I[0],I=I[1],0>b.inArray(M,v)||(j=i[M][I],void 0!=j&&("isClosed"==I&&i[M].isSliding&&(j=!0),(O[M]||(O[M]={}))[h[I]?h[I]:I]=j));
e&&b.each(v,function(c,e){w=a.children[e];B=i.stateData[e];b.isPlainObject(w)&&!b.isEmptyObject(w)&&(C=O[e]||(O[e]={}),C.children||(C.children={}),b.each(w,function(a,c){c.state.initialized?C.children[a]=b.layout.state.readState(c):B&&(B.children&&B.children[a])&&(C.children[a]=b.extend(!0,{},B.children[a]))}))});return O},encodeJSON:function(a){function f(a){var e=[],h=0,i,v,O,I=b.isArray(a);for(i in a)v=a[i],O=typeof v,"string"==O?v='"'+v+'"':"object"==O&&(v=f(v)),e[h++]=(!I?'"'+i+'":':"")+v;return(I?
"[":"{")+e.join(",")+(I?"]":"}")}return f(a)},decodeJSON:function(a){try{return b.parseJSON?b.parseJSON(a):window.eval("("+a+")")||{}}catch(f){return{}}},_create:function(a){var f=b.layout.state,c=a.options.stateManagement;b.extend(a,{readCookie:function(){return f.readCookie(a)},deleteCookie:function(){f.deleteCookie(a)},saveCookie:function(b,c){return f.saveCookie(a,b,c)},loadCookie:function(){return f.loadCookie(a)},loadState:function(b,c){f.loadState(a,b,c)},readState:function(b){return f.readState(a,
b)},encodeJSON:f.encodeJSON,decodeJSON:f.decodeJSON});a.state.stateData={};if(c.autoLoad)if(b.isPlainObject(c.autoLoad))b.isEmptyObject(c.autoLoad)||a.loadState(c.autoLoad);else if(c.enabled)if(b.isFunction(c.autoLoad)){var e={};try{e=c.autoLoad(a,a.state,a.options,a.options.name||"")}catch(h){}e&&(b.isPlainObject(e)&&!b.isEmptyObject(e))&&a.loadState(e)}else a.loadCookie()},_unload:function(a){var f=a.options.stateManagement;if(f.enabled&&f.autoSave)if(b.isFunction(f.autoSave))try{f.autoSave(a,a.state,
a.options,a.options.name||"")}catch(c){}else a.saveCookie()}};b.layout.onCreate.push(b.layout.state._create);b.layout.onUnload.push(b.layout.state._unload);b.layout.plugins.buttons=!0;b.layout.defaults.autoBindCustomButtons=!1;b.layout.optionsMap.layout.push("autoBindCustomButtons");b.layout.buttons={init:function(a){var f=a.options.name||"",c;b.each("toggle open close pin toggle-slide open-slide".split(" "),function(e,h){b.each(b.layout.config.borderPanes,function(e,v){b(".ui-layout-button-"+h+"-"+
v).each(function(){c=b(this).data("layoutName")||b(this).attr("layoutName");(void 0==c||c===f)&&a.bindButton(this,h,v)})})})},get:function(a,f,c,e){var h=b(f),a=a.options,i=a.errors.addButtonError;h.length?0>b.inArray(c,b.layout.config.borderPanes)?(b.layout.msg(i+" "+a.errors.pane+": "+c,!0),h=b("")):(f=a[c].buttonClass+"-"+e,h.addClass(f+" "+f+"-"+c).data("layoutName",a.name)):b.layout.msg(i+" "+a.errors.selector+": "+f,!0);return h},bind:function(a,f,c,e){var h=b.layout.buttons;switch(c.toLowerCase()){case "toggle":h.addToggle(a,
f,e);break;case "open":h.addOpen(a,f,e);break;case "close":h.addClose(a,f,e);break;case "pin":h.addPin(a,f,e);break;case "toggle-slide":h.addToggle(a,f,e,!0);break;case "open-slide":h.addOpen(a,f,e,!0)}return a},addToggle:function(a,f,c,e){b.layout.buttons.get(a,f,c,"toggle").click(function(b){a.toggle(c,!!e);b.stopPropagation()});return a},addOpen:function(a,f,c,e){b.layout.buttons.get(a,f,c,"open").attr("title",a.options[c].tips.Open).click(function(b){a.open(c,!!e);b.stopPropagation()});return a},
addClose:function(a,f,c){b.layout.buttons.get(a,f,c,"close").attr("title",a.options[c].tips.Close).click(function(b){a.close(c);b.stopPropagation()});return a},addPin:function(a,f,c){var e=b.layout.buttons,h=e.get(a,f,c,"pin");if(h.length){var i=a.state[c];h.click(function(f){e.setPinState(a,b(this),c,i.isSliding||i.isClosed);i.isSliding||i.isClosed?a.open(c):a.close(c);f.stopPropagation()});e.setPinState(a,h,c,!i.isClosed&&!i.isSliding);i.pins.push(f)}return a},setPinState:function(a,b,c,e){var h=
b.attr("pin");if(!(h&&e===("down"==h))){var a=a.options[c],h=a.buttonClass+"-pin",i=h+"-"+c,c=h+"-up "+i+"-up",h=h+"-down "+i+"-down";b.attr("pin",e?"down":"up").attr("title",e?a.tips.Unpin:a.tips.Pin).removeClass(e?c:h).addClass(e?h:c)}},syncPinBtns:function(a,f,c){b.each(a.state[f].pins,function(e,h){b.layout.buttons.setPinState(a,b(h),f,c)})},_load:function(a){var f=b.layout.buttons;b.extend(a,{bindButton:function(b,c,i){return f.bind(a,b,c,i)},addToggleBtn:function(b,c,i){return f.addToggle(a,
b,c,i)},addOpenBtn:function(b,c,i){return f.addOpen(a,b,c,i)},addCloseBtn:function(b,c){return f.addClose(a,b,c)},addPinBtn:function(b,c){return f.addPin(a,b,c)}});for(var c=0;4>c;c++)a.state[b.layout.config.borderPanes[c]].pins=[];a.options.autoBindCustomButtons&&f.init(a)},_unload:function(){}};b.layout.onLoad.push(b.layout.buttons._load);b.layout.plugins.browserZoom=!0;b.layout.defaults.browserZoomCheckInterval=1E3;b.layout.optionsMap.layout.push("browserZoomCheckInterval");b.layout.browserZoom=
{_init:function(a){!1!==b.layout.browserZoom.ratio()&&b.layout.browserZoom._setTimer(a)},_setTimer:function(a){if(!a.destroyed){var f=a.options,c=a.state,e=a.hasParentLayout?5E3:Math.max(f.browserZoomCheckInterval,100);setTimeout(function(){if(!a.destroyed&&f.resizeWithWindow){var e=b.layout.browserZoom.ratio();e!==c.browserZoom&&(c.browserZoom=e,a.resizeAll());b.layout.browserZoom._setTimer(a)}},e)}},ratio:function(){function a(a,b){return(100*(parseInt(a,10)/parseInt(b,10))).toFixed()}var f=window,
c=screen,e=document,h=e.documentElement||e.body,i=b.layout.browser,v=i.version,O,I,M;return i.msie&&8<v||!i.msie?!1:c.deviceXDPI&&c.systemXDPI?a(c.deviceXDPI,c.systemXDPI):i.webkit&&(O=e.body.getBoundingClientRect)?a(O.left-O.right,e.body.offsetWidth):i.webkit&&(I=f.outerWidth)?a(I,f.innerWidth):(I=c.width)&&(M=h.clientWidth)?a(I,M):!1}};b.layout.onReady.push(b.layout.browserZoom._init)})(jQuery);
/*! RESOURCE: /scripts/classes/NavPageManager.js */
var NavPageManager = Class.create({
PROCESSOR: 'com.glide.ui11.NavPageProcessor',
initialize : function(options) {
this.initTabs()
this.options = Object.extend({
formTarget : null
}, options || {});
Object.extend(this, NavPageStateButtons).initNavPageStateButtons();
Object.extend(this, NavPagePreferences).initNavPagePreferences();
Object.extend(this, NavPageBookmarks).initNavPageBookmarks();
Object.extend(this, NavPageFlyouts).initNavPageFlyouts();
Object.extend(this, NavPagePanes).initNavPagePanes();
Object.extend(this, NavPageLayouts).initNavPageLayouts();
CustomEvent.observe(GlideEvent.NAV_OPEN_URL, this._openURL.bind(this));
CustomEvent.observe(GlideEvent.NAV_PANE_CLICKED, function(event) {
CustomEvent.fire(GlideEvent.NAV_HIDE_FLYOUTS, event);
});
this._window = window;
this._isLoaded = false;
Element.observe(window, 'load', function() {
this._isLoaded = true;
this.getLayout('body').resizeAll();
CustomEvent.fire(GlideEvent.NAV_UPDATE_EDGE_BUTTON_STATES);
CustomEvent.fire(GlideEvent.NAV_MANAGER_LOADED);
}.bind(this));
},
isLoaded: function() {
return this._isLoaded;
},
getWindow: function() {
return this._window;
},
getFormTarget: function() {
if (!this.options.formTarget)
return null;
return this.currentPane;
},
focusExistingTab: function(url) {
if (!this.getFormTarget())
return;
var url = new GlideURL(url);
var sysId = url.params['sys_id'];
var matchedTabs = $j("#gsft_main_forms").find('span[data-sys-id="'+ sysId +'"]');
if (matchedTabs.length) {
matchedTabs.get(0).click();
return true;
}
return false;
},
_openURL: function(options) {
var opts = Object.extend({
url: null,
openInForm: false
}, options || {});
if (!opts.url)
return;
if (!this.focusExistingTab(opts.url)) {
var pane = this[this.options.formTarget && opts.openInForm === true ? 'getMainFormPane' : 'getMainPane']();
pane.loadLinkFromUrl(opts.url);
}
},
initTabs : function() {
var $ = $j;
this.isTabbed = false;
if (!$("#gsft_main_forms").length)
return;
this.isTabbed = true;
this.tabNumber = 0;
var self = this;
$(".tabs2_tab").on("click", onClick);
$(".tabs2_close").on( "click", onCloseClick);
CustomEvent.observe("form-title", setFormTitle.bind(this));
function onClick(evt) {
var ti = findTabInfo(this);
if (ti.$tab.hasClass("tabs2_add")) {
addTab(ti);
return;
}
activateTab(ti, ti.$tab);
}
function onCloseClick(evt) {
evt.stopPropagation();
var ti = findTabInfo(this);
var current = ti.$tab.hasClass("tabs2_active");
var tabToActivate = ti.$tabs[ti.index+1] === undefined ? ti.$tabs[ti.index-1] : ti.$tabs[ti.index+1];
var frame = $('#' + ti.$tab.data('iframeId'))[0];
var frameWin = frame.contentWindow;
frameWin.location.href = "about:blank";
$j(frame).one('load', function() {
if (frameWin.location.href != 'about:blank')
return;
ti.$tab.remove();
if (!current)
return;
activateTab(ti, tabToActivate);
});
}
function findTabInfo(e) {
var ti = {};
ti.$tabstrip = $(e).closest(".tabs2_strip");
ti.$tab = $(e).closest(".tabs2_tab");
ti.$tabs = ti.$tabstrip.children("span");
ti.index = ti.$tabs.index(ti.$tab);
ti.content = ti.$tabstrip[0].nextSibling;
return ti;
}
function setFormTitle(frameInfo) {
var $tabs = $(".tabs2_strip").children();
$tabs.each(function(i, tab){
if ($(tab).data('iframeId') === frameInfo.iframeId) {
$(tab).html(frameInfo.title + '<span class="tabs2_close icon-cross"></span>');
$(tab).attr("data-sys-id", frameInfo.sysId);
}
});
$(".tabs2_close").off("click", onCloseClick).on("click", onCloseClick);
}
function addTab(ti) {
var o = {};
self.tabNumber++;
o.tabNumber = self.tabNumber;
var iframeId = 'gsft_main_form' + o.tabNumber;
var $t = $(new XMLTemplate('tab_template').evaluate(o));
$t.data('iframeId', iframeId);
ti.$tab.before($t);
$(".tabs2_tab").off("click", onClick);
$(".tabs2_close").off( "click", onCloseClick);
$(".tabs2_tab").on("click", onClick);
$(".tabs2_close").on( "click", onCloseClick);
var $f = $(new XMLTemplate('iframe_template').evaluate(o));
$(ti.content).append($f);
self.addPane(iframeId);
activateTab(ti, $t);
}
function activateTab(ti, tab) {
ti.$tabs.removeClass("tabs2_active");
$(tab).addClass("tabs2_active");
$(ti.content).children().hide();
var iframeId = $(tab).data("iframeId");
$('#' + iframeId).show();
self.setCurrentPane(iframeId);
CustomEvent.fire(GlideEvent.NAV_SYNC_LIST_WITH_FORM, self.getPane(iframeId));
}
},
hasActiveTabs: function() {
if (this.tabNumber > 1)
return true;
var currentTabSrc = $j('iframe[name=' + this.currentPane + ']').prop('src');
return currentTabSrc.indexOf('navpage_form_default.do') == -1;
},
toString: function() { return 'NavPageManager'; }
});
NavPageManager.init = function(options) {
window.g_navManager = new NavPageManager(options);
};
NavPageManager.get = function() {
return window.g_navManager || window.top.g_navManager;
};
;
/*! RESOURCE: /scripts/classes/edge/EdgeBookmark.js */
var EdgeBookmark = Class.create({
initialize: function(options) {
this.options = Object.extend({
id: null,
image: null,
fontIcon: 'icon-help',
url: null,
title: null,
openInForm: false,
flyout: false,
flyoutWidth: 0,
pinned: true,
cancelable: true,
sizing: 'auto'
}, options || {});
this.dirty = false;
},
getBookmarkEdgeHtml: function() {
var color = $j.grep(this.options.fontIcon.split(" "), function(v, i) {
return v.indexOf('color-') === 0;
}).join();
var o = {
id: this.options.id,
image: this.options.image,
fontIcon: this.options.fontIcon,
color: color,
url: this.options.url,
title: this.options.title
};
return this.options.pinned !== true ? '' : new XMLTemplate('navpage_bookmark_pinned_item').evaluate(Object.extend(o, {
edge_tooltip: new XMLTemplate('navpage_bookmark_tooltip').evaluate(o)
}));
},
getAllBookmarksRowHtml: function() {
return new XMLTemplate('navpage_all_bookmarks_item').evaluate({
id: this.options.id,
image: this.options.image,
fontIcon: this.options.fontIcon,
url: this.options.url,
title: this.options.title
});
},
hideTooltip: function() {
if (this.tooltip)
this.tooltip.hide();
},
remove: function() {
$('edge_all_bookmarks_content_main').select('[data-bookmark-id="' + this.options.id + '"]').each(function(elem) {
elem.remove();
});
if (this.options.pinned !== true)
return;
if (this.tooltip) {
var tip = this.tooltip.getTip();
if (tip)
tip.remove();
}
this._getEdgeButton().remove();
CustomEvent.fire(GlideEvent.NAV_REMOVE_FLYOUT, NavPageManager.get().getFlyout(this.options.id));
},
initEvents: function() {
if (this.options.pinned !== true)
return;
var edgeButton = this._getEdgeButton();
this._initEdgeButtonHover(edgeButton);
this._initEdgeButtonClick(edgeButton);
this._initEdgeButtonDrag(edgeButton);
},
openBookmark: function(event) {
if ((event && event.shiftKey) || (this.options.flyout !== true && (event && !event.ctrlKey && !event.metaKey))) {
if (g_cancelPreviousTransaction && this.options.cancelable) {
setTimeout(function(origURL) {
this.options.url = origURL;
}.bind(this, this.options.url), 50);
var nextChar = this.options.url.indexOf('?') > -1 ? '&' : '?';
this.options.url += nextChar + 'sysparm_cancelable=true';
}
CustomEvent.fire(GlideEvent.NAV_HIDE_FLYOUTS);
CustomEvent.fire(GlideEvent.NAV_OPEN_URL, this.options);
} else {
this.openBookmarkAsFlyout();
}
CustomEvent.fire(GlideEvent.NAV_OPEN_BOOKMARK, {
id: this.options.id
});
},
openBookmarkAsFlyout: function() {
var flyout = NavPageManager.get().getFlyout(this.options.id);
var edgeAlign;
this.docDirection = $$('html')[0].dir === 'rtl' ? edgeAlign = 'right' : edgeAlign = 'left';
if (!flyout) {
flyout = new EdgeFlyoutBookmark({
id: this.options.id,
url: this.options.url,
title: this.options.title,
image: this.options.image,
fontIcon: this.options.fontIcon,
sizing: this.options.sizing,
flyoutWidth: this.options.flyoutWidth,
draggable: false,
showArrow: true,
arrowRefElement: 'div.edge_item[data-bookmark-id="' + this.options.id + '"] > button',
edgeAlign: edgeAlign
});
}
CustomEvent.fire(GlideEvent.NAV_TOGGLE_FLYOUT, flyout);
CustomEvent.fire(GlideEvent.NAV_OPEN_BOOKMARK, {
id: this.options.id
});
},
isDirty: function() {
return this.dirty;
},
markDirty: function() {
this._getEdgeButton().addClassName('dirty');
},
clearDirty: function() {
this.dirty = false;
this._getEdgeButton().removeClassName('dirty');
},
_initEdgeButtonHover: function(button) {
var self = this;
button.tooltip({
relative: false,
position: 'right top-baseline',
offset: [5, -2],
predelay: 300,
delay: 420,
onBeforeShow: function() {
CustomEvent.fire(GlideEvent.NAV_HIDE_ALL_TOOLTIPS);
var flyout = NavPageManager.get().getFlyout(self.options.id);
if (flyout && flyout.isVisible())
return false;
var tip = this.getTip();
tip.select('.edge_flyout_main_content')[0].innerHTML = '';
tip.select('.edge_tooltip_inner')[0].addClassName('no_main_content');
tip.select('.edge_flyout_footer_content')[0].innerHTML = new XMLTemplate('edge_bookmark_default_footer_content').evaluate({});
tip.setStyle({width: ''});
var maxWidth = tip.getStyle('max-width');
if (maxWidth == 'none')
maxWidth = 305;
if (maxWidth === undefined)
tip.setStyle({width: '305px'});
else
tip.setStyle({width: Math.min(parseInt(maxWidth, 10), tip.getWidth()) + 'px'});
button.addClassName('active');
},
onShow: function() {
var scrollTop = $j('#edge_west').scrollTop();
if (scrollTop == 0)
return;
var offset = $j(this.getTrigger()).offset().top;
$j(this.getTip()).css('top', offset);
},
onHide: function() {
button.removeClassName('active');
GlideOverlay.hideMask();
},
onTipInit: function() {
var tip = this.getTip();
var tooltip = this;
tip.on('click', '.edge_bookmark_link', function(event) {
$j('#edge_west').trigger('click');
tooltip.hide();
self.openBookmark(event);
event.stop();
});
tip.on('click', 'a.edit_bookmark', function() {
var color = $j.grep(self.options.fontIcon.split(" "), function(v, i) {
return v.indexOf('color-') === 0;
}).join();
tip.select('.edge_flyout_main_content')[0].innerHTML = new XMLTemplate('edge_bookmark_edit_main_content').evaluate({
url: self.options.url,
title: self.options.title,
image: self.options.image,
fontIcon: self.options.fontIcon,
color: color
});
if (self.options.pinned === true)
tip.down('input[name="pinned"]').writeAttribute('checked', 'checked');
if (self.options.flyout === true)
tip.down('input[name="flyout"]').writeAttribute('checked', 'checked');
if (self.options.openInForm === true)
tip.down('input[name="open_in_form"]').writeAttribute('checked', 'checked');
self._escapeObserver = self._escapeHandler.bindAsEventListener(self);
$(document).observe('keydown', self._escapeObserver);
tip.select('.edge_tooltip_inner')[0].removeClassName('no_main_content');
tip.select('.edge_flyout_footer_content')[0].innerHTML = new XMLTemplate('edge_bookmark_edit_footer_content').evaluate({});
GlideOverlay.showMask();
tooltip.preventHide();
tip.setStyle({width: Math.max(tip.getWidth(), 335) + 'px'});
var dims = document.viewport.getDimensions();
var top = parseInt(tip.style.top, 10);
var tipHeight = tip.getHeight();
if (top + tipHeight > dims.height)
tip.setStyle({top: (dims.height - tipHeight) + 'px'});
var firstInput = tip.down('input[type="text"]');
if (firstInput)
firstInput.focus();
tooltip.updateIframeShim();
});
tip.on('click', 'button.cancel_bookmark', function() {
tooltip.hide();
});
tip.on('click', 'button.delete_bookmark', function() {
tooltip.hide();
CustomEvent.fire(GlideEvent.NAV_REMOVE_BOOKMARK, self.options.id);
});
var saveBookmark = function() {
var image = '';
var fontIcon = '';
var imageElem = tip.select('img.bookmark_image')[0];
var spanElem = tip.select('span.bookmark_image')[0];
if(imageElem)
image = imageElem.readAttribute('src');
if(spanElem) {
fontIcon = $j.grep(spanElem.readAttribute('class').split(" "), function(v, i) {
return (v.indexOf('icon-') === 0) || (v.indexOf('color-') === 0);
}).join(' ');
}
CustomEvent.fire(GlideEvent.NAV_UPDATE_BOOKMARK, self.options.id, {
title: tip.select('input[name="title"]')[0].getValue(),
image: image,
flyout: tip.select('input[name="flyout"]')[0].getValue() == 'on' ? 'true' : 'false',
pinned: tip.select('input[name="pinned"]')[0].getValue() == 'on' ? 'true' : 'false',
open_in_form: tip.select('input[name="open_in_form"]')[0].getValue() == 'on' ? 'true' : 'false',
icon: fontIcon
});
tooltip.hide();
};
tip.on('keypress', function (event) {
if (event.keyCode === Event.KEY_RETURN &&
event.target.nodeName !== 'BUTTON' &&
event.target.nodeName !== 'A') {
event.preventDefault();
saveBookmark();
}
});
tip.on('click', 'button.update_bookmark', saveBookmark);
}
});
this.tooltip = button.retrieve('tooltip');
},
_initEdgeButtonClick: function(button) {
button.observe('click', function(event) {
$j('#edge_west').trigger('click');
this.tooltip.hide();
this.openBookmark(event);
event.stopPropagation();
}.bind(this));
},
_getEdgeButton: function() {
return $$('div.edge_item[data-bookmark-id="' + this.options.id + '"] > button')[0];
},
_escapeHandler: function(event) {
if (event.keyCode == Event.KEY_ESC) {
var edgeButton = this._getEdgeButton();
this.tooltip.hide();
$(document).stopObserving('keydown', this._escapeObserver);
this._escapeObserver = null;
}
},
_initEdgeButtonDrag: function(button) {
var self = this;
var getBookmarkProps = function() {
var o = {};
$('edge_pinned_bookmarks').select('.edge_item').each(function(elem) {
o[elem.readAttribute('data-edge-id')] = {
id: elem.readAttribute('data-edge-id'),
elem: elem,
switchTop: elem.cumulativeOffset().top - elem.cumulativeScrollOffset().top + (elem.getHeight()/2)
};
});
var me = $('edge_pinned_bookmarks').select('.edge_item[data-edge-id="' + self.options.id + '"]')[0];
var prev = me.previous('.edge_item');
var next = me.next('.edge_item');
return {
hash: o,
prev: prev ? o[prev.readAttribute('data-edge-id')] : null,
next: next ? o[next.readAttribute('data-edge-id')] : null
};
};
button.glideDraggable({
clone: true,
distance: 5,
onDragStart: function(event) {
self.hideTooltip();
self.tooltip.preventShow();
CustomEvent.fire(GlideEvent.NAV_DRAGGING_BOOKMARK_START);
var clone = this.getClone();
clone.setStyle({
opacity: '0.7',
filter: 'alpha(opacity=70)'
}).removeClassName('active');
button.addClassName('active');
self._bookmarkProps = getBookmarkProps();
},
onDrag: function(event) {
var pos = this.getOriginalPosition();
this.getClone().setStyle({
top: (event.pageY - pos.offsetY) + 'px',
left: (event.pageX - pos.offsetX) + 'px'
});
var prev = next = null;
for (var i in self._bookmarkProps.hash) {
if (i == self.options.id)
continue;
var edgeItem = self._bookmarkProps.hash[i];
if (event.pageY > edgeItem.switchTop) {
if (!prev || prev.switchTop < edgeItem.switchTop)
prev = edgeItem;
}
else {
if (!next || next.switchTop > edgeItem.switchTop)
next = edgeItem;
}
}
if (self._bookmarkProps.prev != prev || self._bookmarkProps.next != next) {
var liveMe = $('edge_pinned_bookmarks').select('.edge_item[data-edge-id="' + self.options.id + '"]')[0];
var clone = Element.clone(liveMe, true);
liveMe.remove();
if (prev)
prev.elem.insert({after: clone});
else if (next)
next.elem.insert({before: clone});
self._bookmarkProps = getBookmarkProps();
}
},
onDragEnd: function() {
var liveButton = $('edge_pinned_bookmarks').select('.edge_item[data-edge-id="' + self.options.id + '"] > button')[0];
liveButton.removeClassName('active');
CustomEvent.fire(GlideEvent.NAV_DRAGGING_BOOKMARK_STOP);
CustomEvent.fire(GlideEvent.NAV_UPDATE_BOOKMARK, self.options.id, {
prev: self._bookmarkProps.prev ? self._bookmarkProps.prev.id : null,
next: self._bookmarkProps.next ? self._bookmarkProps.next.id : null
});
}
});
},
toString: function() { return 'EdgeBookmark'; }
});
;
/*! RESOURCE: /scripts/classes/edge/EdgeFlyout.js */
var EdgeFlyout = Class.create({
initialize: function(options) {
this.options = Object.extend({
id:			null,
edgeAlign:	'left',
title: 		null,
titleBody:	null,
onLoad:		function() {},
onShow:		function() {},
onHide:		function() {}
}, options || {});
this._isVisible = false;
CustomEvent.fire(GlideEvent.NAV_ADD_FLYOUT, this);
},
setVisible: function(b) { this._isVisible = b; },
isVisible: function() { return this._isVisible; },
remove: function() {},
hide: function() {},
show: function() {},
getBox: function() {},
createArrow: function(position, opts) {
if (!position || this.options.draggable === true || !this.options.arrowRefElement || this.flyoutArrow)
return;
var ref = Object.isElement(this.options.arrowRefElement) ? this.options.arrowRefElement : $$(this.options.arrowRefElement)[0];
var offset = ref.cumulativeOffset();
var scrollOffset = ref.cumulativeScrollOffset();
this.flyoutArrow = $(document.createElement('div'));
var styles = { display: 'none', top: (offset.top - scrollOffset.top + (ref.getHeight()/2) - 12) + 'px' };
var box = this.getBox();
switch (position.toLowerCase()) {
case 'left':
styles.left = '38px';
if (this.options.arrowColor)
styles.borderRightColor = this.options.arrowColor;
this.flyoutArrow.addClassName('edge_arrow edge_left_arrow');
this.flyoutArrow.setStyle(styles);
if (box)
box.options.maxTop = Math.max(4, offset.top - scrollOffset.top - 30);
break;
case 'right':
styles.right = '42px';
if (this.options.arrowColor)
styles.borderLeftColor = this.options.arrowColor;
this.flyoutArrow.addClassName('edge_arrow edge_right_arrow');
this.flyoutArrow.setStyle(styles);
if (box)
box.options.maxTop = Math.max(4, offset.top - scrollOffset.top - 40);
break;
}
document.body.appendChild(this.flyoutArrow);
if (this.options.createHidden !== true)
this.flyoutArrow.fadeIn(this.options.fadeInTime ? this.options.fadeInTime : 0);
},
toString: function() { return 'EdgeFlyout'; }
});
;
/*! RESOURCE: /scripts/classes/edge/EdgeFlyoutBookmark.js */
var EdgeFlyoutBookmark = Class.create(EdgeFlyout, {
initialize: function($super, options) {
$super(Object.extend({
title: 				null,
url: 				null,
image:				null,
fontIcon: 			null,
sizing:				'auto',
flyoutWidth:        0,
draggable:			false,
arrowRefElement:	null,
fadeOutTime: 		100,
gearSlideTime:		300,
helpSlideTime:		300
}, options || {}));
this.badgeFunc = this._onBadgeText.bind(this);
CustomEvent.observe('badge_text', this.badgeFunc);
},
remove: function() {
if (this.flyoutArrow)
this.flyoutArrow.remove();
if (this._box)
GlideBox.close(this._box, 0);
if (this._boundWindowResizer) {
Event.stopObserving(window, 'resize', this._boundWindowResizer);
this._boundWindowResizer;
}
CustomEvent.un('badge_text', this.badgeFunc);
},
hide: function() {
if (!this.isVisible())
return;
this.setVisible(false);
if (this.flyoutArrow)
this.flyoutArrow.fadeOut(this.options.fadeOutTime);
if (this._box) {
this._hideGearOptions(0);
this._box.hide();
}
this.options.onHide.call(this);
this._fireEvent('flyout_hide');
},
show: function() {
if (!this._box) {
this._createFlyoutAndShow();
} else {
if (this.flyoutArrow)
this.flyoutArrow.show();
this._box.show(0);
if (this.options.sizing == 'auto')
this._box.autoDimension();
}
this.setVisible(true);
this.options.onShow.call(this);
this._fireEvent('flyout_show');
},
_createFlyoutAndShow: function() {
var url = new GlideURL(this.options.url);
url.addParam('sysparm_nameofstack', guid());
url.addParam('sysparm_clear_stack', 'yes');
url.setEncode(false);
var opts = {
boxClass: 'edge_flyout',
iframe: url.getURL(),
iframeId: 'iframe_edge_' + this.options.id,
title: this.options.title,
showClose: false,
draggable: false,
left: this.options.edgeAlign == 'left' ? 48 : null,
right : this.options.edgeAlign == 'right' ? 48 : null,
fadeOutTime: this.options.fadeOutTime,
onBeforeLoad: function(box) {
var pane = new IFramePane('iframe_edge_' + this.options.id);
Object.extend(pane, PaneBookmarkDragging).initPaneBookmarkDragging();
}.bind(this)
};
if (this.options.sizing == 'auto') {
Object.extend(opts, {
height: '98%',
width: '75%',
autoDimensionOnLoad: false
});
if (this.options.flyoutWidth > 0)
opts.width = this.options.flyoutWidth;
}
this._box = new GlideBox(opts);
if(document.documentElement.getAttribute('data-doctype') == 'true') {
this._box.addWindowIcon('<span class="flyout-window-icon ' + this.options.fontIcon + '"></span>');
} else {
this._box.addWindowIcon('<img src="' + this.options.image + '" height="16" width="16" />');
}
this._box.getBoxElement().observe('click', function(event) {
event.stopPropagation();
});
var ref = Object.isElement(this.options.arrowRefElement) ? this.options.arrowRefElement : $$(this.options.arrowRefElement)[0];
if (ref) {
var offset = ref.cumulativeOffset();
var scrollOffset = ref.cumulativeScrollOffset();
this._box.setMaxTop(offset.top - scrollOffset.top - 36);
this._box.setMinBottom(offset.top - scrollOffset.top + 36);
}
this._box.addToolbarRightDecoration('<a href="#" title="Refresh" class="flyout_refresh"><span style="float:none;"class="icon-refresh i12 i12_refresh"></span></a>');
this._box.addToolbarRightDecoration('<a href="#" title="Bookmark Options" class="flyout_options"><span style="float:none;"class="icon-cog i12 i12_gear"></span></a>');
this._box.addToolbarRightDecoration('<a href="#" title="Close" class="flyout_close"><span style="float:none;" class="icon-cross-circle i12 i12_close"></span></a>');
var toolbar = this._box.getToolbar();
toolbar.on('click', 'a.flyout_refresh', function(event, elem) {
this._hideGearOptions(0);
this._box.render({
autoDimensionOnPreLoad: false,
autoDimensionOnLoad: false
});
event.stop();
}.bind(this));
toolbar.on('click', 'a.flyout_options', function(event, elem) {
event.stop();
this[this._optionsVisible === true ? '_hideGearOptions' : '_showGearOptions']();
}.bind(this));
toolbar.on('click', 'a.flyout_close', function(event, elem) {
event.stop();
this.hide();
}.bind(this));
if (this.options.sizing === 'auto') {
this._boundWindowResizer = function() {
if (this._box.isVisible())
this._box.autoDimension();
}.bind(this);
Event.observe(window, 'resize', this._boundWindowResizer);
}
if (this.options.arrowRefElement)
this.docDirection = $$('html')[0].dir === 'rtl' ? this.createArrow('right') : this.createArrow('left');
this._box.render();
},
_hideGearOptions: function(gearSlideTime) {
if (this._optionsVisible !== true)
return;
gearSlideTime = gearSlideTime === 0 ? 0 : this.options.gearSlideTime;
var options = this._box.getBoxElement().select('.edge_flyout_options')[0];
var mask = options.previous();
if (gearSlideTime != 0) {
options.stop().animate({top: (options.down().getHeight() * -1) + 'px'}, gearSlideTime, function() {
options.remove();
mask.remove();
}.bind(this));
} else {
options.remove();
mask.remove();
}
this._optionsVisible = false;
},
_showGearOptions: function() {
if (this._optionsVisible === true)
return;
var edgeBookmark = NavPageManager.get().getBookmark(this.options.id);
if (!edgeBookmark)
throw 'Unable to retrieve the required bookmark';
var div = this._box.getBoxElement().select('.edge_flyout_options')[0];
if (div) {
div.stop();
} else {
var injectPoint = this._box.getBoxElement().select('.iframe_container .inner_wrap_inner')[0];
var mask = $(document.createElement('div'));
mask.className = 'glide_mask_abs';
if (isMSIE6)
mask.style.height = (injectPoint.getHeight() - 2) + 'px';
injectPoint.appendChild(mask);
mask.show();
var color = $j.grep(edgeBookmark.options.fontIcon.split(" "), function(v, i) {
return v.indexOf('color-') === 0;
}).join();
var div = $(document.createElement('div'));
div.setStyle({ position: 'absolute', right: '0' });
div.addClassName('edge_flyout_options');
div.innerHTML = new XMLTemplate('navpage_bookmark_tooltip').evaluate({
url: edgeBookmark.options.url,
title: edgeBookmark.options.title
});
div.select('.edge_tooltip')[0].setStyle({display: 'block', right: '20px' });
div.select('.edge_flyout_header')[0].remove();
div.select('.edge_flyout_main_content')[0].innerHTML = new XMLTemplate('edge_bookmark_edit_main_content').evaluate({
image: edgeBookmark.options.image,
url: edgeBookmark.options.url,
title: edgeBookmark.options.title,
fontIcon: edgeBookmark.options.fontIcon,
color: color
});
if (edgeBookmark.options.pinned === true)
div.down('input[name="pinned"]').writeAttribute('checked', 'checked');
if (edgeBookmark.options.flyout === true)
div.down('input[name="flyout"]').writeAttribute('checked', 'checked');
div.select('.edge_tooltip_inner')[0].removeClassName('no_main_content');
div.select('.edge_flyout_footer_content')[0].innerHTML = new XMLTemplate('edge_bookmark_edit_footer_content').evaluate({});
div.on('click', 'button.cancel_bookmark', function() {
this._hideGearOptions();
}.bind(this));
div.on('click', 'button.delete_bookmark', function() {
CustomEvent.fire(GlideEvent.NAV_REMOVE_BOOKMARK, edgeBookmark.options.id);
}.bind(this));
div.on('click', 'button.update_bookmark', function() {
var image = '';
var fontIcon = '';
var imageElem = div.select('img.bookmark_image')[0];
var spanElem = div.select('span.bookmark_image')[0];
if(imageElem)
image = imageElem.readAttribute('src');
if(spanElem) {
fontIcon = $j.grep(spanElem.readAttribute('class').split(" "), function(v, i) {
return (v.indexOf('icon-') === 0) || (v.indexOf('color-') === 0);
}).join(' ');
}
CustomEvent.fire(GlideEvent.NAV_QUEUE_BOOKMARK_OPEN_FLYOUT, edgeBookmark.options.id);
CustomEvent.fire(GlideEvent.NAV_UPDATE_BOOKMARK, edgeBookmark.options.id, {
title: div.select('input[name="title"]')[0].getValue(),
image: image,
flyout: div.select('input[name="flyout"]')[0].getValue() == 'on' ? 'true' : 'false',
pinned: div.select('input[name="pinned"]')[0].getValue() == 'on' ? 'true' : 'false',
icon: fontIcon
});
}.bind(this));
injectPoint.appendChild(div);
div.setStyle({top: (div.down().getHeight() * -1) + 'px'});
div.down().setStyle({width: '275px'});
}
div.animate({top: 0}, this.options.gearSlideTime, function() {
div.setStyle({margin: 0, padding: 0});
});
this._optionsVisible = true;
},
_fireEvent: function(name) {
var ifr = this._box.getIFrameElement();
if (!ifr)
return;
var d = ifr.contentWindow;
if (d && d.CustomEvent && d.CustomEvent.fire)
d.CustomEvent.fire(name, this.options.id);
},
_onBadgeText: function(opts) {
if (opts.id != this.options.id)
return;
var div = $$('div.edge_item[data-bookmark-id="' + this.options.id + '"]')[0];
if (!div)
return;
var badge = $('badge_'+opts.id);
var cnt = badge.getAttribute('data-badge-count') ? parseInt(badge.getAttribute('data-badge-count')) : 0;
if (opts.text.length){
cnt += parseInt(opts.text);
if (cnt > 9) {
opts.text = "*";
if (badge.className.indexOf('edge_badge_bookmark_many') == -1)
badge.className += ' edge_badge_bookmark_many';
} else {
badge.className = badge.className.replace(' edge_badge_bookmark_many', '');
opts.text = cnt + '';
}
badge.innerHTML = opts.text;
badge.style.display = 'block';
badge.setAttribute('data-badge-count', cnt);
}else{
badge.innerHTML = "";
badge.style.display = 'none';
badge.setAttribute('data-badge-count', 0);
}
},
toString: function() { return 'EdgeFlyoutBookmark'; }
});
;
/*! RESOURCE: /scripts/classes/edge/EdgeFlyoutBody.js */
var EdgeFlyoutBody = Class.create(EdgeFlyout, {
initialize: function($super, options) {
$super(Object.extend({
createHidden:			false,
id:						null,
icon:					null,
showClose:				false,
draggable:				false,
fadeInTime:				60,
fadeOutTime:			60,
body:					'',
header:					null,
height:					null,
width:					null,
right:					null,
left:					null,
top:					null,
autoDimensionOnLoad:	true,
onBeforeLoad:			function() {},
onAfterLoad:			function() {},
onCreate:				function() {},
onAfterShow:			function() {},
onAfterHide:			function() {}
}, options || {}));
if (this.options.createHidden === true)
this._createFlyout();
},
remove: function($super) {},
hide: function() {
if (!this.isVisible())
return;
this.setVisible(false);
if (this.flyoutArrow)
this.flyoutArrow.fadeOut(this.options.fadeOutTime);
if (this._box)
this._box.hide();
},
show: function() {
if (!this._box) {
this._createFlyout();
} else {
if (this.flyoutArrow)
this.flyoutArrow.fadeIn(this.options.fadeInTime);
this._box.autoDimension();
this._box.autoPosition();
this._box.show();
this.setVisible(true);
}
},
getBox: function() {
return this._box;
},
_createFlyout: function() {
var opts = {
id:	this.options.id,
title: this.options.title,
boxClass: 'dark',
showClose: this.options.showClose,
draggable: this.options.draggable,
height: this.options.height,
width: this.options.width,
right: this.options.right,
top: this.options.top,
padding: { top: 0, right: 0, bottom: 0, left: 0 },
bodyPadding: 0,
body: this.options.body,
autoDimensionOnLoad: this.options.autoDimensionOnLoad,
fadeInTime: this.options.fadeInTime,
fadeOutTime: this.options.fadeOutTime,
onBeforeLoad: this.options.onBeforeLoad,
onAfterLoad: this.options.onAfterLoad,
onAfterShow: this.options.onAfterShow,
onAfterHide: this.options.onAfterHide
};
this._box = new GlideBox(opts);
if (this.options.titleHtml)
this._box.setTitleHtml(this.options.titleHtml);
if (this.options.header)
this._box.addToolbarRow(this.options.header);
if (this.options.icon)
this._box.addWindowIcon('<img src="' + this.options.icon + '" height="16" width="16" style="display:block;" />');
var box = this._box.getBoxElement();
box.observe('click', function(event) {
event.stopPropagation();
CustomEvent.fire(GlideEvent.WINDOW_CLICKED, event, window);
});
this._box.getBodyElement().setStyle({padding: 0, background: '#373737'});
this.options.onCreate.call(this._box);
if (this.options.arrowRefElement)
this.createArrow(this.options.right ? 'right' : 'left');
if (this.options.createHidden !== true) {
this._box.render();
this.setVisible(true);
} else
this.setVisible(false);
},
toString: function() { return 'EdgeFlyoutBody'; }
});
;
/*! RESOURCE: /scripts/classes/panes/IFramePane.js */
var IFramePane = Class.create({
initialize: function(name) {
this.frameName = name;
this.frame = $(name);
this.frame.observe('load', function() {
this.window = this.frame.contentWindow;
this.document = getIFrameDocument(this.frame);
if (this.window.Prototype) {
this.window.$$('.section_header_content_no_scroll').each(function(e) {
e.scrollLeft = '0px';
e.scrollTop = '0px';
});
}
if (navigator.userAgent.toLowerCase().indexOf('msie') > 0) {
var b = this.document.body;
b.attachEvent('ondragenter', function(event) { event = event || window.event; event.cancelBubble = true; return false; });
b.attachEvent('ondragover', function(event) { event = event || window.event; event.cancelBubble = true; return false; });
b.attachEvent('ondrop', function() { CustomEvent.fireTop(GlideEvent.NAV_DRAGGING_BOOKMARK_STOP); });
}
this._isLoading = false;
}.bind(this));
CustomEvent.observe(GlideEvent.NAV_FORM_DIRTY_CANCEL_STAY, function(window) {
if (window.name != this.window.name)
return;
this.hideLoadingOverlay();
}.bind(this));
this._isLoading = true;
},
getWindow: function() {
return this.frame.contentWindow;
},
getDocument: function() {
return getIFrameDocument(this.frame);
},
isLoading: function() {
return this._isLoading;
},
showLoadingOverlay: function() {
if (this._isLoading)
return;
var overlay = this.document.createElement('div');
overlay.className = 'ui11_pane_loading';
this.document.body.appendChild(overlay);
},
hideLoadingOverlay: function() {
$(this.document.body).select('.ui11_pane_loading').each(function(elem) {
elem.remove();
});
},
loadLinkFromUrl: function(link) {
if (link.indexOf('sys_attachment.do') == -1)
this.showLoadingOverlay();
this.frame.src = link;
this._isLoading = true;
},
loadLinkFromAjax: function(link) {
this.showLoadingOverlay();
var parts = link.split('?');
var ajax = new GlideAjax('', parts[0]);
ajax.setQueryString(parts[1]);
ajax.getXML(function(response) {
if (!(response && response.responseText))
return this.hideLoadingOverlay();
var text = response.responseText;
var spos = text.indexOf(">", text.indexOf("<body"));
var epos = text.indexOf("</body>");
if (spos == -1 || epos == -1)
return this.hideLoadingOverlay();
this.window.self.loaded = true;
this.window.g_evalScriptCache = new Object();
this.window.g_load_functions = new Array();
this.window.g_late_load_functions = new Array();
this.window.g_render_functions = new Array();
this.window.document.body.innerHTML = bodyHtml;
this.window.String.prototype.evalScripts.call(text.substr(spos + 1, epos - spos), true);
}.bind(this));
},
toString: function() { return 'IFramePane'; }
});
;
/*! RESOURCE: /scripts/classes/panes/PaneBanner.js */
var PaneBanner = Class.create({
initialize: function(manager) {
this.window = window;
this.document = document;
Object.extend(this, PaneFilterHotkey).initPaneFilterHotkey(window);
$('banner_minimize').on('click', function() {
setTimeout(function() {
g_navManager.getLayout('edge_center').resizeAll();
}.bind(this), 15);
}.bind(this));
},
getWindow: function() {
return this.window;
},
getDocument: function() {
return this.document;
},
toString: function() { return 'PaneBanner'; }
});
;
/*! RESOURCE: /scripts/classes/panes/PaneMain.js */
var PaneMain = Class.create(IFramePane, {
initialize: function($super) {
$super('gsft_main');
Object.extend(this, PaneBookmarkDragging).initPaneBookmarkDragging();
Object.extend(this, PaneFlyoutMousedown).initPaneFlyoutMousedown();
Object.extend(this, PaneLinkManagement).initPaneLinkManagement();
Object.extend(this, PaneListManagement).initPaneListManagement();
Object.extend(this, PaneMaximizeHotkeys).initPaneMaximizeHotkeys();
Object.extend(this, PaneFilterHotkey).initPaneFilterHotkey(this.frame);
},
toString: function() { return 'PaneMain'; }
});
;
/*! RESOURCE: /scripts/classes/panes/PaneMainForm.js */
var PaneMainForm = Class.create(IFramePane, {
initialize: function($super, name) {
$super(name);
Object.extend(this, PaneBookmarkDragging).initPaneBookmarkDragging();
Object.extend(this, PaneFlyoutMousedown).initPaneFlyoutMousedown();
Object.extend(this, PaneFormManagement).initPaneFormManagement();
Object.extend(this, PaneLinkManagement).initPaneLinkManagement();
Object.extend(this, PaneMaximizeHotkeys).initPaneMaximizeHotkeys();
Object.extend(this, PaneFilterHotkey).initPaneFilterHotkey(this.frame);
this.frame.observe('load', function() {
this.setTabTitle();
if (!this.frame.contentWindow.$)
return;
var table = this.frame.contentWindow.$('sys_target');
this.sysId = this._getSysId();
this.table = table ? table.value : null;
CustomEvent.fire(GlideEvent.NAV_SYNC_LIST_WITH_FORM, this);
}.bind(this));
},
_getSysId: function() {
if (!this.frame.contentWindow.$)
return;
var sysId = this.frame.contentWindow.$('sys_uniqueValue');
return sysId ? sysId.value : null;
},
setTabTitle: function() {
var title = $j(getIFrameDocument(this.frame)).find("[data-form-title]").attr('data-form-title');
if (!title) {
var url = this.frame.src;
var a = $j('<a>', { href:url } )[0];
var path = a.pathname;
if (path.startsWith('/'))
path = path.substring(1);
var x = path.indexOf(".do");
if (x > -1)
path = path.substring(0, x);
title = path;
delete a;
}
CustomEvent.fire("form-title", {
title: title,
iframeId: this.frame.id,
sysId: this._getSysId()
});
},
toString: function() { return 'PaneMainForm'; }
});
;
/*! RESOURCE: /scripts/classes/panes/PaneNav.js */
var PaneNav = Class.create(IFramePane, {
initialize: function($super) {
$super('gsft_nav');
Object.extend(this, PaneBookmarkDragging).initPaneBookmarkDragging();
Object.extend(this, PaneFlyoutMousedown).initPaneFlyoutMousedown();
Object.extend(this, PaneLinkManagement).initPaneLinkManagement();
Object.extend(this, PaneFilterHotkey).initPaneFilterHotkey(this.frame);
if (document.documentElement.getAttribute('data-doctype') == 'true')
Object.extend(this, PaneMaximizeHotkeys).initPaneMaximizeHotkeys();
},
toString: function() { return 'PaneNav'; }
});
;
/*! RESOURCE: /scripts/modules/NavPageBookmarks.js */
var NavPageBookmarks = {
initNavPageBookmarks: function() {
this.bookmarks = {};
this._queuedFlyouts = {};
this._getBookmarks();
CustomEvent.observe(GlideEvent.NAV_ADD_BOOKMARK, this._addBookmark.bind(this));
CustomEvent.observe(GlideEvent.NAV_REMOVE_BOOKMARK, this._removeBookmark.bind(this));
CustomEvent.observe(GlideEvent.NAV_UPDATE_BOOKMARK, this._updateBookmark.bind(this));
CustomEvent.observe(GlideEvent.NAV_DRAGGING_BOOKMARK_START, this._addDragAdjustments.bind(this));
CustomEvent.observe(GlideEvent.NAV_DRAGGING_BOOKMARK_STOP, this._clearDragAdjustments.bind(this));
CustomEvent.observe(GlideEvent.NAV_HIDE_ALL_TOOLTIPS, this._hideAllTooltips.bind(this));
CustomEvent.observe(GlideEvent.NAV_QUEUE_BOOKMARK_OPEN_FLYOUT, this._queueOpenBookmarkFlyout.bind(this));
CustomEvent.observe(GlideEvent.NAV_OPEN_BOOKMARK, this._openBookmark.bind(this));
CustomEvent.observe(GlideEvent.IMAGE_PICKED, this._imagePicked.bind(this));
this._initDragging();
this._initAllBookmarks();
},
getBookmark: function(id) {
return this.bookmarks[id];
},
getBookmarks: function() {
return this.bookmarks;
},
_getBookmarks: function() {
var ga = new GlideAjax(this.PROCESSOR);
ga.addParam('sys_action', 'load_bookmarks');
ga.getXML(this._handleAjaxBookmarkLoadResponse.bind(this));
},
_updateBookmark: function(sysId, obj) {
if (!sysId)
return;
var ga = new GlideAjax(this.PROCESSOR);
ga.addParam('sys_action', 'update_bookmark');
ga.addParam('sys_id', sysId);
for (var i in obj) ga.addParam(i, obj[i]);
ga.getXML(this._handleAjaxBookmarkLoadResponse.bind(this));
},
_removeBookmark: function(id) {
var ga = new GlideAjax(this.PROCESSOR);
ga.addParam('sys_action', 'delete_bookmark');
ga.addParam('sys_id', id);
ga.getXML();
var item = this.bookmarks[id];
if (item)
item.remove();
delete this.bookmarks[id];
var i = 0;
for (var xx in this.bookmarks)
i++;
if (i == 0)
$('edge_all_bookmarks').retrieve('tooltip').hide();
this._clearGearOptions();
},
_openBookmark: function(bookmarkInfo) {
this.bookmarks[bookmarkInfo.id].clearDirty();
},
_removeAllBookmarks: function() {
if (this.bookmarks) {
for (var i in this.bookmarks)
this.bookmarks[i].remove();
}
this.bookmarks = {};
this._clearGearOptions();
},
_addBookmark: function(obj) {
var ga = new GlideAjax(this.PROCESSOR);
ga.addParam('sys_action', 'save_' + obj.type);
switch (obj.type) {
case 'module':
ga.addParam('sys_id', obj.moduleID);
ga.addParam('url', obj.href);
break;
case 'breadcrumb':
ga.addParam('table', obj.table);
case 'document':
ga.addParam('text', obj.text);
ga.addParam('url', obj.href);
break;
default:
return;
}
ga.getXML(function(response) {
var xml = response.responseXML;
if (!xml || !xml.documentElement)
return;
var nodes = xml.getElementsByTagName('bookmark');
var node = nodes && nodes[0] || null;
var ei = this._createBookmark(node);
this._updateAllBookmarksFlyout();
var div = document.createElement('div');
div.innerHTML = ei.getBookmarkEdgeHtml();
$('edge_pinned_bookmarks').appendChild(div.childNodes[0]);
ei.initEvents();
}.bind(this));
},
_handleAjaxBookmarkLoadResponse: function(response) {
var xml = response.responseXML;
if (!xml || !xml.documentElement)
return;
var bookmarkEdgeHtml = '';
var autoLoadBookmarks = [];
this._removeAllBookmarks();
var nodes = xml.getElementsByTagName('bookmark');
for (var i = 0, l = nodes.length; i < l; i++) {
var node = nodes[i];
var ei = this._createBookmark(node);
bookmarkEdgeHtml += ei.getBookmarkEdgeHtml();
if (node.getAttribute('auto_open') === 'true')
autoLoadBookmarks.push(ei);
}
$('edge_pinned_bookmarks').innerHTML = bookmarkEdgeHtml;
this._updateAllBookmarksFlyout();
for (var i in this.bookmarks)
this.bookmarks[i].initEvents();
for (var i = 0, l = autoLoadBookmarks.length; i < l; i++) {
setTimeout(function() {
this.openBookmark();
}.bind(autoLoadBookmarks[i]), 70);
}
for (var i in this._queuedFlyouts) {
var bookmark = this.getBookmark(i);
if (bookmark) {
setTimeout(function() { bookmark.openBookmarkAsFlyout(); }, 0);
delete this._queuedFlyouts[i];
}
}
},
_createBookmark: function(node) {
var i = node.getAttribute('flyout_width');
i = parseInt(i);
var flyoutWidth = 0;
if ("NaN" != i)
flyoutWidth = i;
var ei = new EdgeBookmark({
id: node.getAttribute('bookmark_id'),
image: node.getAttribute('image'),
fontIcon: node.getAttribute('icon'),
url: node.getAttribute('url'),
flyout: node.getAttribute('flyout') === 'true',
pinned: node.getAttribute('pinned') === 'true',
cancelable: node.getAttribute('uncancelable') !== 'true',
sizing: node.getAttribute('flyout_sizing'),
flyoutWidth: flyoutWidth,
title: node.getAttribute('title'),
openInForm: node.getAttribute('open_in_form') == 'true'
});
this.bookmarks[node.getAttribute('bookmark_id')] = ei;
return ei;
},
_updateAllBookmarksFlyout: function() {
var rows = ''
for (var i in this.bookmarks)
rows += this.bookmarks[i].getAllBookmarksRowHtml();
$('edge_all_bookmarks_content_main').innerHTML = new XMLTemplate('navpage_all_bookmarks').evaluate({rows: rows});
},
_clearGearOptions: function() {
$$('body')[0].select('.edge_flyout_options').each(function(elem) {
elem.remove();
});
this.openBookmarkId = null;
},
_setToScreenHeight: function(element, windowHeight){
element
.height(windowHeight)
.css({
top: 0,
overflowY: 'auto',
overflowX: 'visible'
});
},
_forgetScreenHeight: function(element){
element
.css({
height : '',
top: 0,
overflowY: '',
overflowX: ''
});
},
_hideAllBookmarksContent: function() {
$('edge_all_bookmarks').retrieve('tooltip').hide();
},
_hideAllTooltips: function() {
for (var i in this.bookmarks)
this.bookmarks[i].hideTooltip();
},
_initAllBookmarks: function() {
var self = this;
var button = $('edge_all_bookmarks');
var isDoctype = document.documentElement.getAttribute('data-doctype') == 'true';
var offset = isDoctype ? [5, -2] : [-2, 0];
button.tooltip({
relative: false,
position: 'right top-baseline',
offset: offset,
tip: '#edge_all_bookmarks_content',
predelay: 300,
delay: 300,
onTipInit: function() {
var tip = this.getTip();
var api = this;
tip.on('click', 'a.edit_bookmark', function(event, elem) {
event.stop();
GlideOverlay.showMask();
api.preventHide();
self._clearGearOptions();
var tr = elem.up('tr[data-bookmark-id]');
var bookmarkId = tr.readAttribute('data-bookmark-id');
var edgeBookmark = NavPageManager.get().getBookmark(bookmarkId);
if (!edgeBookmark || self.openBookmarkId == bookmarkId)
return;
self.openBookmarkId = bookmarkId;
var div = $(document.createElement('div'));
div.addClassName('edge_flyout_options');
div.innerHTML = new XMLTemplate('navpage_bookmark_tooltip').evaluate({
url: edgeBookmark.options.url,
title: edgeBookmark.options.title
});
if (($j('html').is('[dir="rtl"]')))
div.select('.edge_tooltip')[0].setStyle({display: 'block', right: $( "edge_all_bookmarks_content" ).getWidth() +"px" });
else
div.select('.edge_tooltip')[0].setStyle({display: 'block', left: "-2px" });
div.select('.edge_flyout_header')[0].remove();
div.select('.edge_flyout_footer')[0].removeClassName('no_main_content');
div.select('.edge_flyout_footer_content')[0].innerHTML = new XMLTemplate('edge_bookmark_edit_footer_content').evaluate({});
div.select('.edge_flyout_main_content')[0].innerHTML = new XMLTemplate('edge_bookmark_edit_main_content').evaluate({
image: edgeBookmark.options.image,
fontIcon: edgeBookmark.options.fontIcon,
url: edgeBookmark.options.url,
title: edgeBookmark.options.title
});
if (edgeBookmark.options.pinned === true)
div.down('input[name="pinned"]').writeAttribute('checked', 'checked');
if (edgeBookmark.options.flyout === true)
div.down('input[name="flyout"]').writeAttribute('checked', 'checked');
if (edgeBookmark.options.openInForm === true)
div.down('input[name="open_in_form"]').writeAttribute('checked', 'checked');
div.on('click', 'button.cancel_bookmark', function() {
api.allowHide();
self._clearGearOptions();
GlideOverlay.hideMask();
self._hideAllBookmarksContent();
}.bind(this));
div.on('click', 'button.delete_bookmark', function() {
CustomEvent.fire(GlideEvent.NAV_REMOVE_BOOKMARK, edgeBookmark.options.id);
self._clearGearOptions();
GlideOverlay.hideMask();
api.hide();
self._hideAllBookmarksContent();
}.bind(this));
div.on('click', 'button.update_bookmark', function() {
function getFontIcon(el) {
return $j.grep(el.readAttribute('class').split(" "), function(v, i) {
return (v.indexOf('icon-') === 0) || (v.indexOf('color-') === 0);
}).join(' ')
}
var img = div.select('.bookmark_image')[0];
CustomEvent.fire(GlideEvent.NAV_UPDATE_BOOKMARK, edgeBookmark.options.id, {
title: div.select('input[name="title"]')[0].getValue(),
image: img.readAttribute('src'),
icon: getFontIcon(img),
flyout: div.select('input[name="flyout"]')[0].getValue() == 'on' ? 'true' : 'false',
open_in_form: div.select('input[name="open_in_form"]')[0].getValue() == 'on' ? 'true' : 'false',
pinned: div.select('input[name="pinned"]')[0].getValue() == 'on' ? 'true' : 'false'
});
api.allowHide();
self._clearGearOptions();
GlideOverlay.hideMask();
self._hideAllBookmarksContent();
}.bind(this));
$$('body')[0].appendChild(div);
div.down().setStyle({width: '335px'});
var dims = document.viewport.getDimensions(),
offset = $j(tr).offset(),
parentWidth = elemMainParent.width();
if(parentWidth === 0) {
parentWidth = $j('.flyout_bookmarks').width();
}
offset.left = offset.left + parentWidth;
div.setStyle({
top: offset.top + 'px'
});
var topAbs = div.cumulativeOffset().top;
var height = div.down().getHeight() + 2;
if (topAbs + height > dims.height)
div.setStyle({ top: (top - (topAbs + height - dims.height)) + 'px' });
$j(div).animate({ left: offset.left }, 250, null, function(){
div.addClassName("open");
});
});
tip.on('click', 'a.remove_bookmark', function(event, elem) {
event.stop();
self._removeBookmark(elem.up('tr').readAttribute('data-bookmark-id'));
});
tip.on('click', 'tr.bookmark_row', function(event, elem) {
if (event.target.hasClassName('row_action') || event.target.up('a.row_action'))
return;
var bookmark = self.getBookmark(elem.readAttribute('data-bookmark-id'));
CustomEvent.fire(GlideEvent.NAV_OPEN_URL, {
url: bookmark.options.url,
openInForm: bookmark.options.openInForm
});
CustomEvent.fire(GlideEvent.NAV_OPEN_BOOKMARK, {
id: bookmark.options.id
});
api.allowHide();
self._clearGearOptions();
GlideOverlay.hideMask();
self._hideAllBookmarksContent();
this.hide();
});
},
onBeforeShow: function() {
self._hideAllTooltips();
this.getTrigger().addClassName('active_flyout');
$('edge_west').setStyle({zIndex: '1012'});
},
onShow: function() {
var scrollTop = $j('#edge_west_inner').scrollTop(),
windowHeight = $j(window).height(),
menuHeight = elemMainParent.height(),
oversizedMenuWithOffset = (menuHeight + 207 >= windowHeight),
oversizedMenu = (menuHeight >= windowHeight) ? true : false;
if ( oversizedMenu || oversizedMenuWithOffset ) {
self._setToScreenHeight(elemMainParent, windowHeight);
return true;
}
if (scrollTop == 0)
return;
var offset = $j(this.getTrigger()).offset().top;
$j(this.getTip()).css('top', offset);
},
onHide: function() {
this.getTrigger().removeClassName('active_flyout');
$('edge_west').setStyle({zIndex: '3'});
self._clearGearOptions();
self._forgetScreenHeight(elemMainParent);
}
});
var elemMain = $('edge_all_bookmarks_content_main'),
elemMainParent = $j('#edge_all_bookmarks_content');
},
_queueOpenBookmarkFlyout: function(sysId) {
this._queuedFlyouts[sysId] = true;
},
_imagePicked: function(opts) {
if (opts.name != 'bookmark_image')
return;
if(opts.className) {
$$('span.bookmark_image').each(function(elem) {
elem.writeAttribute("class", "bookmark_image " + opts.className);
});
} else {
$$('img.bookmark_image').each(function(elem) {
elem.writeAttribute("src", opts.imgSrc);
});
}
},
_initDragging: function() {
var edgeWest = $('edge_west');
edgeWest.on('dragenter', function(event) { event.stop(); });
edgeWest.on('dragover', function(event) { event.stop(); });
edgeWest.on('drop', this._onWestDragDrop.bind(this));
if (Prototype.Browser.IE) {
var b = $(document.body);
b.on('dragenter', function(event) { event.stop(); });
b.on('dragover', function(event) { event.stop(); });
b.on('drop', function() { this._clearDragAdjustments(); }.bind(this));
}
},
_addDragAdjustments: function() {
var b = $(document.body);
if (b.hasClassName('bookmark_dragging'))
return;
b.addClassName('bookmark_dragging');
var west = $('edge_west');
west.setStyle({
height: west.getHeight() - 4 + 'px'
});
},
_clearDragAdjustments: function(event, elem) {
var b = $(document.body);
if (!b.hasClassName('bookmark_dragging'))
return;
b.removeClassName('bookmark_dragging');
var west = $('edge_west');
west.setStyle({
height: west.getHeight() + 4 + 'px'
});
},
_onWestDragDrop: function(event, elem) {
event.stop();
var t = event.dataTransfer.getData('text');
if (!t || !t.isJSON())
return false;
this._clearDragAdjustments();
this._addBookmark(t.evalJSON());
}
};
;
/*! RESOURCE: /scripts/modules/NavPageFlyouts.js */
var NavPageFlyouts = {
initNavPageFlyouts: function() {
this.flyouts = {};
CustomEvent.observe(GlideEvent.NAV_ADD_FLYOUT, this._addFlyout.bind(this));
CustomEvent.observe(GlideEvent.NAV_REMOVE_FLYOUT, this._removeFlyout.bind(this));
CustomEvent.observe(GlideEvent.NAV_TOGGLE_FLYOUT, this._toggleFlyout.bind(this));
CustomEvent.observe(GlideEvent.NAV_HIDE_FLYOUTS, this._hideFlyouts.bind(this));
window.document.observe('click', function(event) {
CustomEvent.fire(GlideEvent.NAV_PANE_CLICKED, event);
});
},
getFlyout: function(id) {
return this.flyouts[id];
},
_hideFlyouts: function() {
for (var i in this.flyouts)
this.flyouts[i].hide();
},
_addFlyout: function(flyout) {
this.flyouts[flyout.options.id] = flyout;
if (this._queuedFlyouts[flyout.options.id]) {
flyout.show();
delete this._queuedFlyouts[flyout.options.id];
}
},
_removeFlyout: function(flyout) {
if (!flyout || !flyout.options.id)
return;
flyout.remove();
delete this.flyouts[flyout.options.id];
},
_toggleFlyout: function(flyout) {
if (flyout && flyout.isVisible()) {
flyout.hide();
} else {
this._hideFlyouts();
flyout.show();
}
}
};
;
/*! RESOURCE: /scripts/modules/NavPageLayouts.js */
var NavPageLayouts = {
_ARROW_GRIP_WIDTH: 40,
_FX_NAME: 'none',
initNavPageLayouts : function() {
this.layouts = {};
$j(document).ready(function() {
this._initLayouts();
}.bind(this));
},
getLayout : function(name) {
return this.layouts[name];
},
isEntireLayoutResizing: function() {
return this._layoutResizingAll;
},
isRTL: function() {
return ($j('html').is('[dir="rtl"]')) ? true : false;
},
_initLayouts: function() {
var optsBody = {
maskIframesOnResize: true,
west: {
paneSelector:			'#edge_west',
size:					'auto',
maxSize:				72,
closable:				false,
resizable:				false,
slidable:				false,
spacing_open:			0,
enableCursorHotkey:		false
},
center: {
paneSelector:			'#edge_center',
enableCursorHotkey:		false
},
south: {
paneSelector:           '#edge_south_debug',
initHidden:				true,
size:                   250,
enableCursorHotkey:     false,
resizable:              true,
slidable:               true,
resizerCursor:  		'row-resize',
spacing_closed:	      	8,
spacing_open:         	8,
togglerLength_open:   	this._ARROW_GRIP_WIDTH,
togglerLength_closed: 	this._ARROW_GRIP_WIDTH,
togglerContent_open:	'<span class="iSmall iSmall_mac_down_arrow"></span>',
togglerContent_closed:	'<span class="iSmall iSmall_mac_up_arrow"></span>',
togglerTip_open:		'Hide',
togglerTip_closed:		'Open',
closable:               true,
onresize: function(region, el, container, panel) {
setTimeout(function() {
var minCloseHeight = 15;
var minHeight = 30;
var minOffset = 15, maxOffset = 32;
var mouseY = container.layoutHeight;
var myLayout = $j(document.body).layout();
if (mouseY < minCloseHeight) {
myLayout.hide('south', true);
panel.fireEventOpenClose('debuggerTools.hidden');
myLayout.sizePane("south", myLayout.restoreHeight);
} else if ((minHeight - minOffset < mouseY) && (mouseY <  minHeight + maxOffset))
myLayout.sizePane("south", minHeight);
else
myLayout.restoreHeight = mouseY;
}, 200);
}.bind(this),
fireEventOpenClose: function(key) {
var debuggerFrame = getTopWindow()['footerTrayFrm'];
var cevt = debuggerFrame.CustomEvent;
if (cevt && cevt.fire) {
cevt.fire(key);
}
}.bind(this)
}
}
if (GlideManager.get().getSetting('can_run_chat') === true) {
optsBody.east = {
paneSelector:			'#edge_east',
size:           		48,
closable:				false,
resizable:				false,
slidable:				false,
spacing_open:         	0,
enableCursorHotkey:		false,
onresize: function() {
CustomEvent.fire(GlideEvent.NAV_EAST_PANE_RESIZED);
}.bind(this)
};
}
if (this.isRTL()) {
if (optsBody.east)
var temp = optsBody.east;
optsBody.east = optsBody.west;
if (temp)
optsBody.west = temp;
else
optsBody.west = undefined;
}
this.layouts['body'] = $j(document.body).layout(optsBody);
var optsCenter = {
north: {
paneSelector:	      	'#gsft_banner',
initClosed:           	this.getPreference('edge_center.north.isClosed'),
size:					'auto',
spacing_closed:	      	7,
spacing_open:         	7,
slidable:				false,
resizable:				false,
fxName:               	'none',
togglerLength_open:   	this._ARROW_GRIP_WIDTH,
togglerLength_closed: 	this._ARROW_GRIP_WIDTH,
togglerContent_open:	'<span class="iSmall iSmall_mac_up_arrow" style="margin-top:1px;"></span>',
togglerContent_closed:	'<span class="iSmall iSmall_mac_down_arrow" style="margin-top:1px;"></span>',
togglerTip_open:		'Hide Banner',
togglerTip_closed:		'Open Banner',
enableCursorHotkey:		false,
onopen: function() {
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
}.bind(this),
onclose: function() {
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
}.bind(this)
},
west: {
paneSelector:         	'#nav_west',
initClosed:           	this.getPreference('edge_center.west.isClosed'),
size:                 	this.getPreference('edge_center.west.size'),
fxName:               	this._FX_NAME,
spacing_closed:       	6,
spacing_open:         	7,
slidable:				false,
resizerCursor:  		'col-resize',
resizable:				true,
resizerTip:				'Resize',
togglerLength_open:   	this._ARROW_GRIP_WIDTH,
togglerLength_closed: 	this._ARROW_GRIP_WIDTH,
togglerContent_open:	'<span class="iSmall iSmall_mac_left_arrow" style="margin-left:1px;display:block;"></span>',
togglerContent_closed:	'<span class="iSmall iSmall_mac_right_arrow" style="cursor:pointer;"></span>',
togglerTip_closed:		'Open Pane',
togglerTip_open:		'Close Pane',
enableCursorHotkey:		false,
maskContents: 			true,
minSize:				200,
maxSize:				400,
onopen: function() {
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
if(isSafari) {
setTimeout(function() {
$j(".nav_controls", getIFrameDocument($('gsft_nav'))).css({ 'z-index': 100 });
}, 10);
}
}.bind(this),
onresize: function() {
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
}.bind(this),
onclose: function() {
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
}.bind(this)
},
center: {
paneSelector:			'#l1_center',
maskContents:			true
},
onload: function() {
var b = $('maximize_button');
if (b)
b.hide();
$j('#gsft_banner-toggler').hover(function() {
$j(this).parent().addClass('ui-layout-resizer-north-toggler-hover');
}, function() {
$j(this).parent().removeClass('ui-layout-resizer-north-toggler-hover');
});
$j('#nav_west-toggler').hover(function() {
$j(this).parent().addClass('ui-layout-resizer-west-toggler-hover');
}, function() {
$j(this).parent().removeClass('ui-layout-resizer-west-toggler-hover');
});
},
onresizeall_start: function() {
this._layoutResizingAll = true;
}.bind(this),
onresizeall_end: function() {
this._layoutResizingAll = false;
}.bind(this)
}
if (GlideManager.get().getSetting('can_run_chat') === true) {
optsCenter.south = {
paneSelector:			'#edge_center_south',
size:           		25,
closable:				true,
resizable:				false,
slidable:				false,
spacing_open:         	0,
spacing_closed: 		0,
enableCursorHotkey:		false,
initHidden:				true
};
}
if (this.isRTL()) {
optsCenter.east = optsCenter.west;
optsCenter.west = undefined;
}
this.layouts['edge_center'] = $j('#edge_center').layout(optsCenter);
this.layouts['nav_west'] = $j('#nav_west').layout({
north: {
closable: false,
paneSelector: '#nav_west_north',
resizable: false,
spacing_open: 0,
spacing_closed: 0,
enableCursorHotkey: false
},
center: {
paneSelector: '#nav_west_center',
enableCursorHotkey: false
}
});
var optsEast = {
togglerContent_open: '<span class="iSmall iSmall_mac_right_arrow" style="display:block;margin-left:1px;"></span>',
togglerContent_closed: '<span class="iSmall iSmall_mac_left_arrow" style="display:block;margin-right:1px;"></span>',
resizerCursor:  'col-resize'
}
var optsSouth = {
togglerContent_open: '<span class="iSmall iSmall_mac_down_arrow" style="margin-top:1px;"></span>',
togglerContent_closed: '<span class="iSmall iSmall_mac_up_arrow" style="margin-top:1px;"></span>',
resizerCursor:  'row-resize'
}
var formPane = "#gsft_main_form";
if ($j('#gsft_main_forms').length)
formPane = '#gsft_main_forms';
var optsForm = {
paneSelector:	      	formPane,
initHidden:				false,
fxName:               	this._FX_NAME,
spacing_closed:       	7,
spacing_open:         	8,
slidable:				false,
togglerLength_open:		this._ARROW_GRIP_WIDTH,
togglerLength_closed: 	this._ARROW_GRIP_WIDTH,
togglerTip_open:		'Close Pane',
togglerTip_closed:		'Open Pane',
enableCursorHotkey:		false,
autoResize:				true,
autoRepoen:				false,
maskContents:			true,
minSize: 50,
onswap_start: function(pane) {
var opts = this.layouts.main.options;
if (pane == 'south') {
opts.south.togglerContent_open = optsEast.togglerContent_open;
opts.south.togglerContent_closed = optsEast.togglerContent_closed;
} else if (pane == 'east') {
opts.east.togglerContent_open = optsSouth.togglerContent_open;
opts.east.togglerContent_closed = optsSouth.togglerContent_closed;
}
}.bind(this),
onopen: function(pane) {
this.options.formTarget = 'gsft_main_form';
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
$j('#gsft_main_form-toggler')
.unbind('mouseover.bg-adjustment')
.unbind('mouseout.bg-adjustment')
.parent()
.removeClass('ui-layout-resizer-east-toggler-hover')
.removeClass('ui-layout-resizer-south-toggler-hover');
}.bind(this),
onclose: function(pane) {
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
this._bindMainFormClosedTogglers();
delete this.options.formTarget;
}.bind(this),
onresize: function(pane) {
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
if (this.layouts.main.options[pane].paneSelector === "#gsft_main_forms"){
var $pane = jQuery("#gsft_main_forms");
var tabHeight = $pane.find("div.tabs2_strip").outerHeight();
$pane.find("div[data-comment='tab contents']").height($pane.height() - tabHeight);
}
setTimeout(function() {
var per = this.convertPaneToPercent(this.layouts.main, pane);
this.layouts.main.options[pane].autoResize = true;
this.layouts.main.options[pane].size = per;
}.bind(this), 15);
}.bind(this)
};
var optsDummy = {
initHidden:				true,
initClosed:				true,
fxName:               	this._FX_NAME,
paneSelector:         	"#gsft_dummy",
resizable:      		false,
spacing_closed:			0,
autoResize:				true
};
if (this.getPreference('formPane') == 'south') {
Object.extend(optsSouth, optsForm);
Object.extend(optsEast, optsDummy);
optsSouth.initHidden = false;
} else {
Object.extend(optsSouth, optsDummy);
Object.extend(optsEast, optsForm);
optsEast.initHidden = false;
}
optsEast.initClosed = !!this.getPreference('main.east.isClosed');
optsEast.size = this.getPreference('main.east.size');
optsSouth.initClosed = !!this.getPreference('main.south.isClosed');
optsSouth.size = this.getPreference('main.south.size');
if (!optsSouth.initClosed || !optsEast.initClosed)
this.options.formTarget = 'gsft_main_form';
this.layouts['main'] = $j('#l1_center').layout({
center: {
paneSelector:			'#gsft_main',
closable:				false,
resizable:				false,
slidable:				false,
maskContents:			true,
minWidth:				50,
minHeight:				50
},
south: optsSouth,
east: optsEast,
onresizeall_start: function() {
this._layoutResizingAll = true;
}.bind(this),
onresizeall_end: function() {
this._layoutResizingAll = false;
}.bind(this),
onload: function() {
this._bindMainFormClosedTogglers();
}.bind(this)
});
},
_bindMainFormClosedTogglers: function(elem) {
(elem || $j('#gsft_main_form-toggler.ui-layout-toggler-closed'))
.bind('mouseover.bg-adjustment', function() {
var parent = $j(this).parent();
if (parent.hasClass('ui-layout-resizer-east-closed'))
parent.addClass('ui-layout-resizer-east-toggler-hover');
else if (parent.hasClass('ui-layout-resizer-south-closed'))
parent.addClass('ui-layout-resizer-south-toggler-hover');
})
.bind('mouseout.bg-adjustment', function() {
var parent = $j(this).parent();
if (parent.hasClass('ui-layout-resizer-east'))
parent.removeClass('ui-layout-resizer-east-toggler-hover');
else
parent.removeClass('ui-layout-resizer-south-toggler-hover');
});
}
};
;
/*! RESOURCE: /scripts/modules/NavPagePanes.js */
var NavPagePanes = {
NAV_PANE_NAME: 'gsft_nav',
MAIN_PANE_NAME: 'gsft_main',
MAIN_PANE_FORM_NAME: 'gsft_main_form',
initNavPagePanes: function() {
this.panes = {};
this.currentPane = this.MAIN_PANE_FORM_NAME;
this.panes['gsft_banner'] = new PaneBanner();
this.panes[this.NAV_PANE_NAME] = new PaneNav();
this.panes[this.MAIN_PANE_NAME] = new PaneMain();
this.panes[this.MAIN_PANE_FORM_NAME] = new PaneMainForm(this.MAIN_PANE_FORM_NAME);
},
setCurrentPane: function(name) {
this.currentPane = name;
},
addPane: function(name) {
this.panes[name] = new PaneMainForm(name);
},
removePane: function(name) {
delete this.panes[name];
},
getPane: function(name) {
return this.panes[name];
},
getMainPane: function() {
return this.panes[this.MAIN_PANE_NAME];
},
getMainFormPane : function() {
return this.panes[this.currentPane];
},
isRTL: function() {
return ($j('html').is('[dir="rtl"]')) ? true : false;
},
toggleFormPane: function(layout) {
this.togglePane(layout, this.options.preferences.formPane);
},
togglePane: function(layout, paneName) {
var l = this.layouts[layout];
if (!l)
return;
if (layout == 'main' && this.options.preferences.formPane != paneName) {
var tag = l.state[paneName].tagName.toLowerCase();
if (tag != "iframe") {
l.swapPanes('east', 'south');
l.options.south.autoResize = true;
l.options.east.autoResize = true;
this.options.preferences.formPane = paneName;
l.open(paneName);
setTimeout(function() {
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
}.bind(this), 80);
return;
}
}
if (this.isRTL())
if(paneName == "west")
paneName = "east";
l[!l.state[paneName].isClosed ? 'close' : 'open'].call(l, paneName);
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
},
closePanes: function(layout) {
var l = this.layouts[layout];
if (!l)
return;
l.hide('south');
l.hide('east');
},
showPane: function(layout, paneName) {
var l = this.layouts[layout];
if (!l)
return;
if (l.state[paneName].isClosed) {
l['open'].call(l, paneName);
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
}
}
};
;
/*! RESOURCE: /scripts/modules/NavPagePreferences.js */
var NavPagePreferences = {
_PREF_NAME: 'glide.ui.navpage.state',
initNavPagePreferences: function() {
this.options.preferenceDefaults = {
'formPane': 'east',
'edge_center.north.isClosed': false,
'edge_center.west.isClosed': false,
'edge_center.east.isClosed': false,
'edge_center.west.size': 242,
'main.south.isClosed': true,
'main.south.size': '66%',
'main.east.isClosed': true,
'main.east.size': '50%'
};
var p = GlideManager.get().getPreference(this._PREF_NAME);
this.options.preferences = Object.extend(Object.clone(this.options.preferenceDefaults), p && p.isJSON() ? p.evalJSON() : {});
var windowWidth = $j(window).width();
var mainEastMinWidth = 150;
var mainEastActualWidth = windowWidth - (parseFloat(this.options.preferences['main.east.size']) / 100) * windowWidth;
var newMainEastWidth = (((windowWidth - mainEastMinWidth) / windowWidth) * 100) + '%';
if (mainEastActualWidth <= mainEastMinWidth)
this.options.preferences['main.east.size'] = newMainEastWidth;
CustomEvent.observe(GlideEvent.NAV_SAVE_PREFERENCES, this._savePreferences.bind(this));
},
getFormLayoutPosition: function() {
return this.options.preferences.formPane;
},
getPreference: function(pref) {
return this.options.preferences[pref];
},
getPreferenceDefault: function(pref) {
return this.options.preferenceDefaults[pref];
},
convertPaneToPercent: function(layout, pane) {
var center = this.layouts['edge_center'];
if (pane == 'south')
var avail = center.state.center.outerHeight +
(center.panes.north ? center.options.north.spacing_open : 0) +
(center.panes.south ? center.options.south.spacing_open : 0);
else
var avail = center.state.center.outerWidth +
(center.panes.west ? center.options.west.spacing_open : 0) +
(center.panes.east ? center.options.east.spacing_open : 0);
return Math.ceil(100 * layout.state[pane].size / avail) + '%';
},
_savePreferences: function() {
var layoutEdge = this.layouts['edge_center'];
var layoutMain = this.layouts['main'];
if (!layoutEdge || !layoutMain || this.isEntireLayoutResizing())
return;
if (!layoutMain.state.east.size || !layoutMain.state.south.size)
return;
var o = {
formPane: this.options.preferences.formPane,
'edge_center.north.isClosed': layoutEdge.state.north.isClosed,
'edge_center.west.isClosed': layoutEdge.state.west.isClosed,
'edge_center.east.isClosed': layoutEdge.state.east.isClosed,
'edge_center.west.size': layoutEdge.state.west.size,
'main.south.isClosed': layoutMain.state.south.isClosed,
'main.south.size': this.convertPaneToPercent(layoutMain, 'south'),
'main.east.isClosed': layoutMain.state.east.isClosed,
'main.east.size': this.convertPaneToPercent(layoutMain, 'east')
};
if (Object.equals(o, this.options.preferences))
return;
this.options.preferences = o;
setPreference(this._PREF_NAME, Object.toJSON(o));
CustomEvent.fire(GlideEvent.NAV_UPDATE_EDGE_BUTTON_STATES);
}
};
;
/*! RESOURCE: /scripts/modules/NavPageStateButtons.js */
var NavPageStateButtons = {
initNavPageStateButtons: function() {
$('edge_west').on('click', 'button.layout_button', function(event, elem) {
this.togglePane(elem.readAttribute('data-layout'), elem.readAttribute('data-pane'));
}.bind(this));
CustomEvent.observe(GlideEvent.NAV_UPDATE_EDGE_BUTTON_STATES, this._updateButtonEdgeStates.bind(this));
$('edge_west').on('click', 'button.edge_button_link', function(event, elem) {
var href = elem.parentNode.getAttribute('data-href');
CustomEvent.fire(GlideEvent.NAV_OPEN_URL, {
url: href,
openInForm: false
});
})
},
_updateButtonEdgeStates: function() {
$('edge_west').select('button.layout_button').each(function(elem) {
var isClosed = this.layouts[elem.readAttribute('data-layout')].state[elem.readAttribute('data-pane')].isClosed;
var inverted = elem.hasClassName('layout_button_inverted');
elem[(!isClosed && !inverted) || (isClosed && inverted) ? 'addClassName' : 'removeClassName'].call(elem, 'active');
}.bind(this));
}
};
;
/*! RESOURCE: /scripts/modules/PaneBookmarkDragging.js */
var PaneBookmarkDragging = {
initPaneBookmarkDragging: function() {
this.frame.observe('load', function() {
var doc = this.getDocument();
if (!doc || !doc.on)
return;
doc.on('drop', function(event) { event.stop(); CustomEvent.fireTop(GlideEvent.NAV_DRAGGING_BOOKMARK_STOP); });
doc.on('dragstart', 'a, img', this._onBookmarkDragStart.bind(this));
doc.on('dragend', 'a, img', function() { CustomEvent.fireTop(GlideEvent.NAV_DRAGGING_BOOKMARK_STOP); });
}.bind(this));
},
_onBookmarkDragStart: function(event, elem) {
if (elem.hasClassName('menu')) {
event.dataTransfer.setData('text', Object.toJSON({
type: 'module',
moduleID: elem.id,
href: elem.readAttribute('href')
}));
} else if (elem.tagName == 'IMG' && elem.up().up().readAttribute('name') == 'nav.module') {
var a = elem.up().down('a');
event.dataTransfer.setData('text', Object.toJSON({
type: 'module',
moduleID: a.id,
href: elem.up().down('a:first').readAttribute('href')
}));
} else if (elem.hasClassName('breadcrumb_link')) {
var container = elem.up('span.breadcrumb_container');
var table = container.getAttribute('table');
var fixedQuery = container.getAttribute('fixed_query');
var view = container.readAttribute('view');
var filter = elem.readAttribute('filter');
var getBreadcrumbText = function(t) {
var text = t.innerHTML;
t = t.previous('a.breadcrumb_link');
while (t) {
text = t.innerHTML + ' > ' + text;
t = t.previous('a.breadcrumb_link');
}
return text;
};
event.dataTransfer.setData('text', Object.toJSON({
type: 'breadcrumb',
href: table + '_list.do?sysparm_query=' + (filter ? encodeURIComponent(filter) : '') +
(fixedQuery ? '&sysparm_fixed_query=' + encodeURIComponent(fixedQuery) : '') + (view ? '&sysparm_view=' + view : ''),
table: table,
text: getBreadcrumbText(elem)
}));
} else if (elem.className == 'breadcrumb' && elem.readAttribute('name') == 'breadcrumb') {
event.dataTransfer.setData('text', Object.toJSON({
type: 'breadcrumb',
href: elem.readAttribute('href'),
table: 'sys_report',
text: elem.innerText || elem.textContent
}));
} else if (elem.hasClassName('linked') || elem.hasClassName('report_link') || elem.hasClassName('kb_link') || elem.hasClassName('service_catalog')) {
event.dataTransfer.setData('text', Object.toJSON({
type: 'document',
href: elem.readAttribute('href').replace(/.*nav_to.do\?uri=/i, ''),
text: elem.innerText || elem.textContent
}));
} else {
return;
}
CustomEvent.fireTop(GlideEvent.NAV_DRAGGING_BOOKMARK_START);
}
};
;
/*! RESOURCE: /scripts/modules/PaneFlyoutMousedown.js */
var PaneFlyoutMousedown = {
initPaneFlyoutMousedown: function() {
this.frame.observe('load', function() {
var doc = this.getDocument();
if (!doc || !doc.on)
return;
doc.observe('click', function(event) {
CustomEvent.fireTop(GlideEvent.NAV_PANE_CLICKED, event);
});
}.bind(this));
}
};
;
/*! RESOURCE: /scripts/modules/PaneFormManagement.js */
var PaneFormManagement = {
initPaneFormManagement: function() {
CustomEvent.observe('glide:ui_notification.action', this._handleListToFormAction.bind(this));
},
_handleListToFormAction : function(notification) {
var action = notification.getAttribute('action');
var sysId = notification.getAttribute('sys_id');
var table = notification.getAttribute('table');
var form = this.window.g_form;
if (this.sysId != sysId || !form)
return;
switch (action) {
case 'list_update':
if (form.modified) {
var overlay = new this.window.GlideOverlay({
title: 'Record Updated',
maxWidth: 420
});
overlay.setBodyFromForm('overlay_form_updated_by_list');
overlay.render();
} else {
var url = new this.window.GlideURL();
url.setFromCurrent();
url.addParam('sysparm_nofocus', 'true');
this.loadLinkFromUrl(url.getURL());
}
break;
case 'delete_checked':
if (form.modified) {
var overlay = new this.window.GlideOverlay({
title: 'Record Deleted',
body: 'This record has been deleted.'
});
overlay.setOnAfterClose(function() {
this.window.g_form.modified = false;
this.loadLinkFromUrl('blank.do');
}.bind(this));
overlay.center();
overlay.render();
} else {
this.loadLinkFromUrl('blank.do');
}
break;
}
}
};
;
/*! RESOURCE: /scripts/modules/PaneLinkManagement.js */
var PaneLinkManagement = {
initPaneLinkManagement: function() {
this.frame.observe('load', function() {
var doc = this.getDocument();
if (!doc || !doc.on)
return;
var win = this.getWindow();
doc.on('click', 'a.menu', this._handleNavMenuClick.bind(this));
doc.on('click', 'a.linked, a.web, a.kb_link, a.report_link, .list_decoration > a, .list_decoration_cell > a', this._handleLinkClick.bind(this));
try {
if (typeof win.CustomEvent.observe != "undefined")
win.CustomEvent.observe('list.handler', this._handleListNewClick.bind(this));
} catch(err) {}
}.bind(this));
},
_handleNavMenuClick: function(event, element) {
var target = NavPageManager.get().getFormTarget();
if (!target || event.ctrlKey || event.shiftKey)
return;
var href = element.getAttribute('href');
if (!href || href == "#")
return;
var url = new GlideURL(href);
url.setEncode(false);
if (url.params['sys_id'] != '-1')
return;
url.deleteParam('sysparm_stack');
url.addParam('sysparm_nameofstack', target);
url.addParam('sysparm_clear_stack', 'true');
url.addParam('sysparm_nostack', 'true');
url.addParam('sysparm_goto_url', encodeURIComponent(url.getContexPath() + '?sysparm_nameofstack=' + target + '&sys_id=$sys_id'));
NavPageManager.get().getPane(target).loadLinkFromUrl(url.getURL());
event.stop();
},
_handleLinkClick: function(event, element) {
var href = element.getAttribute('href');
var navManager = NavPageManager.get();
var target = navManager.getFormTarget();
if (!href || href == "#")
return;
if (!navManager.focusExistingTab(href)) {
if (this._shouldUseInAppTab() && this._isModifierKey(event)) {
if (!target)
navManager.toggleFormPane('main');
if (navManager.hasActiveTabs())
$j('.tabs2_add').click();
target = navManager.getFormTarget();
}
if (!target || event.shiftKey || event.ctrlKey
|| (!this._shouldUseInAppTab() && this._isModifierKey(event)))
return;
var url = new GlideURL(href);
url.setEncode(false);
url.addParam('sysparm_nameofstack', target);
if (target != this.frameName)
url.addParam('sysparm_clear_stack', 'true');
if (element.hasClassName('linked'))
CustomEvent.fire(GlideEvent.NAV_LOAD_FORM_FROM_LIST, element.up('tr'));
NavPageManager.get().getPane(target).loadLinkFromUrl(url.getURL());
}
event.preventDefault();
event.stopPropagation();
event.stop();
},
_isModifierKey: function(evt) {
if (isMacintosh)
return evt.metaKey;
return evt.altKey;
},
_shouldUseInAppTab: function() {
return window.NOW.listOpenInAppTab
},
_handleListNewClick: function( list, actionId, actionName) {
if (actionName != "sysverb_new")
return true;
var target = NavPageManager.get().getFormTarget();
if (!target)
return true;
if (target === this.frameName) {
list.addToForm('sysparm_nameofstack', target);
return true;
}
var fe = list.formElements;
var path = fe['sys_target'] + '.do';
list.addToForm('sysparm_referring_url', path + '?sysparm_nameofstack=' + target + '&sys_id=$sys_id_ui11');
list.form.target = target;
list.addToForm('sysparm_nameofstack', target);
list.addToForm('sysparm_clear_stack', 'true');
return true;
}
};
;
/*! RESOURCE: /scripts/modules/doctype/PaneListManagement.js */
var PaneListManagement = {
_LIST_ITEM_HIGHLIGHT_CLASS: 'ui11_list_item_selected',
initPaneListManagement: function() {
CustomEvent.observe('glide:ui_notification.action', this._handleFormToListAction.bind(this));
CustomEvent.observe(GlideEvent.NAV_LOAD_FORM_FROM_LIST, this._showListRowLoading.bind(this));
CustomEvent.observe(GlideEvent.NAV_SYNC_LIST_WITH_FORM, this._syncListFromForm.bind(this));
CustomEvent.observe(GlideEvent.NAV_FORM_DIRTY_CANCEL_STAY, function() {
this._syncListFromForm();
}.bind(this));
this.frame.observe('load', function() {
var doc = this.getDocument();
var win = this.getWindow();
if (!doc)
return;
for (var i in win.GlideLists2) {
var l = win.GlideLists2[i];
if (l.table)
l.table.on('keydown', this._handleListKeyPress.bind(this));
}
this._syncListFromForm();
}.bind(this));
},
_handleFormToListAction: function(notification) {
var win = this.getWindow();
var action = notification.getAttribute('action');
var sysId = notification.getAttribute('sys_id');
var table = notification.getAttribute('table');
switch (action) {
case 'sysverb_update_and_stay':
case 'sysverb_update':
if (typeof win.GlideList2 !== 'function')
return;
var tr = win.$$('tr[sys_id="' + sysId + '"]')[0];
if (!tr)
return;
var list = win.GlideList2.get(tr);
if (!list)
return;
var ajax = new GlideAjax('com.glide.ui_list_edit.AJAXListEdit');
ajax.addParam("sysparm_type", 'get_values');
ajax.addParam('sysparm_view', list.getView());
ajax.addParam('sysparm_table', list.tableName);
ajax.addParam('sysparm_fields', list.fieldNames.slice(1));
ajax.addParam('sys_id', sysId);
ajax.getXML(function(response) {
var xml = response.responseXML;
var items = xml.getElementsByTagName('item');
for (var i = 0, l = items.length; i < l; i++) {
var item = items[i];
var sysId = item.getAttribute('sys_id');
var fqField = item.getAttribute('fqField');
var cell = list.getCell(sysId, fqField);
if(cell) {
win.GlideList2.updateCellContents(cell, item.firstChild);
CustomEvent.fire("list.cell_updated_from_form", sysId, fqField);
}
}
});
break;
case 'sysverb_insert_and_stay':
case 'sysverb_insert':
if (win && win.GlideList2) {
var list = win.GlideList2.get(table);
if (list)
list.refresh();
}
break;
case 'sysverb_delete':
var tr = win.$$('tr[sys_id="' + sysId + '"]')[0];
if (!tr)
return;
var list = win.GlideList2.get(tr);
if (list)
list.refresh();
break;
}
},
_handleListKeyPress: function(event) {
if (event.keyCode == 10 || (event.keyCode == Event.KEY_RETURN && (event.shiftKey || event.ctrlKey))) {
var listEdit = this.window.GwtListEditor._getListEditor(this.window.GwtListEditor.getListId(event.target));
var selections = listEdit.getSelectedRows();
if (!selections[0])
return;
this._handleLinkClick(event, selections[0].select('a.linked:first')[0]);
}
},
_syncListFromForm: function(formPane) {
this._clearTableLoading();
var pane = formPane || NavPageManager.get().getMainFormPane();
if (pane && pane.sysId && pane.table)
this._highlightList(pane.table, pane.sysId);
},
_highlightList: function(table, sysId) {
CustomEvent.fireAll("list.select_row", { table : table, sys_id : sysId });
},
_clearTableLoading: function() {
var win = this.getWindow();
if (!win || !win.$$)
return;
win.$$('table.ui11_loading').each(function(elem) {
elem.removeClassName('ui11_loading');
var tr = elem.select('tr.ui11_loading_row');
if (tr[0])
tr[0].removeClassName('ui11_loading_row');
});
},
_showListRowLoading: function(elemRow) {
if (!elemRow)
return;
this._clearTableLoading();
elemRow.addClassName('ui11_loading_row');
elemRow.up('table').addClassName('ui11_loading');
}
};
;
/*! RESOURCE: /scripts/modules/PaneCreateHotKey.js */
var PaneCreateHotKey = {
createHotKey: function(key, func) {
var doc = this.getDocument();
var button = $(doc.createElement('button'));
button.style.position = 'absolute';
button.style.top = '-9999px';
button.style.left = '-9999px';
button.style.opacity = '0';
button.style.filter = 'alpha(opacity=0)';
button.style.height = '0';
button.style.width = '0';
button.setAttribute('accesskey', key);
button.tabIndex = '-1';
button.setAttribute('aria-hidden', 'true');
button.onclick = func;
button.className = "sr-only";
doc.body.appendChild(button);
}
};
;
/*! RESOURCE: /scripts/modules/PaneMaximizeHotkeys.js */
var PaneMaximizeHotkeys = {
initPaneMaximizeHotkeys: function() {
var selfWin = window;
this.frame.observe('load', function() {
Object.extend(this, PaneCreateHotKey);
this.createHotKey('m', this._toggleMaximize.bind(this));
if (selfWin.Prototype.Browser.WebKit) {
this.createHotKey('b', function() {
var e = selfWin.$('edge_west').select('[data-pane="north"]')[0];
g_navManager.togglePane(e.readAttribute('data-layout'), e.readAttribute('data-pane'));
});
this.createHotKey('n', function() {
var e = selfWin.$('edge_west').select('[data-pane="west"]')[0];
g_navManager.togglePane(e.readAttribute('data-layout'), e.readAttribute('data-pane'));
});
this.createHotKey('v', function() {
var e = selfWin.$('edge_west').select('[data-pane="east"]')[0];
g_navManager.togglePane(e.readAttribute('data-layout'), e.readAttribute('data-pane'));
});
this.createHotKey('h', function() {
var e = selfWin.$('edge_west').select('[data-pane="south"]')[0];
g_navManager.togglePane(e.readAttribute('data-layout'), e.readAttribute('data-pane'));
});
}
}.bind(this));
},
_isMaximized: function() {
var lCenter = NavPageManager.get().getLayout('edge_center');
if (lCenter.state.north.isClosed === false || lCenter.state.west.isClosed === false)
return false;
var lMain = NavPageManager.get().getLayout('main');
var formPane = NavPageManager.get().getFormLayoutPosition();
switch (this.frameName) {
case 'gsft_main':
if (lMain.state[formPane].isClosed === false)
return false;
break;
case 'gsft_main_form':
var p = formPane == 'south' ? 'outerHeight' : 'outerWidth';
if (lMain.state[formPane].size / (lMain.state.container[p] || 1) < 0.96)
return false;
break;
}
return true;
},
_toggleMaximize: function() {
var verb = this._isMaximized() ? 'open' : 'close';
var lCenter = NavPageManager.get().getLayout('edge_center');
var lMain = NavPageManager.get().getLayout('main');
var formPane = NavPageManager.get().getFormLayoutPosition();
switch (this.frameName) {
case 'gsft_main':
lCenter[verb]('north', false, false);
lCenter[verb]('west', false, false);
lMain[verb](formPane);
break;
case 'gsft_main_form':
lCenter[verb]('north');
lCenter[verb]('west');
lMain.sizePane(formPane, verb == 'close' ? '99%' : NavPageManager.get().getPreferenceDefault('main.' + formPane + '.size'));
break;
}
CustomEvent.fire(GlideEvent.NAV_SAVE_PREFERENCES);
setTimeout(function() {
this.getWindow().focus();
}.bind(this), 10);
}
};
;
/*! RESOURCE: /scripts/modules/PaneFilterHotkey.js */
var PaneFilterHotkey = {
initPaneFilterHotkey: function(elem) {
Element.observe(elem, 'load', function() {
var selfWin = window;
Object.extend(this, PaneCreateHotKey).createHotKey('f', function() {
var e = selfWin.$('edge_west').select('[data-pane="west"]')[0];
var navPageManager = NavPageManager.get();
navPageManager.showPane(e.readAttribute('data-layout'), e.readAttribute('data-pane'));
navPageManager.getWindow().$('filter').focus();
});
}.bind(this));
}
};
;
/*! RESOURCE: /scripts/classes/doctype/NotificationMessage.js */
var NotificationMessage = Class.create({
FADE_IN_DEFAULT_MS: 400,
FADE_OUT_DEFAULT_MS: 200,
CLOSE_DEFAULT_MS: 3000,
initialize: function(options) {
this.options = Object.extend({
text: '',
type: 'info',
image: '',
styles: {},
sticky: false,
fadeIn: this.FADE_IN_DEFAULT_MS,
fadeOut: this.FADE_OUT_DEFAULT_MS,
closeDelay: this.CLOSE_DEFAULT_MS,
classPrefix: 'notification',
container: 'ui_notification',
classContainer: 'panel-body',
bundleMessages: false,
singleMessage: false,
onBeforeOpen: function() {},
onAfterOpen: function() {},
onBeforeClose: function() {},
onAfterClose: function() {}
}, options || {});
if (this.options.type == 'warn')
this.options.type = 'warning';
if (this.options.type === '')
this.options.type = 'info';
if (this.options.type == 'system')
this.options.type = 'info';
this.options.fadeIn = this._validNumber(this.options.fadeIn, this.FADE_IN_DEFAULT_MS);
this.options.fadeOut = this._validNumber(this.options.fadeOut, this.FADE_OUT_DEFAULT_MS);
this.options.closeDelay = this._validNumber(this.options.closeDelay, this.CLOSE_DEFAULT_MS);
this._show();
},
_show: function() {
var container = this._getContainer(this.options.container);
this.options.onBeforeOpen.call(this);
if (this.options.singleMessage)
container.update("");
this.notification = this._create();
if (!this.options.bundleMessages || container.childElements().length === 0) {
container.insert(this.notification);
if (!this.options.sticky) {
this.timeoutId = setTimeout(this._close.bind(this, false),
this.options.closeDelay + this.options.fadeIn);
this.notification.observe('mouseover', this._makeSticky.bind(this));
}
} else {
var notification = container.down('.' + this.options.classPrefix);
if (!notification)
notification = this.notification;
this._showOuterPanel(notification);
NotificationMessage.prototype.messages.push(this.notification);
this._updateMoreText(notification, NotificationMessage.prototype.messages.length + " more...");
}
this.notification.on('click', '.notification_close_action', this._close.bind(this, true));
this.notification.fadeIn(this.options.fadeIn, function() {
this.options.onAfterOpen.call(this);
}.bind(this));
},
_close: function(boolCloseImmediately, closeEvent) {
if (!this.notification || this._isClosing === true)
return;
this._isClosing = true;
this.options.onBeforeClose.call(this);
clearTimeout(this.timeoutId);
this.timeoutId = null;
function _onClose(notification) {
this._isClosing = false;
notification.stopObserving();
var parent = notification.up();
if (notification.up('.' + this.options.classContainer)
&& notification
.up('.' + this.options.classContainer).select('.' + this.options.classPrefix).length  <= 1)
notification.up('#' + this.options.container).remove();
else {
if (notification.parentNode)
notification.remove();
notification = null;
}
this.options.onAfterClose.call(this);
if (isMSIE && parent) {
parent.style.display = "none"
parent.style.display = "block";
}
}
var notification = this.notification;
if (closeEvent && closeEvent.element)
notification = closeEvent.element().up('.' + this.options.classPrefix + '-closable');
if (boolCloseImmediately)
_onClose.call(this, notification);
else
notification.animate({ height: 0, opacity: 0.2 }, this.options.fadeOut, _onClose.bind(this, notification));
},
_makeSticky: function() {
clearTimeout(this.timeoutId);
this.notification.stopObserving('mouseover');
this.notification.down('.close').show();
this.notification.addClassName(this.options.classPrefix + '_message_sticky');
},
_showAll: function(more) {
if (this.notification.up(".panel-body").length === 0) {
var notificationContainer = this._createContainer();
this.notification.insert(notificationContainer)
this.notification.wrap(notificationContainer);
this.notification.addClassName("notification_inner");
this.notification = notificationContainer;
}
for (var i = 0; i < NotificationMessage.prototype.messages.length; i++) {
var notification = NotificationMessage.prototype.messages[i];
this.notification.up('.panel-body').insert(notification);
notification.stopObserving('mouseover');
notification.down('.close').show();
notification.addClassName(this.options.classPrefix + '_message_sticky');
}
more.up('.notification-more-container').hide();
NotificationMessage.prototype.messages = [];
},
_getContainer: function(n) {
var c = $(n);
if (c)
return c.down('.' + this.options.classContainer);
c = new Element('div', {
'id': n,
'className': this.options.classPrefix + '_container notification-closable'
});
document.body.appendChild(c);
this._createHeading(c);
var body = this._createBody(c);
this._createFooter(c);
return body;
},
_createContainer: function() {
return this._createMainDiv(true);
},
_createHeading: function(container) {
var heading = new Element('div', {className: "panel-heading", style: 'display: none;' });
var close = this._createCloseIcon();
close.setStyle({display:"block"});
heading.insert(close);
heading.insert("<h3 class=\"panel-title\">Current Notification Messages</h3>");
container.insert(heading);
},
_createBody: function(container) {
var el = new Element('div', { className: this.options.classContainer, style: 'padding: 0;' });
container.insert(el);
return el;
},
_createFooter: function(container) {
var el = new Element('div', { className: 'panel-footer notification-more-container', style: 'display:none; '});
container.insert(el);
el.insert(this._createMoreIcon());
},
_create: function() {
var e = this._createMainDiv();
e.appendChild(this._createCloseIcon());
e.insert(this.options.text);
e.style.display = 'none';
return e;
},
_createCloseIcon: function() {
var close = new Element('span', {
className: 'icon-cross close',
style: 'display: ' + (this.options.sticky ? 'block' : 'none')
});
close.observe('click', this._close.bind(this,true));
return close;
},
_createMainDiv: function(isContainer) {
var className = this.options.classPrefix;
if (!isContainer && this.options.type)
className += ' notification-closable ' + this.options.classPrefix + '-' + this.options.type;
else if (isContainer)
className = this.options.classPrefix + '_message_container panel-body';
if (this.options.sticky)
className += ' ' + this.options.classPrefix + '_sticky';
var e = new Element('div', { 'className' : className });
e.setStyle(this.options.styles);
return e;
},
_createMoreIcon: function(){
var more = new Element("a", { "className": "notification-more" });
more.observe('click',this._showAll.bind(this, more));
return more;
},
_showOuterPanel: function(notification) {
notification.up('.notification_container').down('.panel-heading').show();
notification.up('.notification_container').down('.panel-body').style.padding = '';
notification.up('.notification_container').addClassName('panel panel-default');
notification.up('.panel').down(".notification-more-container").show();
},
_updateMoreText: function(notification, text) {
notification.up('.panel').select(".notification-more")[0].update(text);
},
_validNumber: function(n, v) {
n = parseInt(n, 10);
return isNaN(n) ? v : n;
},
toString: function() { return 'NotificationMessage'; }
});
NotificationMessage.prototype.messages = [];
;
/*! RESOURCE: /scripts/NavPageMenu.js */
$j(function ($) {
'use strict';
$('#navpage_header_control_button').on('click', toggleMenu);
var openCloseAnimationTime = 300;
function toggleMenu(evt) {
var $m = $('#navpage_header_controls');
var $triggerButton = $(this);
if ($m.is(":visible")) {
$m.hide(openCloseAnimationTime);
$triggerButton.attr('aria-expanded', false);
} else {
fixerUpper($m);
positionMenu(evt, $triggerButton, $m);
$m.show(openCloseAnimationTime);
$triggerButton.attr('aria-expanded', true);
}
evt.stopPropagation();
}
$(window).on('resize', function(evt){
var $m = $('#navpage_header_controls');
var $triggerButton = $('#navpage_header_control_button');
positionMenu(evt, $triggerButton, $m);
});
$('body').click(function(evt) {
var $t = $(evt.target);
if ($t.closest('#navpage_header_controls').length)
if ($t.closest('a').length < 1)
return;
CustomEvent.fireAll('body_clicked', evt);
});
CustomEvent.observe('body_clicked', function(originalEvent) {
if (!originalEvent)
return;
var $m = $('#navpage_header_controls');
if ($m.is(":visible"))
$m.hide();
return true;
});
var fixed = false;
function fixerUpper($m) {
if (fixed)
return;
$('#application_picker_select_title').css('color', '').addClass("navpage_header_label");
$('#update_set_picker_select_title').css('color', '').addClass("navpage_header_label");
fixPickerDisplay("application_picker");
fixPickerDisplay("update_set_picker");
fixPickerDisplay("timezone_changer");
fixPickerDisplay("theme_changer");
fixPickerDisplay("gsft_domain");
fixPickerDisplay("gsft_domain_reference");
fixTheme();
$("#select_toggle").hide();
$("#select_decorations").show();
fixed = true;
}
function fixPickerDisplay(id) {
var $e = $("#" + id);
if ($e.css("visibility") == "visible")
$e.css("display", "block");
$e.find("select").on("change", function(){
var $m = $('#navpage_header_controls');
if ($m.is(":visible"))
$m.hide();
});
}
function fixTheme() {
var $e = $('#theme_changer_select').first();
if (!$e.length)
return;
var select = $e[0];
var o = select.options[0];
o.text = "System";
$("#theme_changer").find("label").addClass("navpage_header_label");
$("#timezone_changer").find("label").addClass("navpage_header_label");
$("#language").find("label").addClass("navpage_header_label");
$("#gsft_domain").find("label").addClass("navpage_header_label");
$("#gsft_domain_reference").find("label").addClass("navpage_header_label");
}
function positionMenu(evt, $e, $m) {
var offest = $e.offset();
var h = $e.height();
var w = $('#navpage_header_controls').width();
var mh = $(window).height() - 78 - 20 + 'px';
var top = $e.position().top + $e.outerHeight(true) + 5;
$m.css({
top: top,
maxHeight: mh
});
}
$('.split_layout_selector').click(function(e) {
var newPane = $(this).attr("data-pane");
if(newPane == "none") {
g_navManager.closePanes("main");
return;
}
var oldPane = g_navManager.options.preferences.formPane;
var edge_button = $('#edge_west button[data-pane="'+ newPane +'"]');
g_navManager.togglePane(edge_button.attr('data-layout'), edge_button.attr('data-pane'));
});
paneChange();
CustomEvent.observe(GlideEvent.NAV_UPDATE_EDGE_BUTTON_STATES, function() {
paneChange();
});
function paneChange() {
var newPane = g_navManager.options.preferences.formPane;
var oldPane = newPane == 'east' ? 'south' : 'east';
$('#edge_west button[data-pane="'+ oldPane +'"]').parent().hide();
$('#edge_west button[data-pane="'+ newPane +'"]').parent().show();
}
var $input = $('#accessibility');
if (window.g_accessibility)
$input.prop('checked', true);
$input.change(function() {
var checked = $(this).prop('checked');
CustomEvent.fire('accessibility.change', checked);
});
var $tabbedinput = $('#tabbed_forms');
if (window.NOW.tabbed)
$tabbedinput.prop('checked', true);
$tabbedinput.change(function() {
var checked = $(this).prop('checked');
CustomEvent.fireAll('tabbed', checked);
});
CustomEvent.observe('tabbed', function(value) {
$tabbedinput.prop('checked', value);
});
$input = $('#table_wrap');
if (window.NOW.listTableWrap === true || window.NOW.listTableWrap === 'normal')
$input.prop('checked', true);
$input.change(function() {
var checked = $(this).prop('checked');
CustomEvent.fireAll('table_wrap', checked);
setPreference('table.wrap', (checked ? 'true' : 'false'));
})
$input = $('#compact');
if (window.NOW.compact)
$input.prop('checked', true);
$input.change(function() {
var checked = $(this).prop('checked');
CustomEvent.fireAll('compact', checked);
setPreference('glide.ui.compact', (checked ? 'true' : 'false'));
})
$('.font_size_controls').on('click', function(e) {
e.stopImmediatePropagation();
})
var $related_list_selector = $('.related_list_selector_container');
var val = $related_list_selector.attr('data-pref-value');
$('.related_list_selector[data-value=' + val + ']').addClass('active');
$('.related_list_selector').on('click', function(e) {
var value = $(e.target).attr('data-value');
setPreference('glide.ui.related_list_timing', value);
})
var metaKey = isMacintosh ? 'data-mac-text' : 'data-nonmac-text';
var $metaLabel = $('.meta_list_link_text');
$metaLabel.text($metaLabel.attr(metaKey));
$('#meta_list_link').prop('checked', window.NOW.listOpenInAppTab).change(function() {
var value = $(this).prop('checked');
CustomEvent.fireAll('glide:ui.open_list_link_inapp_tab', value);
setPreference('glide.ui.open_list_link_inapp_tab', value ? 'true' : 'false');
})
$('.recent-changes-link').click(function() {
NOW.launchOverviewHelp('ui15');
})
})
;
/*! RESOURCE: /scripts/navpage_date_time_format.js */
$j(function ($) {
'use strict';
var df = window.NOW.dateFormat;
$('#enable_calendar').on('click', function(e) {
CustomEvent.fireAll("timeago_set", false);
savePreference(true);
})
$('#enable_timeago').on('click', function(e) {
CustomEvent.fireAll("timeago_set", true);
savePreference(false);
})
$('#enable_date_both').on('click', function(e) {
CustomEvent.fireAll("date_both", true);
savePreference(true);
})
if (df.dateBoth)
$("#enable_date_both").addClass("active");
else if (df.timeAgo) {
$("#enable_timeago").addClass("active");
$(".enable_shortdates_row").addClass("collapsed");
}
else
$("#enable_calendar").addClass("active");
var x = $('#enable_shortdates').change(function(e) {
CustomEvent.fireAll("shortdates_set", e.target.checked);
savePreference(true);
})
if (df.shortDates)
x[0].checked = true;
function savePreference(showShortDates) {
if(showShortDates) {
$(".enable_shortdates_row").removeClass("collapsed");
} else {
$(".enable_shortdates_row").addClass("collapsed");
}
setPreference('glide.ui.date_format', JSON.stringify(df));
}
})
;
/*! RESOURCE: /scripts/doctype/html_class_setter.js */
(function () {
var df = window.NOW.dateFormat;
var $h = $j('HTML');
$j(function() {
if (!df)
return;
CustomEvent.observe('timeago_set', function(timeAgo) {
df.timeAgo = timeAgo;
df.dateBoth = false;
setDateClass();
})
CustomEvent.observe('shortdates_set', function(trueFalse) {
df.shortDates = trueFalse;
setDateClass();
})
CustomEvent.observe('date_both', function(trueFalse) {
df.dateBoth = trueFalse;
df.timeAgo = false;
setDateClass();
})
})
function setDateClass() {
$h.removeClass('date-timeago');
$h.removeClass('date-calendar');
$h.removeClass('date-calendar-short');
$h.removeClass('date-both');
if (df.dateBoth) {
$h.addClass('date-both');
if (df.shortDates)
$h.addClass('date-calendar-short');
else
$h.addClass('date-calendar');
} else if (df.timeAgo)
$h.addClass('date-timeago');
else {
if (df.shortDates)
$h.addClass('date-calendar-short');
else
$h.addClass('date-calendar');
}
}
setDateClass();
CustomEvent.observe('compact', function(trueFalse) {
window.NOW.compact = trueFalse;
setCompact();
})
function setCompact() {
if (window.NOW.compact)
$h.addClass('compact');
else
$h.removeClass('compact');
}
setCompact();
CustomEvent.observe('tabbed', function(trueFalse) {
window.NOW.tabbed = trueFalse;
setTabbed();
})
function setTabbed() {
if (window.NOW.tabbed)
$h.addClass('tabbed');
else
$h.removeClass('tabbed');
}
setTabbed();
})()
function printList(maxRows) {
var mainWin = getMainWindow();
if (mainWin && mainWin.CustomEvent && mainWin.CustomEvent.fire && mainWin.CustomEvent.fire("print", maxRows) === false)
return false;
var veryLargeNumber = "999999999";
var print = true;
var features = "resizable=yes,scrollbars=yes,status=yes,toolbar=no,menubar=yes,location=no";
if (isChrome && isMacintosh)
features = "";
var href = "";
var frame = top.gsft_main;
if (!frame)
frame = top;
if (frame.document.getElementById("printURL") != null) {
href = frame.document.getElementById("printURL").value;
href = printListURLDecode(href);
}
if (!href) {
if (frame.document.getElementById("sysparm_total_rows") != null) {
var mRows = parseInt(maxRows);
if (mRows < 1)
mRows = 5000;
var totalrows = frame.document.getElementById("sysparm_total_rows").value;
if (parseInt(totalrows) > parseInt(mRows))
print = confirm(getMessage("Printing large lists may affect system performance. Continue?"));
}
var formTest;
var f = 0;
var form;
while ((formTest = frame.document.forms[f++])) {
if (formTest.id == 'sys_personalize_ajax') {
form = formTest;
break;
}
}
if (!form)
form = frame.document.forms['sys_personalize'];
if (form && form.sysparm_referring_url) {
href = form.sysparm_referring_url.value;
if (href.indexOf("?sys_id=-1") != -1 && !href.startsWith('sys_report_template')) {
alert(getMessage("Please save the current form before printing."));
return false;
}
if (isMSIE) {
var isFormPage = frame.document.getElementById("isFormPage");
if (isFormPage != null && isFormPage.value == "true")
href = href.replace(/javascript%3A/gi, "_javascript_%3A");
}
href = printListURLDecode(href);
} else
href = document.getElementById("gsft_main").contentWindow.location.href;
}
if( href.indexOf("?") <0 )
href += "?";
else
href += "&";
href = href.replace("partial_page=", "syshint_unimportant=");
href = href.replace("sysparm_media=", "syshint_unimportant=");
href += "sysparm_stack=no&sysparm_force_row_count=" + veryLargeNumber + "&sysparm_media=print";
if (print) {
if (href != null && href != "") {
win = window.open(href, "Printer_friendly_format", features);
win.focus();
} else {
alert("Nothing to print");
}
}
function printListURLDecode(href) {
href = href.replace(/@99@/g, "&");
href = href.replace(/@88@/g, "@99@");
href = href.replace(/@77@/g, "@88@");
href = href.replace(/@66@/g, "@77@");
return href;
}
}
function clearCacheSniperly() {
var aj = new GlideAjax("GlideSystemAjax");
aj.addParam("sysparm_name", "cacheFlush");
aj.getXML(clearCacheDone);
}
function clearCacheDone() {
window.status = "Cache flushed";
}
;
/*! RESOURCE: /scripts/sn.messaging/NOW.messaging.js */
(function(global) {
"use strict";
global.NOW = global.NOW || {};
var messaging = global.NOW.messaging = global.NOW.messaging || {};
messaging.snCustomEventAdapter = function(snCustomEvent, snTopicRegistrar, snDate, snUuid) {
var busId = snUuid.generate();
return {
channel: function (channelName) {
var topicRegistrations = snTopicRegistrar.create();
var fireCall = 'fireAll';
snCustomEvent.on(channelName, function (envelope) {
var topic = envelope.topic;
topicRegistrations.subscribersTo(topic).forEach(function (subscription) {
subscription.callback(envelope.data, envelope);
});
});
return {
publish: function (topic, payload) {
if (!topic)
throw "'topic' argument must be supplied to publish";
snCustomEvent[fireCall](channelName, envelope(topic, payload));
},
subscribe: function (topic, callback) {
if (!topic)
throw "'topic' argument must be supplied to subscribe";
if (!callback)
throw "'callback' argument must be supplied to subscribe";
var sub = subscription(topic, callback);
topicRegistrations.registerSubscriber(sub);
return sub;
},
unsubscribe: function (subscription) {
if (!subscription)
throw "'subscription' argument must be supplied to unsubscribe";
return topicRegistrations.deregisterSubscriber(subscription);
},
destroy : function() {
topicRegistrations = null;
snCustomEvent.un(channelName);
}
};
function subscription(topic, callback) {
return {
get topic() {
return topic
},
get callback() {
return callback
}
}
}
function envelope(topic, payload) {
return {
channel: channelName,
topic: topic,
data: payload,
timestamp: snDate.now(),
messageId: snUuid.generate(),
busId: busId
}
}
}
};
};
messaging.snTopicRegistrar = function() {
var validTopicRegex = /^(\w+\.)*(\w+)$/;
function validateSubscription(subscription) {
if (!subscription)
throw new Error("Subscription argument is required");
if (!subscription.topic || !subscription.callback)
throw new Error("Subscription argument must be a valid subscription");
}
function validateTopic(topic) {
if (!topic)
throw new Error("Topic argument is required");
if (!validTopicRegex.test(topic))
throw new Error("Invalid topic name: " + topic);
}
function regexForBinding(binding) {
binding = binding.split('.').map(function(segment) {
if (segment === '')
throw new Error("Empty segment not allowed in topic binding: " + binding);
if (segment === '*')
return '[^.]+';
if (segment === '#')
return '(\\b.*\\b)?';
if (segment.match(/\W/))
throw new Error("Segments may only contain wildcards or word characters: " + binding + ' [' + segment + ']');
return segment;
}).join('\\.');
return new RegExp('^' + binding + '$');
}
return {
create : function() {
var registrations = {};
var bindingRegExps = {};
return {
registerSubscriber : function(subscription) {
validateSubscription(subscription);
if (!registrations[subscription.topic])
registrations[subscription.topic] = [];
registrations[subscription.topic].push(subscription);
bindingRegExps[subscription.topic] = regexForBinding(subscription.topic);
return subscription;
},
deregisterSubscriber : function(toRemove) {
validateSubscription(toRemove);
var topic = toRemove.topic;
var regs = registrations[topic];
if (regs) {
registrations[topic] = regs.filter(function (subscription) {
return subscription !== toRemove;
});
if (registrations[topic].length === 0) {
delete registrations[topic];
delete bindingRegExps[topic];
}
}
},
subscribersTo : function(topic) {
validateTopic(topic);
var bindings = Object.keys(registrations);
return bindings.reduce(function(memo, binding) {
var regex = bindingRegExps[binding];
if (regex.test(topic))
return memo.concat(registrations[binding]);
return memo;
}, []);
}
}
}
}
};
messaging.snDate = function() {
return {
now : function() {
return new Date();
}
}
};
messaging.snUuid = function() {
return {
generate: function() {
var d = new Date().getTime();
return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
var r = (d + Math.random()*16)%16 | 0;
d = Math.floor(d/16);
return (c === 'x' ? r : (r&0x7 | 0x8)).toString(16);
});
}
};
};
global.NOW.MessageBus =
messaging.snCustomEventAdapter(CustomEvent, messaging.snTopicRegistrar(), messaging.snDate(), messaging.snUuid());
})(this);
;
/*! RESOURCE: /scripts/classes/doctype/GlideModal.js */
(function(global, $) {
"use strict";
var GlideModal = function() {
GlideModal.prototype.initialize.apply(this, arguments);
};
GlideModal.prototype = {
initialize: function(id, readOnly, width, height) {
this.preferences = {};
this.id = id;
this.readOnly = readOnly;
this.backdropStatic = false;
this.setDialog(id);
this.setSize(width, height);
this.setPreference('renderer', 'RenderForm');
this.setPreference('type', 'direct');
},
setDialog: function(dialogName) {
this.setPreference('table', dialogName);
},
setPreference: function(name, value) {
this.preferences[name] = value;
},
getPreference: function(name) {
return this.preferences[name];
},
setSize: function(width) {
this.size = 'modal-md';
if (!width)
this.size = 'modal-md';
else if (width < 350)
this.size = 'modal-alert';
else if (width < 450)
this.size = 'modal-sm';
else if (width < 650)
this.size = 'modal-md';
else
this.size = 'modal-lg';
},
setWidth: function(width) {
this.setSize(width);
},
setTitle: function(title) {
this.title = title;
},
setBackdropStatic: function(makeStatic) {
this.backdropStatic = makeStatic;
},
updateTitle: function() {
$('.modal-title', this.$window).html(this.title);
},
updateSize: function() {
$('.modal-dialog', this.$window).attr('class', 'modal-dialog').addClass(this.size);
},
setFocus: function(el) {
},
render: function() {
var description = this.getDescribingText();
var ajax = new GlideAjax("RenderInfo");
ajax.addParam("sysparm_value", description);
ajax.addParam("sysparm_name", this.id);
ajax.getXML(this._renderFromAjax.bind(this));
},
_renderFromAjax: function(response) {
var xml = response.responseXML;
var newBody = xml.getElementsByTagName("html")[0];
xml = newBody.xml ? newBody.xml
: new XMLSerializer().serializeToString(newBody);
if (!xml)
return;
this.setPreferencesFromBody(response.responseXML);
this.setEscapedBody(xml);
this._evalScripts(xml);
},
renderWithContent: function(content) {
this._createModal();
if (typeof content == 'string')
$('.modal-body', this.$window)[0].innerHTML = content;
else
$('.modal-body', this.$window).html(content);
this.$window.modal({
backdrop: this.readOnly || this.backdropStatic ? 'static' : undefined,
keyboard: !this.readOnly
});
this.fireEvent("bodyrendered", this);
_frameChanged();
},
_createModal: function() {
if (this.$window) {
this.updateTitle();
this.updateSize();
return;
}
this._closeIdenticalModals();
var html = new Template(getTemplate()).evaluate({
title: this.title,
id: this.id,
size: this.size,
readOnly: this.readOnly ? 'true' : 'false',
showHelp: this.showHelp ? 'true' : 'false'
});
var $modal = $(html);
$modal.data('gWindow', this);
this.$window = $modal;
$(document.body).append(this.$window);
this._watchForClose();
this._watchHelp();
},
setEscapedBody: function(body) {
if (!body)
return;
body = body.replace(/\t/g, "");
body = body.replace(/\r/g, "");
body = body.replace(/\n+/g, "\n");
body = body.replace(/%27/g, "'");
body = body.replace(/%3c/g, "<");
body = body.replace(/%3e/g, ">");
body = body.replace(/&amp;/g, "&");
this.setBody(body, true);
},
setBody: function(html, noEvaluate) {
if (typeof html == 'string') {
html = this._substituteGet(html);
html = this._fixBrowserTags(html);
this.renderWithContent(html);
if (!noEvaluate)
this._evalScripts(html);
} else {
this.renderWithContent(html);
}
},
setPreferencesFromBody: function(xml) {
var prefs = xml.getElementsByTagName("renderpreference");
if (prefs.length > 0) {
for(var i = 0; i < prefs.length; i++) {
var pref = prefs[i];
var name = pref.getAttribute("name");
var valu = pref.getAttribute("value");
this.setPreference(name, valu);
if (name == "title")
this.setTitle(valu);
if (name == "render_title" && valu == "false")
this.setTitle("");
}
}
},
_substituteGet: function(html) {
if (!html)
return html;
var substitutions = [this.type(), 'GlideDialogWindow', 'GlideDialogForm'];
for (var i = 0; i < substitutions.length; i++) {
var reg = new RegExp(substitutions[i] + ".get\\(", "g");
html = html.replace(reg, this.type() + ".prototype.get('" + this.getID() + "'");
}
return html;
},
_fixBrowserTags: function(html) {
if (!html)
return html;
var tags = [ "script", "a ", "div", "span", "select" ];
for(var i = 0; i < tags.length; i++) {
var tag = tags[i];
html = html.replace(new RegExp('<' + tag + '([^>]*?)/>', 'img'), '<' + tag + '$1></' + tag + '>');
}
return html;
},
_evalScripts: function(html) {
html = this._substituteGet(html, this.type());
var x = loadXML("<xml>" + html + "</xml>");
if (x) {
var scripts = x.getElementsByTagName("script");
for(var i = 0; i < scripts.length; i++)	{
var script = scripts[i];
var s = "";
if (script.getAttribute("type") == "application/xml")
continue;
if (script.getAttribute("src")) {
var url = script.getAttribute("src");
var req = serverRequestWait(url);
s = req.responseText;
} else {
s = getTextValue(script);
if (!s)
s = script.innerHTML;
}
if (s)
evalScript(s, true);
}
}
if (!window.G_vmlCanvasManager)
return;
window.G_vmlCanvasManager.init_(document)
},
getID: function() {
return this.id;
},
getPreferences: function() {
return this.preferences;
},
getDescribingXML: function() {
var section = document.createElement("section");
section.setAttribute("name", this.getID());
var preferences = this.getPreferences();
for(var name in preferences) {
if (!preferences.hasOwnProperty(name))
continue;
var p = document.createElement("preference");
var v = preferences[name];
p.setAttribute("name", name);
if (v !== null && typeof v == 'object') {
if (typeof v.join == "function") {
v = v.join(",");
} else if (typeof v.toString == "function") {
v = v.toString();
}
}
if (v && typeof v.escapeHTML === "function")
v = v.escapeHTML();
if (v)
p.setAttribute("value", v);
section.appendChild(p);
}
return section;
},
getDescribingText : function() {
var gxml = document.createElement("gxml");
var x = this.getDescribingXML();
gxml.appendChild(x);
return gxml.innerHTML;
},
destroy: function() {
if (!this.fireEvent('closeconfirm', this))
return;
if (this.$window)
this.$window.modal('hide');
},
_removeWindow: function() {
this.fireEvent('beforeclose', this);
this.$window.remove();
},
get: function(id) {
if (!id)
return this;
var win = document.getElementById(id);
if (!win)
return this;
return $(win).data('gWindow');
},
_watchForClose: function() {
this.$window.on('click', '[data-dismiss=GlideModal]', function() {
this.destroy();
}.bind(this));
this.$window.on('hidden.bs.modal', function() {
this._removeWindow(true);
}.bind(this));
},
_watchHelp: function() {
this.$window.on('click', '.help', function() {
if (this._helpCallback)
this._helpCallback.call();
}.bind(this));
},
on: function(evtName, callbackFn) {
if (!this._events)
this._events = {};
if (!this._events[evtName])
this._events[evtName] = [];
this._events[evtName].push(callbackFn);
},
fireEvent: function() {
var args = Array.prototype.slice.call(arguments, 0);
var evtName = args.shift();
if (!this._events || !this._events[evtName])
return true;
for (var i = 0; i < this._events[evtName].length; i++) {
var ev = this._events[evtName][i];
if (!ev)
continue;
if (ev.apply(this, args) === false)
return false;
}
return true;
},
_closeIdenticalModals: function() {
var $existingModal = $('#' + this.id).data('gWindow');
if (!$existingModal)
return;
$existingModal.destroy();
},
addDecoration: function(decorationElement, leftSide) {
},
addFunctionDecoration: function(imgSrc, imgAlt, func, side) {
if (imgSrc == 'images/help.gif')
this.addHelpDecoration(func);
},
addHelpDecoration: function(func) {
this.showHelp = true;
this._helpCallback = func;
},
type: function() {
return "GlideModal";
}
};
function getTemplate() {
return '<div id="#{HTML:id}" tabindex="-1" ' +
'aria-hidden="true" class="modal" role="dialog" ' +
'aria-labelledby="#{HTML:id}_title" data-readonly="#{HTML:readOnly}" data-has-help="#{HTML:showHelp}">' +
'	<div class="modal-dialog #{size}">' +
'		<div class="modal-content">' +
'			<header class="modal-header">' +
'				<button data-dismiss="GlideModal" class="btn btn-icon close icon-cross">' +
'					<span class="sr-only">Close</span>' +
'				</button>' +
'			<h4 id="#{HTML:id}_title" class="modal-title">' +
'				#{HTML:title}' +
'			<button class="btn btn-icon icon-help help">' +
'				<span class="sr-only">Help</span>' +
'			</button>' +
'			</h4>' +
'			</header>' +
'			<div class="modal-body container-fluid"></div>' +
'		</div>' +
'	</div>' +
'</div>';
}
global.GlideModal = GlideModal;
})(window, jQuery);
;
/*! RESOURCE: /scripts/classes/doctype/GlideModalForm.js */
(function(global, $) {
"use strict";
var GlideModalForm = function() {
GlideModalForm.prototype.init.apply(this, arguments);
};
GlideModalForm.prototype = $.extend({}, GlideModal.prototype, {
IGNORED_PREFERENCES: {
'renderer': true,
'type': true,
'table': true
},
init: function(title, tableName, onCompletionCallback, readOnly) {
this.initialize.call(this, tableName, readOnly, 800);
this.tableName = tableName;
if (title)
this.setTitle(title);
if (onCompletionCallback)
this.setCompletionCallback(onCompletionCallback);
},
setSize: function(width) {
this.size = 'modal-95';
},
setSysID: function(id) {
this.setPreference('sys_id', id);
},
setType: function(type) {
this.setPreference('type', type);
},
setCompletionCallback: function(func) {
this.onCompletionFunc = func;
},
render: function() {
this._createModal();
var body = $('.modal-body', this.$window)[0];
body.innerHTML = getFormTemplate();
var frame = $('.modal-frame', this.$window);
frame.on('load', function() {
this._formLoaded();
}.bind(this));
this.$window.modal({
backdrop: 'static'
});
this._bodyHeight = $('#' + this.id)[0].getHeight();
var margin = $('.modal-dialog', this.$window)[0].offsetTop * 2;
margin += frame.offset().top;
if (this._bodyHeight > margin)
this._bodyHeight -= margin;
frame.css('height', this._bodyHeight);
var $doc = frame[0].contentWindow ? frame[0].contentWindow.document : frame[0].contentDocument;
var $body = $($doc.body);
$body.html('');
$body.append($('link').clone());
$body.append('<center>' + getMessage('Loading') + '... <br/><img src="images/ajax-loader.gifx"/></center></span>');
var f = $('.modal_dialog_form_poster', this.$window)[0];
f.action = this.getPreference('table') + '.do';
addHidden(f, 'sysparm_clear_stack', 'true');
addHidden(f, 'sysparm_nameofstack', 'formDialog');
addHidden(f, 'sysparm_titleless', 'true');
addHidden(f, 'sysparm_is_dialog_form', 'true');
var sysId = this.getPreference('sys_id');
if (!sysId)
sysId = '';
addHidden(f, 'sys_id', sysId);
var targetField = '';
if (this.fieldIDSet)
targetField = this.getPreference('sysparm_target_field');
for (var id in this.preferences) {
if (!this.IGNORED_PREFERENCES[id])
addHidden(f, id, this.preferences[id]);
}
var parms = [];
parms.push('sysparm_skipmsgs=true');
parms.push('sysparm_nostack=true');
parms.push('sysparm_target_field=' + targetField);
parms.push('sysparm_returned_action=$action');
parms.push('sysparm_returned_sysid=$sys_id');
parms.push('sysparm_returned_value=$display_value');
addHidden(f, 'sysparm_goto_url', 'modal_dialog_form_response.do?' + parms.join('&'));
f.submit();
},
_formLoaded: function() {
var frame = $('.modal-frame', this.$window);
if (frame.contents().get(0).location.href.indexOf('modal_dialog_form_response') != -1) {
if (this.onCompletionFunc) {
var f = $('.modal_dialog_form_response form', frame.contents())[0];
this.onCompletionFunc(f.action.value, f.sysid.value, this.tableName, f.value.value);
}
this.destroy();
return;
}
if (this.onFormLoad)
this.onFormLoad(this);
},
addParm: function(k, v) {
this.setPreference(k, v);
}
});
function getFormTemplate() {
return '<form class="modal_dialog_form_poster" target="dialog_frame" method="POST" style="display: inline;"/>' +
'<iframe id="dialog_frame" name="dialog_frame" class="modal-frame" style="width:100%;height:100%;" frameborder="no" />';
}
global.GlideModalForm = GlideModalForm;
})(window, jQuery);
;
/*! RESOURCE: /scripts/NavpageAngularBootstrap.js */
$j(function() {
"use strict";
setTimeout(function() {
var modules = ['sn.base'];
if (window.NOW.ngLoadModules)
modules = modules.concat(window.NOW.ngLoadModules);
angular.bootstrap(document, modules);
}, 0);
});
;
/*! RESOURCE: /scripts/doctype/list_link_tab_pref.js */
(function() {
"use strict";
CustomEvent.observe('glide:ui.open_list_link_inapp_tab', function(val) {
window.NOW.listOpenInAppTab = val;
});
})();
;
/*! RESOURCE: /scripts/overview_help.js */
$j(function() {
"use strict";
window.NOW.launchOverviewHelp = function(pageName, override) {
var existingHelp = getHelpFrame(pageName);
if (existingHelp.length > 0)
return;
var $frame = $j(
'<iframe src="$overview_help.do?sysparm_help_page=' + pageName + '" ' +
'class="overview-help-frame"' +
'data-help="' + pageName + '" />');
$frame.hide();
$j('body').append($frame);
$frame.bind('load', function() {
$frame.show();
});
}
CustomEvent.observe('overview_help.finished', function(data) {
getHelpFrame(data.id).remove();
})
function getHelpFrame(id) {
return $j('iframe[data-help=' + id + ']');
}
})
;
;
