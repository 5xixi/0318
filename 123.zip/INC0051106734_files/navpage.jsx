/*! RESOURCE: /scripts/navpage.js */
var leftNav;
var middleNav;
var rightNav;
var navControls;
var navToggleImage;
var g_active_user = false;
var previousTerm;
function adjustBanner() {
if (!g_active_user)
return;
var bannerSrc = g_active_user.getBannerImage();
var bannerText = g_active_user.getBannerText();
var bannerImage = gel('mainBannerImage');
if (bannerImage && bannerSrc)
bannerImage.src = bannerSrc;
if (bannerText) {
inner("nav_header_text", bannerText);
if (bannerText.indexOf('-') == 0)
bannerText = bannerText.substring(1);
inner("nav_header_text_small", bannerText);
}
}
function toggleBanner() {
var image = gel("banner_minimize");
var tall = gel("banner_tall");
var small = gel("banner_small");
var preferenceValue = "small";
if (tall.style.display == "block") {
hideObject(tall);
showObject(small);
image.src = "images/header_view.gifx";
} else {
showObject(tall);
hideObject(small);
image.src = "images/header_collapse.gifx";
preferenceValue = "tall";
}
if(g_active_user)
setPreference('banner', preferenceValue);
CustomEvent.fire("banner.changed");
}
function gsftReloadNav() {
var nav = getNavWindow();
if (nav != null) {
nav.location.replace(nav.location.pathname);
}
}
function hideAllAppsLink() {
var e = $('show_all_apps');
if (e)
e.style.display = "none"
}
function showAllAppsLink() {
var e = $('show_all_apps');
if (e)
e.style.display = "block"
}
function toggleNav() {
if (navVisible()) {
hideNav();
} else {
showNav();
}
}
function showNav() {
if (!leftNav) getNavs();
leftNav.style.width = "";
middleNav.style.width = "1px";
middleNav.style.backgroundColor = "#dddddd";
rightNav.style.width = "82%";
navControls.style.display = "block";
navToggleImage.src = "images/toggle_left.gifx";
}
function hideNav() {
if (!leftNav) getNavs();
leftNav.style.width = "1px";
middleNav.style.width = "1px";
middleNav.style.backgroundColor = "white";
rightNav.style.width = "100%";
navControls.style.display = "none";
navToggleImage.src = "images/toggle_right.gifx";
}
function navVisible() {
if (!leftNav) getNavs();
return leftNav.style.width != "1px";
}
function jslog(msg, src, dateTime) {
if (window.console && window.console.log)
console.log(msg);
if (debuggerTools.isDebugPanelVisible()) {
if (!src)
src = "navpage.do";
msg = '<div class="debug_line"><span class="log-time CLIENT">' + getFormattedTime(dateTime) + '</span><span class="log-category">' + src + '</span><span class="log-message">' + msg + "</span></div>";
var wndw = debuggerTools.getJsDebugWindow();
if (typeof wndw != undefined && wndw.addJsLogMessage)
wndw.addJsLogMessage(msg);
}
}
function getNavs() {
leftNav = $("leftnavtd");
middleNav = $("linenavtd");
rightNav = $("rightnavtd");
navControls = $("navControlsTD");
navToggleImage = $("navToggleImage");
}
function expandAllMenus() {
var navWin = getNavWindow();
navWin.CustomEvent.fire("navigator.expand.all");
}
function collapseAllMenus() {
var navWin = getNavWindow();
navWin.CustomEvent.fire("navigator.collapse.all");
}
function toggleCollapseIcon(show, hide) {
var e1 = $(show);
var e2 = $(hide);
if (e1 && e2) {
e1.style.display = "inline";
e2.style.display = "none";
}
}
function showPerspectiveMenu(e) {
var navWin = getNavWindow();
var psection = navWin.$('div.perspectives');
if (!psection)
return;
var p = navWin.document.getElementsByTagName('a');
var gcm = new GwtContextMenu("context_perspectives_menu");
gcm.clear();
for(var i = 0; i < p.length; i++) {
var a = p[i];
if (a.getAttribute("parent_id") == "perspectives") {
var name = a.innerHTML;
if (a.href.split("=")[1] == "All")
gcm.addHref(name, "hideAllAppsLink();resetNavFilter();getNavWindow().location = '" + a.href + "'");
else
gcm.addHref(name, "showAllAppsLink();resetNavFilter();getNavWindow().location = '" + a.href + "'");
}
}
if (!psection.getAttribute("extinct")) {
gcm.addLine();
if (psection.style.display == "none")
gcm.addHref('Show "Menu Items"', "toggleMenuItems()");
else
gcm.addHref('Hide "Menu Items"', "toggleMenuItems()");
}
contextShow(e, gcm.getID(), -1, 0, 0);
e.cancelBubble = true;
}
function toggleMenuItems() {
clearFilterText();
var navWin = getNavWindow();
var s = navWin.$('perspectives');
var d = navWin.$('div.perspectives');
if (d.style.display == "none") {
d.style.display = "block";
setPreference('view.perspectives', 'true');
} else {
d.style.display = "none";
s.style.display = "none";
setPreference('view.perspectives', 'false');
}
}
function navFilterFocus(input, msg) {
input.className = 'nav_filter_in';
var val = input.value;
if (!val || (val == msg)) {
input.value = '';
previousTerm = '';
}
else
previousTerm = val;
setTimeout(function() { input.select(); }, 10);
}
function navFilterBlur(input, msg) {
unhighlightModule();
var val = input.value;
if (!val) {
input.value = msg;
previousTerm = '';
input.className = 'nav_filter_out';
} else
input.className = 'nav_filter_out_value';
}
function navFilterKeyUp(val, msg, evt) {
var s = $('nav_filter_controls');
if (val == msg)
val = '';
if (!val || val == '')
s.style.visibility = "hidden";
else
s.style.visibility = "visible";
if (evt && val != '') {
if (evt.keyCode == 40) {
if (typeof highlighted_mod == "undefined")
focusFirstVisibleModule();
else
focusNextVisibleModule(highlighted_mod);
return;
}
if (evt.keyCode == 38) {
if (typeof highlighted_mod != "undefined")
focusPreviousVisibleModule(highlighted_mod);
return;
}
if (evt.keyCode == 13) {
if (typeof highlighted_mod != "undefined")
runModule(highlighted_mod, evt.shiftKey);
return;
}
}
unhighlightModule();
try {
if (typeof navFilterExtension == "function" && navFilterExtension(val, msg))
return;
}
catch(e) {
jslog("Error in UI Script navFilterExtension - " + e);
}
if (val.endsWith('.form')) {
restoreFilterText(msg);
val = val.toLowerCase().replace(/ /g, '');
$('gsft_main').src = getCancelableLink(val.replace('.form','.do?sys_id=-1'));
} else if (val.endsWith('.list')) {
restoreFilterText(msg);
val = val.toLowerCase().replace(/ /g, '');
$('gsft_main').src = getCancelableLink(val.replace('.list','_list.do'));
} else if (val.endsWith('.FORM')) {
val = val.replace(/ /g, '');
restoreFilterText(msg);
var url = new GlideURL(val.toLowerCase().replace('.form','.do?sys_id=-1'));
window.open(url.getURL());
} else if (val.endsWith('.LIST')) {
val = val.replace(/ /g, '');
restoreFilterText(msg);
var url = new GlideURL(val.toLowerCase().replace('.list','_list.do'));
window.open(url.getURL());
} else if (val.endsWith('_list.do')) {
restoreFilterText(msg);
val = val.toLowerCase().replace(/ /g, '');
$('gsft_main').src = val;
} else if (val.endsWith('.do')) {
restoreFilterText(msg);
val = val.toLowerCase().replace(/ /g, '');
$('gsft_main').src = val + "?sys_id=-1";
} else {
getNavWindow().GwtNavFilter.filter(val);
if (val == '')
unhighlightModule();
else
focusFirstVisibleModule();
}
}
function navFilterKeyPress(val, msg, evt) {
if (evt.keyCode != 13)
return;
navFilterKeyUp(val, msg, evt);
if (evt.preventDefault)
evt.preventDefault();
else
evt.returnValue = false;
}
function unhighlightModule() {
if (typeof highlighted_mod != "undefined") {
getNavWindow().gel(highlighted_mod).style.backgroundColor = "";
highlighted_mod = undefined;
}
}
function focusFirstVisibleModule() {
var mods = getNavWindow().document.getElementsByTagName("tr");
for (var i = 0; i < mods.length; i++) {
var mod = mods[i];
if (mod.getAttribute("name") != "nav.module" || mod.getAttribute("moduletype") == "MENU_LIST" || mod.getAttribute("moduletype") == "SEPARATOR")
continue;
if (mod.style.display != "none") {
highlightMod(mod);
highlighted_mod = mod.id;
break;
}
}
}
function focusNextVisibleModule(hl) {
var mods = getNavWindow().document.getElementsByTagName("tr");
var found = false;
for (var i = 0; i < mods.length; i++) {
var mod = mods[i];
if (!found && mod.id == hl) {
found = true;
continue;
}
if (!found)
continue;
if (mod.getAttribute("name") != "nav.module" || mod.getAttribute("moduletype") == "MENU_LIST" || mod.getAttribute("moduletype") == "SEPARATOR")
continue;
if (mod.style.display != "none") {
if (hl != "")
getNavWindow().gel(hl).style.backgroundColor = "";
highlightMod(mod);
highlighted_mod = mod.id;
break;
}
}
}
function focusPreviousVisibleModule(hl) {
var mods = getNavWindow().document.getElementsByTagName("tr");
var foundhighlighted = false;
var foundcandidate = false;
var candidate;
for (var i = 0; i < mods.length; i++) {
var mod = mods[i];
if (!foundhighlighted && mod.id != hl &&
mod.getAttribute("name") == "nav.module" &&
mod.getAttribute("moduletype") != "MENU_LIST" &&
mod.getAttribute("moduletype") != "SEPARATOR" &&
mod.style.display != "none") {
candidate = mod;
foundcandidate = true;
}
if (!foundhighlighted && mod.id == hl) {
foundhighlighted = true;
if (foundcandidate) {
highlightMod(candidate);
highlighted_mod = candidate.id;
} else
highlighted_mod = undefined;
getNavWindow().gel(hl).style.backgroundColor = "";
break;
}
}
}
function highlightMod(mod) {
var td = mod.firstChild;
if (typeof g_mod_highlight_color != "undefined")
mod.style.backgroundColor = g_mod_highlight_color;
else
mod.style.backgroundColor = "#eee";
}
function runModule(hl,newWindow) {
var mod = getNavWindow().gel(hl);
var td = mod.getElementsByTagName("td")[0];
var a = td.getElementsByTagName("a")[0];
var target = a.getAttribute("target");
var cancelable = a.getAttribute("data-cancelable");
var href = a.getAttribute('href');
if (newWindow)
target = "_blank";
if (cancelable == 'true')
href = getCancelableLink(href);
if (target == "" || target == "gsft_main") {
mod.style.backgroundColor = "";
highlighted_mod = undefined;
$('gsft_main').src = href;
} else
window.open(href);
}
function getCancelableLink(link) {
if (g_cancelPreviousTransaction) {
var nextChar = link.indexOf('?') > -1 ? '&' : '?';
link += nextChar + "sysparm_cancelable=true";
}
return link;
}
function clearFilterText() {
previousTerm = '';
var f = gel('filter');
if (f) {
f.value = '';
f.className = 'nav_filter_out';
}
}
function restoreFilterText(msg) {
var f = gel('filter');
if (!f)
return;
if (previousTerm != "") {
f.value = previousTerm;
navFilterKeyUp(previousTerm, msg);
}
else {
clearFilterText();
navFilterKeyUp('', msg);
}
}
function resetNavFilter() {
var e = gel('filter');
e.className = 'nav_filter_out';
e.value = e.defaultValue;
var s = gel('nav_filter_controls');
s.style.visibility = "hidden";
previousTerm = "";
}
function initCache() {
g_cache_message = new GlideClientCache(500);
g_cache_td = new GlideClientCache(50);
}
function onLogin( user) {
g_active_user = user;
setTimeout('adjustBanner();', 0);
}
function initNavUser() {
return new GlideUser();
}
var debuggerTools = function() {
var minHeight = 38;
function restoreHeight() {
if (!isDebugPanelVisible())
return;
var panel = $('edge_south_debug') || $('footerTray');
if (panel.getHeight() <= minHeight)
toggleTrayCollapsed();
}
function toggleTrayCollapsed() {
if (!isDebugPanelVisible())
return;
var jqueryLayout = $('edge_south_debug');
var minimize = false;
if (jqueryLayout) {
var myLayout = $j(document.body).layout();
var height = minHeight - 7;
minimize = (jqueryLayout.getHeight() > height);
myLayout.sizePane("south", minimize ? height : myLayout.restoreHeight);
} else {
var footerTray = $('footerTray');
minimize = (footerTray.getHeight() > minHeight);
footerTray.style.height = (minimize ? minHeight : footerTray.restoreHeight) + 'px';
}
}
function setDefaultTrayHeight() {
var height = Math.round($(document.body).getHeight() * 0.30);
var jqueryLayout = $('edge_south_debug');
if (jqueryLayout) {
var myLayout = $j(document.body).layout();
myLayout.sizePane("south", height);
myLayout.restoreHeight = height;
} else {
var footerTray = $('footerTray');
footerTray.style.height = height + 'px';
footerTray.restoreHeight = height;
}
}
function initDebugIframe() {
var footerTrayFrm = $('footerTrayFrm');
if (!footerTrayFrm.isLoaded) {
setDefaultTrayHeight();
footerTrayFrm.src = 'jsdebug.do?sysparm_doctype=true&sysparm_stack=no';
footerTrayFrm.isLoaded = true;
debugToolSplitterContext.init();
var debugToolsSplitterH = $('debugToolsSplitterH');
if (debugToolsSplitterH)
debugToolsSplitterH.observe('mousedown', debugToolSplitterContext.mouseDownHandler);
}
}
function selectFieldWatcherTab() {
var wndw = getJsDebugWindow();
if (!wndw || !wndw.selectFieldWatcherTab)
setTimeout(selectFieldWatcherTab, 100);
else
wndw.selectFieldWatcherTab();
}
function isDebugPanelVisible() {
var jqueryLayout = $('edge_south_debug');
if (jqueryLayout) {
return jqueryLayout.getStyle('display') == 'block';
} else {
var footerTrayRow = $('footerTrayRow');
if (footerTrayRow)
return !footerTrayRow.hasClassName('footer-tray-hidden');
else
return false;
}
}
function toggleJSDebugger() {
var isVisible = isDebugPanelVisible();
if (!isVisible)
initDebugIframe();
var jqueryLayout = $('edge_south_debug');
if (jqueryLayout) {
var myLayout = $j(document.body).layout();
myLayout[isVisible ? 'hide' : 'show']('south', true);
} else {
var footerTrayRow = $('footerTrayRow');
if (footerTrayRow)
footerTrayRow.toggleClassName('footer-tray-hidden');
}
isVisible = !isVisible;
var debuggerFrame = getTopWindow()['footerTrayFrm'];
var cevt = debuggerFrame.CustomEvent;
if(!cevt && debuggerFrame.contentWindow)
cevt = debuggerFrame.contentWindow.CustomEvent;
if (cevt && cevt.fire) {
cevt.fire(isVisible ? 'debuggerTools.visible' : 'debuggerTools.hidden');
}
}
function showFieldWatcher() {
toggleJSDebugger();
selectFieldWatcherTab();
}
function getJsDebugWindow() {
return $('footerTrayFrm').contentWindow;
}
return {
restoreHeight: restoreHeight,
toggleTrayCollapsed: toggleTrayCollapsed,
isDebugPanelVisible: isDebugPanelVisible,
toggleJSDebugger: toggleJSDebugger,
showJSDebugger: toggleJSDebugger,
showFieldWatcher: showFieldWatcher,
getJsDebugWindow: getJsDebugWindow
};
}();
var debugToolSplitterContext = function() {
var isDragSplitter = false;
var footerTray = null;
var splitter_h = null;
var ghostSplitter = null;
var glassPane = null;
var minCloseHeight = 15;
var minHeight = 38;
var me = null;
function setGhost() {
var dims = footerTray.getDimensions();
var rect = splitter_h.getClientRects();
ghostSplitter.setStyle('width:' + dims.width + 'px;left:' + rect.left + 'px;display:block;');
}
function hideGhost() {
ghostSplitter.setStyle('display:none;top:-100px;');
glassPane.setStyle('display:none;width:0px;height:0px;');
}
function mouseMoveHandler(e) {
if (isDragSplitter !== true) return;
var mouseY = e.pageY || e.clientY + document.documentElement.scrollTop - 3;
var size = glassPane.getDimensions().height - mouseY;
if (size >= minCloseHeight)
ghostSplitter.setStyle('top:' + mouseY + 'px');
}
function mouseDownHandler(e) {
if (e.element().id == 'debugToolsSplitterH') {
Event.stop(e);
footerTray = $('footerTray');
splitter_h = $('debugToolsSplitterH');
ghostSplitter = $('ghostSplitter');
glassPane = $('glassPane');
if (glassPane == null) {
var div = document.createElement('div');
div.id = 'glassPane';
div.className = 'glass-pane';
document.body.appendChild(div);
glassPane = $('glassPane');
} else {
glassPane.setStyle('display:block;height:100%;width:100%;');
}
glassPane.observe('mouseup', me.endDragHandler);
glassPane.observe('mouseout', me.endDragHandler);
glassPane.observe('mousemove', me.mouseMoveHandler);
isDragSplitter = true;
setGhost();
me.mouseMoveHandler(e);
}
}
function endDragHandler(e) {
if (isDragSplitter === true) {
isDragSplitter = false;
var mouseY = e.pageY || e.clientY + document.documentElement.scrollTop;
mouseY = glassPane.getDimensions().height - mouseY;
if (mouseY < minCloseHeight) {
debuggerTools.toggleJSDebugger();
} else {
mouseY = (mouseY < minHeight) ? minHeight : mouseY + 5;
footerTray.setStyle('height:' + mouseY + 'px');
footerTray.restoreHeight = mouseY;
}
hideGhost();
}
if (glassPane) {
glassPane.stopObserving('mouseup', me.endDragHandler);
glassPane.stopObserving('mouseout', me.endDragHandler);
glassPane.stopObserving('mousemove', me.mouseMoveHandler);
}
footerTray = null;
splitter_h = null;
ghostSplitter = null;
glassPane = null;
}
return {
init: function() {
me = this;
},
mouseDownHandler: mouseDownHandler,
endDragHandler: endDragHandler,
mouseMoveHandler: mouseMoveHandler
};
}();
addLoadEvent(initCache);
CustomEvent.observe('user.login', onLogin);
CustomEvent.observe('navigator.refresh', gsftReloadNav);
CustomEvent.observe('showFieldWatcher', debuggerTools.showFieldWatcher);
CustomEvent.observe('glide.product.description', function(value) {
gel('nav_header_text').innerHTML = value;
});
CustomEvent.observe('css.base.color', function(value) {
$j('tr.nav_header_stripe').css("background-color", value);
$j('button.nav_header_button').css("background-color", value);
$j('button.navpage_header_control_button').css("background-color", value);
});
CustomEvent.observe('glide.product.name', function(value) {
document.title = value;
});
CustomEvent.observe('glide.product.image', function(value) {
var img = gel('mainBannerImage');
img.src = value;
});
CustomEvent.observe('css.banner.description.color', function(value) {
$j('#nav_header_text').css("color", value);
});
;
