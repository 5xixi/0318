/*! RESOURCE: /scripts/js_includes_catalog.js */
/*! RESOURCE: /scripts/classes/ServiceCatalogForm.js */
function getSCFormElement(tableName, fieldName, type, mandatory, reference, attributes) {
if (typeof g_sc_form != 'undefined') {
var elem = g_sc_form.getGlideUIElement(fieldName);
if (typeof elem != 'undefined')
return elem;
}
return new GlideUIElement(tableName, fieldName, type, mandatory, reference, attributes);
}
var ServiceCatalogForm = Class.create(GlideForm, {
initialize: function (tableName, mandatory, checkMandatory, checkNumeric, checkInteger) {
GlideForm.prototype.initialize.call(this, tableName, mandatory, checkMandatory, checkNumeric, checkInteger);
this.onCatalogSubmit = new Array();
},
addOption: function (fieldName, choiceValue, choiceLabel, choiceIndex) {
var realName = this.resolveNameMap(fieldName);
var control = this.getControl(this.removeCurrentPrefix(realName));
if (!control)
return;
if (!control.options)
return;
var opts = control.options;
for (var i = 0; i < opts.length; i++)
if (opts[i].value == choiceValue) {
control.remove(i);
break;
}
var len = control.options.length;
if (choiceIndex == undefined || choiceIndex < 0 || choiceIndex > len)
choiceIndex = len;
var newOption = new Option(choiceLabel, choiceValue);
var value = choiceValue;
if (len > 0) {
value = this.getValue(fieldName);
control.options[len] = new Option('', '');
for (var i = len; i > choiceIndex; i--) {
control.options[i].text = control.options[i - 1].text;
control.options[i].value = control.options[i - 1].value;
}
}
control.options[choiceIndex] = newOption;
var original = gel('sys_original.' + control.id);
if (original) {
if (original.value == choiceValue)
this.setValue(fieldName, original.value);
} else
this.setValue(fieldName, value);
},
fieldChanged: function(variableName, changeFlag) {
if (g_form && g_form !== this)
g_form.fieldChanged(variableName, changeFlag);
this.modified = true;
},
getMissingFields : function(answer) {
var self = this;
answer = answer || [];
var glideUIElements = this.elements;
for (var i = 0; i < glideUIElements.length; i++) {
var fieldName = glideUIElements[i].fieldName;
var glideUIElement = glideUIElements[i];
if (fieldName && answer.indexOf(fieldName) == -1)
if (glideUIElement.mandatory && self.getControl(fieldName) && self._isMandatoryFieldEmpty(glideUIElement))
answer.push(fieldName);
}
return answer;
},
_setCatalogCheckBoxDisplay : function (id, d) {
var id = this.resolveNameMap(id);
var nidot = gel('ni.' + id);
if (!nidot)
return false;
var iotable = nidot.parentNode;
while(!hasClassName(iotable, "io_table"))
iotable = iotable.parentNode;
if(hasClassName(iotable, "io_table")) {
if(d != "none") {
iotable.style.display = d;
nidot.parentNode.style.display = d;
this._setCatalogSpacerDisplay(iotable, d);
} else {
var hideParent = true;
var inputs = iotable.getElementsByTagName('input');
for(var h=0;h<inputs.length;h++) {
if(inputs[h].id.indexOf('ni.') == 0 &&
inputs[h].type != 'hidden' &&
inputs[h].parentNode.style.display != "none" &&
inputs[h].id != nidot.id) {
hideParent = false;
}
}
if(hideParent) {
iotable.style.display = d;
this._setCatalogSpacerDisplay(iotable, d);
}
nidot.parentNode.style.display = d;
}
}
return true;
},
_setCatalogSpacerDisplay : function (table, d) {
var spacer = table.parentNode.parentNode.previousSibling;
if(spacer && spacer.id && spacer.id.startsWith('spacer_IO'))
spacer.style.display = d;
},
setCatalogDisplay: function(id, d) {
var id = this.resolveNameMap(id);
if (this._setCatalogCheckBoxDisplay(id, d))
return;
var label = gel('label_' + id);
if (label) {
if (hasClassName(label, 'io_label_container'))
label.style.display = d;
else
label.parentNode.parentNode.style.display = d;
this._setCatalogSpacerDisplay(label.parentNode.parentNode, d);
}
var readonlyRow = gel(id + '_read_only');
if (readonlyRow)
readonlyRow.style.display = d;
},
setCatalogVisibility: function(id, d) {
var id = this.resolveNameMap(id);
var label = gel('label_' + id);
if (label)
label.parentNode.parentNode.style.visibility = d;
var help = gel('help_' + id + '_wrapper');
if (help)
help.style.visibility = d;
var spacer = gel('spacer_' + id);
if (spacer) {
spacer.style.visibility = d;
}
},
removeCurrentPrefix: function(id) {
return this.removeVariablesPrefix(GlideForm.prototype.removeCurrentPrefix.call(this, id));
},
removeVariablesPrefix: function(id) {
var VARIABLES_PREFIX = "variables.";
if (id.startsWith(VARIABLES_PREFIX))
id = id.substring(VARIABLES_PREFIX.length);
return id;
},
_cleanupName : function(fieldName) {
fieldName = this.removeCurrentPrefix(fieldName);
fieldName = this.resolveNameMap(fieldName);
fieldName = fieldName.split(':');
if (fieldName.length != 2)
return fieldName[0];
fieldName = fieldName[1];
return fieldName;
},
setContainerDisplay : function(fieldName, display) {
fieldName = this._cleanupName(fieldName);
if (!fieldName)
return false;
var container = gel('container_'+fieldName);
if (!container) {
var containerVariable = gel(fieldName);
if (!containerVariable)
return false;
fieldName = containerVariable.getAttribute('container_id');
if (!fieldName)
return false;
container = gel('container_' + fieldName);
if (!container)
return false;
}
var d = 'none';
if (display == 'true' || display == true)
d = '';
container.style.display = d;
_frameChanged();
return true;
},
setContainerVisibility : function(fieldName, visibility) {
fieldName = this._cleanupName(fieldName);
if (!fieldName)
return false;
var container = gel('container_'+fieldName);
if (!container) {
var containerVariable = gel(fieldName);
if (!containerVariable)
return false;
fieldName = containerVariable.getAttribute('container_id');
if (!fieldName)
return false;
container = gel('container_' + fieldName);
if (!container)
return false;
}
var v = 'hidden';
if (visibility == 'true')
visibility = true;
if (visibility)
v = 'visible';
container.style.visibility = v;
return true;
},
hideSection : function(fieldName) {
this.hideReveal(fieldName, false);
},
revealSection : function(fieldName) {
this.hideReveal(fieldName, true);
},
hideReveal : function(fieldName, expand) {
fieldName = this._cleanupName(fieldName);
if (!fieldName)
return false;
var row = gel('row_'+fieldName);
if (!row)
return false;
if (expand && row.style.display=='none')
toggle = true;
else if (!expand && row.style.display != 'none')
toggle = true;
if (toggle)
toggleVariableSet(fieldName);
},
setDisplay: function(id, display) {
if (this.setContainerDisplay(id, display))
return;
id = this.removeCurrentPrefix(id);
var s = this.tableName + '.' + id;
var fieldName = id;
var control = this.getControl(fieldName);
if (!control)
return;
if (display == 'true')
display = true;
var fieldValue = this.getValue(fieldName);
if ((display != true) && this.isMandatory(fieldName) && (fieldValue == null || fieldValue.blank()))
return;
var d = 'none';
var parentClass = '';
if (display) {
d = '';
parentClass = 'label';
}
this.setCatalogDisplay(id, d);
_frameChanged();
return;
},
setVisible: function(id, visibility) {
if (this.setContainerVisibility(id, visibility))
return;
id = this.removeCurrentPrefix(id);
var s = this.tableName + '.' + id;
var fieldName = id;
var control = this.getControl(fieldName);
if (!control)
return;
var v = 'hidden';
var parentClass = '';
if (visibility == 'true')
visibility = true;
if (visibility) {
v = 'visible';
parentClass = 'label';
}
this.setCatalogVisibility(id, v);
return;
},
setMandatory: function (fieldName, mandatory) {
fieldName = this.removeCurrentPrefix(fieldName);
fieldName = this.resolveNameMap(fieldName);
var foundIt = this._setMandatory(this.elements, fieldName, mandatory);
if (foundIt==false && g_form != null && window.g_sc_form && g_form != g_sc_form) {
this._setMandatory(g_form.elements, fieldName, mandatory);
}
},
debounceMandatoryChanged: function(){
var that = this;
if (this.debounceMandatoryChangedTimeout){
clearTimeout(this.debounceMandatoryChangedTimeout);
}
this.debounceMandatoryChangedTimeout = setTimeout(function(){
that.debounceMandatoryChangedTimeout = null;
CustomEvent.fire("mandatory.changed");
}, 300);
},
_setMandatory: function (elements, fieldName, mandatory) {
var foundIt = false;
for (var x=0; x< elements.length; x++) {
var thisElement = elements[x];
var thisField = thisElement.fieldName;
if (thisField == fieldName) {
foundIt = true;
thisElement.mandatory = mandatory;
var curField = $('status.' + fieldName);
if (curField)
curField.setAttribute("mandatory", mandatory);
var className = '';
var classTitle = '';
var realName = this.resolveNameMap(fieldName);
var original = gel('sys_original.' + realName);
var oValue = 'unknown';
if (original)
oValue = original.value;
var nValue = this.getValue(fieldName, mandatory);
if (mandatory && oValue != nValue) {
className = "changed required-marker";
classTitle = "Field value has changed"
} else if (mandatory && !this.getValue(fieldName, mandatory).blank()) {
className = "mandatory_populated required-marker";
classTitle = 'Mandatory - preloaded with saved data';
} else if (mandatory) {
className = 'mandatory required-marker';
classTitle = 'Mandatory - must be populated before Submit';
}
var niElem = $("ni."+fieldName);
if (niElem && niElem.type == "checkbox")
this.changeCatLabel($(fieldName).getAttribute("gsftContainer"), className + ' label_description', classTitle);
else
this.changeCatLabel(fieldName, className + ' label_description', classTitle);
this.debounceMandatoryChanged();
setMandatoryExplained();
}
}
return foundIt;
},
changeCatLabel: function (fieldName, className, classTitle) {
var d = $('status.' + fieldName);
if (d) {
if (d.className == 'changed') {
d.setAttribute("oclass", className);
} else {
d.setAttribute("oclass", '');
d.className = className;
}
if (typeof classTitle != 'undefined')
d.setAttribute('title', classTitle);
var s = $('section508.' + fieldName);
if (s && typeof classTitle != 'undefined') {
s.setAttribute('title', classTitle);
s.setAttribute('alt', classTitle);
}
var fieldClassName = '';
var mandatory = false;
if (className == 'changed required-marker label_description') {
fieldClassName = 'is-filled';
mandatory = true;
}
else if (className == 'mandatory required-marker label_description') {
fieldClassName = 'is-required';
mandatory = true;
} else if (className == 'mandatory_populated required-marker label_description') {
fieldClassName = 'is-prefilled';
mandatory = true;
}
d.setAttribute('mandatory', mandatory + '');
var container = d.up('.question_spacer');
if (!container)
container = d.up('tr');
container.removeClassName('is-prefilled');
container.removeClassName('is-required')
container.removeClassName('is-filled');
if (fieldClassName) {
container.addClassName(fieldClassName);
}
}
},
getCatLabel : function (fieldName) {
var realName = this.resolveNameMap(fieldName);
var label = $('status.' + realName);
if (label)
return label;
return label;
},
notifyCatLabelChange: function (fieldName) {
var mandatory = false;
var nValue = this.getValue(fieldName);
var fType = this.getControl(fieldName).className;
var realName = this.resolveNameMap(fieldName);
var original = gel('sys_original.' + realName);
var oValue = 'unknown';
if (original)
oValue = original.value;
var newClass = 'changed';
var newFieldClassName = '';
var oldClass = '';
var sl = this.getCatLabel(fieldName);
if (!sl) {
var control = this.getControl(fieldName);
if (!control)
return;
var container = control.getAttribute("gsftContainer");
if (container)
sl = $('status.' + container);
}
if (!sl)
return;
if (sl.getAttribute('mandatory') == 'true')
mandatory = true;
oldClass = sl.className;
if (mandatory && nValue.blank()) {
newClass = 'mandatory';
newFieldClassName = 'is-required';
} else if (mandatory && fType.indexOf("cat_item_option") != -1 && nValue == "") {
newClass = 'mandatory';
newFieldClassName = 'is-required';
} else if (mandatory && fType.indexOf("cat_item_option") != -1 && nValue != "") {
if (nValue != oValue) {
newClass = 'changed';
newFieldClassName = 'is-filled';
} else {
newClass = 'mandatory_populated';
newFieldClassName = 'is-prefilled';
}
}
else if (oValue == nValue)
newClass = sl.getAttribute("oclass");
sl.className = newClass + " required-marker label_description";
if (newFieldClassName) {
var elementContainer = sl.up('.question_spacer');
if (!elementContainer)
elementContainer = sl.up('tr');
elementContainer.removeClassName('is-prefilled');
elementContainer.removeClassName('is-required')
elementContainer.removeClassName('is-filled');
elementContainer.addClassName(newFieldClassName);
}
if (oldClass != newClass)
sl.setAttribute("oclass", oldClass);
this.debounceMandatoryChanged();
},
onSubmit: function () {
var action = this.getActionName();
if (action == 'sysverb_back' || action == 'sysverb_cancel' || action == 'sysverb_delete')
return true;
var rc = this.mandatoryCheck();
rc = rc && this.validate();
return rc;
},
flashTab: function(pNode, flash) {
if (flash) {
var touchScroll = $$("div.touch_scroll");
if (touchScroll.size() > 0) {
} else
scrollTo(0,0);
var interval;
var count = 0;
var flip = false;
interval = setInterval(function(){
if (count > 4) {
clearInterval(interval);
} else {
if (flip)
pNode.style.background = "#FFFACD";
else
pNode.style.background = "";
count++;
flip = !flip;
}
}, 500);
}
},
firstRunComplete: false,
completeTabs: "",
incompleteTabs: "",
removeTab: function(tabs, id) {
var newTabs = '';
var parts = tabs.split(",");
for (var i = 0; i < parts.length; i++)
if (parts[i] != id) {
if (newTabs.length > 0)
newTabs += ',';
newTabs += parts[i];
}
return newTabs;
},
addCompleteTab: function(id) {
if (this.completeTabs.indexOf(id) < 0) {
if (this.completeTabs.length > 0)
this.completeTabs += ",";
this.completeTabs += id;
}
this.incompleteTabs = this.removeTab(this.incompleteTabs, id);
},
addIncompleteTab: function(id) {
if (this.incompleteTabs.indexOf(id) < 0) {
if (this.incompleteTabs.length > 0)
this.incompleteTabs += ',';
this.incompleteTabs += id;
}
this.completeTabs = this.removeTab(this.completeTabs, id);
},
getCompleteTabs: function() {
return this.completeTabs || '';
},
getIncompleteTabs: function() {
return this.incompleteTabs || '';
},
setCompleteTabs: function(val) {
this.completeTabs = val || '';
},
setIncompleteTabs: function(val) {
this.incompleteTabs = val || '';
},
checkTabForms: function(flash) {
var rc = true;
if (typeof tab_frames != "undefined") {
for (var i = 0; i < tab_frames.length; i++) {
var fr = tab_frames[i];
var tabElem = $("tab_ref_"+fr);
var pNode = tabElem.parentNode;
var result = false;
if (this.completeTabs.indexOf(fr) > -1)
result = true;
else if (this.incompleteTabs.indexOf(fr) > -1)
result = false;
else {
var frame = $("item_frame_" + fr);
if (frame) {
var form = frame.contentWindow.g_form;
result = form.mandatoryCheck(true, false);
}
}
if (result) {
this.addCompleteTab(fr);
tabElem.removeClassName("mandatory");
tabElem.addClassName("not_mandatory");
} else {
this.addIncompleteTab(fr);
tabElem.addClassName("mandatory");
tabElem.removeClassName("not_mandatory");
rc = false;
this.flashTab(pNode, flash);
}
}
if (rc == false && this.firstRunComplete) {
var touchScroll = $$("div.touch_scroll");
if (touchScroll.size() > 0)
alert(getMessage('There are tabs containing mandatory fields that are not filled in'));
}
this.firstRunComplete = true;
}
return rc;
},
mandatoryCheck : function(isHiddenForm, checkFrames) {
if (!this.checkMandatory)
return true;
$(document.body).addClassName('form-submitted');
var fa = this.elements;
var rc = true;
var fc = true;
var ic = true;
if (checkFrames)
fc = this.checkTabForms(true);
var incompleteFields = new Array();
var invalidFields = new Array();
var labels = new Array();
for (var x =0; x< fa.length; x++) {
var ed = fa[x];
if (ed.type == "masked") {
var display = $('sys_display.' + ed.fieldName);
var displayConfirm = $('sys_display_confirm.' + ed.fieldName);
if (displayConfirm && display.value != displayConfirm.value) {
ic = false;
var widgetLabel = this.getLabelOf(ed.fieldName);
var shortLabel = trim(widgetLabel + '');
incompleteFields.push(shortLabel);
continue;
}
}
if (!ed.mandatory)
continue;
var widget = this.getControl(ed.fieldName);
if (!widget)
continue;
var widgetValue = this.getValue(ed.fieldName);
if (widgetValue == null || widgetValue.blank()) {
var rowWidget = gel('sys_row');
var row = 0;
if (rowWidget)
row = parseInt(rowWidget.value);
if (row != -1) {
if (this.mandatory == false) {
widgetName = "sys_original." + this.tableName + '.' + ed.fieldName;
widget = gel(widgetName);
if (widget) {
widgetValue = widget.value;
if (widgetValue == null || widgetValue.blank())
continue;
}
}
}
rc = false;
var tryLabel = false;
try {
if (!isHiddenForm)
widget.focus();
} catch (e) {
tryLabel = true;
}
if (tryLabel) {
var displayWidget = this.getDisplayBox(ed.fieldName);
if (displayWidget) {
try {
if (!isHiddenForm)
displayWidget.focus();
} catch (exception) {
}
}
}
var realName = this.resolveNameMap(ed.fieldName);
var widgetLabel = this.getLabelOf(ed.fieldName);
var shortLabel = trim(widgetLabel + '');
invalidFields.push(shortLabel);
labels.push('label_' + realName);
}
}
var alertText1 = "";
var alertText2 = "";
if (!rc && !isHiddenForm)
alertText1 = getMessage('The following mandatory fields are not filled in') + ': ' + invalidFields.join(', ');
if (!ic && !isHiddenForm)
alertText2 = getMessage('The following masked fields do not match') + ': ' + incompleteFields.join(', ');
if (alertText1 != "" || alertText2 != "") {
try {
alert(alertText1 + " " + alertText2);
} catch (e) {
}
}
if (!isHiddenForm) {
for (var x =0; x< labels.length; x++) {
this.flash(labels[x], "#FFFACD", 0);
}
}
return rc && fc && ic;
},
getControls : function(fieldName) {
var widgetName = this.resolveNameMap(fieldName);
return document.getElementsByName(widgetName);
},
getControl : function(fieldName) {
var widgetName = this.resolveNameMap(fieldName);
var possibles = document.getElementsByName(widgetName);
if (possibles.length == 1)
return possibles[0];
else {
var widget;
for (var x=0; x< possibles.length; x++) {
if (possibles[x].checked) {
widget = possibles[x];
break;
}
}
if (!widget)
widget = gel('sys_original.' + widgetName);
}
return widget;
},
getLabelOf : function(fieldName) {
var fieldId = this.tableName + '.' + fieldName;
fieldId = this.resolveNameMap(fieldName);
var label = gel('label_' + fieldId);
if (label) {
var text = '';
if (label.firstChild) {
if (label.firstChild.innerText)
text = label.firstChild.innerText;
else if (label.firstChild.textContent)
text = label.firstChild.textContent;
else if (label.firstChild.innerHTML)
text = label.firstChild.innerHTML;
else
text = '';
}
return text;
}
return null;
},
validate : function() {
var fa = this.elements;
var rc = true;
var invalid = new Array();
var labels = new Array();
for (var x =0; x< fa.length; x++) {
var ed = fa[x];
var widgetName = this.tableName + '.' + ed.fieldName;
var widget = this.getControl(ed.fieldName);
if (widget) {
var widgetValue = widget.value;
var validator = this.validators[ed.type];
if (validator) {
var isValid = validator.call(this, widgetValue);
if (!isValid) {
var widgetLabel = this.getLabelOf(ed.fieldName);
invalid.push(widgetLabel);
labels.push(widgetName);
rc = false;
}
}
}
}
var theText = invalid.join(', ');
theText = getMessage('The following fields contain invalid text') + ': ' + theText;
if (!rc)
alert(theText);
for (var x =0; x< labels.length; x++) {
this.flash(labels[x], "#FFFACD", 0);
}
return rc;
},
setValue : function(fieldName, value, displayValue) {
fieldName = this.removeCurrentPrefix(fieldName);
var control = this.getControl(fieldName);
this.secretSetValue(fieldName, value, displayValue);
if	(control != null) {
triggerEvent(control, 'change');
var id = control.getAttribute("id");
if (id != null) {
var niBox = this.getNiBox(id);
if (niBox != null && niBox.getAttribute("type") == "checkbox") {
variableOnChange(id);
return;
}
if (niBox.className != null && niBox.className.indexOf('htmlField') != -1) {
this._setValue(fieldName, value, displayValue);
return;
}
}
if (control.getAttribute("type") == "radio")
if (control.onclick)
control.onclick.call();
}
},
getNiBox : function(fieldName) {
var niName = 'ni.' + this.tableName + '.' + fieldName;
var id = this.resolveNameMap(fieldName);
if (id)
niName = 'ni.' + id;
var niBox = gel(niName);
if (niBox == null)
niBox = gel(id);
return niBox;
},
getDisplayBox : function(fieldName) {
var dName = 'sys_display.' + this.tableName + '.' + fieldName;
var id = this.resolveNameMap(fieldName);
if (id)
dName = 'sys_display.' + id;
var field = gel(dName);
if (field)
return field;
dName = 'sys_display.' + fieldName;
return gel(dName);
},
secretSetValue : function(fieldName, value, displayValue) {
if (this.catalogSetValue(fieldName, value, displayValue))
return;
fieldName = this.removeCurrentPrefix(fieldName);
var control = this.getControl(fieldName);
var readOnlyField = gel('sys_readonly.' + control.id);
if (readOnlyField) {
readOnlyField.innerHTML = displayValue;
} else {
readOnlyField = gel(control.id + "_label");
if (readOnlyField) {
readOnlyField.value = displayValue;
}
}
if (control.options) {
var options = control.options;
for (var i = 0; i < options.length; i++) {
var option = options[i];
if (option.value == value) {
control.selectedIndex = i;
break;
}
}
} else if (control.type == 'hidden') {
var nibox = this.getNiBox(fieldName);
if (nibox && nibox.type == 'checkbox') {
control.value = value;
if (value == 'true')
nibox.checked = 'true';
else
nibox.checked = null;
return;
}
var displaybox = this.getDisplayBox(fieldName);
if (displaybox) {
if (typeof(displayValue) != 'undefined') {
if (displayValue != '')
control.value = value;
displaybox.value = displayValue;
refFlipImage(displaybox, control.id);
updateRelatedGivenNameAndValue(this.tableName + '.' + fieldName, value);
return;
}
control.value = value;
if (value == null || value == '') {
displaybox.value = '';
refFlipImage(displaybox, control.id);
return;
}
var ed = this.getGlideUIElement(fieldName);
if (!ed)
return;
if (ed.type != 'reference')
return;
var refTable = ed.reference;
if (!refTable)
return;
var ga = new GlideAjax('AjaxClientHelper');
ga.addParam('sysparm_name','getDisplay');
ga.addParam('sysparm_table',refTable);
ga.addParam('sysparm_value',value);
ga.getXMLWait();
var displayValue=ga.getAnswer();
displaybox.value = displayValue;
refFlipImage(displaybox, control.id);
updateRelatedGivenNameAndValue(this.tableName + '.' + fieldName, value);
}
} else {
control.value = value;
}
},
catalogSetValue : function (fieldName, value, displayValue) {
var widgetName = this.resolveNameMap(fieldName);
var possibles = document.getElementsByName(widgetName);
if (possibles.length == 1)
return false;
for (var x=0; x< possibles.length; x++) {
if (possibles[x].value == value) {
possibles[x].checked = true;
} else
possibles[x].checked = false;
}
return true;
},
getGlideUIElement: function (fieldName) {
fieldName = this.removeCurrentPrefix(fieldName);
fieldName = this.resolveNameMap(fieldName);
for (var x = 0; x < this.elements.length; x++) {
var thisElement = this.elements[x];
if (thisElement.fieldName == fieldName)
return thisElement;
}
},
getReference: function(fieldName, callback) {
fieldName = this.removeCurrentPrefix(fieldName);
fieldName = this.resolveNameMap(fieldName);
var ed = this.getGlideUIElement(fieldName);
if (!ed)
return;
if (ed.type != 'reference')
return;
var value = this.getValue(fieldName);
if (!value)
return;
var gr = new GlideRecord(ed.reference);
gr.addQuery('sys_id', value);
if (callback) {
var fn = function(gr) {gr.next(); callback(gr)};
gr.query(fn);
return;
}
gr.query();
gr.next();
return gr;
},
hasPricingImplications : function(fieldName) {
var realName = this.resolveNameMap(fieldName);
var ed = this.getGlideUIElement(realName);
if (ed && ed.attributes == 'priceCheck') {
return true;
}
return false;
},
submit : function() {
var theText = getMessage('The g_form.submit function has no meaning on a catlog item. Perhaps you mean g_form.addToCart() or g_form.orderNow() instead');
alert(theText);
return;
},
flash : function (widgetName, color, count) {
var row = null;
var labels = new Array();
var widget = gel(widgetName);
widget = widget.firstChild;
labels.push(widget);
count = count +1;
for (var x =0; x< labels.length; x++) {
var widget = labels[x];
if (widget) {
var originalColor = widget.style.backgroundColor;
widget.style.backgroundColor = color;
}
}
if (count < 4)
setTimeout('g_form.flash("' + widgetName + '", "' + originalColor + '", ' + count + ')', 500);
},
serialize: function (filterFunc) {
if (typeof(g_cart) == 'undefined')
g_cart = new SCCart();
var cart = g_cart;
var item = gel('sysparm_id');
if (!item)
item = gel('current_item');
if (item)
item = item.value;
else
item = 'none';
var url = cart.generatePostString() + "&sysparm_id=" + encodeURIComponent(item);
return url;
},
serializeChanged: function() {
return this.serialize();
},
addToCart : function() {
if (typeof(addToCart) == 'function')
addToCart();
else {
var theText = getMessage('The add to cart function is usable only on catalog item forms');
alert(theText);
}
},
orderNow : function() {
if (typeof(orderNow) == 'function')
orderNow();
else {
var theText = getMessage('The order now function is usable only on catalog item forms');
alert(theText);
}
},
addCatalogSubmit : function(handler) {
this.onCatalogSubmit.push(handler);
},
callCatalogSubmitHandlers : function() {
for (var x=0; x< this.onCatalogSubmit.length; x++) {
var handler = this.onCatalogSubmit[x];
var rc = handler.call(this);
if (rc == false)
return false;
}
return true;
},
catalogOnSubmit: function(ignoreFrames) {
var rc = this.mandatoryCheck(false, !ignoreFrames);
rc = rc && this.callCatalogSubmitHandlers();
return rc;
},
isRadioControl : function(fieldName) {
var radios = document.getElementsByName(fieldName);
if (radios && radios[0]) {
var radio = $(radios[0]);
if (radio && radio.readAttribute('type') && radio.readAttribute('type') === 'radio')
return true;
}
return false;
},
getRadioControlCheckedValue : function(fieldName) {
var radios = document.getElementsByName(fieldName)
var val = '';
if (radios.length > 0)
for (var i = 0; i < radios.length; i++) {
if (radios[i].checked)
val = radios[i].value;
}
return val;
},
getValue: function(fieldName) {
if (this.isRadioControl(fieldName)) {
return this.getRadioControlCheckedValue(fieldName);
} else {
fieldName = this.removeCurrentPrefix(fieldName);
var control = this.getControl(fieldName);
if (!control)
return '';
return GlideForm.prototype._getValueFromControl.call(this, control);
}
},
_setReadonly: function(fieldName, disabled, isMandatory, fieldValue) {
fieldName = this.removeCurrentPrefix(fieldName);
var control = this.getControl(fieldName);
if (!control)
return;
var s = this.tableName + '.' + fieldName;
var ge = this.getGlideUIElement(fieldName);
if (typeof ge == "undefined" && this._formExists()) {
var mapName = this.resolveNameMap(fieldName);
for (var x=0; x< g_form.elements.length; x++) {
var thisElement = g_form.elements[x];
var thisField = thisElement.fieldName;
if (thisField == mapName) {
ge = thisElement;
s = mapName;
}
}
}
var lookup = gel('lookup.' + control.id);
if (lookup)
s = control.id;
if (ge) {
if (ge.type == "masked") {
s = control.id;
var confirmRow = $('sys_display.' + s + '.confirm_row');
if (confirmRow) {
if (disabled && (!isMandatory || fieldValue != ''))
this._hideIfPresent(confirmRow);
else
this._showIfPresent(confirmRow);
}
}
if (ge.type == 'reference') {
if (lookup && disabled && (!isMandatory || fieldValue != ''))
this._hideIfPresent(lookup);
else if (lookup && !disabled)
this._showIfPresent(lookup);
}
var possibles = this.getControls(fieldName);
if (possibles && possibles.length > 1 && possibles[0].type == "radio") {
for (var i = 0; i < possibles.length; i++)
GlideForm.prototype._setReadonly0.call(this, ge, possibles[i], s, fieldName, disabled, isMandatory, fieldValue);
} else
GlideForm.prototype._setReadonly0.call(this, ge, control, s, fieldName, disabled, isMandatory, fieldValue);
if (ge.type == "glide_date")
this._displayDateSelector(control,!disabled);
if (ge.type == "glide_date_time")
this._displayDateSelector(control,!disabled);
}
if (this._formExists()) {
var df = g_form.disabledFields.length;
g_form.disabledFields[df] = control;
}
this._processReadOnlySlush(control, fieldName, disabled);
},
_displayDateSelector: function(control, display) {
var selectId = "ni." + control.id + ".ui_policy_sensitive";
if ($(selectId)) {
if (display)
$(selectId).show();
else
$(selectId).hide();
}
},
_getAppliedFieldName: function(fieldName) {
for (var i = 0; i < this.nameMap.length; i++) {
if (this.nameMap[i].prettyName == fieldName)
return this.nameMap[i].realName;
else if (this.nameMap[i].realName == fieldName)
return this.nameMap[i].prettyName;
}
return fieldName;
},
_processReadOnlySlush: function(control, fieldName, disabled) {
if (control.getAttribute("slush") == "true") {
if (!$(fieldName + "_select_1"))
fieldName = this._getAppliedFieldName(fieldName);
var leftOptionList = fieldName + "_select_0";
var rightOptionList = fieldName + "_select_1";
var recordPreviewTable = fieldName + 'recordpreview';
var noFilter = control.getAttribute("nofilter");
if (disabled) {
this._unselectOptions(leftOptionList);
var selectedRightOption = this._selectedOption(rightOptionList);
if (selectedRightOption && typeof (selectedRightOption.value) != 'undefined'
&& selectedRightOption.value != null
&& selectedRightOption.value != ''
&& selectedRightOption.value != '--None--') {
showSelected(
gel(rightOptionList),
recordPreviewTable,
this._retrieveTableName(fieldName));
}
else {
this._hideIfPresent(recordPreviewTable);
}
$(rightOptionList).ondblclickOLD = $(rightOptionList).ondblclick;
$(rightOptionList).ondblclick = "";
this._hideIfPresent(leftOptionList);
this._hideIfPresent(leftOptionList + "_title_row");
this._hideIfPresent(leftOptionList + "_filter_row");
this._hideIfPresent(leftOptionList + "_filters_row");
this._hideIfPresent(leftOptionList + "_search_row");
this._hideIfPresent(rightOptionList + "_search_row");
this._hideIfPresent(leftOptionList + "_add_remove_container");
this._hideIfPresent(leftOptionList + "_add_remove_message_table");
} else {
if ($(fieldName + "_select_1").ondblclickOLD)
$(fieldName + "_select_1").ondblclick = $(fieldName + "_select_1").ondblclickOLD;
this._showIfPresent(recordPreviewTable);
this._showIfPresent(leftOptionList);
this._showIfPresent(leftOptionList + "_title_row");
if (noFilter != "true") {
this._showIfPresent(leftOptionList + "_filter_row");
this._showIfPresent(leftOptionList + "_filters_row");
}
this._showIfPresent(leftOptionList + "_search_row");
this._showIfPresent(rightOptionList + "_search_row");
this._showIfPresent(leftOptionList +"_add_remove_container");
this._showIfPresent(leftOptionList +"_add_remove_message_table");
}
}
},
_retrieveTableName : function(fieldName) {
var relatedTableNameFunction = fieldName
+ '_getMTOMRelatedTable();';
var relatedTableNameDotFieldName = eval(relatedTableNameFunction);
var tableName = relatedTableNameDotFieldName.split('.')[0];
return tableName;
},
_selectedOption : function(optionsArray) {
var selectedOption;
var selectedOptionIndex = gel(optionsArray).selectedIndex;
var cssOptionsSelector = '#' + optionsArray + ' option';
if ( selectedOptionIndex == -1 && $$(cssOptionsSelector)[0]) {
selectedOption = $$(cssOptionsSelector)[0];
selectedOption.selected = true;
gel(optionsArray).selectedIndex = 0;
} else {
selectedOption = $$(cssOptionsSelector)[selectedOptionIndex];
}
return selectedOption;
},
_unselectOptions : function(optionsArray) {
var cssOptionsSelector = '#' + optionsArray + ' option';
var optionsArray = $$(cssOptionsSelector).each(function(ele, i) {
return $(ele).selected = false;
});
gel(optionsArray).selectedIndex = -1;
},
_hideIfPresent: function(elemID) {
var elem = $(elemID);
if (elem)
Element.hide(elem);
},
_showIfPresent: function(elemID) {
var elem = $(elemID);
if (elem)
Element.show(elem);
},
_formExists: function() {
if (typeof g_form == 'undefined')
return false;
if (typeof g_sc_form == 'undefined')
return false;
return g_form != g_sc_form;
}
});
;
/*! RESOURCE: /scripts/classes/GwtTable.js */
var GwtTable = Class.create({
initialize: function(parent) {
this.type        = 'GwtTable';
this.name        = 'GwtTable';
this.dragger = null;
this.htmlElement = cel("TABLE");
this.body = cel("TBODY", this.htmlElement);
this.row = null;
if (parent)
parent.appendChild(this.htmlElement);
},
addRow: function() {
this.row = cel("TR", this.body);
for(var i = 0; i < arguments.length; i++) {
var t = arguments[i];
var td = cel("TD", this.row);
td.innerHTML = t;
}
},
addRowWithClassName: function() {
this.row = cel("TR", this.body);
for (var i = 1; i < arguments.length; i++) {
var t = arguments[i];
var td = cel("TD", this.row);
td.className = arguments[0];
td.innerHTML = t;
}
},
addTD: function(element) {
var td = cel("TD", this.row);
td.appendChild(element);
},
addCellsWithClassName: function() {
for(var i = 1; i < arguments.length; i++) {
var t = arguments[i];
var td = cel("TD", this.row);
td.className = arguments[0];
td.innerHTML = t;
}
},
setRowClassName: function(className) {
this.row.className = className;
},
addSpanCell: function() {
var td = cel("TD", this.row);
td.colSpan = arguments[0]
return td;
}
});
;
/*! RESOURCE: /scripts/sc_cart.js */
var SCCart = Class.create();
SCCart.prototype = {
initialize: function() {
this.htmlElement = null;
this.fAction = "service_catalog.do";
this.processor = "com.glideapp.servicecatalog.CartAjaxProcessor";
this.urlPrefix = "xmlhttp.do?sysparm_processor=" +
this.processor;
this.showCart = true;
this.enhanceLabels = false;
},
attachWindow: function(qtyName, cartName, windowTitle) {
var w = new GlideWindow('adder', true);
w.setClassName('sc_cart_window');
w.setPosition("relative");
w.setSize(200, 10);
w.setTitle(windowTitle);
var qty = gel(qtyName);
qty.style.display='';
w.setBody(qty);
w.insert(gel(cartName));
},
setCartVisible : function(showCart) {
this.showCart = showCart;
},
addCartContent: function() {
},
order: function(item, quantity, sc_cart_item_id, catalog_id, catalog_view) {
this._postAction(null, quantity,item, "order", sc_cart_item_id, catalog_id, catalog_view);
},
orderUpdate: function(cart_item, quantity) {
var item_id = gel("sysparm_id").value;
this._postAction(cart_item, quantity, item_id, "update_proceed");
},
add: function(item, quantity, itemId) {
var url = this.urlPrefix +
"&sysparm_action=" + "add" +
"&sysparm_id=" + item +
"&sysparm_quantity=" + quantity +
"&sysparm_item_guid=" + itemId;
var hint = gel('sysparm_processing_hint');
if (hint && hint.value)
url += "&sysparm_processing_hint=" + hint.value;
var postString = this.generatePostString();
serverRequestPost(url, postString, this._addResponse.bind(this));
},
_addResponse : function(response) {
CustomEvent.fire("catalog_cart_changed", response);
},
generatePostString : function() {
var postString = "";
var optionsElements = $(document.body).select(".cat_item_option");
postString = this.generatePostStringOptions(postString, optionsElements);
optionsElements = $(document.body).select(".questionSetWidget")
postString = this.generatePostStringOptions(postString, optionsElements);
return postString;
},
generatePostStringOptions : function(postString, optionsElements) {
var seq = 0;
for (i = 0; i < optionsElements.length; i++) {
var element = optionsElements[i];
var n = element.name;
jslog(n + " = " + element.value);
if ("variable_sequence" == n) {
seq++;
n = n + seq;
}
if (element.type == "radio" && element.checked)
postString += n + "=" + encodeURIComponent(element.value) + "&";
else if (element.type != "radio")
postString += n + "=" + encodeURIComponent(element.value) + "&";
}
return postString;
},
recalcPrice: function(item, quantity) {
price = new CatalogPricing(item, this);
price.refreshCart(quantity, this.enhanceLabels);
},
edit: function(cart_item, quantity) {
var item_id = $F("sysparm_id");
this._postAction(cart_item, quantity, item_id, "update");
},
addAttachment : function(item_sys_id, tableName, allowAttachment) {
saveAttachment(tableName, item_sys_id, allowAttachment);
},
showReferenceForm : function(inputName, tableName) {
if (!g_form.catalogOnSubmit())
return;
var quantity = 1;
var quan_widget = gel("quantity");
if (quan_widget)
quantity = quan_widget.value;
var item_id = $F("sysparm_id");
var ref_sys_id = gel(inputName).value;
var form = this.initForm();
addInput(form, "HIDDEN", "sysparm_table", tableName);
addInput(form, "HIDDEN", "sysparm_ref_lookup", ref_sys_id);
addInput(form, "HIDDEN", "sysparm_action", "show_reference");
addInput(form, "HIDDEN", "sysparm_quantity", quantity);
addInput(form, "HIDDEN", "sysparm_id", item_id);
var hint = gel('sysparm_processing_hint');
if (hint && hint.value)
addInput(form, "HIDDEN", "sysparm_processing_hint", hint.value);
this.addInputToForm(form);
form.submit();
},
_postAction: function(cart_item, quantity, item_id, action, sc_cart_item_id, catalog_id, catalog_view) {
var form = this.initForm();
addInput(form, "HIDDEN", "sysparm_action", action);
if (cart_item)
addInput(form, "HIDDEN", "sysparm_cart_id", cart_item);
addInput(form, "HIDDEN", "sysparm_quantity", quantity);
addInput(form, "HIDDEN", "sysparm_id", item_id);
addInput(form, "HIDDEN", "sysparm_catalog", catalog_id);
addInput(form, "HIDDEN", "sysparm_catalog_view", catalog_view);
var hint = gel('sysparm_processing_hint');
if (hint && hint.value)
addInput(form, "HIDDEN", "sysparm_processing_hint", hint.value);
if (sc_cart_item_id)
addInput(form, "HIDDEN", "sysparm_item_guid", sc_cart_item_id);
this.addInputToForm(form);
form.submit();
},
addInputToForm: function(form) {
jslog("addInputToForm");
var optionsElements = $(document.body).select(".cat_item_option:not(.ignore)");
var seq = 0;
for (i = 0; i < optionsElements.length; i++) {
var element = optionsElements[i];
var n = element.name;
if (n != null && n != "") {
if ("variable_sequence" == n) {
seq++;
n = n + seq;
}
if (element.type == "radio" && element.checked)
addInput(form, "HIDDEN", n, element.value);
else if (element.type != "radio")
addInput(form, "HIDDEN", n, element.value);
}
}
},
getWithBackButton: function() {
if (!this.showCart)
return;
var i = new CartItemList(this);
i.create();
i.get();
},
getWithoutBackButton : function() {
if (!this.showCart)
return;
var cartItemList = new CartItemList(this);
cartItemList.create();
cartItemList.backbutton = false;
cartItemList.get();
},
_changed : function() {
var args = new Object();
args['html'] = gel("cart").innerHTML;
args['window'] = window;
CustomEvent.fireTop('cart.loaded', args);
},
initForm: function() {
var form = addForm();
form.action = this.fAction;
form.name = this.fAction;
form.id = this.fAction;
form.method = "POST";
return form;
},
setContentElement: function (htmlElement) {
this.htmlElement = $(htmlElement);
}
};
;
/*! RESOURCE: /scripts/section.js */
function expandCollapseAllSections(expandFlag) {
var spans = document.getElementsByTagName('span');
for (var i = 0; i < spans.length; i++) {
if (spans[i].id.substr(0, 8) != "section.")
continue;
var id = spans[i].id.substring(8);
var state = collapsedState(id);
if (state == expandFlag)
toggleSectionDisplay(id);
}
CustomEvent.fire('toggle.sections', expandFlag);
}
function collapsedState(sectionName) {
var el = $(sectionName);
if (el)
return (el.style.display == "none");
}
function setCollapseAllIcons(action, sectionID) {
var exp = gel('img.' + sectionID + '_expandall');
var col = gel('img.' + sectionID + '_collapseall');
if (!exp || !col)
return;
if (action == "expand") {
exp.style.display = "none";
col.style.display = "inline";
return;
}
exp.style.display = "inline";
col.style.display = "none";
}
function toggleSectionDisplay(id,imagePrefix,sectionID) {
var collapsed = collapsedState(id);
setPreference("collapse.section." + id, !collapsed, null);
hideReveal(id, imagePrefix);
toggleDivDisplay(id + '_spacer');
if (collapsed) {
CustomEvent.fire("section.expanded", id);
setCollapseAllIcons("expand",sectionID);
}
}
;
/*! RESOURCE: /scripts/catalog.js */
var pagingTimerHandle = null;
function catIsDoctype() {
var isDoctype = document.documentElement.getAttribute('data-doctype') == 'true';
return isDoctype;
}
function clickItemLink(elem, event, id) {
var target = event.target || event.srcElement;
if (target.tagName && target.tagName.toLowerCase() == "a" && target.href)
return true;
if (elem != target && target.up("a.service_catalog"))
return true;
if (typeof $(target).up("#item_link_" + id) != "undefined")
return false;
var link = $("item_link_" + id);
var href = link.href;
var target = link.target;
if (target == "_blank")
window.open(href);
else
document.location.href = href;
Event.stop(event);
return false;
}
function clickItemBreadcrumbLink(event, openTop) {
var target = event.target || event.srcElement;
var href = $(target).href;
if (typeof href == "undefined" || !href) {
var anchor = $(target).up("a");
if (anchor)
href = anchor.href;
}
if (href) {
if (!openTop)
document.location.href = href;
else
top.location.href = href;
}
Event.stop(event);
return false;
}
function gotoRowBrowse(category, element, page, catalog, catalog_view){
if (gel(element.id + "_orig").value == element.value)
return;
if (pagingTimerHandle != null)
clearTimeout (pagingTimerHandle);
timerHandle = setTimeout("_gotoRowBrowse('"+category+"','"+element.value+"','"+page+"','"+catalog+"','"+catalog_view+"')",1000);
}
function _gotoRowBrowse(category, row, page, catalog, catalog_view){
if (page != null && page.length > 0)
document.location.href = page + ".do?sysparm_parent=" + category + "&sysparm_current_row=" + row + "&sysparm_catalog=" + catalog + "&sysparm_catalog_view=" + catalog_view;
else
document.location.href = "com.glideapp.servicecatalog_category_view.do?sysparm_parent=" + category + "&sysparm_current_row=" + row + "&sysparm_catalog=" + catalog + "&sysparm_catalog_view=" + catalog_view;
}
function gotoRowSearch(category, term, ck, element, page, catalog, catalog_view){
if (gel(element.id + "_orig").value == element.value)
return;
if (pagingTimerHandle != null)
clearTimeout (pagingTimerHandle);
timerHandle = setTimeout("_gotoRowSearch('"+category+"', '" + term + "', '" + ck + "', '" + element.value + "', '" + page + "','"+catalog+"','"+catalog_view+"')",1000);
}
function _gotoRowSearch(category, term, ck, row, page, catalog, catalog_view){
if (page != null && page.length > 0)
document.location.href = page + ".do?sysparm_search=" + term + "&sysparm_ck=" + ck + "&sysparm_parent=" + category + "&sysparm_current_row=" + row + "&sysparm_catalog=" + catalog+ "&sysparm_catalog_view=" + catalog_view;
else
document.location.href = "catalog_find.do?sysparm_search=" + term + "&sysparm_ck=" + ck + "&sysparm_parent=" + category + "&sysparm_current_row=" + row + "&sysparm_catalog=" + catalog+ "&sysparm_catalog_view=" + catalog_view;
}
function toggleDetail(elem, id, expandMsg, collapseMsg) {
if (elem) {
if (collapseMsg == elem.getAttribute("toggle_state")) {
elem.setAttribute("toggle_state", expandMsg);
elem.alt = expandMsg;
elem.src = "./images/filter_hide16.gifx";
} else {
elem.setAttribute("toggle_state", collapseMsg);
elem.alt = collapseMsg;
elem.src = "./images/filter_reveal16.gifx";
}
$("detail_"+id).toggle();
} else {
if ($('search_detail_'+id))
$('search_detail_'+id).toggle();
if ($('full_detail_'+id))
$('full_detail_'+id).toggle();
}
_frameChanged();
}
function processBreadCrumbOver(elem) {
if (typeof elem != "undefined" && typeof elem.nextSiblings == "function") {
elem.nextSiblings().each(function(elem) {
if (elem.tagName.toLowerCase() == 'a' || elem.tagName.toLowerCase() == 'span') {
elem.addClassName("caption_link_remove_catalog");
}
});
}
}
function processBreadCrumbOut(elem) {
if (typeof elem != "undefined" && typeof elem.nextSiblings == "function") {
elem.nextSiblings().each(function(elem) {
if (elem.tagName.toLowerCase() == 'a' || elem.tagName.toLowerCase() == 'span') {
elem.removeClassName("caption_link_remove_catalog");
}
});
}
}
function processChevronOver(elem) {
elem.nextSiblings().each(function(elem) {
if (elem.tagName.toLowerCase() == 'a') {
elem.addClassName("caption_link_remove_catalog");
}
});
}
function processChevronOut(elem) {
elem.nextSiblings().each(function(elem) {
if (elem.tagName.toLowerCase() == 'a') {
elem.removeClassName("caption_link_remove_catalog");
}
});
}
var oldLightWeightReferenceLink = null;
if (typeof lightWeightReferenceLink != "undefined")
oldLightWeightReferenceLink = lightWeightReferenceLink;
lightWeightReferenceLink = function(id, table) {
if (id.indexOf("IO:") == 0 || oldLightWeightReferenceLink == null)
return false;
else
return oldLightWeightReferenceLink(id, table);
}
function catalogTextSearch(e) {
if (e != null && e.keyCode != 13)
return;
var f = document.forms['search_form'];
if (!f['onsubmit'] || f.onsubmit())
f.submit();
}
function superLink(inputname) {
var superinput = gel(inputname);
var sys_id = superinput.value;
var url = "sys_user.do?sys_id=" + sys_id;
var frame = top.gsft_main;
if (!frame)
frame = top;
frame.location = url;
}
function saveCartAttachment(sys_id) {
saveAttachment("sc_cart", sys_id)
}
var checkoutSubmitted = false;
function checkout(control, form) {
if (checkoutSubmitted)
return;
checkoutSubmitted = true;
gsftSubmit(control, form, 'sysverb_insert');
}
var guideSubmitted = false;
function guideNext(item) {
if (guideSubmitted)
return;
guideSubmitted = true;
var m = g_form.catalogOnSubmit();
if (!m) {
guideSubmitted = false;
return;
}
var action = "init_guide";
var guide = gel('sysparm_guide').value;
if (guide != item)
action = 'next_guide';
guideSubmit(action, item) ;
}
function guideSubmit(action, item) {
var active = gel('sysparm_active').value;
var edit = gel('sysparm_cart_edit').value;
var guide = gel('sysparm_guide').value;
var catalog = gel('sysparm_catalog').value;
var catalog_view = gel('sysparm_catalog_view').value;
var hint = gel('sysparm_processing_hint').value;
hint = equalsHtmlToHex(hint);
var quantity = 1;
if (gel('quantity'))
quantity = gel('quantity').value;
var form = addForm();
form.action = "service_catalog.do";
form.name = "service_catalog.do";
form.id = "service_catalog.do";
form.method = "POST";
addInput(form, "HIDDEN", "sysparm_action", action);
addInput(form, "HIDDEN", "sysparm_id", item);
addInput(form, "HIDDEN", "sysparm_guide", guide);
addInput(form, "HIDDEN", "sysparm_active", active);
addInput(form, "HIDDEN", "sysparm_cart_edit", edit);
addInput(form, "HIDDEN", "sysparm_quantity", quantity);
addInput(form, "HIDDEN", "sysparm_processing_hint", hint);
addInput(form, "HIDDEN", "sysparm_catalog", catalog);
addInput(form, "HIDDEN", "sysparm_catalog_view", catalog_view);
addSequence(form);
if (typeof(g_cart) == 'undefined' || !g_cart)
g_cart = new SCCart();
g_cart.addInputToForm(form);
form.submit();
}
function equalsHtmlToHex(value) {
if (!value)
return;
value = value.replace('&#61;','%3d');
value = value.replace('=','%3d');
return value;
}
function addSequence(form) {
var s = gel('variable_sequence');
var seq = '';
if (s)
seq = s.value;
addInput(form, "HIDDEN", "variable_sequence1", seq);
}
function guidePrevious(item) {
var action = "previous_guide";
guideSubmit(action, item);
}
function contextCatalogHeader(e, sys_id) {
var name = "context_catalog_header";
menuTable = "VARIABLE_catalog_header";
menuField = "not_important";
rowSysId = sys_id;
if (getMenuByName(name)) {
var contextMenu = getMenuByName(name).context;
contextMenu.setProperty('sysparm_sys_id', sys_id);
contextMenu.display(e);
}
return false;
}
function saveAndNavigate(target) {
var m = g_form.catalogOnSubmit(true);
if (!m) {
return;
}
saveAndNavigateNoValidate(target);
}
function saveAndNavigateNoValidate(target, currentTab) {
var action = "nav_guide";
var active = gel('sysparm_active').value;
var edit = gel('sysparm_cart_edit').value;
var guide = gel('sysparm_guide').value;
var item = gel('current_item').value;
var quan = gel('quantity');
var catalog = gel('sysparm_catalog').value;
var catalog_view = gel('sysparm_catalog_view').value;
var hint = equalsHtmlToHex(gel('sysparm_processing_hint').value);
var form = addForm();
form.action = "service_catalog.do";
form.name = "service_catalog.do";
form.id = "service_catalog.do";
form.method = "POST";
var m = g_form.getMissingFields();
if (m && m.length > 0) {
var tabs = g_form.getCompleteTabs().split(",");
if (tabs && tabs.length > 0)
g_form.addIncompleteTab(currentTab);
}
addInput(form, "HIDDEN", "sysparm_complete_tabs", g_form.getCompleteTabs());
addInput(form, "HIDDEN", "sysparm_incomplete_tabs", g_form.getIncompleteTabs());
addInput(form, "HIDDEN", "sysparm_action", action);
addInput(form, "HIDDEN", "sysparm_target", target);
addInput(form, "HIDDEN", "sysparm_id", item);
addInput(form, "HIDDEN", "sysparm_guide", guide);
addInput(form, "HIDDEN", "sysparm_active", active);
addInput(form, "HIDDEN", "sysparm_cart_edit", edit);
addInput(form, "HIDDEN", "sysparm_processing_hint", hint);
addInput(form, "HIDDEN", "sysparm_catalog", catalog);
addInput(form, "HIDDEN", "sysparm_catalog_view", catalog_view);
if (quan)
addInput(form, "HIDDEN", "sysparm_quantity", quan.value);
addSequence(form);
if (typeof(g_cart) == 'undefined' || !g_cart)
g_cart = new SCCart();
g_cart.addInputToForm(form);
form.submit();
}
function saveCatAttachment(item_sys_id, tableName) {
if (typeof(g_cart) == 'undefined' || !g_cart)
g_cart = new SCCart();
g_cart.addAttachment(item_sys_id, tableName, true);
}
function variableOnChange(variableName) {
doCatOnChange(variableName);
var form = g_form;
if (window.g_sc_form)
form = g_sc_form;
var original = gel('sys_original.' + variableName);
if (original)
form.fieldChanged(variableName, original.value != form.getValue(variableName));
else
form.fieldChanged(variableName, true);
if (form.notifyCatLabelChange) {
form.notifyCatLabelChange(variableName);
if (form.hasPricingImplications(variableName)){
if(orderItemWidget && orderItemWidget.g_cart)
orderItemWidget.calcPrice();
else
calcPrice();
}
}
}
function doCatOnChange(variableName) {
var prettyName = resolvePrettyNameMap(variableName);
for (var x=0; x< g_event_handlers.length; x++) {
var handler = g_event_handlers[x];
var vName = handler.fieldName;
if (vName == variableName || vName == prettyName) {
var original = gel('sys_original.' + variableName);
var oValue = 'unknown';
if (original)
oValue = original.value;
var nValue = g_form.getValue(variableName);
var eChanged = g_form.getControl(variableName);
var realFunction = handler.handler;
realFunction.call(this, eChanged, oValue, nValue, false);
}
}
}
function resolvePrettyNameMap(variableName) {
var prettyName = variableName;
for (var i=0; i< g_form.nameMap.length; i++) {
var entry = g_form.nameMap[i];
if (variableName == "ni.VE" + entry.realName) {
prettyName = "variables." + entry.prettyName;
break;
}
}
return prettyName;
}
function toggleVariableSet(id) {
var img = gel('img_' + id);
if (!img)
return;
var src = img.src;
var display = '';
if (src.indexOf('reveal') > -1 ) {
img.src = "images/filter_hide.gifx";
img.at = getMessage('Expand');
display='none';
} else {
img.src = "images/filter_reveal.gifx";
img.alt = getMessage('Collapse');
}
var setRow = gel('row_' + id);
setRow.style.display = display;
_frameChanged();
}
function expandCollapseAllSets(expand) {
var rows = $(document.body).select('.variable_set_row');
for (var i =0; i < rows.length; i++) {
var row = rows[i];
var toggle = false;
if (expand && row.style.display=='none')
toggle = true;
else if (!expand && row.style.display != 'none')
toggle = true;
if (toggle)
toggleVariableSet(row.id.substring(4));
}
}
function orderStatusBack() {
var found = false;
$$('.ui_notification').each(function(elem) {
if (elem.readAttribute('data-attr-table') && history.length > 3) {
history.go(-3);
found = true;
}
});
if (!found)
history.go(-1);
}
;
/*! RESOURCE: /scripts/CatalogPricing.js */
var priceReceiveCounter = 0;
var priceSendCounter = 0;
var CatalogPricing = Class.create();
CatalogPricing.prototype = {
initialize: function(cat_item_id, cart) {
this.cat_item_id = cat_item_id;
this.xml = getXMLIsland('pricing_' + cat_item_id);
this.variables = [];
this._initPriceVars();
this.messenger = new GwtMessage();
this.labels = true;
this.cart = cart;
},
_initPriceVars: function() {
if (!this.xml)
return;
var allVars = this.xml.getElementsByTagName('variable');
for (var i =0; i < allVars.length; i++) {
var v = allVars[i];
var longName = v.getAttribute('id');
var name = longName.substring('price_of_'.length);
if (g_form.hasPricingImplications(name))
this.variables.push(v);
}
},
enhanceLabels: function() {
this._getAllPrices();
},
refreshCart : function(quantity, labels) {
this.disableOrderThisControls();
priceReceiveCounter += 1;
if (typeof(labels) != 'undefined')
this.labels = labels;
if (this.priceSendCounter > 1000000)
priceSendCounter = 0;
priceSendCounter++;
var counter = priceSendCounter;
var self = this;
setTimeout(function() {
if (counter != priceSendCounter)
return;
var ga = new GlideAjax("CartAjaxProcessor");
ga.addParam('sysparm_action', 'price');
ga.addParam('sysparm_quantity', quantity);
ga.addParam('sysparm_id', self.cat_item_id);
ga.addEncodedString(g_cart.generatePostString());
ga.setErrorCallback(self._priceResponseError.bind(self));
ga.getXML(self._priceResponse.bind(self), null, priceReceiveCounter);
}, 200)
},
_enhanceLabels: function (priceMap) {
var msg = [ 'lowercase_add', 'subtract' ];
var answer = this.messenger.getMessages(msg);
this.add = answer['lowercase_add'];
this.subtract = answer['subtract'];
for (var i =0; i < this.variables.length; i++) {
var v = this.variables[i];
var longName = v.getAttribute('id');
var name = longName.substring('price_of_'.length);
var realThing = document.getElementsByName(name);
if (realThing) {
for (var j = 0; j < realThing.length; j++) {
if (realThing[j].type == 'radio')
this._enhanceRadio(realThing[j], v, priceMap)
else if (realThing[j].options)
this._enhanceSelect(realThing[j], v, priceMap);
}
}
realThing = document.getElementsByName("ni." + name);
if (realThing) {
for (var j = 0; j < realThing.length; j++) {
if (realThing[j].type == 'checkbox')
this._enhanceCheckbox(name, v, priceMap)
}
}
}
},
_adjustPrice: function(price) {
if (price && price.endsWith(".0"))
price = price.substring(0, price.length - 2);
if (price && price.endsWith(".00"))
price = price.substring(0, price.length - 3);
return price;
},
_enhanceCheckbox: function(name, v, priceMap) {
var node = v.childNodes[0];
var recurringFrequency = node.getAttribute('recurring_frequency');
var recurringPrice = node.getAttribute('recurring_price');
var price = node.getAttribute('price');
var label = node.getAttribute('base_label');
var displayCurrency = node.getAttribute('display_currency');
var realThing = $("ni." + name + "_label");
if (realThing) {
var checkbox = document.getElementsByName("ni." + name)[0];
var displayPrice = priceMap[displayCurrency + "_" + this._adjustPrice(price)];
var displayRecurringPrice = priceMap[displayCurrency + "_" + this._adjustPrice(recurringPrice)];
var mod1 = "";
var mod2 = "";
if (checkbox.checked + "" == "true") {
if (parseFloat(price)  > 0)
mod1 = "has added " + displayPrice;
if (parseFloat(recurringPrice)  > 0 && recurringFrequency != '')
mod2 = "has added " + displayRecurringPrice + " " + recurringFrequency;
} else {
if (parseFloat(price)  > 0)
mod1 = "will add " + displayPrice;
if (parseFloat(recurringPrice)  > 0 && recurringFrequency != '')
mod2 = "will add " + displayRecurringPrice + " " + recurringFrequency;
}
var mod = '';
if (mod1 != '')
mod += mod1;
if (mod1 != '' && mod2 != '')
mod += ' | ';
if (mod2 != '')
mod += mod2;
if (mod != '')
realThing.update(label  + ' [ ' + mod + ' ]');
else
realThing.update(label);
}
},
_enhanceSelect: function(select, v, priceMap) {
for (var i=0; i < select.options.length; i++) {
var recurringFrequency = v.childNodes[0].getAttribute('recurring_frequency');
var option = select.options[i];
var price = this._priceOfVar(v, option.value);
var currentPrice = this._currentPriceOf(select.name);
price = price - currentPrice;
var recurringPrice = this._recurringPriceOfVar(v, option.value);
var currentRecurringPrice = this._currentRecurringPriceOf(select.name);
recurringPrice = recurringPrice - currentRecurringPrice;
var baseLabel = this._labelOfVar(v, option.value);
if (!baseLabel)
continue;
var pt = this._attributeOfVar(v, option.value, 'display_currency');
var pt1 = this._getPriceToken(price, pt);
var pt2 = this._getPriceToken(recurringPrice, pt);
var enhancement1 = this._getEnhancement(price, priceMap, pt1);
var enhancement2 = this._getEnhancement(recurringPrice, priceMap, pt2, recurringFrequency);
var enhancements = '';
if (enhancement1 != '')
enhancements += enhancement1;
if (enhancement1 != '' && enhancement2 != '')
enhancements += ' | ';
if (enhancement2 != '')
enhancements += enhancement2;
if (enhancements != '')
option.text = baseLabel + ' [' + enhancements + ']';
else
option.text = baseLabel;
}
},
_enhanceRadio: function(radio, v, priceMap) {
var recurringFrequency = v.childNodes[0].getAttribute('recurring_frequency');
var l = radio.nextSibling;
var value = radio.value;
var price = this._priceOfVar(v, value);
var currentPrice = this._currentPriceOf(radio.name);
price = price - currentPrice;
var recurringPrice = this._recurringPriceOfVar(v, value);
var currentRecurringPrice = this._currentRecurringPriceOf(radio.name);
recurringPrice = recurringPrice - currentRecurringPrice;
var baseLabel = this._labelOfVar(v, value);
if (!baseLabel)
return;
var pt = this._attributeOfVar(v, value, 'display_currency');
var pt1 = this._getPriceToken(price, pt);
var pt2 = this._getPriceToken(recurringPrice, pt);
var enhancement1 = this._getEnhancement(price, priceMap, pt1);
var enhancement2 = this._getEnhancement(recurringPrice, priceMap, pt2, recurringFrequency);
var enhancements = '';
if (enhancement1 != '')
enhancements += enhancement1;
if (enhancement1 != '' && enhancement2 != '')
enhancements += ' | ';
if (enhancement2 != '')
enhancements += enhancement2;
var update = '';
if (enhancements != '')
update = baseLabel + ' [' + enhancements + ']';
else
update = baseLabel;
l.nodeValue = update;
},
_getEnhancement: function(price, priceMap, priceToken, recurringFrequency) {
if (price == 0 || recurringFrequency == '')
return '';
var term = this.add;
if (price < 0)
term = this.subtract;
if (term != '' && term != null)
term += ' ';
var nicePrice = priceMap[priceToken];
if(!nicePrice)
g_form.addErrorMessage(gs.getMessage('No response received from server'));
if (nicePrice.indexOf("(") == 0)
nicePrice = nicePrice.substring(1, nicePrice.length - 1);
if (recurringFrequency != null)
return term + nicePrice + ' ' + recurringFrequency;
else
return term + nicePrice;
},
_getAllPrices: function() {
var cf = new CurrencyFormat(this._enhanceLabels.bind(this), this.cat_item_id);
if (this.fillFormat(cf))
cf.formatPrices();
},
fillFormat : function(cf) {
var epp = new Object();
var doIt = false;
for (var i =0; i < this.variables.length; i++) {
var costs = this.variables[i].childNodes;
var vName = this.variables[i].getAttribute('id');
vName = vName.substring('price_of_'.length);
var currentPrice = this._currentPriceOf(vName);
var currentRecurringPrice = this._currentRecurringPriceOf(vName);
for (var j=0; j < costs.length; j++) {
var price = costs[j].getAttribute('price');
var recurringPrice = costs[j].getAttribute('recurring_price');
price = parseFloat(price);
price = price - currentPrice;
recurringPrice = parseFloat(recurringPrice);
recurringPrice = recurringPrice - currentRecurringPrice;
Math.abs(price);
Math.abs(recurringPrice);
var sc = costs[j].getAttribute('session_currency');
var dc = costs[j].getAttribute('display_currency');
var pt = this._getPriceToken(price, dc);
cf.addPrice(pt, sc + ';' + price);
pt = this._getPriceToken(recurringPrice, dc);
cf.addPrice(pt, sc + ';' + recurringPrice);
doIt = true;
}
}
return doIt;
},
_processPrice: function(cf, price) {
price = parseFloat(price);
price = price - currentPrice;
Math.abs(price);
var sc = costs[j].getAttribute('session_currency');
var dc = costs[j].getAttribute('display_currency');
var pt = this._getPriceToken(price, dc);
cf.addPrice(pt, sc + ';' + price);
},
_getPriceToken : function(price, displayCurrency) {
var answer = price;
if (displayCurrency)
answer = displayCurrency +'_' + price;
return answer;
},
_currentPriceOf : function(vName) {
var realThing = document.getElementsByName(vName);
if (!realThing)
return 0;
for (var i = 0; i < realThing.length; i++) {
if (realThing[i].type == 'radio' && realThing[i].checked)
return this._priceOf(vName, realThing[i].value);
else if (realThing[i].options) {
if (realThing[i].selectedIndex != '-1')
return this._priceOf(vName, realThing[i].options[realThing[i].selectedIndex].value);
}
}
return 0;
},
_currentRecurringPriceOf : function(vName) {
var realThing = document.getElementsByName(vName);
if (!realThing)
return 0;
for (var i = 0; i < realThing.length; i++) {
if (realThing[i].type == 'radio' && realThing[i].checked)
return this._recurringPriceOf(vName, realThing[i].value);
else if (realThing[i].options) {
if (realThing[i].selectedIndex != '-1')
return this._recurringPriceOf(vName, realThing[i].options[realThing[i].selectedIndex].value);
}
}
return 0;
},
disableOrderThisControls: function() {
$$(".order_buttons .text_cell").each(function(elem) {
elem.addClassName("disabled_order_button");
});
},
enableOrderThisControls: function() {
$$(".order_buttons .text_cell").each(function(elem) {
elem.removeClassName("disabled_order_button");
});
},
_priceResponseError : function(request, counter) {
if (priceReceiveCounter != counter)
return;
this.enableOrderThisControls();
},
_priceResponse : function(response, counter) {
if (priceReceiveCounter != counter)
return;
this.enableOrderThisControls();
var xml = response.responseXML;
var items = xml.getElementsByTagName("item");
if (items.length > 0) {
var a = false;
for (var i = 0; i < items.length; i++) {
if (items[i].getAttribute("show_price") == "true")
a = true;
}
for (var i = 0; i < items.length; i++) {
var s = items[i].getAttribute("show_price");
var p = items[i].getAttribute("display_price");
var t = items[i].getAttribute("display_total");
var r = items[i].getAttribute("recurring_price") == "true";
this._setTotals(s,p,t,r,a);
}
}
var cf = new CurrencyFormat(this._updateCart.bind(this));
this.fillFormat(cf);
cf.formatPrices();
},
_priceOf : function(name, value) {
var test = 'price_of_' + name;
for (var i =0; i < this.variables.length; i++) {
if (this.variables[i].getAttribute('id') != test)
continue;
return this._priceOfVar(this.variables[i], value);
}
return 0;
},
_recurringPriceOf : function(name, value) {
var test = 'price_of_' + name;
for (var i =0; i < this.variables.length; i++) {
if (this.variables[i].getAttribute('id') != test)
continue;
return this._recurringPriceOfVar(this.variables[i], value);
}
return 0;
},
_priceOfVar : function(v, value) {
var p =  this._attributeOfVar(v, value, 'price');
if(isNaN(parseFloat(p)))
return 0
else
return parseFloat(p);
},
_recurringPriceOfVar : function(v, value) {
var p =  this._attributeOfVar(v, value, 'recurring_price');
if(isNaN(parseFloat(p)))
return 0
else
return parseFloat(p);
},
_checkMap : function(v) {
if (!this.optionMap)
this.optionMap = {};
if (!this.optionMap[v.id])
this.optionMap[v.id] = {};
var options = v.getElementsByTagName('cost');
for (var n = 0; n < options.length; n++)
this.optionMap[v.id][options[n].getAttribute('value')] = options[n];
},
_attributeOfVar : function(v, value, attribute) {
this._checkMap(v);
if (this.optionMap[v.id] && this.optionMap[v.id][value])
return this.optionMap[v.id][value].getAttribute(attribute);
return null;
},
_labelOfVar : function(v, value) {
this._checkMap(v);
if (this.optionMap[v.id] && this.optionMap[v.id][value])
return this.optionMap[v.id][value].getAttribute('base_label');
return 0;
},
_setTotals : function(show_price, display_price, total, recurring, any) {
var style = "none";
if(show_price == "true")
style = "";
var label_style = "none";
if (show_price == "true" || any)
label_style = "";
var prefix = "";
if (recurring)
prefix = "recurring_";
var price_label_span = gel('price_label_span');
if (price_label_span) {
price_label_span.style.display = label_style;
var price_span = gel(prefix + 'price_span');
if (price_span) {
if (recurring)
price_span.innerHTML = '+ ' + display_price;
else
price_span.innerHTML = display_price;
price_span.style.display = style;
if (recurring) {
var freqLabel = gel("recurring_frequency_span");
if (freqLabel)
freqLabel.style.display = style;
var recurringTable = $("recurring_price_table");
if (recurringTable)
recurringTable.style.display = style;
}
}
}
var total_label_span = gel('price_subtotal_label_span');
if (total_label_span) {
total_label_span.style.display = label_style;
var total_span = gel(prefix + 'price_subtotal_span');
if (total_span) {
if (recurring)
total_span.innerHTML = '+ ' + total;
else
total_span.innerHTML = total;
total_span.style.display = style;
if (recurring) {
var freqLabel = gel("recurring_frequency_subtotal_span");
if (freqLabel)
freqLabel.style.display = style;
var recurringTable = $("recurring_price_subtotal_table");
if (recurringTable)
recurringTable.style.display = style;
}
}
}
},
_updateCart : function(responseMap) {
if (this.labels)
this._enhanceLabels(responseMap);
this.cart._changed();
}
}
;
/*! RESOURCE: /scripts/currency_format.js */
var CurrencyFormat = Class.create();
CurrencyFormat.prototype = {
_PROCESSOR : "com.glideapp.servicecatalog.CurrencyAjaxProcessor",
initialize: function(callBack) {
this._callBack = callBack;
this._map = new Object();
},
addPrice: function (key, value) {
this._map[key] = value + '';
},
formatPrices: function () {
var ajax = new GlideAjax(this._PROCESSOR);
ajax.addParam("sysparm_action", "calcprice");
for (key in this._map)
ajax.addParam("sysparm_price_" + key, this._map[key]);
ajax.getXML(this.handleResponse.bind(this));
},
handleResponse: function(request) {
responseMap = new Object();
var xml = request.responseXML;
if(xml) {
for (key in this._map) {
var items = xml.getElementsByTagName("sysparm_price_" + key);
if (items.length == 1) {
var price = items[0].getAttribute("price");
responseMap[key] = price;
}
}
this._callBack.call(this, responseMap);
}
}
}
;
/*! RESOURCE: /scripts/CatalogReferenceChoice.js */
var CatalogReferenceChoice = Class.create(AJAXReferenceChoice, {
initialize: function(element, reference, dependentReference, refQualElements, targetTable) {
if (!element)
element = gel('sys_original.' + reference);
AJAXReferenceCompleter.prototype.initialize.call(this, element, reference, dependentReference, refQualElements, targetTable);
},
addSysParms: function() {
var sp = "sysparm_processor=LookupSelectProcessor" +
"&sysparm_name=" + this.elementName +
"&sysparm_timer=" + this.timer +
"&sysparm_max=" + this.max +
"&sysparm_chars=" + encodeText(this.searchChars);
return sp;
},
ajaxResponse: function(response) {
var e = response.responseXML.documentElement;
var vn = e.getAttribute("variable_name");
var v = e.getAttribute("variable");
if (isMSIE && gel('sysparm_id')) {
var island = getXMLIsland('pricing_' + gel('sysparm_id').value);
if (island) {
var vars = island.getElementsByTagName('variable');
for (var i = 0; i < vars.length; i++) {
if (vars[i].getAttribute('id') == vn) {
var xml = loadXML(v);
var root = xml.documentElement;
var p = vars[i].parentNode;
p.removeChild(vars[i]);
p.appendChild(root.cloneNode(true));
gel('pricing_' + gel('sysparm_id').value).innerHTML = island.xml;
}
}
}
} else {
var t = gel(vn);
if (t)
t.outerHTML = v;
}
if ("true" == e.getAttribute("radio"))
this._updateRadio(e);
else
this._updateSelect(e);
},
addRefQualValues: function() {
if (this.refQualElements) {
var form = g_form;
if (typeof g_sc_form != 'undefined')
form = g_sc_form
return "&" + form.serializeChanged();
} else
return "";
},
_updateSelect : function(e) {
var options = e.getAttribute("options");
var td = findParentByTag(this.element, 'td');
td.innerHTML = options;
this.element = td.getElementsByTagName("select")[0];
this.element.onchange.call();
},
_updateRadio : function(e) {
var t = findParentByTag(this.element, 'table');
var td = findParentByTag(t, "td");
var options = e.getAttribute("options");
td.innerHTML = options;
var inputs = $(td).select(".cat_item_option");
for (var i =0; i < inputs.length;i++) {
var element = inputs[i];
if (element.checked) {
this.element = element;
this.element.onclick.call();
return;
}
}
},
getKeyElement: function() {
if (this.keyElement)
return this.keyElement;
return this.element;
}
});
;
/*! RESOURCE: /scripts/CartItemList.js */
var CartItemList = Class.create();
CartItemList.prototype = {
initialize: function(cart) {
this.processor = "com.glideapp.servicecatalog.CartAjaxProcessor";
this.urlPrefix = "xmlhttp.do?sysparm_processor=" +  this.processor;
this.bStart = "<table><tr><td>";
this.bMid = "</td><td class=\"text_cell\">";
this.bEnd = "</td></tr></table>";
this.backbutton = true;
this.cart = cart;
this._setOptions();
var gwt = new GwtMessage();
var values = ["Shopping Cart", "Empty", "Edit Cart", "Continue Shopping", "Proceed to Checkout", "Save and Checkout"];
this.answer = gwt.getMessages(values);
CustomEvent.observe("catalog_cart_changed", this._cartResponse.bind(this));
},
_setOptions: function() {
this.backbutton = true;
var no_checkout = gel('sysparm_no_checkout');
var no_proceed_checkout = gel('no_proceed_checkout');
this.no_checkout = no_checkout && no_checkout.value == 'true';
this.no_proceed_checkout = no_proceed_checkout && no_proceed_checkout.value == 'true';
this.show_proceed = !(this.no_checkout || this.no_proceed_checkout);
},
create: function() {
var w = new GlideWindow('cartContent', true);
w.setClassName('sc_cart_window');
this.cartBody = w.getBody();
w.setPosition("relative");
w.setSize(200, 10);
w.setTitle(this.answer["Shopping Cart"]);
w.setBody("<div class='sc_cart_empty_message'>" + this.answer["Empty"] + "</div>");
w.insert(gel('cart'));
},
get: function() {
serverRequest(this.urlPrefix, this._cartResponse.bind(this));
},
notify: function(event, response) {
if (event == 'cart_change')
this._cartResponse(response);
},
_updateCart: function(update) {
if (this.cartBody)
this.cartBody.innerHTML = update;
else
$$("div[id^=cart]").each(function(elem) {
elem.innerHTML = update;
})
},
_appendCart: function(child) {
if (this.cartBody)
this.cartBody.appendChild(child);
else
$$("div[id^=cart]").each(function(elem) {
elem.appendChild($(child).clone(true));
})
},
_cartResponse: function(request) {
var xml = request.responseXML;
this._updateCart("");
var gwt = new GwtMessage();
var restyle = xml.getElementsByTagName("restyle")[0].getAttribute("value") == "true";
var subtotal = xml.getElementsByTagName("subtotal");
var hasprice = subtotal[0].getAttribute("has_price");
var subtotalText = subtotal[0].getAttribute("text");
var subtotalPrice = subtotal[0].getAttribute("price");
var items = xml.getElementsByTagName("item");
if (items.length < 1) {
this._updateCart("<div class='sc_cart_empty_message'>" + this.answer["Empty"] + "</div>");
this._afterChange();
return;
}
var catItem = xml.getElementsByTagName("cat_item");
if (catItem.length > 0) {
var itemGuid = catItem[0].getAttribute("item_guid");
var itemParm = gel("sysparm_item_guid");
if (itemParm)
itemParm.value = itemGuid;
}
var table = new GwtTable();
table.htmlElement.style.width = "100%";
for(var i = 0; i < items.length; i++) {
var q = items[i].getAttribute("quantity");
var d = items[i].getAttribute("description");
var p = items[i].getAttribute("price");
var r = items[i].getAttribute("recurring_price");
var f = items[i].getAttribute("recurring_frequency");
table.addRowWithClassName("sc_cart_cell", q, d);
if (p != null)
table.addCellsWithClassName("sc_cart_cell_right", p);
if (r != null && f != null && f != '') {
if (p != null) {
table.addRowWithClassName("");
table.row.appendChild(document.createElement('td'));
var rpCol = document.createElement('td');
var rpColText = document.createTextNode('+ ' + r + ' ' + f);
rpCol.className = "sc_cart_cell_smaller sc_cart_cell_smaller_right";
rpCol.colSpan = 2;
rpCol.appendChild(rpColText);
table.row.appendChild(rpCol);
}
else
table.addRowWithClassName("sc_cart_cell_right sc_cart_cell_smaller", '', '+ ' + r + ' ' + f);
}
}
this._appendCart(table.htmlElement);
var table = new GwtTable();
table.htmlElement.style.width = "100%";
if (hasprice == 'true') {
table.addRowWithClassName("");
table.setRowClassName("sc_cart_subtotal_row");
var horizontalRule = document.createElement("hr");
var tableCol = document.createElement('td');
tableCol.colSpan = 3;
tableCol.appendChild(horizontalRule)
table.row.appendChild(tableCol);
table.addRowWithClassName("sc_cart_cell_total");
var subtotalCell = table.addSpanCell(2);
var subtotalNode = document.createTextNode(subtotalText)
subtotalCell.appendChild(subtotalNode);
subtotalCell.className = "sc_cart_cell sc_cart_cell_total";
table.addCellsWithClassName("sc_cart_cell_total_right", subtotalPrice);
}
this._appendCart(table.htmlElement);
var catalog = "";
var urlSuffix = "";
if (gel("sysparm_catalog")) {
catalog = gel("sysparm_catalog").value;
urlSuffix += "sysparm_catalog=" + catalog;
}
var catalog_view = "";
if (gel("sysparm_catalog_view")) {
catalog_view = gel("sysparm_catalog_view").value;
if (urlSuffix)
urlSuffix += "&";
urlSuffix += "sysparm_catalog_view=" + catalog_view;
}
var buttonRow = cel("tr");
buttonRow.className = "sc_cart_buttons";
if (isMSIE7)
buttonRow.style.display = "block";
else
buttonRow.style.display = "table-row";
this.buttonCell = cel("td");
this.buttonCell.colSpan = "3";
buttonRow.appendChild(this.buttonCell);
table.body.appendChild(buttonRow);
this._generateButton('request_catalog_button_with_icon btn btn-default', 'catalog_cart_edit_button', '#', "window.location='com.glideapp.servicecatalog_cart_view.do?" + urlSuffix + "'", this.answer["Edit Cart"], "images/button_arrow_rt.gifx", this.answer["Edit Cart"], restyle);
if (this.show_proceed) {
if (this.editID) {
this._generateButton('request_catalog_button_with_icon btn btn-default', 'catalog_cart_save_checkout', '#', "proceedCheckout('" + this.editID + "')", this.answer["Save and Checkout"], "images/button_arrow_rt.gifx", this.answer["Save and Checkout"], restyle);
} else {
var gurl = new GlideURL("service_catalog.do");
gurl.addParam('sysparm_action', 'checkout');
if(catalog)
gurl.addParam('sysparm_catalog', catalog);
if(catalog_view)
gurl.addParam('sysparm_catalog_view', catalog_view);
gurl.addToken();
this._generateButton('request_catalog_button_with_icon btn btn-primary', 'catalog_cart_proceed_checkout', '#', "window.location='" + gurl.getURL() + "'", this.answer["Proceed to Checkout"], 'images/button_arrow_rt.gifx', this.answer["Proceed to Checkout"], restyle);
}
}
if (this.backbutton) {
var cartBackButtonOnClickAction = "window.history.back()";
var target = "window";
var targetKey = "BROWSING_CONTEXT_TARGET";
if ($(targetKey) != undefined && $(targetKey) != null && $(targetKey).value != null)
target = $(targetKey).value;
var urlKey = "BROWSING_CONTEXT_CATEGORY_SYSID";
if ($(urlKey) != undefined && $(urlKey) != null && $(urlKey).value != null)
cartBackButtonOnClickAction = target + ".location=\'" + $(urlKey).value + "\';";
this._generateButton('request_catalog_button_with_icon btn btn-default', 'catalog_cart_continue_shopping', '#', cartBackButtonOnClickAction, this.answer["Continue Shopping"], 'images/button_arrow_lt.gifx', this.answer["Continue Shopping"], restyle);
}
this._afterChange();
},
_generateButton: function(clazz, id, href, onclick, title, img, label, restyle) {
if (restyle) {
var button = cel("button");
button.type = "button";
button.className = clazz;
button.id = id;
button.onclick = function() {
eval(onclick);
return false;
}
button.title = title;
button.innerHTML = label;
this.buttonCell.appendChild(button);
} else {
var span = cel("div");
span.className += "catalog_button_container";
span.innerHTML = "<a class='" + clazz + "' id='" + id + "' href='" + href + "' onclick=\"" + onclick + "\"  title='" + title + "'>" + this.bStart + "<img src='" + img + "' />" + this.bMid + label + this.bEnd + "</a>";
this.buttonCell.appendChild(span);
}
},
_afterChange : function() {
if (this.cart)
this.cart._changed();
_frameChanged();
},
initForm: function() {
var form = addForm();
form.action = this.fAction;
form.name = this.fAction;
form.id = this.fAction;
form.method = "POST";
return form;
},
setContentElement: function (cartBody) {
this.cartBody = $(cartBody);
}
};
;
/*! RESOURCE: /scripts/CartProxy.js */
var CartProxy = Class.create();
CartProxy.prototype = {
initialize: function(id) {
this.target = id;
CustomEvent.observe('cart.loaded', this.onCartChange.bind(this));
CustomEvent.observe('cart.edit', this.onCartEdit.bind(this));
},
proxy : function(html, win) {
this.targetWindow = win;
gel(this.target).innerHTML = html;
this._cleanup();
},
reload : function() {
gel(this.target).innerHTML = "";
},
onCartEdit : function() {
this.reload();
},
onCartChange : function(args) {
var html = args['html'];
var win = args['window'];
if (win == window)
return;
this.proxy(html, win);
},
_cleanup : function() {
var quanThere = this.targetWindow.gel("quantity");
if (quanThere)
gel("quantity").selectedIndex = quanThere.selectedIndex;
var shopping = gel('catalog_cart_continue_shopping');
if (shopping)
shopping.style.display="none";
var pc = gel('catalog_cart_proceed_checkout');
if (pc) {
pc.onclick = function() { proceedCheckout() }
pc.removeAttribute("href");
}
var edit = gel('catalog_cart_edit_button');
if (edit)
edit.onclick = function() { editCart() };
}
};
function addToCart() {
if (window.g_cart_proxy)
window.g_cart_proxy.targetWindow.addToCart();
}
function orderEdit() {
if (window.g_cart_proxy)
window.g_cart_proxy.targetWindow.orderEdit();
}
function orderNow() {
if (window.g_cart_proxy)
window.g_cart_proxy.targetWindow.orderNow();
}
function proceedCheckout() {
if (window.g_cart_proxy) {
var targetWin = window.g_cart_proxy.targetWindow;
targetWin.gel('catalog_cart_proceed_checkout').onclick();
}
}
function editCart() {
if (window.g_cart_proxy) {
var targetWin = window.g_cart_proxy.targetWindow;
targetWin.gel('catalog_cart_edit_button').onclick();
}
}
function calcPrice() {
if (window.g_cart_proxy) {
var quan = g_cart_proxy.targetWindow.gel("quantity");
quan.selectedIndex = gel("quantity").selectedIndex;
g_cart_proxy.targetWindow.calcPrice();
}
}
;
/*! RESOURCE: /scripts/CartV2/CartItems.js */
var CartItems = Class.create();
CartItems.prototype = {
initialize : function() {
this.g_cart = new SCCartV2();
this.processor = "CartAjaxProcessorV2";
this.urlPrefix = "xmlhttp.do?sysparm_processor=" + this.processor;
CustomEvent.observe("catalog_cart_changed", this._cartResponse.bind(this));
this._processTitle($$('.sc_cart_items_title')[0]);
this.get();
this._afterChange();
},
tableRowStyle : function() {
if (isMSIE6 || isMSIE7)
return 'block';
return 'table-row';
}(),
get : function() {
var url = this.urlPrefix + "&" + this.g_cart._addParams();
serverRequest(url, this._cartResponse.bind(this));
},
scCartOnRender : function(showShoppingCart) {
this.showShoppingCart = showShoppingCart;
if (showShoppingCart != 'true') {
$$('#sc_cart_item_list').each(function(el) {
el.setStyle({
'display' : 'none'
});
});
} else {
$$('#sc_cart_item_list').each(function(el) {
var style = isMSIE7 ? "block" : "table";
el.setStyle({
'display' : style
});
});
}
},
_processTitle: function(title) {
if ($('sc_cart_window') && (($('sc_cart_window').next() && $('sc_cart_window').next().nodeName == "RENDERPREFERENCE") || $('sc_cart_window').up().nodeName === "RENDERED_BODY"))
title.setStyle({ 'display' : 'none' });
},
_cartResponse : function(request) {
var xml = request.responseXML;
var catItem = xml.getElementsByTagName("cat_item");
if (catItem.length > 0) {
var itemGuid = catItem[0].getAttribute("item_guid");
var itemParm = gel("sysparm_item_guid");
if (itemParm)
itemParm.value = itemGuid;
}
var content = xml.getElementsByTagName("markup")[0].getAttribute("content");
var temp = cel("table");
$(temp).update(content);
this._processTitle($(temp).down('.sc_cart_items_title'));
var container = $('sc_cart_window');
if (!container)
container = $('sc_cart_item_list');
container.update(temp.innerHTML);
this._afterChange();
},
_afterChange : function() {
var args = {};
if ($("sc_cart_contents"))
args['html'] = $("sc_cart_contents").innerHTML;
args['window'] = window;
args['original_id'] = "sc_cart_contents";
CustomEvent.fireTop('cart.loaded', args);
_frameChanged();
}
};
;
/*! RESOURCE: /scripts/CartV2/OrderItem.js */
var OrderItem = Class.create();
OrderItem.prototype = {
g_cart : null,
initialize : function() {
this.g_cart = new SCCartV2();
},
scOrderItemOnRender : function(showOrderItem) {
this.showOrderItem = showOrderItem;
if (showOrderItem != 'true') {
if ($('qty') && $('qty').hasClassName('sc_cart_window'))
$('qty').setStyle({
'display' : 'none'
});
}
this.g_cart.addCartContent();
if ($('cart_edit'))
this.g_cart.editID = $('cart_edit').getValue();
if (this.g_cart.editID && this.g_cart.editID.length > 0)
this.calcPrice();
},
addToCart : function() {
var m = g_form.catalogOnSubmit();
if (!m)
return;
var guid;
var item_guid = gel("sysparm_item_guid");
if (item_guid)
guid = item_guid.value;
if (guid == "")
return;
item_guid.value = "";
var attachmentList = gel("header_attachment_list");
if (attachmentList) {
var count = attachmentList.childNodes.length;
while (count > 1) {
count--;
var node = attachmentList.childNodes[count];
rel(node);
}
var listLabel = gel("header_attachment_list_label");
listLabel.style.display = "none";
var spanNodes = $(listLabel).select("span");
if (spanNodes && spanNodes.length != 0)
spanNodes[0].update("");
}
this.g_cart.add($("sysparm_id").getValue(), this.getQuantity(), guid);
},
orderNow : function() {
var m = g_form.catalogOnSubmit();
if (!m)
return;
gel("oi_order_now_button").onclick = "";
var item_guid = gel("sysparm_item_guid");
if (item_guid)
item_guid = item_guid.value
var catalog_guid = gel("sysparm_catalog");
if (catalog_guid)
catalog_guid = catalog_guid.value
var catalog_view = gel("sysparm_catalog_view");
if (catalog_view)
catalog_view = catalog_view.value
this.g_cart.order($("sysparm_id").getValue(), this.getQuantity(),
item_guid, catalog_guid, catalog_view);
},
calcPrice : function() {
this.g_cart.recalcPrice($("sysparm_id").getValue(), this.getQuantity());
},
orderEdit : function(target) {
if (!target)
target = $('cart_edit').getValue();
var m = g_form.catalogOnSubmit();
if (!m)
return;
this.g_cart.edit(target, this.getQuantity());
},
proceedCheckout : function(target) {
var m = g_form.catalogOnSubmit();
if (!m)
return;
this.g_cart.orderUpdate(target, this.getQuantity());
},
getQuantity : function() {
var quantity = 1;
var quan_widget = gel("quantity");
if (quan_widget)
quantity = $('quantity').getValue();
return quantity;
}
};
;
/*! RESOURCE: /scripts/CartV2/SCCartV2.js */
var SCCartV2 = Class.create();
SCCartV2.prototype = {
initialize : function() {
this.htmlElement = null;
this.fAction = "service_catalog.do";
this.processor = "CartAjaxProcessorV2";
this.urlPrefix = "xmlhttp.do?sysparm_processor=" + this.processor;
this.showCart = true;
this.enhanceLabels = true;
},
setCartVisible : function(showCart) {
this.showCart = showCart;
},
addCartContent : function() {
},
order : function(item, quantity, sc_cart_item_id, catalog_id, catalog_view) {
this._postAction(null, quantity, item, "order", sc_cart_item_id,
catalog_id, catalog_view);
},
orderUpdate : function(cart_item, quantity) {
var item_id = gel("sysparm_id").value;
this._postAction(cart_item, quantity, item_id, "update_proceed");
},
add : function(item, quantity, itemId) {
var url = this.urlPrefix + "&sysparm_action=" + "add" + "&sysparm_id="
+ item + "&sysparm_quantity=" + quantity
+ "&sysparm_item_guid=" + itemId;
url += this._addParams();
var postString = this.generatePostString();
serverRequestPost(url, postString, this._addResponse.bind(this));
},
_addResponse : function(response) {
CustomEvent.fire("catalog_cart_changed", response);
},
_addParam : function(name) {
var value = gel(name);
if (value && value.value)
return "&" + name + "=" + equalsHtmlToHex(value.value);
return '';
},
_addParams : function() {
var ret = this._addParam('sysparm_processing_hint');
ret += this._addParam('sysparm_catalog');
ret += this._addParam('sysparm_catalog_view');
ret += this._addParam('sysparm_link_parent');
return ret;
},
generatePostString : function() {
var postString = "";
var optionsElements = $(document.body).select(".cat_item_option");
postString = this.generatePostStringOptions(postString, optionsElements);
optionsElements = $(document.body).select(".questionSetWidget")
postString = this.generatePostStringOptions(postString, optionsElements);
return postString;
},
generatePostStringOptions : function(postString, optionsElements) {
var seq = 0;
for (i = 0; i < optionsElements.length; i++) {
var element = optionsElements[i];
var n = element.name;
jslog(n + " = " + element.value);
if ("variable_sequence" == n) {
seq++;
n = n + seq;
}
if (element.type == "radio" && element.checked)
postString += n + "=" + encodeURIComponent(element.value) + "&";
else if (element.type != "radio")
postString += n + "=" + encodeURIComponent(element.value) + "&";
}
return postString;
},
recalcPrice : function(item, quantity) {
price = new CatalogPricingV2(item, this);
price.refreshCart(quantity, this.enhanceLabels);
},
edit : function(cart_item, quantity) {
var item_id = $F("sysparm_id");
this._postAction(cart_item, quantity, item_id, "update");
},
addAttachment : function(item_sys_id, tableName, allowAttachment) {
saveAttachment(tableName, item_sys_id, allowAttachment);
},
showReferenceForm : function(inputName, tableName) {
if (!g_form.catalogOnSubmit())
return;
var quantity = 1;
var quan_widget = gel("quantity");
if (quan_widget)
quantity = quan_widget.value;
var item_id = $F("sysparm_id");
var ref_sys_id = gel(inputName).value;
var form = this.initForm();
addInput(form, "HIDDEN", "sysparm_table", tableName);
addInput(form, "HIDDEN", "sysparm_ref_lookup", ref_sys_id);
addInput(form, "HIDDEN", "sysparm_action", "show_reference");
addInput(form, "HIDDEN", "sysparm_quantity", quantity);
addInput(form, "HIDDEN", "sysparm_id", item_id);
var hint = gel('sysparm_processing_hint');
if (hint && hint.value)
addInput(form, "HIDDEN", "sysparm_processing_hint", hint.value);
this.addInputToForm(form);
form.submit();
},
_postAction : function(cart_item, quantity, item_id, action,
sc_cart_item_id, catalog_id, catalog_view) {
var form = this.initForm();
addInput(form, "HIDDEN", "sysparm_action", action);
if (cart_item)
addInput(form, "HIDDEN", "sysparm_cart_id", cart_item);
addInput(form, "HIDDEN", "sysparm_quantity", quantity);
addInput(form, "HIDDEN", "sysparm_id", item_id);
addInput(form, "HIDDEN", "sysparm_catalog", catalog_id);
addInput(form, "HIDDEN", "sysparm_catalog_view", catalog_view);
var hint = gel('sysparm_processing_hint');
if (hint && hint.value)
addInput(form, "HIDDEN", "sysparm_processing_hint", hint.value);
if (sc_cart_item_id)
addInput(form, "HIDDEN", "sysparm_item_guid", sc_cart_item_id);
this.addInputToForm(form);
form.submit();
},
addInputToForm : function(form) {
jslog("addInputToForm");
var optionsElements = $(document.body).select(".cat_item_option:not(.ignore)");
var seq = 0;
for (i = 0; i < optionsElements.length; i++) {
var element = optionsElements[i];
var n = element.name;
if (n != null && n != "") {
if ("variable_sequence" == n) {
seq++;
n = n + seq;
}
if (element.type == "radio" && element.checked)
addInput(form, "HIDDEN", n, element.value);
else if (element.type != "radio")
addInput(form, "HIDDEN", n, element.value);
}
}
},
getCartContents : function() {
if (!this.showCart)
return;
var self = this;
var url = this.urlPrefix;
url += this._addHint();
serverRequest(url, function() {
self._changed();
});
},
_changed : function() {
var args = new Object();
if (!gel("sc_cart_contents"))
return;
args['html'] = gel("sc_cart_contents").innerHTML;
args['window'] = window;
CustomEvent.fireTop('cart.loaded', args);
},
initForm : function() {
var form = addForm();
form.action = this.fAction;
form.name = this.fAction;
form.id = this.fAction;
form.method = "POST";
return form;
},
setContentElement : function(htmlElement) {
this.htmlElement = $(htmlElement);
},
checkoutComplete : function() {
CustomEvent.fireTop('cart.edit');
}
};
;
/*! RESOURCE: /scripts/CartV2/CartProxyV2.js */
var CartProxyV2 = Class.create();
CartProxyV2.prototype = {
initialize : function(id) {
this.target = id;
CustomEvent.observe('cart.loaded', this.onCartChange.bind(this));
CustomEvent.observe('cart.edit', this.onCartEdit.bind(this));
},
proxy : function(html, win) {
this.targetWindow = win;
gel(this.target).innerHTML = html;
var displayStyle = 'table';
if (isMSIE6 || isMSIE7)
displayStyle = 'block';
if (window.g_cart_proxy && window.g_cart_proxy.targetWindow.document.cartItemsWidget && window.g_cart_proxy.targetWindow.document.cartItemsWidget.showShoppingCart == 'true')
$(this.target).select('#sc_cart_item_list')[0].setStyle({'display' : displayStyle});
if (window.g_cart_proxy && window.g_cart_proxy.targetWindow.orderItemWidget.showOrderItem == 'true')
$(this.target).select('#qty')[0].setStyle({'display' : displayStyle});
this._cleanup();
},
reload : function() {
gel(this.target).innerHTML = "";
},
onCartEdit : function() {
this.reload();
},
onCartChange : function(args) {
var html = args['html'];
var win = args['window'];
if (win == window)
return;
this.proxy(html, win);
},
_cleanup : function() {
var qtyThere = this.targetWindow.gel("quantity");
if (qtyThere)
gel("quantity").selectedIndex = qtyThere.selectedIndex;
var shopping = gel('catalog_cart_continue_shopping');
if (shopping)
shopping.style.display = "none";
var pc = gel('catalog_cart_proceed_checkout');
if (pc) {
pc.onclick = function() {
orderItemWidget.proceedCheckout()
}
pc.removeAttribute("href");
}
var edit = gel('catalog_cart_edit_button');
if (edit)
edit.onclick = function() {
orderItemWidget.editCart()
};
}
};
var orderItemWidget = {
addToCart : function() {
if (window.g_cart_proxy)
window.g_cart_proxy.targetWindow.orderItemWidget.addToCart();
},
orderEdit : function() {
if (window.g_cart_proxy)
window.g_cart_proxy.targetWindow.orderItemWidget.orderEdit();
},
orderNow : function() {
if (window.g_cart_proxy)
window.g_cart_proxy.targetWindow.orderItemWidget.orderNow();
},
proceedCheckout : function() {
if (window.g_cart_proxy) {
var targetWin = window.g_cart_proxy.targetWindow;
targetWin.gel('catalog_cart_proceed_checkout').onclick();
}
},
editCart : function() {
if (window.g_cart_proxy) {
var targetWin = window.g_cart_proxy.targetWindow;
targetWin.gel('catalog_cart_edit_button').onclick();
}
},
calcPrice : function() {
if (window.g_cart_proxy) {
var quan = g_cart_proxy.targetWindow.gel("quantity");
quan.selectedIndex = gel("quantity").selectedIndex;
g_cart_proxy.targetWindow.orderItemWidget.calcPrice();
}
}
}
;
/*! RESOURCE: /scripts/CartV2/CatalogPricingV2.js */
var priceReceiveCounter = 0;
var priceSendCounter = 0;
var CatalogPricingV2 = Class.create();
CatalogPricingV2.prototype = {
initialize: function(cat_item_id, cart) {
this.cat_item_id = cat_item_id;
this.xml = getXMLIsland('pricing_' + cat_item_id);
this.variables = [];
this._initPriceVars();
this.messenger = new GwtMessage();
this.labels = true;
this.cart = cart;
},
_initPriceVars: function() {
if (!this.xml)
return;
var allVars = this.xml.getElementsByTagName('variable');
for (var i =0; i < allVars.length; i++) {
var v = allVars[i];
var longName = v.getAttribute('id');
var name = longName.substring('price_of_'.length);
if (g_form.hasPricingImplications(name))
this.variables.push(v);
}
},
enhanceLabels: function() {
this._getAllPrices();
},
refreshCart : function(quantity, labels) {
this.disableOrderThisControls();
priceReceiveCounter += 1;
if (typeof(labels) != 'undefined')
this.labels = labels;
if (this.priceSendCounter > 1000000)
priceSendCounter = 0;
priceSendCounter++;
var counter = priceSendCounter;
var self = this;
setTimeout(function() {
if (counter != priceSendCounter)
return;
var ga = new GlideAjax("CartAjaxProcessorV2");
if(!$('sysparm_guide'))
ga.addParam('sysparm_action', 'order_item');
else
ga.addParam('sysparm_action', 'this_item_order_guide');
ga.addParam('sysparm_quantity', quantity);
ga.addParam('sysparm_id', self.cat_item_id);
ga.addEncodedString(self.cart.generatePostString());
ga.setErrorCallback(self._priceResponseError.bind(self));
ga.getXML(self._priceResponse.bind(self), null, priceReceiveCounter);
}, 200)
},
_enhanceLabels: function (priceMap) {
var msg = [ 'lowercase_add', 'subtract' ];
var answer = this.messenger.getMessages(msg);
this.add = answer['lowercase_add'];
this.subtract = answer['subtract'];
for (var i =0; i < this.variables.length; i++) {
var v = this.variables[i];
var longName = v.getAttribute('id');
var name = longName.substring('price_of_'.length);
var realThing = document.getElementsByName(name);
if (realThing) {
for (var j = 0; j < realThing.length; j++) {
if (realThing[j].type == 'radio')
this._enhanceRadio(realThing[j], v, priceMap)
else if (realThing[j].options)
this._enhanceSelect(realThing[j], v, priceMap);
}
}
realThing = document.getElementsByName("ni." + name);
if (realThing) {
for (var j = 0; j < realThing.length; j++) {
if (realThing[j].type == 'checkbox')
this._enhanceCheckbox(name, v, priceMap)
}
}
}
},
_adjustPrice: function(price) {
if (price && price.endsWith(".0"))
price = price.substring(0, price.length - 2);
if (price && price.endsWith(".00"))
price = price.substring(0, price.length - 3);
return price;
},
_enhanceCheckbox: function(name, v, priceMap) {
var node = v.childNodes[0];
var recurringFrequency = node.getAttribute('recurring_frequency');
var recurringPrice = node.getAttribute('recurring_price');
var price = node.getAttribute('price');
var label = node.getAttribute('base_label');
var displayCurrency = node.getAttribute('display_currency');
var realThing = $("ni." + name + "_label");
if (realThing) {
var checkbox = document.getElementsByName("ni." + name)[0];
var displayPrice = priceMap[displayCurrency + "_" + this._adjustPrice(price)];
var displayRecurringPrice = priceMap[displayCurrency + "_" + this._adjustPrice(recurringPrice)];
var mod1 = "";
var mod2 = "";
if (checkbox.checked + "" == "true") {
if (parseFloat(price)  > 0)
mod1 = "has added " + displayPrice;
if (parseFloat(recurringPrice)  > 0 && recurringFrequency != '')
mod2 = "has added " + displayRecurringPrice + " " + recurringFrequency;
} else {
if (parseFloat(price)  > 0)
mod1 = "will add " + displayPrice;
if (parseFloat(recurringPrice)  > 0 && recurringFrequency != '')
mod2 = "will add " + displayRecurringPrice + " " + recurringFrequency;
}
var mod = '';
if (mod1 != '')
mod += mod1;
if (mod1 != '' && mod2 != '')
mod += ' | ';
if (mod2 != '')
mod += mod2;
if (mod != '')
realThing.update(label  + ' [ ' + mod + ' ]');
else
realThing.update(label);
}
},
_enhanceSelect: function(select, v, priceMap) {
for (var i=0; i < select.options.length; i++) {
var recurringFrequency = v.childNodes[0].getAttribute('recurring_frequency');
var option = select.options[i];
var price = this._priceOfVar(v, option.value);
var currentPrice = this._currentPriceOf(select.name);
price = price - currentPrice;
var recurringPrice = this._recurringPriceOfVar(v, option.value);
var currentRecurringPrice = this._currentRecurringPriceOf(select.name);
recurringPrice = recurringPrice - currentRecurringPrice;
var baseLabel = this._labelOfVar(v, option.value);
if (!baseLabel)
continue;
var pt = this._attributeOfVar(v, option.value, 'display_currency');
var pt1 = this._getPriceToken(price, pt);
var pt2 = this._getPriceToken(recurringPrice, pt);
var enhancement1 = this._getEnhancement(price, priceMap, pt1);
var enhancement2 = this._getEnhancement(recurringPrice, priceMap, pt2, recurringFrequency);
var enhancements = '';
if (enhancement1 != '')
enhancements += enhancement1;
if (enhancement1 != '' && enhancement2 != '')
enhancements += ' | ';
if (enhancement2 != '')
enhancements += enhancement2;
if (enhancements != '')
option.text = baseLabel + ' [' + enhancements + ']';
else
option.text = baseLabel;
}
},
_enhanceRadio: function(radio, v, priceMap) {
var recurringFrequency = v.childNodes[0].getAttribute('recurring_frequency');
var l = radio.nextSibling;
var value = radio.value;
var price = this._priceOfVar(v, value);
var currentPrice = this._currentPriceOf(radio.name);
price = price - currentPrice;
var recurringPrice = this._recurringPriceOfVar(v, value);
var currentRecurringPrice = this._currentRecurringPriceOf(radio.name);
recurringPrice = recurringPrice - currentRecurringPrice;
var baseLabel = this._labelOfVar(v, value);
if (!baseLabel)
return;
var pt = this._attributeOfVar(v, value, 'display_currency');
var pt1 = this._getPriceToken(price, pt);
var pt2 = this._getPriceToken(recurringPrice, pt);
var enhancement1 = this._getEnhancement(price, priceMap, pt1);
var enhancement2 = this._getEnhancement(recurringPrice, priceMap, pt2, recurringFrequency);
var enhancements = '';
if (enhancement1 != '')
enhancements += enhancement1;
if (enhancement1 != '' && enhancement2 != '')
enhancements += ' | ';
if (enhancement2 != '')
enhancements += enhancement2;
var update = '';
if (enhancements != '')
update = baseLabel + ' [' + enhancements + ']';
else
update = baseLabel;
l.nodeValue = update;
},
_getEnhancement: function(price, priceMap, priceToken, recurringFrequency) {
if (price == 0 || recurringFrequency == '')
return '';
var term = this.add;
if (price < 0)
term = this.subtract;
if (term != '' && term != null)
term += ' ';
var nicePrice = priceMap[priceToken];
if(!nicePrice)
g_form.addErrorMessage(gs.getMessage('No response received from server'));
if (nicePrice.indexOf("(") == 0)
nicePrice = nicePrice.substring(1, nicePrice.length - 1);
if (recurringFrequency != null)
return term + nicePrice + ' ' + recurringFrequency;
else
return term + nicePrice;
},
_getAllPrices: function() {
var cf = new CurrencyFormat(this._enhanceLabels.bind(this), this.cat_item_id);
if (this.fillFormat(cf))
cf.formatPrices();
},
fillFormat : function(cf) {
var epp = new Object();
var doIt = false;
for (var i =0; i < this.variables.length; i++) {
var costs = this.variables[i].childNodes;
var vName = this.variables[i].getAttribute('id');
vName = vName.substring('price_of_'.length);
var currentPrice = this._currentPriceOf(vName);
var currentRecurringPrice = this._currentRecurringPriceOf(vName);
for (var j=0; j < costs.length; j++) {
var price = costs[j].getAttribute('price');
var recurringPrice = costs[j].getAttribute('recurring_price');
price = parseFloat(price);
price = price - currentPrice;
recurringPrice = parseFloat(recurringPrice);
recurringPrice = recurringPrice - currentRecurringPrice;
Math.abs(price);
Math.abs(recurringPrice);
var sc = costs[j].getAttribute('session_currency');
var dc = costs[j].getAttribute('display_currency');
var pt = this._getPriceToken(price, dc);
cf.addPrice(pt, sc + ';' + price);
pt = this._getPriceToken(recurringPrice, dc);
cf.addPrice(pt, sc + ';' + recurringPrice);
doIt = true;
}
}
return doIt;
},
_processPrice: function(cf, price) {
price = parseFloat(price);
price = price - currentPrice;
Math.abs(price);
var sc = costs[j].getAttribute('session_currency');
var dc = costs[j].getAttribute('display_currency');
var pt = this._getPriceToken(price, dc);
cf.addPrice(pt, sc + ';' + price);
},
_getPriceToken : function(price, displayCurrency) {
var answer = price;
if (displayCurrency)
answer = displayCurrency +'_' + price;
return answer;
},
_currentPriceOf : function(vName) {
var realThing = document.getElementsByName(vName);
if (!realThing)
return 0;
for (var i = 0; i < realThing.length; i++) {
if (realThing[i].type == 'radio' && realThing[i].checked)
return this._priceOf(vName, realThing[i].value);
else if (realThing[i].options) {
if (realThing[i].selectedIndex != '-1')
return this._priceOf(vName, realThing[i].options[realThing[i].selectedIndex].value);
}
}
return 0;
},
_currentRecurringPriceOf : function(vName) {
var realThing = document.getElementsByName(vName);
if (!realThing)
return 0;
for (var i = 0; i < realThing.length; i++) {
if (realThing[i].type == 'radio' && realThing[i].checked)
return this._recurringPriceOf(vName, realThing[i].value);
else if (realThing[i].options) {
if (realThing[i].selectedIndex != '-1')
return this._recurringPriceOf(vName, realThing[i].options[realThing[i].selectedIndex].value);
}
}
return 0;
},
disableOrderThisControls: function() {
$$(".order_buttons .text_cell").each(function(elem) {
elem.addClassName("disabled_order_button");
});
},
enableOrderThisControls: function() {
$$(".order_buttons .text_cell").each(function(elem) {
elem.removeClassName("disabled_order_button");
});
},
_priceResponseError : function(request, counter) {
if (priceReceiveCounter != counter)
return;
this.enableOrderThisControls();
},
_priceResponse : function(response, counter) {
var self = this;
if (!response.responseXML.getElementsByTagName("item"))
return;
if (priceReceiveCounter != counter)
return;
self.enableOrderThisControls();
var items = response.responseXML.getElementsByTagName("item");
if (items.length > 0) {
var show_price = false;
for (var i = 0; i < items.length; i++) {
itemObject = items[i].getAttribute("values").evalJSON();
if (itemObject.show_price == "true")
show_price = true;
}
for (var i = 0; i < items.length; i++) {
var itemObject = items[i].getAttribute("values").evalJSON();
if($('price_span'))
$('price_span').update(itemObject.display_price);
if($('recurring_price_span'))
$('recurring_price_span').update((self._isNegativePrice(itemObject.display_recurring_price) ? '' : '+ ') + itemObject.display_recurring_price);
if($('price_subtotal_span'))
$('price_subtotal_span').update(itemObject.display_subtotal);
else if($('price_subtotal_span'))
$('price_subtotal_span').update('');
if($('recurring_price_subtotal_span'))
$('recurring_price_subtotal_span').update((self._isNegativePrice(itemObject.display_subtotal_recurring_price) ? '' : '+ ') + itemObject.display_subtotal_recurring_price);
if ($('recurring_frequency_subtotal_span'))
$('recurring_frequency_subtotal_span').update(itemObject.recurring_frequency);
}
}
var cf = new CurrencyFormat(this._updateCart.bind(this));
this.fillFormat(cf);
cf.formatPrices();
},
_isNegativePrice : function(price) {
var firstChar = price.substring(0, 1);
if(firstChar == '-' || firstChar == '('){
return true;
}
return false;
},
_priceOf : function(name, value) {
var test = 'price_of_' + name;
for (var i =0; i < this.variables.length; i++) {
if (this.variables[i].getAttribute('id') != test)
continue;
return this._priceOfVar(this.variables[i], value);
}
return 0;
},
_recurringPriceOf : function(name, value) {
var test = 'price_of_' + name;
for (var i =0; i < this.variables.length; i++) {
if (this.variables[i].getAttribute('id') != test)
continue;
return this._recurringPriceOfVar(this.variables[i], value);
}
return 0;
},
_priceOfVar : function(v, value) {
var p =  this._attributeOfVar(v, value, 'price');
if(isNaN(parseFloat(p)))
return 0
else
return parseFloat(p);
},
_recurringPriceOfVar : function(v, value) {
var p =  this._attributeOfVar(v, value, 'recurring_price');
if(isNaN(parseFloat(p)))
return 0
else
return parseFloat(p);
},
_checkMap : function(v) {
if (!this.optionMap)
this.optionMap = {};
if (!this.optionMap[v.id])
this.optionMap[v.id] = {};
var options = v.getElementsByTagName('cost');
for (var n = 0; n < options.length; n++)
this.optionMap[v.id][options[n].getAttribute('value')] = options[n];
},
_attributeOfVar : function(v, value, attribute) {
this._checkMap(v);
if (this.optionMap[v.id] && this.optionMap[v.id][value])
return this.optionMap[v.id][value].getAttribute(attribute);
return null;
},
_labelOfVar : function(v, value) {
this._checkMap(v);
if (this.optionMap[v.id] && this.optionMap[v.id][value])
return this.optionMap[v.id][value].getAttribute('base_label');
return 0;
},
_updateCart : function(responseMap) {
if (this.labels)
this._enhanceLabels(responseMap);
this.cart._changed();
}
}
;
/*! RESOURCE: /scripts/question_event_initialize.js */
addLoadEvent(function() {
if (document.documentElement.getAttribute('data-doctype') != 'true')
return;
$j(document).on('click', '[data-type=question_date]', function() {
"use strict";
var element = $j(this).attr('data-element');
var format = $j(this).attr('data-date_time_format');
ScriptLoader.getScripts('scripts/classes/GwtDateTimePicker.js', function() {
new GwtDateTimePicker(element, format, false);
});
});
});
;
;
