/*! RESOURCE: /scripts/js_includes_navpage.js */
/*! RESOURCE: /scripts/lib/prototype.min.js */
/*!
 *  Prototype JavaScript framework, version 1.7
 *  (c) 2005-2010 Sam Stephenson
 *
 *  Prototype is freely distributable under the terms of an MIT-style license.
 *  For details, see the Prototype web site: http://www.prototypejs.org/
 *
 */
var Prototype={Version:"1.7",Browser:(function(){var b=navigator.userAgent;var a=Object.prototype.toString.call(window.opera)=="[object Opera]";return{IE:!!window.attachEvent&&!a,Opera:a,WebKit:b.indexOf("AppleWebKit/")>-1,Gecko:b.indexOf("Gecko")>-1&&b.indexOf("KHTML")===-1,MobileSafari:/Apple.*Mobile/.test(b)}})(),BrowserFeatures:{XPath:!!document.evaluate,SelectorsAPI:!!document.querySelector,ElementExtensions:(function(){var a=window.Element||window.HTMLElement;return !!(a&&a.prototype)})(),SpecificElementExtensions:(function(){if(typeof window.HTMLDivElement!=="undefined"){return true}var c=document.createElement("div"),b=document.createElement("form"),a=false;if(c.__proto__&&(c.__proto__!==b.__proto__)){a=true}c=b=null;return a})()},ScriptFragment:"<script[^>]*>([\\S\\s]*?)<\/script>",JSONFilter:/^\/\*-secure-([\s\S]*)\*\/\s*$/,emptyFunction:function(){},K:function(a){return a}};if(Prototype.Browser.MobileSafari){Prototype.BrowserFeatures.SpecificElementExtensions=false}var Abstract={};var Try={these:function(){var c;for(var b=0,d=arguments.length;b<d;b++){var a=arguments[b];try{c=a();break}catch(f){}}return c}};var Class=(function(){var d=(function(){for(var e in {toString:1}){if(e==="toString"){return false}}return true})();function a(){}function b(){var h=null,g=$A(arguments);if(Object.isFunction(g[0])){h=g.shift()}function e(){this.initialize.apply(this,arguments)}Object.extend(e,Class.Methods);e.superclass=h;e.subclasses=[];if(h){a.prototype=h.prototype;e.prototype=new a;h.subclasses.push(e)}for(var f=0,j=g.length;f<j;f++){e.addMethods(g[f])}if(!e.prototype.initialize){e.prototype.initialize=Prototype.emptyFunction}e.prototype.constructor=e;return e}function c(l){var g=this.superclass&&this.superclass.prototype,f=Object.keys(l);if(d){if(l.toString!=Object.prototype.toString){f.push("toString")}if(l.valueOf!=Object.prototype.valueOf){f.push("valueOf")}}for(var e=0,h=f.length;e<h;e++){var k=f[e],j=l[k];if(g&&Object.isFunction(j)&&j.argumentNames()[0]=="$super"){var m=j;j=(function(i){return function(){return g[i].apply(this,arguments)}})(k).wrap(m);j.valueOf=m.valueOf.bind(m);j.toString=m.toString.bind(m)}this.prototype[k]=j}return this}return{create:b,Methods:{addMethods:c}}})();(function(){var C=Object.prototype.toString,B="Null",o="Undefined",v="Boolean",f="Number",s="String",H="Object",t="[object Function]",y="[object Boolean]",g="[object Number]",l="[object String]",h="[object Array]",x="[object Date]",i=window.JSON&&typeof JSON.stringify==="function"&&JSON.stringify(0)==="0"&&typeof JSON.stringify(Prototype.K)==="undefined";function k(J){switch(J){case null:return B;case (void 0):return o}var I=typeof J;switch(I){case"boolean":return v;case"number":return f;case"string":return s}return H}function z(I,K){for(var J in K){I[J]=K[J]}return I}function G(I){try{if(c(I)){return"undefined"}if(I===null){return"null"}return I.inspect?I.inspect():String(I)}catch(J){if(J instanceof RangeError){return"..."}throw J}}function D(I){return F("",{"":I},[])}function F(R,O,P){var Q=O[R],N=typeof Q;if(k(Q)===H&&typeof Q.toJSON==="function"){Q=Q.toJSON(R)}var K=C.call(Q);switch(K){case g:case y:case l:Q=Q.valueOf()}switch(Q){case null:return"null";case true:return"true";case false:return"false"}N=typeof Q;switch(N){case"string":return Q.inspect(true);case"number":return isFinite(Q)?String(Q):"null";case"object":for(var J=0,I=P.length;J<I;J++){if(P[J]===Q){throw new TypeError()}}P.push(Q);var M=[];if(K===h){for(var J=0,I=Q.length;J<I;J++){var L=F(J,Q,P);M.push(typeof L==="undefined"?"null":L)}M="["+M.join(",")+"]"}else{var S=Object.keys(Q);for(var J=0,I=S.length;J<I;J++){var R=S[J],L=F(R,Q,P);if(typeof L!=="undefined"){M.push(R.inspect(true)+":"+L)}}M="{"+M.join(",")+"}"}P.pop();return M}}function w(I){return JSON.stringify(I)}function j(I){return $H(I).toQueryString()}function p(I){return I&&I.toHTML?I.toHTML():String.interpret(I)}function r(I){if(k(I)!==H){throw new TypeError()}var J=[];for(var K in I){if(I.hasOwnProperty(K)){J.push(K)}}return J}function d(I){var J=[];for(var K in I){J.push(I[K])}return J}function A(I){return z({},I)}function u(I){return !!(I&&I.nodeType==1)}function m(I){return C.call(I)===h}var b=(typeof Array.isArray=="function")&&Array.isArray([])&&!Array.isArray({});if(b){m=Array.isArray}function e(I){return I instanceof Hash}function a(I){return C.call(I)===t}function n(I){return C.call(I)===l}function q(I){return C.call(I)===g}function E(I){return C.call(I)===x}function c(I){return typeof I==="undefined"}z(Object,{extend:z,inspect:G,toJSON:i?w:D,toQueryString:j,toHTML:p,keys:Object.keys||r,values:d,clone:A,isElement:u,isArray:m,isHash:e,isFunction:a,isString:n,isNumber:q,isDate:E,isUndefined:c})})();Object.extend(Function.prototype,(function(){var k=Array.prototype.slice;function d(o,l){var n=o.length,m=l.length;while(m--){o[n+m]=l[m]}return o}function i(m,l){m=k.call(m,0);return d(m,l)}function g(){var l=this.toString().match(/^[\s\(]*function[^(]*\(([^)]*)\)/)[1].replace(/\/\/.*?[\r\n]|\/\*(?:.|[\r\n])*?\*\//g,"").replace(/\s+/g,"").split(",");return l.length==1&&!l[0]?[]:l}function h(n){if(arguments.length<2&&Object.isUndefined(arguments[0])){return this}var l=this,m=k.call(arguments,1);return function(){var o=i(m,arguments);return l.apply(n,o)}}function f(n){var l=this,m=k.call(arguments,1);return function(p){var o=d([p||window.event],m);return l.apply(n,o)}}function j(){if(!arguments.length){return this}var l=this,m=k.call(arguments,0);return function(){var n=i(m,arguments);return l.apply(this,n)}}function e(n){var l=this,m=k.call(arguments,1);n=n*1000;return window.setTimeout(function(){return l.apply(l,m)},n)}function a(){var l=d([0.01],arguments);return this.delay.apply(this,l)}function c(m){var l=this;return function(){var n=d([l.bind(this)],arguments);return m.apply(this,n)}}function b(){if(this._methodized){return this._methodized}var l=this;return this._methodized=function(){var m=d([this],arguments);return l.apply(null,m)}}return{argumentNames:g,bind:h,bindAsEventListener:f,curry:j,delay:e,defer:a,wrap:c,methodize:b}})());(function(c){function b(){return this.getUTCFullYear()+"-"+(this.getUTCMonth()+1).toPaddedString(2)+"-"+this.getUTCDate().toPaddedString(2)+"T"+this.getUTCHours().toPaddedString(2)+":"+this.getUTCMinutes().toPaddedString(2)+":"+this.getUTCSeconds().toPaddedString(2)+"Z"}function a(){return this.toISOString()}if(!c.toISOString){c.toISOString=b}if(!c.toJSON){c.toJSON=a}})(Date.prototype);RegExp.prototype.match=RegExp.prototype.test;RegExp.escape=function(a){return String(a).replace(/([.*+?^=!:()|[\]\/\\])/g,"\\$1")};var PeriodicalExecuter=Class.create({initialize:function(b,a){this.callback=b;this.frequency=a;this.currentlyExecuting=false;this.registerCallback()},registerCallback:function(){this.timer=setInterval(this.onTimerEvent.bind(this),this.frequency*1000)},execute:function(){this.callback(this)},stop:function(){if(!this.timer){return}clearInterval(this.timer);this.timer=null},onTimerEvent:function(){if(!this.currentlyExecuting){try{this.currentlyExecuting=true;this.execute();this.currentlyExecuting=false}catch(a){this.currentlyExecuting=false;throw a}}}});Object.extend(String,{interpret:function(a){return a==null?"":String(a)},specialChar:{"\b":"\\b","\t":"\\t","\n":"\\n","\f":"\\f","\r":"\\r","\\":"\\\\"}});Object.extend(String.prototype,(function(){var NATIVE_JSON_PARSE_SUPPORT=window.JSON&&typeof JSON.parse==="function"&&JSON.parse('{"test": true}').test;function prepareReplacement(replacement){if(Object.isFunction(replacement)){return replacement}var template=new Template(replacement);return function(match){return template.evaluate(match)}}function gsub(pattern,replacement){var result="",source=this,match;replacement=prepareReplacement(replacement);if(Object.isString(pattern)){pattern=RegExp.escape(pattern)}if(!(pattern.length||pattern.source)){replacement=replacement("");return replacement+source.split("").join(replacement)+replacement}while(source.length>0){if(match=source.match(pattern)){result+=source.slice(0,match.index);result+=String.interpret(replacement(match));source=source.slice(match.index+match[0].length)}else{result+=source,source=""}}return result}function sub(pattern,replacement,count){replacement=prepareReplacement(replacement);count=Object.isUndefined(count)?1:count;return this.gsub(pattern,function(match){if(--count<0){return match[0]}return replacement(match)})}function scan(pattern,iterator){this.gsub(pattern,iterator);return String(this)}function truncate(length,truncation){length=length||30;truncation=Object.isUndefined(truncation)?"...":truncation;return this.length>length?this.slice(0,length-truncation.length)+truncation:String(this)}function strip(){return this.replace(/^\s+/,"").replace(/\s+$/,"")}function stripTags(){return this.replace(/<\w+(\s+("[^"]*"|'[^']*'|[^>])+)?>|<\/\w+>/gi,"")}function stripScripts(){return this.replace(new RegExp(Prototype.ScriptFragment,"img"),"")}function extractScripts(){var matchAll=new RegExp(Prototype.ScriptFragment,"img"),matchOne=new RegExp(Prototype.ScriptFragment,"im");return(this.match(matchAll)||[]).map(function(scriptTag){return(scriptTag.match(matchOne)||["",""])[1]})}function evalScripts(){return this.extractScripts().map(function(script){return eval(script)})}function escapeHTML(){return this.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function unescapeHTML(){return this.stripTags().replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&")}function toQueryParams(separator){var match=this.strip().match(/([^?#]*)(#.*)?$/);if(!match){return{}}return match[1].split(separator||"&").inject({},function(hash,pair){if((pair=pair.split("="))[0]){var key=decodeURIComponent(pair.shift()),value=pair.length>1?pair.join("="):pair[0];if(value!=undefined){value=decodeURIComponent(value)}if(key in hash){if(!Object.isArray(hash[key])){hash[key]=[hash[key]]}hash[key].push(value)}else{hash[key]=value}}return hash})}function toArray(){return this.split("")}function succ(){return this.slice(0,this.length-1)+String.fromCharCode(this.charCodeAt(this.length-1)+1)}function times(count){return count<1?"":new Array(count+1).join(this)}function camelize(){return this.replace(/-+(.)?/g,function(match,chr){return chr?chr.toUpperCase():""})}function capitalize(){return this.charAt(0).toUpperCase()+this.substring(1).toLowerCase()}function underscore(){return this.replace(/::/g,"/").replace(/([A-Z]+)([A-Z][a-z])/g,"$1_$2").replace(/([a-z\d])([A-Z])/g,"$1_$2").replace(/-/g,"_").toLowerCase()}function dasherize(){return this.replace(/_/g,"-")}function inspect(useDoubleQuotes){var escapedString=this.replace(/[\x00-\x1f\\]/g,function(character){if(character in String.specialChar){return String.specialChar[character]}return"\\u00"+character.charCodeAt().toPaddedString(2,16)});if(useDoubleQuotes){return'"'+escapedString.replace(/"/g,'\\"')+'"'}return"'"+escapedString.replace(/'/g,"\\'")+"'"}function unfilterJSON(filter){return this.replace(filter||Prototype.JSONFilter,"$1")}function isJSON(){var str=this;if(str.blank()){return false}str=str.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,"@");str=str.replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,"]");str=str.replace(/(?:^|:|,)(?:\s*\[)+/g,"");return(/^[\],:{}\s]*$/).test(str)}function evalJSON(sanitize){var json=this.unfilterJSON(),cx=/[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;if(cx.test(json)){json=json.replace(cx,function(a){return"\\u"+("0000"+a.charCodeAt(0).toString(16)).slice(-4)})}try{if(!sanitize||json.isJSON()){return eval("("+json+")")}}catch(e){}throw new SyntaxError("Badly formed JSON string: "+this.inspect())}function parseJSON(){var json=this.unfilterJSON();return JSON.parse(json)}function include(pattern){return this.indexOf(pattern)>-1}function startsWith(pattern){return this.lastIndexOf(pattern,0)===0}function endsWith(pattern){var d=this.length-pattern.length;return d>=0&&this.indexOf(pattern,d)===d}function empty(){return this==""}function blank(){return/^\s*$/.test(this)}function interpolate(object,pattern){return new Template(this,pattern).evaluate(object)}return{gsub:gsub,sub:sub,scan:scan,truncate:truncate,strip:String.prototype.trim||strip,stripTags:stripTags,stripScripts:stripScripts,extractScripts:extractScripts,evalScripts:evalScripts,escapeHTML:escapeHTML,unescapeHTML:unescapeHTML,toQueryParams:toQueryParams,parseQuery:toQueryParams,toArray:toArray,succ:succ,times:times,camelize:camelize,capitalize:capitalize,underscore:underscore,dasherize:dasherize,inspect:inspect,unfilterJSON:unfilterJSON,isJSON:isJSON,evalJSON:NATIVE_JSON_PARSE_SUPPORT?parseJSON:evalJSON,include:include,startsWith:startsWith,endsWith:endsWith,empty:empty,blank:blank,interpolate:interpolate}})());var Template=Class.create({initialize:function(a,b){this.template=a.toString();this.pattern=b||Template.Pattern},evaluate:function(a){if(a&&Object.isFunction(a.toTemplateReplacements)){a=a.toTemplateReplacements()}return this.template.gsub(this.pattern,function(d){if(a==null){return(d[1]+"")}var f=d[1]||"";if(f=="\\"){return d[2]}var b=a,g=d[3],e=/^([^.[]+|\[((?:.*?[^\\])?)\])(\.|\[|$)/;d=e.exec(g);if(d==null){return f}while(d!=null){var c=d[1].startsWith("[")?d[2].replace(/\\\\]/g,"]"):d[1];b=b[c];if(null==b||""==d[3]){break}g=g.substring("["==d[3]?d[1].length:d[0].length);d=e.exec(g)}return f+String.interpret(b)})}});Template.Pattern=/(^|.|\r|\n)(#\{(.*?)\})/;var $break={};var Enumerable=(function(){function c(y,x){var w=0;try{this._each(function(A){y.call(x,A,w++)})}catch(z){if(z!=$break){throw z}}return this}function r(z,y,x){var w=-z,A=[],B=this.toArray();if(z<1){return B}while((w+=z)<B.length){A.push(B.slice(w,w+z))}return A.collect(y,x)}function b(y,x){y=y||Prototype.K;var w=true;this.each(function(A,z){w=w&&!!y.call(x,A,z);if(!w){throw $break}});return w}function i(y,x){y=y||Prototype.K;var w=false;this.each(function(A,z){if(w=!!y.call(x,A,z)){throw $break}});return w}function j(y,x){y=y||Prototype.K;var w=[];this.each(function(A,z){w.push(y.call(x,A,z))});return w}function t(y,x){var w;this.each(function(A,z){if(y.call(x,A,z)){w=A;throw $break}});return w}function h(y,x){var w=[];this.each(function(A,z){if(y.call(x,A,z)){w.push(A)}});return w}function g(z,y,x){y=y||Prototype.K;var w=[];if(Object.isString(z)){z=new RegExp(RegExp.escape(z))}this.each(function(B,A){if(z.match(B)){w.push(y.call(x,B,A))}});return w}function a(w){if(Object.isFunction(this.indexOf)){if(this.indexOf(w)!=-1){return true}}var x=false;this.each(function(y){if(y==w){x=true;throw $break}});return x}function q(x,w){w=Object.isUndefined(w)?null:w;return this.eachSlice(x,function(y){while(y.length<x){y.push(w)}return y})}function l(w,y,x){this.each(function(A,z){w=y.call(x,w,A,z)});return w}function v(x){var w=$A(arguments).slice(1);return this.map(function(y){return y[x].apply(y,w)})}function p(y,x){y=y||Prototype.K;var w;this.each(function(A,z){A=y.call(x,A,z);if(w==null||A>=w){w=A}});return w}function n(y,x){y=y||Prototype.K;var w;this.each(function(A,z){A=y.call(x,A,z);if(w==null||A<w){w=A}});return w}function e(z,x){z=z||Prototype.K;var y=[],w=[];this.each(function(B,A){(z.call(x,B,A)?y:w).push(B)});return[y,w]}function f(x){var w=[];this.each(function(y){w.push(y[x])});return w}function d(y,x){var w=[];this.each(function(A,z){if(!y.call(x,A,z)){w.push(A)}});return w}function m(x,w){return this.map(function(z,y){return{value:z,criteria:x.call(w,z,y)}}).sort(function(B,A){var z=B.criteria,y=A.criteria;return z<y?-1:z>y?1:0}).pluck("value")}function o(){return this.map()}function s(){var x=Prototype.K,w=$A(arguments);if(Object.isFunction(w.last())){x=w.pop()}var y=[this].concat(w).map($A);return this.map(function(A,z){return x(y.pluck(z))})}function k(){return this.toArray().length}function u(){return"#<Enumerable:"+this.toArray().inspect()+">"}return{each:c,eachSlice:r,all:b,every:b,any:i,some:i,collect:j,map:j,detect:t,findAll:h,select:h,filter:h,grep:g,include:a,member:a,inGroupsOf:q,inject:l,invoke:v,max:p,min:n,partition:e,pluck:f,reject:d,sortBy:m,toArray:o,entries:o,zip:s,size:k,inspect:u,find:t}})();function $A(c){if(!c){return[]}if("toArray" in Object(c)){return c.toArray()}var b=c.length||0,a=new Array(b);while(b--){a[b]=c[b]}return a}function $w(a){if(!Object.isString(a)){return[]}a=a.strip();return a?a.split(/\s+/):[]}Array.from=$A;(function(){var r=Array.prototype,m=r.slice,o=r.forEach;function b(w,v){for(var u=0,x=this.length>>>0;u<x;u++){if(u in this){w.call(v,this[u],u,this)}}}if(!o){o=b}function l(){this.length=0;return this}function d(){return this[0]}function g(){return this[this.length-1]}function i(){return this.select(function(u){return u!=null})}function t(){return this.inject([],function(v,u){if(Object.isArray(u)){return v.concat(u.flatten())}v.push(u);return v})}function h(){var u=m.call(arguments,0);return this.select(function(v){return !u.include(v)})}function f(u){return(u===false?this.toArray():this)._reverse()}function k(u){return this.inject([],function(x,w,v){if(0==v||(u?x.last()!=w:!x.include(w))){x.push(w)}return x})}function p(u){return this.uniq().findAll(function(v){return u.detect(function(w){return v===w})})}function q(){return m.call(this,0)}function j(){return this.length}function s(){return"["+this.map(Object.inspect).join(", ")+"]"}function a(w,u){u||(u=0);var v=this.length;if(u<0){u=v+u}for(;u<v;u++){if(this[u]===w){return u}}return -1}function n(v,u){u=isNaN(u)?this.length:(u<0?this.length+u:u)+1;var w=this.slice(0,u).reverse().indexOf(v);return(w<0)?w:u-w-1}function c(){var z=m.call(this,0),x;for(var v=0,w=arguments.length;v<w;v++){x=arguments[v];if(Object.isArray(x)&&!("callee" in x)){for(var u=0,y=x.length;u<y;u++){z.push(x[u])}}else{z.push(x)}}return z}Object.extend(r,Enumerable);if(!r._reverse){r._reverse=r.reverse}Object.extend(r,{_each:o,clear:l,first:d,last:g,compact:i,flatten:t,without:h,reverse:f,uniq:k,intersect:p,clone:q,toArray:q,size:j,inspect:s});var e=(function(){return[].concat(arguments)[0][0]!==1})(1,2);if(e){r.concat=c}if(!r.indexOf){r.indexOf=a}if(!r.lastIndexOf){r.lastIndexOf=n}})();function $H(a){return new Hash(a)}var Hash=Class.create(Enumerable,(function(){function e(p){this._object=Object.isHash(p)?p.toObject():Object.clone(p)}function f(q){for(var p in this._object){var r=this._object[p],s=[p,r];s.key=p;s.value=r;q(s)}}function j(p,q){return this._object[p]=q}function c(p){if(this._object[p]!==Object.prototype[p]){return this._object[p]}}function m(p){var q=this._object[p];delete this._object[p];return q}function o(){return Object.clone(this._object)}function n(){return this.pluck("key")}function l(){return this.pluck("value")}function g(q){var p=this.detect(function(r){return r.value===q});return p&&p.key}function i(p){return this.clone().update(p)}function d(p){return new Hash(p).inject(this,function(q,r){q.set(r.key,r.value);return q})}function b(p,q){if(Object.isUndefined(q)){return p}return p+"="+encodeURIComponent(String.interpret(q))}function a(){return this.inject([],function(t,w){var s=encodeURIComponent(w.key),q=w.value;if(q&&typeof q=="object"){if(Object.isArray(q)){var v=[];for(var r=0,p=q.length,u;r<p;r++){u=q[r];v.push(b(s,u))}return t.concat(v)}}else{t.push(b(s,q))}return t}).join("&")}function k(){return"#<Hash:{"+this.map(function(p){return p.map(Object.inspect).join(": ")}).join(", ")+"}>"}function h(){return new Hash(this)}return{initialize:e,_each:f,set:j,get:c,unset:m,toObject:o,toTemplateReplacements:o,keys:n,values:l,index:g,merge:i,update:d,toQueryString:a,inspect:k,toJSON:o,clone:h}})());Hash.from=$H;Object.extend(Number.prototype,(function(){function d(){return this.toPaddedString(2,16)}function b(){return this+1}function h(j,i){$R(0,this,true).each(j,i);return this}function g(k,j){var i=this.toString(j||10);return"0".times(k-i.length)+i}function a(){return Math.abs(this)}function c(){return Math.round(this)}function e(){return Math.ceil(this)}function f(){return Math.floor(this)}return{toColorPart:d,succ:b,times:h,toPaddedString:g,abs:a,round:c,ceil:e,floor:f}})());function $R(c,a,b){return new ObjectRange(c,a,b)}var ObjectRange=Class.create(Enumerable,(function(){function b(f,d,e){this.start=f;this.end=d;this.exclusive=e}function c(d){var e=this.start;while(this.include(e)){d(e);e=e.succ()}}function a(d){if(d<this.start){return false}if(this.exclusive){return d<this.end}return d<=this.end}return{initialize:b,_each:c,include:a}})());var Ajax={getTransport:function(){return Try.these(function(){return new XMLHttpRequest()},function(){return new ActiveXObject("Msxml2.XMLHTTP")},function(){return new ActiveXObject("Microsoft.XMLHTTP")})||false},activeRequestCount:0};Ajax.Responders={responders:[],_each:function(a){this.responders._each(a)},register:function(a){if(!this.include(a)){this.responders.push(a)}},unregister:function(a){this.responders=this.responders.without(a)},dispatch:function(d,b,c,a){this.each(function(f){if(Object.isFunction(f[d])){try{f[d].apply(f,[b,c,a])}catch(g){}}})}};Object.extend(Ajax.Responders,Enumerable);Ajax.Responders.register({onCreate:function(){Ajax.activeRequestCount++},onComplete:function(){Ajax.activeRequestCount--}});Ajax.Base=Class.create({initialize:function(a){this.options={method:"post",asynchronous:true,contentType:"application/x-www-form-urlencoded",encoding:"UTF-8",parameters:"",evalJSON:true,evalJS:true};Object.extend(this.options,a||{});this.options.method=this.options.method.toLowerCase();if(Object.isHash(this.options.parameters)){this.options.parameters=this.options.parameters.toObject()}}});Ajax.Request=Class.create(Ajax.Base,{_complete:false,initialize:function($super,b,a){$super(a);this.transport=Ajax.getTransport();this.request(b)},request:function(b){this.url=b;this.method=this.options.method;var d=Object.isString(this.options.parameters)?this.options.parameters:Object.toQueryString(this.options.parameters);if(!["get","post"].include(this.method)){d+=(d?"&":"")+"_method="+this.method;this.method="post"}if(d&&this.method==="get"){this.url+=(this.url.include("?")?"&":"?")+d}this.parameters=d.toQueryParams();try{var a=new Ajax.Response(this);if(this.options.onCreate){this.options.onCreate(a)}Ajax.Responders.dispatch("onCreate",this,a);this.transport.open(this.method.toUpperCase(),this.url,this.options.asynchronous);if(this.options.asynchronous){this.respondToReadyState.bind(this).defer(1)}this.transport.onreadystatechange=this.onStateChange.bind(this);this.setRequestHeaders();this.body=this.method=="post"?(this.options.postBody||d):null;this.transport.send(this.body);if(!this.options.asynchronous&&this.transport.overrideMimeType){this.onStateChange()}}catch(c){this.dispatchException(c)}},onStateChange:function(){var a=this.transport.readyState;if(a>1&&!((a==4)&&this._complete)){this.respondToReadyState(this.transport.readyState)}},setRequestHeaders:function(){var e={"X-Requested-With":"XMLHttpRequest","X-Prototype-Version":Prototype.Version,Accept:"text/javascript, text/html, application/xml, text/xml, */*"};if(this.method=="post"){e["Content-type"]=this.options.contentType+(this.options.encoding?"; charset="+this.options.encoding:"");if(this.transport.overrideMimeType&&(navigator.userAgent.match(/Gecko\/(\d{4})/)||[0,2005])[1]<2005){e.Connection="close"}}if(typeof this.options.requestHeaders=="object"){var c=this.options.requestHeaders;if(Object.isFunction(c.push)){for(var b=0,d=c.length;b<d;b+=2){e[c[b]]=c[b+1]}}else{$H(c).each(function(f){e[f.key]=f.value})}}for(var a in e){this.transport.setRequestHeader(a,e[a])}},success:function(){var a=this.getStatus();return !a||(a>=200&&a<300)||a==304},getStatus:function(){try{if(this.transport.status===1223){return 204}return this.transport.status||0}catch(a){return 0}},respondToReadyState:function(a){var c=Ajax.Request.Events[a],b=new Ajax.Response(this);if(c=="Complete"){try{this._complete=true;(this.options["on"+b.status]||this.options["on"+(this.success()?"Success":"Failure")]||Prototype.emptyFunction)(b,b.headerJSON)}catch(d){this.dispatchException(d)}var f=b.getHeader("Content-type");if(this.options.evalJS=="force"||(this.options.evalJS&&this.isSameOrigin()&&f&&f.match(/^\s*(text|application)\/(x-)?(java|ecma)script(;.*)?\s*$/i))){this.evalResponse()}}try{(this.options["on"+c]||Prototype.emptyFunction)(b,b.headerJSON);Ajax.Responders.dispatch("on"+c,this,b,b.headerJSON)}catch(d){this.dispatchException(d)}if(c=="Complete"){this.transport.onreadystatechange=Prototype.emptyFunction}},isSameOrigin:function(){var a=this.url.match(/^\s*https?:\/\/[^\/]*/);return !a||(a[0]=="#{protocol}//#{domain}#{port}".interpolate({protocol:location.protocol,domain:document.domain,port:location.port?":"+location.port:""}))},getHeader:function(a){try{return this.transport.getResponseHeader(a)||null}catch(b){return null}},evalResponse:function(){try{return eval((this.transport.responseText||"").unfilterJSON())}catch(e){this.dispatchException(e)}},dispatchException:function(a){(this.options.onException||Prototype.emptyFunction)(this,a);Ajax.Responders.dispatch("onException",this,a)}});Ajax.Request.Events=["Uninitialized","Loading","Loaded","Interactive","Complete"];Ajax.Response=Class.create({initialize:function(c){this.request=c;var d=this.transport=c.transport,a=this.readyState=d.readyState;if((a>2&&!Prototype.Browser.IE)||a==4){this.status=this.getStatus();this.statusText=this.getStatusText();this.responseText=String.interpret(d.responseText);this.headerJSON=this._getHeaderJSON()}if(a==4){var b=d.responseXML;this.responseXML=Object.isUndefined(b)?null:b;this.responseJSON=this._getResponseJSON()}},status:0,statusText:"",getStatus:Ajax.Request.prototype.getStatus,getStatusText:function(){try{return this.transport.statusText||""}catch(a){return""}},getHeader:Ajax.Request.prototype.getHeader,getAllHeaders:function(){try{return this.getAllResponseHeaders()}catch(a){return null}},getResponseHeader:function(a){return this.transport.getResponseHeader(a)},getAllResponseHeaders:function(){return this.transport.getAllResponseHeaders()},_getHeaderJSON:function(){var a=this.getHeader("X-JSON");if(!a){return null}a=decodeURIComponent(escape(a));try{return a.evalJSON(this.request.options.sanitizeJSON||!this.request.isSameOrigin())}catch(b){this.request.dispatchException(b)}},_getResponseJSON:function(){var a=this.request.options;if(!a.evalJSON||(a.evalJSON!="force"&&!(this.getHeader("Content-type")||"").include("application/json"))||this.responseText.blank()){return null}try{return this.responseText.evalJSON(a.sanitizeJSON||!this.request.isSameOrigin())}catch(b){this.request.dispatchException(b)}}});Ajax.Updater=Class.create(Ajax.Request,{initialize:function($super,a,c,b){this.container={success:(a.success||a),failure:(a.failure||(a.success?null:a))};b=Object.clone(b);var d=b.onComplete;b.onComplete=(function(e,f){this.updateContent(e.responseText);if(Object.isFunction(d)){d(e,f)}}).bind(this);$super(c,b)},updateContent:function(d){var c=this.container[this.success()?"success":"failure"],a=this.options;if(!a.evalScripts){d=d.stripScripts()}if(c=$(c)){if(a.insertion){if(Object.isString(a.insertion)){var b={};b[a.insertion]=d;c.insert(b)}else{a.insertion(c,d)}}else{c.update(d)}}}});Ajax.PeriodicalUpdater=Class.create(Ajax.Base,{initialize:function($super,a,c,b){$super(b);this.onComplete=this.options.onComplete;this.frequency=(this.options.frequency||2);this.decay=(this.options.decay||1);this.updater={};this.container=a;this.url=c;this.start()},start:function(){this.options.onComplete=this.updateComplete.bind(this);this.onTimerEvent()},stop:function(){this.updater.options.onComplete=undefined;clearTimeout(this.timer);(this.onComplete||Prototype.emptyFunction).apply(this,arguments)},updateComplete:function(a){if(this.options.decay){this.decay=(a.responseText==this.lastText?this.decay*this.options.decay:1);this.lastText=a.responseText}this.timer=this.onTimerEvent.bind(this).delay(this.decay*this.frequency)},onTimerEvent:function(){this.updater=new Ajax.Updater(this.container,this.url,this.options)}});function $(b){if(arguments.length>1){for(var a=0,d=[],c=arguments.length;a<c;a++){d.push($(arguments[a]))}return d}if(Object.isString(b)){b=document.getElementById(b)}return Element.extend(b)}if(Prototype.BrowserFeatures.XPath){document._getElementsByXPath=function(f,a){var c=[];var e=document.evaluate(f,$(a)||document,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);for(var b=0,d=e.snapshotLength;b<d;b++){c.push(Element.extend(e.snapshotItem(b)))}return c}}if(!Node){var Node={}}if(!Node.ELEMENT_NODE){Object.extend(Node,{ELEMENT_NODE:1,ATTRIBUTE_NODE:2,TEXT_NODE:3,CDATA_SECTION_NODE:4,ENTITY_REFERENCE_NODE:5,ENTITY_NODE:6,PROCESSING_INSTRUCTION_NODE:7,COMMENT_NODE:8,DOCUMENT_NODE:9,DOCUMENT_TYPE_NODE:10,DOCUMENT_FRAGMENT_NODE:11,NOTATION_NODE:12})}(function(c){function d(f,e){if(f==="select"){return false}if("type" in e){return false}return true}var b=(function(){try{var e=document.createElement('<input name="x">');return e.tagName.toLowerCase()==="input"&&e.name==="x"}catch(f){return false}})();var a=c.Element;c.Element=function(g,f){f=f||{};g=g.toLowerCase();var e=Element.cache;if(b&&f.name){g="<"+g+' name="'+f.name+'">';delete f.name;return Element.writeAttribute(document.createElement(g),f)}if(!e[g]){e[g]=Element.extend(document.createElement(g))}var h=d(g,f)?e[g].cloneNode(false):document.createElement(g);return Element.writeAttribute(h,f)};Object.extend(c.Element,a||{});if(a){c.Element.prototype=a.prototype}})(this);Element.idCounter=1;Element.cache={};Element._purgeElement=function(b){var a=b._prototypeUID;if(a){Element.stopObserving(b);b._prototypeUID=void 0;delete Element.Storage[a]}};Element.Methods={visible:function(a){return $(a).style.display!="none"},toggle:function(a){a=$(a);Element[Element.visible(a)?"hide":"show"](a);return a},hide:function(a){a=$(a);a.style.display="none";return a},show:function(a){a=$(a);a.style.display="";return a},remove:function(a){a=$(a);a.parentNode.removeChild(a);return a},update:(function(){var d=(function(){var g=document.createElement("select"),h=true;g.innerHTML='<option value="test">test</option>';if(g.options&&g.options[0]){h=g.options[0].nodeName.toUpperCase()!=="OPTION"}g=null;return h})();var b=(function(){try{var g=document.createElement("table");if(g&&g.tBodies){g.innerHTML="<tbody><tr><td>test</td></tr></tbody>";var i=typeof g.tBodies[0]=="undefined";g=null;return i}}catch(h){return true}})();var a=(function(){try{var g=document.createElement("div");g.innerHTML="<link>";var i=(g.childNodes.length===0);g=null;return i}catch(h){return true}})();var c=d||b||a;var f=(function(){var g=document.createElement("script"),i=false;try{g.appendChild(document.createTextNode(""));i=!g.firstChild||g.firstChild&&g.firstChild.nodeType!==3}catch(h){i=true}g=null;return i})();function e(l,m){l=$(l);var g=Element._purgeElement;var n=l.getElementsByTagName("*"),k=n.length;while(k--){g(n[k])}if(m&&m.toElement){m=m.toElement()}if(Object.isElement(m)){return l.update().insert(m)}m=Object.toHTML(m);var j=l.tagName.toUpperCase();if(j==="SCRIPT"&&f){l.text=m;return l}if(c){if(j in Element._insertionTranslations.tags){while(l.firstChild){l.removeChild(l.firstChild)}Element._getContentFromAnonymousElement(j,m.stripScripts()).each(function(i){l.appendChild(i)})}else{if(a&&Object.isString(m)&&m.indexOf("<link")>-1){while(l.firstChild){l.removeChild(l.firstChild)}var h=Element._getContentFromAnonymousElement(j,m.stripScripts(),true);h.each(function(i){l.appendChild(i)})}else{l.innerHTML=m.stripScripts()}}}else{l.innerHTML=m.stripScripts()}m.evalScripts.bind(m).defer();return l}return e})(),replace:function(b,c){b=$(b);if(c&&c.toElement){c=c.toElement()}else{if(!Object.isElement(c)){c=Object.toHTML(c);var a=b.ownerDocument.createRange();a.selectNode(b);c.evalScripts.bind(c).defer();c=a.createContextualFragment(c.stripScripts())}}b.parentNode.replaceChild(c,b);return b},insert:function(c,e){c=$(c);if(Object.isString(e)||Object.isNumber(e)||Object.isElement(e)||(e&&(e.toElement||e.toHTML))){e={bottom:e}}var d,f,b,g;for(var a in e){d=e[a];a=a.toLowerCase();f=Element._insertionTranslations[a];if(d&&d.toElement){d=d.toElement()}if(Object.isElement(d)){f(c,d);continue}d=Object.toHTML(d);b=((a=="before"||a=="after")?c.parentNode:c).tagName.toUpperCase();g=Element._getContentFromAnonymousElement(b,d.stripScripts());if(a=="top"||a=="after"){g.reverse()}g.each(f.curry(c));d.evalScripts.bind(d).defer()}return c},wrap:function(b,c,a){b=$(b);if(Object.isElement(c)){$(c).writeAttribute(a||{})}else{if(Object.isString(c)){c=new Element(c,a)}else{c=new Element("div",c)}}if(b.parentNode){b.parentNode.replaceChild(c,b)}c.appendChild(b);return c},inspect:function(b){b=$(b);var a="<"+b.tagName.toLowerCase();$H({id:"id",className:"class"}).each(function(f){var e=f.first(),c=f.last(),d=(b[e]||"").toString();if(d){a+=" "+c+"="+d.inspect(true)}});return a+">"},recursivelyCollect:function(a,c,d){a=$(a);d=d||-1;var b=[];while(a=a[c]){if(a.nodeType==1){b.push(Element.extend(a))}if(b.length==d){break}}return b},ancestors:function(a){return Element.recursivelyCollect(a,"parentNode")},descendants:function(a){return Element.select(a,"*")},firstDescendant:function(a){a=$(a).firstChild;while(a&&a.nodeType!=1){a=a.nextSibling}return $(a)},immediateDescendants:function(b){var a=[],c=$(b).firstChild;while(c){if(c.nodeType===1){a.push(Element.extend(c))}c=c.nextSibling}return a},previousSiblings:function(a,b){return Element.recursivelyCollect(a,"previousSibling")},nextSiblings:function(a){return Element.recursivelyCollect(a,"nextSibling")},siblings:function(a){a=$(a);return Element.previousSiblings(a).reverse().concat(Element.nextSiblings(a))},match:function(b,a){b=$(b);if(Object.isString(a)){return Prototype.Selector.match(b,a)}return a.match(b)},up:function(b,d,a){b=$(b);if(arguments.length==1){return $(b.parentNode)}var c=Element.ancestors(b);return Object.isNumber(d)?c[d]:Prototype.Selector.find(c,d,a)},down:function(b,c,a){b=$(b);if(arguments.length==1){return Element.firstDescendant(b)}return Object.isNumber(c)?Element.descendants(b)[c]:Element.select(b,c)[a||0]},previous:function(b,c,a){b=$(b);if(Object.isNumber(c)){a=c,c=false}if(!Object.isNumber(a)){a=0}if(c){return Prototype.Selector.find(b.previousSiblings(),c,a)}else{return b.recursivelyCollect("previousSibling",a+1)[a]}},next:function(b,d,a){b=$(b);if(Object.isNumber(d)){a=d,d=false}if(!Object.isNumber(a)){a=0}if(d){return Prototype.Selector.find(b.nextSiblings(),d,a)}else{var c=Object.isNumber(a)?a+1:1;return b.recursivelyCollect("nextSibling",a+1)[a]}},select:function(a){a=$(a);var b=Array.prototype.slice.call(arguments,1).join(", ");return Prototype.Selector.select(b,a)},adjacent:function(a){a=$(a);var b=Array.prototype.slice.call(arguments,1).join(", ");return Prototype.Selector.select(b,a.parentNode).without(a)},identify:function(a){a=$(a);var b=Element.readAttribute(a,"id");if(b){return b}do{b="anonymous_element_"+Element.idCounter++}while($(b));Element.writeAttribute(a,"id",b);return b},readAttribute:function(c,a){c=$(c);if(Prototype.Browser.IE){var b=Element._attributeTranslations.read;if(b.values[a]){return b.values[a](c,a)}if(b.names[a]){a=b.names[a]}if(a.include(":")){return(!c.attributes||!c.attributes[a])?null:c.attributes[a].value}}return c.getAttribute(a)},writeAttribute:function(e,c,f){e=$(e);var b={},d=Element._attributeTranslations.write;if(typeof c=="object"){b=c}else{b[c]=Object.isUndefined(f)?true:f}for(var a in b){c=d.names[a]||a;f=b[a];if(d.values[a]){c=d.values[a](e,f)}if(f===false||f===null){e.removeAttribute(c)}else{if(f===true){e.setAttribute(c,c)}else{e.setAttribute(c,f)}}}return e},getHeight:function(a){return Element.getDimensions(a).height},getWidth:function(a){return Element.getDimensions(a).width},classNames:function(a){return new Element.ClassNames(a)},hasClassName:function(a,b){if(!(a=$(a))){return}var c=a.className;return(c.length>0&&(c==b||new RegExp("(^|\\s)"+b+"(\\s|$)").test(c)))},addClassName:function(a,b){if(!(a=$(a))){return}if(!Element.hasClassName(a,b)){a.className+=(a.className?" ":"")+b}return a},removeClassName:function(a,b){if(!(a=$(a))){return}a.className=a.className.replace(new RegExp("(^|\\s+)"+b+"(\\s+|$)")," ").strip();return a},toggleClassName:function(a,b){if(!(a=$(a))){return}return Element[Element.hasClassName(a,b)?"removeClassName":"addClassName"](a,b)},cleanWhitespace:function(b){b=$(b);var c=b.firstChild;while(c){var a=c.nextSibling;if(c.nodeType==3&&!/\S/.test(c.nodeValue)){b.removeChild(c)}c=a}return b},empty:function(a){return $(a).innerHTML.blank()},descendantOf:function(b,a){b=$(b),a=$(a);if(b.compareDocumentPosition){return(b.compareDocumentPosition(a)&8)===8}if(a.contains){return a.contains(b)&&a!==b}while(b=b.parentNode){if(b==a){return true}}return false},scrollTo:function(a){a=$(a);var b=Element.cumulativeOffset(a);window.scrollTo(b[0],b[1]);return a},getStyle:function(b,c){b=$(b);c=c=="float"?"cssFloat":c.camelize();var d=b.style[c];if(!d||d=="auto"){var a=document.defaultView.getComputedStyle(b,null);d=a?a[c]:null}if(c=="opacity"){return d?parseFloat(d):1}return d=="auto"?null:d},getOpacity:function(a){return $(a).getStyle("opacity")},setStyle:function(b,c){b=$(b);var e=b.style,a;if(Object.isString(c)){b.style.cssText+=";"+c;return c.include("opacity")?b.setOpacity(c.match(/opacity:\s*(\d?\.?\d*)/)[1]):b}for(var d in c){if(d=="opacity"){b.setOpacity(c[d])}else{e[(d=="float"||d=="cssFloat")?(Object.isUndefined(e.styleFloat)?"cssFloat":"styleFloat"):d]=c[d]}}return b},setOpacity:function(a,b){a=$(a);a.style.opacity=(b==1||b==="")?"":(b<0.00001)?0:b;return a},makePositioned:function(a){a=$(a);var b=Element.getStyle(a,"position");if(b=="static"||!b){a._madePositioned=true;a.style.position="relative";if(Prototype.Browser.Opera){a.style.top=0;a.style.left=0}}return a},undoPositioned:function(a){a=$(a);if(a._madePositioned){a._madePositioned=undefined;a.style.position=a.style.top=a.style.left=a.style.bottom=a.style.right=""}return a},makeClipping:function(a){a=$(a);if(a._overflow){return a}a._overflow=Element.getStyle(a,"overflow")||"auto";if(a._overflow!=="hidden"){a.style.overflow="hidden"}return a},undoClipping:function(a){a=$(a);if(!a._overflow){return a}a.style.overflow=a._overflow=="auto"?"":a._overflow;a._overflow=null;return a},clonePosition:function(b,d){var a=Object.extend({setLeft:true,setTop:true,setWidth:true,setHeight:true,offsetTop:0,offsetLeft:0},arguments[2]||{});d=$(d);var e=Element.viewportOffset(d),f=[0,0],c=null;b=$(b);if(Element.getStyle(b,"position")=="absolute"){c=Element.getOffsetParent(b);f=Element.viewportOffset(c)}if(c==document.body){f[0]-=document.body.offsetLeft;f[1]-=document.body.offsetTop}if(a.setLeft){b.style.left=(e[0]-f[0]+a.offsetLeft)+"px"}if(a.setTop){b.style.top=(e[1]-f[1]+a.offsetTop)+"px"}if(a.setWidth){b.style.width=d.offsetWidth+"px"}if(a.setHeight){b.style.height=d.offsetHeight+"px"}return b}};Object.extend(Element.Methods,{getElementsBySelector:Element.Methods.select,childElements:Element.Methods.immediateDescendants});Element._attributeTranslations={write:{names:{className:"class",htmlFor:"for"},values:{}}};if(Prototype.Browser.Opera){Element.Methods.getStyle=Element.Methods.getStyle.wrap(function(d,b,c){switch(c){case"height":case"width":if(!Element.visible(b)){return null}var e=parseInt(d(b,c),10);if(e!==b["offset"+c.capitalize()]){return e+"px"}var a;if(c==="height"){a=["border-top-width","padding-top","padding-bottom","border-bottom-width"]}else{a=["border-left-width","padding-left","padding-right","border-right-width"]}return a.inject(e,function(f,g){var h=d(b,g);return h===null?f:f-parseInt(h,10)})+"px";default:return d(b,c)}});Element.Methods.readAttribute=Element.Methods.readAttribute.wrap(function(c,a,b){if(b==="title"){return a.title}return c(a,b)})}else{if(Prototype.Browser.IE){Element.Methods.getStyle=function(a,b){a=$(a);b=(b=="float"||b=="cssFloat")?"styleFloat":b.camelize();var c=a.style[b];if(!c&&a.currentStyle){c=a.currentStyle[b]}if(b=="opacity"){if(c=(a.getStyle("filter")||"").match(/alpha\(opacity=(.*)\)/)){if(c[1]){return parseFloat(c[1])/100}}return 1}if(c=="auto"){if((b=="width"||b=="height")&&(a.getStyle("display")!="none")){return a["offset"+b.capitalize()]+"px"}return null}return c};Element.Methods.setOpacity=function(b,e){function f(g){return g.replace(/alpha\([^\)]*\)/gi,"")}b=$(b);var a=b.currentStyle;if((a&&!a.hasLayout)||(!a&&b.style.zoom=="normal")){b.style.zoom=1}var d=b.getStyle("filter"),c=b.style;if(e==1||e===""){(d=f(d))?c.filter=d:c.removeAttribute("filter");return b}else{if(e<0.00001){e=0}}c.filter=f(d)+"alpha(opacity="+(e*100)+")";return b};Element._attributeTranslations=(function(){var b="className",a="for",c=document.createElement("div");c.setAttribute(b,"x");if(c.className!=="x"){c.setAttribute("class","x");if(c.className==="x"){b="class"}}c=null;c=document.createElement("label");c.setAttribute(a,"x");if(c.htmlFor!=="x"){c.setAttribute("htmlFor","x");if(c.htmlFor==="x"){a="htmlFor"}}c=null;return{read:{names:{"class":b,className:b,"for":a,htmlFor:a},values:{_getAttr:function(d,e){return d.getAttribute(e)},_getAttr2:function(d,e){return d.getAttribute(e,2)},_getAttrNode:function(d,f){var e=d.getAttributeNode(f);return e?e.value:""},_getEv:(function(){var d=document.createElement("div"),g;d.onclick=Prototype.emptyFunction;var e=d.getAttribute("onclick");if(String(e).indexOf("{")>-1){g=function(f,h){h=f.getAttribute(h);if(!h){return null}h=h.toString();h=h.split("{")[1];h=h.split("}")[0];return h.strip()}}else{if(e===""){g=function(f,h){h=f.getAttribute(h);if(!h){return null}return h.strip()}}}d=null;return g})(),_flag:function(d,e){return $(d).hasAttribute(e)?e:null},style:function(d){return d.style.cssText.toLowerCase()},title:function(d){return d.title}}}}})();Element._attributeTranslations.write={names:Object.extend({cellpadding:"cellPadding",cellspacing:"cellSpacing"},Element._attributeTranslations.read.names),values:{checked:function(a,b){a.checked=!!b},style:function(a,b){a.style.cssText=b?b:""}}};Element._attributeTranslations.has={};$w("colSpan rowSpan vAlign dateTime accessKey tabIndex encType maxLength readOnly longDesc frameBorder").each(function(a){Element._attributeTranslations.write.names[a.toLowerCase()]=a;Element._attributeTranslations.has[a.toLowerCase()]=a});(function(a){Object.extend(a,{href:a._getAttr2,src:a._getAttr2,type:a._getAttr,action:a._getAttrNode,disabled:a._flag,checked:a._flag,readonly:a._flag,multiple:a._flag,onload:a._getEv,onunload:a._getEv,onclick:a._getEv,ondblclick:a._getEv,onmousedown:a._getEv,onmouseup:a._getEv,onmouseover:a._getEv,onmousemove:a._getEv,onmouseout:a._getEv,onfocus:a._getEv,onblur:a._getEv,onkeypress:a._getEv,onkeydown:a._getEv,onkeyup:a._getEv,onsubmit:a._getEv,onreset:a._getEv,onselect:a._getEv,onchange:a._getEv})})(Element._attributeTranslations.read.values);if(Prototype.BrowserFeatures.ElementExtensions){(function(){function a(e){var b=e.getElementsByTagName("*"),d=[];for(var c=0,f;f=b[c];c++){if(f.tagName!=="!"){d.push(f)}}return d}Element.Methods.down=function(c,d,b){c=$(c);if(arguments.length==1){return c.firstDescendant()}return Object.isNumber(d)?a(c)[d]:Element.select(c,d)[b||0]}})()}}else{if(Prototype.Browser.Gecko&&/rv:1\.8\.0/.test(navigator.userAgent)){Element.Methods.setOpacity=function(a,b){a=$(a);a.style.opacity=(b==1)?0.999999:(b==="")?"":(b<0.00001)?0:b;return a}}else{if(Prototype.Browser.WebKit){Element.Methods.setOpacity=function(a,b){a=$(a);a.style.opacity=(b==1||b==="")?"":(b<0.00001)?0:b;if(b==1){if(a.tagName.toUpperCase()=="IMG"&&a.width){a.width++;a.width--}else{try{var d=document.createTextNode(" ");a.appendChild(d);a.removeChild(d)}catch(c){}}}return a}}}}}if("outerHTML" in document.documentElement){Element.Methods.replace=function(c,e){c=$(c);if(e&&e.toElement){e=e.toElement()}if(Object.isElement(e)){c.parentNode.replaceChild(e,c);return c}e=Object.toHTML(e);var d=c.parentNode,b=d.tagName.toUpperCase();if(Element._insertionTranslations.tags[b]){var f=c.next(),a=Element._getContentFromAnonymousElement(b,e.stripScripts());d.removeChild(c);if(f){a.each(function(g){d.insertBefore(g,f)})}else{a.each(function(g){d.appendChild(g)})}}else{c.outerHTML=e.stripScripts()}e.evalScripts.bind(e).defer();return c}}Element._returnOffset=function(b,c){var a=[b,c];a.left=b;a.top=c;return a};Element._getContentFromAnonymousElement=function(e,d,f){var g=new Element("div"),c=Element._insertionTranslations.tags[e];var a=false;if(c){a=true}else{if(f){a=true;c=["","",0]}}if(a){g.innerHTML="&nbsp;"+c[0]+d+c[1];g.removeChild(g.firstChild);for(var b=c[2];b--;){g=g.firstChild}}else{g.innerHTML=d}return $A(g.childNodes)};Element._insertionTranslations={before:function(a,b){a.parentNode.insertBefore(b,a)},top:function(a,b){a.insertBefore(b,a.firstChild)},bottom:function(a,b){a.appendChild(b)},after:function(a,b){a.parentNode.insertBefore(b,a.nextSibling)},tags:{TABLE:["<table>","</table>",1],TBODY:["<table><tbody>","</tbody></table>",2],TR:["<table><tbody><tr>","</tr></tbody></table>",3],TD:["<table><tbody><tr><td>","</td></tr></tbody></table>",4],SELECT:["<select>","</select>",1]}};(function(){var a=Element._insertionTranslations.tags;Object.extend(a,{THEAD:a.TBODY,TFOOT:a.TBODY,TH:a.TD})})();Element.Methods.Simulated={hasAttribute:function(a,c){c=Element._attributeTranslations.has[c]||c;var b=$(a).getAttributeNode(c);return !!(b&&b.specified)}};Element.Methods.ByTag={};Object.extend(Element,Element.Methods);(function(a){if(!Prototype.BrowserFeatures.ElementExtensions&&a.__proto__){window.HTMLElement={};window.HTMLElement.prototype=a.__proto__;Prototype.BrowserFeatures.ElementExtensions=true}a=null})(document.createElement("div"));Element.extend=(function(){function c(g){if(typeof window.Element!="undefined"){var i=window.Element.prototype;if(i){var k="_"+(Math.random()+"").slice(2),h=document.createElement(g);i[k]="x";var j=(h[k]!=="x");delete i[k];h=null;return j}}return false}function b(h,g){for(var j in g){var i=g[j];if(Object.isFunction(i)&&!(j in h)){h[j]=i.methodize()}}}var d=c("object");if(Prototype.BrowserFeatures.SpecificElementExtensions){if(d){return function(h){if(h&&typeof h._extendedByPrototype=="undefined"){var g=h.tagName;if(g&&(/^(?:object|applet|embed)$/i.test(g))){b(h,Element.Methods);b(h,Element.Methods.Simulated);b(h,Element.Methods.ByTag[g.toUpperCase()])}}return h}}return Prototype.K}var a={},e=Element.Methods.ByTag;var f=Object.extend(function(i){if(!i||typeof i._extendedByPrototype!="undefined"||i.nodeType!=1||i==window){return i}var g=Object.clone(a),h=i.tagName.toUpperCase();if(e[h]){Object.extend(g,e[h])}b(i,g);i._extendedByPrototype=Prototype.emptyFunction;return i},{refresh:function(){if(!Prototype.BrowserFeatures.ElementExtensions){Object.extend(a,Element.Methods);Object.extend(a,Element.Methods.Simulated)}}});f.refresh();return f})();if(document.documentElement.hasAttribute){Element.hasAttribute=function(a,b){return a.hasAttribute(b)}}else{Element.hasAttribute=Element.Methods.Simulated.hasAttribute}Element.addMethods=function(c){var i=Prototype.BrowserFeatures,d=Element.Methods.ByTag;if(!c){Object.extend(Form,Form.Methods);Object.extend(Form.Element,Form.Element.Methods);Object.extend(Element.Methods.ByTag,{FORM:Object.clone(Form.Methods),INPUT:Object.clone(Form.Element.Methods),SELECT:Object.clone(Form.Element.Methods),TEXTAREA:Object.clone(Form.Element.Methods),BUTTON:Object.clone(Form.Element.Methods)})}if(arguments.length==2){var b=c;c=arguments[1]}if(!b){Object.extend(Element.Methods,c||{})}else{if(Object.isArray(b)){b.each(g)}else{g(b)}}function g(k){k=k.toUpperCase();if(!Element.Methods.ByTag[k]){Element.Methods.ByTag[k]={}}Object.extend(Element.Methods.ByTag[k],c)}function a(m,l,k){k=k||false;for(var o in m){var n=m[o];if(!Object.isFunction(n)){continue}if(!k||!(o in l)){l[o]=n.methodize()}}}function e(n){var k;var m={OPTGROUP:"OptGroup",TEXTAREA:"TextArea",P:"Paragraph",FIELDSET:"FieldSet",UL:"UList",OL:"OList",DL:"DList",DIR:"Directory",H1:"Heading",H2:"Heading",H3:"Heading",H4:"Heading",H5:"Heading",H6:"Heading",Q:"Quote",INS:"Mod",DEL:"Mod",A:"Anchor",IMG:"Image",CAPTION:"TableCaption",COL:"TableCol",COLGROUP:"TableCol",THEAD:"TableSection",TFOOT:"TableSection",TBODY:"TableSection",TR:"TableRow",TH:"TableCell",TD:"TableCell",FRAMESET:"FrameSet",IFRAME:"IFrame"};if(m[n]){k="HTML"+m[n]+"Element"}if(window[k]){return window[k]}k="HTML"+n+"Element";if(window[k]){return window[k]}k="HTML"+n.capitalize()+"Element";if(window[k]){return window[k]}var l=document.createElement(n),o=l.__proto__||l.constructor.prototype;l=null;return o}var h=window.HTMLElement?HTMLElement.prototype:Element.prototype;if(i.ElementExtensions){a(Element.Methods,h);a(Element.Methods.Simulated,h,true)}if(i.SpecificElementExtensions){for(var j in Element.Methods.ByTag){var f=e(j);if(Object.isUndefined(f)){continue}a(d[j],f.prototype)}}Object.extend(Element,Element.Methods);delete Element.ByTag;if(Element.extend.refresh){Element.extend.refresh()}Element.cache={}};document.viewport={getDimensions:function(){return{width:this.getWidth(),height:this.getHeight()}},getScrollOffsets:function(){return Element._returnOffset(window.pageXOffset||document.documentElement.scrollLeft||document.body.scrollLeft,window.pageYOffset||document.documentElement.scrollTop||document.body.scrollTop)}};(function(b){var g=Prototype.Browser,e=document,c,d={};function a(){if(g.WebKit&&!e.evaluate){return document}if(g.Opera&&window.parseFloat(window.opera.version())<9.5){return document.body}return document.documentElement}function f(h){if(!c){c=a()}d[h]="client"+h;b["get"+h]=function(){return c[d[h]]};return b["get"+h]()}b.getWidth=f.curry("Width");b.getHeight=f.curry("Height")})(document.viewport);Element.Storage={UID:1};Element.addMethods({getStorage:function(b){if(!(b=$(b))){return}var a;if(b===window){a=0}else{if(typeof b._prototypeUID==="undefined"){b._prototypeUID=Element.Storage.UID++}a=b._prototypeUID}if(!Element.Storage[a]){Element.Storage[a]=$H()}return Element.Storage[a]},store:function(b,a,c){if(!(b=$(b))){return}if(arguments.length===2){Element.getStorage(b).update(a)}else{Element.getStorage(b).set(a,c)}return b},retrieve:function(c,b,a){if(!(c=$(c))){return}var e=Element.getStorage(c),d=e.get(b);if(Object.isUndefined(d)){e.set(b,a);d=a}return d},clone:function(c,a){if(!(c=$(c))){return}var e=c.cloneNode(a);e._prototypeUID=void 0;if(a){var d=Element.select(e,"*"),b=d.length;while(b--){d[b]._prototypeUID=void 0}}return Element.extend(e)},purge:function(c){if(!(c=$(c))){return}var a=Element._purgeElement;a(c);var d=c.getElementsByTagName("*"),b=d.length;while(b--){a(d[b])}return null}});(function(){function h(v){var u=v.match(/^(\d+)%?$/i);if(!u){return null}return(Number(u[1])/100)}function o(F,G,v){var y=null;if(Object.isElement(F)){y=F;F=y.getStyle(G)}if(F===null){return null}if((/^(?:-)?\d+(\.\d+)?(px)?$/i).test(F)){return window.parseFloat(F)}var A=F.include("%"),w=(v===document.viewport);if(/\d/.test(F)&&y&&y.runtimeStyle&&!(A&&w)){var u=y.style.left,E=y.runtimeStyle.left;y.runtimeStyle.left=y.currentStyle.left;y.style.left=F||0;F=y.style.pixelLeft;y.style.left=u;y.runtimeStyle.left=E;return F}if(y&&A){v=v||y.parentNode;var x=h(F);var B=null;var z=y.getStyle("position");var D=G.include("left")||G.include("right")||G.include("width");var C=G.include("top")||G.include("bottom")||G.include("height");if(v===document.viewport){if(D){B=document.viewport.getWidth()}else{if(C){B=document.viewport.getHeight()}}}else{if(D){B=$(v).measure("width")}else{if(C){B=$(v).measure("height")}}}return(B===null)?0:B*x}return 0}function g(u){if(Object.isString(u)&&u.endsWith("px")){return u}return u+"px"}function j(v){var u=v;while(v&&v.parentNode){var w=v.getStyle("display");if(w==="none"){return false}v=$(v.parentNode)}return true}var d=Prototype.K;if("currentStyle" in document.documentElement){d=function(u){if(!u.currentStyle.hasLayout){u.style.zoom=1}return u}}function f(u){if(u.include("border")){u=u+"-width"}return u.camelize()}Element.Layout=Class.create(Hash,{initialize:function($super,v,u){$super();this.element=$(v);Element.Layout.PROPERTIES.each(function(w){this._set(w,null)},this);if(u){this._preComputing=true;this._begin();Element.Layout.PROPERTIES.each(this._compute,this);this._end();this._preComputing=false}},_set:function(v,u){return Hash.prototype.set.call(this,v,u)},set:function(v,u){throw"Properties of Element.Layout are read-only."},get:function($super,v){var u=$super(v);return u===null?this._compute(v):u},_begin:function(){if(this._prepared){return}var y=this.element;if(j(y)){this._prepared=true;return}var A={position:y.style.position||"",width:y.style.width||"",visibility:y.style.visibility||"",display:y.style.display||""};y.store("prototype_original_styles",A);var B=y.getStyle("position"),u=y.getStyle("width");if(u==="0px"||u===null){y.style.display="block";u=y.getStyle("width")}var v=(B==="fixed")?document.viewport:y.parentNode;y.setStyle({position:"absolute",visibility:"hidden",display:"block"});var w=y.getStyle("width");var x;if(u&&(w===u)){x=o(y,"width",v)}else{if(B==="absolute"||B==="fixed"){x=o(y,"width",v)}else{var C=y.parentNode,z=$(C).getLayout();x=z.get("width")-this.get("margin-left")-this.get("border-left")-this.get("padding-left")-this.get("padding-right")-this.get("border-right")-this.get("margin-right")}}y.setStyle({width:x+"px"});this._prepared=true},_end:function(){var v=this.element;var u=v.retrieve("prototype_original_styles");v.store("prototype_original_styles",null);v.setStyle(u);this._prepared=false},_compute:function(v){var u=Element.Layout.COMPUTATIONS;if(!(v in u)){throw"Property not found."}return this._set(v,u[v].call(this,this.element))},toObject:function(){var u=$A(arguments);var v=(u.length===0)?Element.Layout.PROPERTIES:u.join(" ").split(" ");var w={};v.each(function(x){if(!Element.Layout.PROPERTIES.include(x)){return}var y=this.get(x);if(y!=null){w[x]=y}},this);return w},toHash:function(){var u=this.toObject.apply(this,arguments);return new Hash(u)},toCSS:function(){var u=$A(arguments);var w=(u.length===0)?Element.Layout.PROPERTIES:u.join(" ").split(" ");var v={};w.each(function(x){if(!Element.Layout.PROPERTIES.include(x)){return}if(Element.Layout.COMPOSITE_PROPERTIES.include(x)){return}var y=this.get(x);if(y!=null){v[f(x)]=y+"px"}},this);return v},inspect:function(){return"#<Element.Layout>"}});Object.extend(Element.Layout,{PROPERTIES:$w("height width top left right bottom border-left border-right border-top border-bottom padding-left padding-right padding-top padding-bottom margin-top margin-bottom margin-left margin-right padding-box-width padding-box-height border-box-width border-box-height margin-box-width margin-box-height"),COMPOSITE_PROPERTIES:$w("padding-box-width padding-box-height margin-box-width margin-box-height border-box-width border-box-height"),COMPUTATIONS:{height:function(w){if(!this._preComputing){this._begin()}var u=this.get("border-box-height");if(u<=0){if(!this._preComputing){this._end()}return 0}var x=this.get("border-top"),v=this.get("border-bottom");var z=this.get("padding-top"),y=this.get("padding-bottom");if(!this._preComputing){this._end()}return u-x-v-z-y},width:function(w){if(!this._preComputing){this._begin()}var v=this.get("border-box-width");if(v<=0){if(!this._preComputing){this._end()}return 0}var z=this.get("border-left"),u=this.get("border-right");var x=this.get("padding-left"),y=this.get("padding-right");if(!this._preComputing){this._end()}return v-z-u-x-y},"padding-box-height":function(v){var u=this.get("height"),x=this.get("padding-top"),w=this.get("padding-bottom");return u+x+w},"padding-box-width":function(u){var v=this.get("width"),w=this.get("padding-left"),x=this.get("padding-right");return v+w+x},"border-box-height":function(v){if(!this._preComputing){this._begin()}var u=v.offsetHeight;if(!this._preComputing){this._end()}return u},"border-box-width":function(u){if(!this._preComputing){this._begin()}var v=u.offsetWidth;if(!this._preComputing){this._end()}return v},"margin-box-height":function(v){var u=this.get("border-box-height"),w=this.get("margin-top"),x=this.get("margin-bottom");if(u<=0){return 0}return u+w+x},"margin-box-width":function(w){var v=this.get("border-box-width"),x=this.get("margin-left"),u=this.get("margin-right");if(v<=0){return 0}return v+x+u},top:function(u){var v=u.positionedOffset();return v.top},bottom:function(u){var x=u.positionedOffset(),v=u.getOffsetParent(),w=v.measure("height");var y=this.get("border-box-height");return w-y-x.top},left:function(u){var v=u.positionedOffset();return v.left},right:function(w){var y=w.positionedOffset(),x=w.getOffsetParent(),u=x.measure("width");var v=this.get("border-box-width");return u-v-y.left},"padding-top":function(u){return o(u,"paddingTop")},"padding-bottom":function(u){return o(u,"paddingBottom")},"padding-left":function(u){return o(u,"paddingLeft")},"padding-right":function(u){return o(u,"paddingRight")},"border-top":function(u){return o(u,"borderTopWidth")},"border-bottom":function(u){return o(u,"borderBottomWidth")},"border-left":function(u){return o(u,"borderLeftWidth")},"border-right":function(u){return o(u,"borderRightWidth")},"margin-top":function(u){return o(u,"marginTop")},"margin-bottom":function(u){return o(u,"marginBottom")},"margin-left":function(u){return o(u,"marginLeft")},"margin-right":function(u){return o(u,"marginRight")}}});if("getBoundingClientRect" in document.documentElement){Object.extend(Element.Layout.COMPUTATIONS,{right:function(v){var w=d(v.getOffsetParent());var x=v.getBoundingClientRect(),u=w.getBoundingClientRect();return(u.right-x.right).round()},bottom:function(v){var w=d(v.getOffsetParent());var x=v.getBoundingClientRect(),u=w.getBoundingClientRect();return(u.bottom-x.bottom).round()}})}Element.Offset=Class.create({initialize:function(v,u){this.left=v.round();this.top=u.round();this[0]=this.left;this[1]=this.top},relativeTo:function(u){return new Element.Offset(this.left-u.left,this.top-u.top)},inspect:function(){return"#<Element.Offset left: #{left} top: #{top}>".interpolate(this)},toString:function(){return"[#{left}, #{top}]".interpolate(this)},toArray:function(){return[this.left,this.top]}});function r(v,u){return new Element.Layout(v,u)}function b(u,v){return $(u).getLayout().get(v)}function n(v){v=$(v);var z=Element.getStyle(v,"display");if(z&&z!=="none"){return{width:v.offsetWidth,height:v.offsetHeight}}var w=v.style;var u={visibility:w.visibility,position:w.position,display:w.display};var y={visibility:"hidden",display:"block"};if(u.position!=="fixed"){y.position="absolute"}Element.setStyle(v,y);var x={width:v.offsetWidth,height:v.offsetHeight};Element.setStyle(v,u);return x}function l(u){u=$(u);if(e(u)||c(u)||m(u)||k(u)){return $(document.body)}var v=(Element.getStyle(u,"display")==="inline");if(!v&&u.offsetParent){return $(u.offsetParent)}while((u=u.parentNode)&&u!==document.body){if(Element.getStyle(u,"position")!=="static"){return k(u)?$(document.body):$(u)}}return $(document.body)}function t(v){v=$(v);var u=0,w=0;if(v.parentNode){do{u+=v.offsetTop||0;w+=v.offsetLeft||0;v=v.offsetParent}while(v)}return new Element.Offset(w,u)}function p(v){v=$(v);var w=v.getLayout();var u=0,y=0;do{u+=v.offsetTop||0;y+=v.offsetLeft||0;v=v.offsetParent;if(v){if(m(v)){break}var x=Element.getStyle(v,"position");if(x!=="static"){break}}}while(v);y-=w.get("margin-top");u-=w.get("margin-left");return new Element.Offset(y,u)}function a(v){var u=0,w=0;do{u+=v.scrollTop||0;w+=v.scrollLeft||0;v=v.parentNode}while(v);return new Element.Offset(w,u)}function s(y){v=$(v);var u=0,x=0,w=document.body;var v=y;do{u+=v.offsetTop||0;x+=v.offsetLeft||0;if(v.offsetParent==w&&Element.getStyle(v,"position")=="absolute"){break}}while(v=v.offsetParent);v=y;do{if(v!=w){u-=v.scrollTop||0;x-=v.scrollLeft||0}}while(v=v.parentNode);return new Element.Offset(x,u)}function q(u){u=$(u);if(Element.getStyle(u,"position")==="absolute"){return u}var y=l(u);var x=u.viewportOffset(),v=y.viewportOffset();var z=x.relativeTo(v);var w=u.getLayout();u.store("prototype_absolutize_original_styles",{left:u.getStyle("left"),top:u.getStyle("top"),width:u.getStyle("width"),height:u.getStyle("height")});u.setStyle({position:"absolute",top:z.top+"px",left:z.left+"px",width:w.get("width")+"px",height:w.get("height")+"px"});return u}function i(v){v=$(v);if(Element.getStyle(v,"position")==="relative"){return v}var u=v.retrieve("prototype_absolutize_original_styles");if(u){v.setStyle(u)}return v}if(Prototype.Browser.IE){l=l.wrap(function(w,v){v=$(v);if(e(v)||c(v)||m(v)||k(v)){return $(document.body)}var u=v.getStyle("position");if(u!=="static"){return w(v)}v.setStyle({position:"relative"});var x=w(v);v.setStyle({position:u});return x});p=p.wrap(function(x,v){v=$(v);if(!v.parentNode){return new Element.Offset(0,0)}var u=v.getStyle("position");if(u!=="static"){return x(v)}var w=v.getOffsetParent();if(w&&w.getStyle("position")==="fixed"){d(w)}v.setStyle({position:"relative"});var y=x(v);v.setStyle({position:u});return y})}else{if(Prototype.Browser.Webkit){t=function(v){v=$(v);var u=0,w=0;do{u+=v.offsetTop||0;w+=v.offsetLeft||0;if(v.offsetParent==document.body){if(Element.getStyle(v,"position")=="absolute"){break}}v=v.offsetParent}while(v);return new Element.Offset(w,u)}}}Element.addMethods({getLayout:r,measure:b,getDimensions:n,getOffsetParent:l,cumulativeOffset:t,positionedOffset:p,cumulativeScrollOffset:a,viewportOffset:s,absolutize:q,relativize:i});function m(u){return u.nodeName.toUpperCase()==="BODY"}function k(u){return u.nodeName.toUpperCase()==="HTML"}function e(u){return u.nodeType===Node.DOCUMENT_NODE}function c(u){return u!==document.body&&!Element.descendantOf(u,document.body)}if("getBoundingClientRect" in document.documentElement){Element.addMethods({viewportOffset:function(u){u=$(u);if(c(u)){return new Element.Offset(0,0)}var v=u.getBoundingClientRect(),w=document.documentElement;return new Element.Offset(v.left-w.clientLeft,v.top-w.clientTop)}})}})();window.$$=function(){var a=$A(arguments).join(", ");return Prototype.Selector.select(a,document)};Prototype.Selector=(function(){function a(){throw new Error('Method "Prototype.Selector.select" must be defined.')}function c(){throw new Error('Method "Prototype.Selector.match" must be defined.')}function d(l,m,h){h=h||0;var g=Prototype.Selector.match,k=l.length,f=0,j;for(j=0;j<k;j++){if(g(l[j],m)&&h==f++){return Element.extend(l[j])}}}function e(h){for(var f=0,g=h.length;f<g;f++){Element.extend(h[f])}return h}var b=Prototype.K;return{select:a,match:c,find:d,extendElements:(Element.extend===b)?b:e,extendElement:Element.extend}})();Prototype._original_property=window.Sizzle;
/*!
 * Sizzle CSS Selector Engine - v1.0
 *  Copyright 2009, The Dojo Foundation
 *  Released under the MIT, BSD, and GPL Licenses.
 *  More information: http://sizzlejs.com/
 */
(function(){var q=/((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^[\]]*\]|['"][^'"]*['"]|[^[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g,j=0,d=Object.prototype.toString,o=false,i=true;[0,0].sort(function(){i=false;return 0});var b=function(E,u,B,w){B=B||[];var e=u=u||document;if(u.nodeType!==1&&u.nodeType!==9){return[]}if(!E||typeof E!=="string"){return B}var C=[],D,z,I,H,A,t,s=true,x=p(u),G=E;while((q.exec(""),D=q.exec(G))!==null){G=D[3];C.push(D[1]);if(D[2]){t=D[3];break}}if(C.length>1&&k.exec(E)){if(C.length===2&&f.relative[C[0]]){z=g(C[0]+C[1],u)}else{z=f.relative[C[0]]?[u]:b(C.shift(),u);while(C.length){E=C.shift();if(f.relative[E]){E+=C.shift()}z=g(E,z)}}}else{if(!w&&C.length>1&&u.nodeType===9&&!x&&f.match.ID.test(C[0])&&!f.match.ID.test(C[C.length-1])){var J=b.find(C.shift(),u,x);u=J.expr?b.filter(J.expr,J.set)[0]:J.set[0]}if(u){var J=w?{expr:C.pop(),set:a(w)}:b.find(C.pop(),C.length===1&&(C[0]==="~"||C[0]==="+")&&u.parentNode?u.parentNode:u,x);z=J.expr?b.filter(J.expr,J.set):J.set;if(C.length>0){I=a(z)}else{s=false}while(C.length){var v=C.pop(),y=v;if(!f.relative[v]){v=""}else{y=C.pop()}if(y==null){y=u}f.relative[v](I,y,x)}}else{I=C=[]}}if(!I){I=z}if(!I){throw"Syntax error, unrecognized expression: "+(v||E)}if(d.call(I)==="[object Array]"){if(!s){B.push.apply(B,I)}else{if(u&&u.nodeType===1){for(var F=0;I[F]!=null;F++){if(I[F]&&(I[F]===true||I[F].nodeType===1&&h(u,I[F]))){B.push(z[F])}}}else{for(var F=0;I[F]!=null;F++){if(I[F]&&I[F].nodeType===1){B.push(z[F])}}}}}else{a(I,B)}if(t){b(t,e,B,w);b.uniqueSort(B)}return B};b.uniqueSort=function(s){if(c){o=i;s.sort(c);if(o){for(var e=1;e<s.length;e++){if(s[e]===s[e-1]){s.splice(e--,1)}}}}return s};b.matches=function(e,s){return b(e,null,null,s)};b.find=function(y,e,z){var x,v;if(!y){return[]}for(var u=0,t=f.order.length;u<t;u++){var w=f.order[u],v;if((v=f.leftMatch[w].exec(y))){var s=v[1];v.splice(1,1);if(s.substr(s.length-1)!=="\\"){v[1]=(v[1]||"").replace(/\\/g,"");x=f.find[w](v,e,z);if(x!=null){y=y.replace(f.match[w],"");break}}}}if(!x){x=e.getElementsByTagName("*")}return{set:x,expr:y}};b.filter=function(B,A,E,u){var t=B,G=[],y=A,w,e,x=A&&A[0]&&p(A[0]);while(B&&A.length){for(var z in f.filter){if((w=f.match[z].exec(B))!=null){var s=f.filter[z],F,D;e=false;if(y==G){G=[]}if(f.preFilter[z]){w=f.preFilter[z](w,y,E,G,u,x);if(!w){e=F=true}else{if(w===true){continue}}}if(w){for(var v=0;(D=y[v])!=null;v++){if(D){F=s(D,w,v,y);var C=u^!!F;if(E&&F!=null){if(C){e=true}else{y[v]=false}}else{if(C){G.push(D);e=true}}}}}if(F!==undefined){if(!E){y=G}B=B.replace(f.match[z],"");if(!e){return[]}break}}}if(B==t){if(e==null){throw"Syntax error, unrecognized expression: "+B}else{break}}t=B}return y};var f=b.selectors={order:["ID","NAME","TAG"],match:{ID:/#((?:[\w\u00c0-\uFFFF-]|\\.)+)/,CLASS:/\.((?:[\w\u00c0-\uFFFF-]|\\.)+)/,NAME:/\[name=['"]*((?:[\w\u00c0-\uFFFF-]|\\.)+)['"]*\]/,ATTR:/\[\s*((?:[\w\u00c0-\uFFFF-]|\\.)+)\s*(?:(\S?=)\s*(['"]*)(.*?)\3|)\s*\]/,TAG:/^((?:[\w\u00c0-\uFFFF\*-]|\\.)+)/,CHILD:/:(only|nth|last|first)-child(?:\((even|odd|[\dn+-]*)\))?/,POS:/:(nth|eq|gt|lt|first|last|even|odd)(?:\((\d*)\))?(?=[^-]|$)/,PSEUDO:/:((?:[\w\u00c0-\uFFFF-]|\\.)+)(?:\((['"]*)((?:\([^\)]+\)|[^\2\(\)]*)+)\2\))?/},leftMatch:{},attrMap:{"class":"className","for":"htmlFor"},attrHandle:{href:function(e){return e.getAttribute("href")}},relative:{"+":function(y,e,x){var v=typeof e==="string",z=v&&!/\W/.test(e),w=v&&!z;if(z&&!x){e=e.toUpperCase()}for(var u=0,t=y.length,s;u<t;u++){if((s=y[u])){while((s=s.previousSibling)&&s.nodeType!==1){}y[u]=w||s&&s.nodeName===e?s||false:s===e}}if(w){b.filter(e,y,true)}},">":function(x,s,y){var v=typeof s==="string";if(v&&!/\W/.test(s)){s=y?s:s.toUpperCase();for(var t=0,e=x.length;t<e;t++){var w=x[t];if(w){var u=w.parentNode;x[t]=u.nodeName===s?u:false}}}else{for(var t=0,e=x.length;t<e;t++){var w=x[t];if(w){x[t]=v?w.parentNode:w.parentNode===s}}if(v){b.filter(s,x,true)}}},"":function(u,s,w){var t=j++,e=r;if(!/\W/.test(s)){var v=s=w?s:s.toUpperCase();e=n}e("parentNode",s,t,u,v,w)},"~":function(u,s,w){var t=j++,e=r;if(typeof s==="string"&&!/\W/.test(s)){var v=s=w?s:s.toUpperCase();e=n}e("previousSibling",s,t,u,v,w)}},find:{ID:function(s,t,u){if(typeof t.getElementById!=="undefined"&&!u){var e=t.getElementById(s[1]);return e?[e]:[]}},NAME:function(t,w,x){if(typeof w.getElementsByName!=="undefined"){var s=[],v=w.getElementsByName(t[1]);for(var u=0,e=v.length;u<e;u++){if(v[u].getAttribute("name")===t[1]){s.push(v[u])}}return s.length===0?null:s}},TAG:function(e,s){return s.getElementsByTagName(e[1])}},preFilter:{CLASS:function(u,s,t,e,x,y){u=" "+u[1].replace(/\\/g,"")+" ";if(y){return u}for(var v=0,w;(w=s[v])!=null;v++){if(w){if(x^(w.className&&(" "+w.className+" ").indexOf(u)>=0)){if(!t){e.push(w)}}else{if(t){s[v]=false}}}}return false},ID:function(e){return e[1].replace(/\\/g,"")},TAG:function(s,e){for(var t=0;e[t]===false;t++){}return e[t]&&p(e[t])?s[1]:s[1].toUpperCase()},CHILD:function(e){if(e[1]=="nth"){var s=/(-?)(\d*)n((?:\+|-)?\d*)/.exec(e[2]=="even"&&"2n"||e[2]=="odd"&&"2n+1"||!/\D/.test(e[2])&&"0n+"+e[2]||e[2]);e[2]=(s[1]+(s[2]||1))-0;e[3]=s[3]-0}e[0]=j++;return e},ATTR:function(v,s,t,e,w,x){var u=v[1].replace(/\\/g,"");if(!x&&f.attrMap[u]){v[1]=f.attrMap[u]}if(v[2]==="~="){v[4]=" "+v[4]+" "}return v},PSEUDO:function(v,s,t,e,w){if(v[1]==="not"){if((q.exec(v[3])||"").length>1||/^\w/.test(v[3])){v[3]=b(v[3],null,null,s)}else{var u=b.filter(v[3],s,t,true^w);if(!t){e.push.apply(e,u)}return false}}else{if(f.match.POS.test(v[0])||f.match.CHILD.test(v[0])){return true}}return v},POS:function(e){e.unshift(true);return e}},filters:{enabled:function(e){return e.disabled===false&&e.type!=="hidden"},disabled:function(e){return e.disabled===true},checked:function(e){return e.checked===true},selected:function(e){e.parentNode.selectedIndex;return e.selected===true},parent:function(e){return !!e.firstChild},empty:function(e){return !e.firstChild},has:function(t,s,e){return !!b(e[3],t).length},header:function(e){return/h\d/i.test(e.nodeName)},text:function(e){return"text"===e.type},radio:function(e){return"radio"===e.type},checkbox:function(e){return"checkbox"===e.type},file:function(e){return"file"===e.type},password:function(e){return"password"===e.type},submit:function(e){return"submit"===e.type},image:function(e){return"image"===e.type},reset:function(e){return"reset"===e.type},button:function(e){return"button"===e.type||e.nodeName.toUpperCase()==="BUTTON"},input:function(e){return/input|select|textarea|button/i.test(e.nodeName)}},setFilters:{first:function(s,e){return e===0},last:function(t,s,e,u){return s===u.length-1},even:function(s,e){return e%2===0},odd:function(s,e){return e%2===1},lt:function(t,s,e){return s<e[3]-0},gt:function(t,s,e){return s>e[3]-0},nth:function(t,s,e){return e[3]-0==s},eq:function(t,s,e){return e[3]-0==s}},filter:{PSEUDO:function(x,t,u,y){var s=t[1],v=f.filters[s];if(v){return v(x,u,t,y)}else{if(s==="contains"){return(x.textContent||x.innerText||"").indexOf(t[3])>=0}else{if(s==="not"){var w=t[3];for(var u=0,e=w.length;u<e;u++){if(w[u]===x){return false}}return true}}}},CHILD:function(e,u){var x=u[1],s=e;switch(x){case"only":case"first":while((s=s.previousSibling)){if(s.nodeType===1){return false}}if(x=="first"){return true}s=e;case"last":while((s=s.nextSibling)){if(s.nodeType===1){return false}}return true;case"nth":var t=u[2],A=u[3];if(t==1&&A==0){return true}var w=u[0],z=e.parentNode;if(z&&(z.sizcache!==w||!e.nodeIndex)){var v=0;for(s=z.firstChild;s;s=s.nextSibling){if(s.nodeType===1){s.nodeIndex=++v}}z.sizcache=w}var y=e.nodeIndex-A;if(t==0){return y==0}else{return(y%t==0&&y/t>=0)}}},ID:function(s,e){return s.nodeType===1&&s.getAttribute("id")===e},TAG:function(s,e){return(e==="*"&&s.nodeType===1)||s.nodeName===e},CLASS:function(s,e){return(" "+(s.className||s.getAttribute("class"))+" ").indexOf(e)>-1},ATTR:function(w,u){var t=u[1],e=f.attrHandle[t]?f.attrHandle[t](w):w[t]!=null?w[t]:w.getAttribute(t),x=e+"",v=u[2],s=u[4];return e==null?v==="!=":v==="="?x===s:v==="*="?x.indexOf(s)>=0:v==="~="?(" "+x+" ").indexOf(s)>=0:!s?x&&e!==false:v==="!="?x!=s:v==="^="?x.indexOf(s)===0:v==="$="?x.substr(x.length-s.length)===s:v==="|="?x===s||x.substr(0,s.length+1)===s+"-":false},POS:function(v,s,t,w){var e=s[2],u=f.setFilters[e];if(u){return u(v,t,s,w)}}}};var k=f.match.POS;for(var m in f.match){f.match[m]=new RegExp(f.match[m].source+/(?![^\[]*\])(?![^\(]*\))/.source);f.leftMatch[m]=new RegExp(/(^(?:.|\r|\n)*?)/.source+f.match[m].source)}var a=function(s,e){s=Array.prototype.slice.call(s,0);if(e){e.push.apply(e,s);return e}return s};try{Array.prototype.slice.call(document.documentElement.childNodes,0)}catch(l){a=function(v,u){var s=u||[];if(d.call(v)==="[object Array]"){Array.prototype.push.apply(s,v)}else{if(typeof v.length==="number"){for(var t=0,e=v.length;t<e;t++){s.push(v[t])}}else{for(var t=0;v[t];t++){s.push(v[t])}}}return s}}var c;if(document.documentElement.compareDocumentPosition){c=function(s,e){if(!s.compareDocumentPosition||!e.compareDocumentPosition){if(s==e){o=true}return 0}var t=s.compareDocumentPosition(e)&4?-1:s===e?0:1;if(t===0){o=true}return t}}else{if("sourceIndex" in document.documentElement){c=function(s,e){if(!s.sourceIndex||!e.sourceIndex){if(s==e){o=true}return 0}var t=s.sourceIndex-e.sourceIndex;if(t===0){o=true}return t}}else{if(document.createRange){c=function(u,s){if(!u.ownerDocument||!s.ownerDocument){if(u==s){o=true}return 0}var t=u.ownerDocument.createRange(),e=s.ownerDocument.createRange();t.setStart(u,0);t.setEnd(u,0);e.setStart(s,0);e.setEnd(s,0);var v=t.compareBoundaryPoints(Range.START_TO_END,e);if(v===0){o=true}return v}}}}(function(){var s=document.createElement("div"),t="script"+(new Date).getTime();s.innerHTML="<a name='"+t+"'/>";var e=document.documentElement;e.insertBefore(s,e.firstChild);if(!!document.getElementById(t)){f.find.ID=function(v,w,x){if(typeof w.getElementById!=="undefined"&&!x){var u=w.getElementById(v[1]);return u?u.id===v[1]||typeof u.getAttributeNode!=="undefined"&&u.getAttributeNode("id").nodeValue===v[1]?[u]:undefined:[]}};f.filter.ID=function(w,u){var v=typeof w.getAttributeNode!=="undefined"&&w.getAttributeNode("id");return w.nodeType===1&&v&&v.nodeValue===u}}e.removeChild(s);e=s=null})();(function(){var e=document.createElement("div");e.appendChild(document.createComment(""));if(e.getElementsByTagName("*").length>0){f.find.TAG=function(s,w){var v=w.getElementsByTagName(s[1]);if(s[1]==="*"){var u=[];for(var t=0;v[t];t++){if(v[t].nodeType===1){u.push(v[t])}}v=u}return v}}e.innerHTML="<a href='#'></a>";if(e.firstChild&&typeof e.firstChild.getAttribute!=="undefined"&&e.firstChild.getAttribute("href")!=="#"){f.attrHandle.href=function(s){return s.getAttribute("href",2)}}e=null})();if(document.querySelectorAll){(function(){var e=b,t=document.createElement("div");t.innerHTML="<p class='TEST'></p>";if(t.querySelectorAll&&t.querySelectorAll(".TEST").length===0){return}b=function(x,w,u,v){w=w||document;if(!v&&w.nodeType===9&&!p(w)){try{return a(w.querySelectorAll(x),u)}catch(y){}}return e(x,w,u,v)};for(var s in e){b[s]=e[s]}t=null})()}if(document.getElementsByClassName&&document.documentElement.getElementsByClassName){(function(){var e=document.createElement("div");e.innerHTML="<div class='test e'></div><div class='test'></div>";if(e.getElementsByClassName("e").length===0){return}e.lastChild.className="e";if(e.getElementsByClassName("e").length===1){return}f.order.splice(1,0,"CLASS");f.find.CLASS=function(s,t,u){if(typeof t.getElementsByClassName!=="undefined"&&!u){return t.getElementsByClassName(s[1])}};e=null})()}function n(s,x,w,B,y,A){var z=s=="previousSibling"&&!A;for(var u=0,t=B.length;u<t;u++){var e=B[u];if(e){if(z&&e.nodeType===1){e.sizcache=w;e.sizset=u}e=e[s];var v=false;while(e){if(e.sizcache===w){v=B[e.sizset];break}if(e.nodeType===1&&!A){e.sizcache=w;e.sizset=u}if(e.nodeName===x){v=e;break}e=e[s]}B[u]=v}}}function r(s,x,w,B,y,A){var z=s=="previousSibling"&&!A;for(var u=0,t=B.length;u<t;u++){var e=B[u];if(e){if(z&&e.nodeType===1){e.sizcache=w;e.sizset=u}e=e[s];var v=false;while(e){if(e.sizcache===w){v=B[e.sizset];break}if(e.nodeType===1){if(!A){e.sizcache=w;e.sizset=u}if(typeof x!=="string"){if(e===x){v=true;break}}else{if(b.filter(x,[e]).length>0){v=e;break}}}e=e[s]}B[u]=v}}}var h=document.compareDocumentPosition?function(s,e){return s.compareDocumentPosition(e)&16}:function(s,e){return s!==e&&(s.contains?s.contains(e):true)};var p=function(e){return e.nodeType===9&&e.documentElement.nodeName!=="HTML"||!!e.ownerDocument&&e.ownerDocument.documentElement.nodeName!=="HTML"};var g=function(e,y){var u=[],v="",w,t=y.nodeType?[y]:y;while((w=f.match.PSEUDO.exec(e))){v+=w[0];e=e.replace(f.match.PSEUDO,"")}e=f.relative[e]?e+"*":e;for(var x=0,s=t.length;x<s;x++){b(e,t[x],u)}return b.filter(v,u)};window.Sizzle=b})();(function(c){var d=Prototype.Selector.extendElements;function a(e,f){return d(c(e,f||document))}function b(f,e){return c.matches(e,[f]).length==1}Prototype.Selector.engine=c;Prototype.Selector.select=a;Prototype.Selector.match=b})(Sizzle);window.Sizzle=Prototype._original_property;delete Prototype._original_property;var Form={reset:function(a){a=$(a);a.reset();return a},serializeElements:function(h,d){if(typeof d!="object"){d={hash:!!d}}else{if(Object.isUndefined(d.hash)){d.hash=true}}var e,g,a=false,f=d.submit,b,c;if(d.hash){c={};b=function(i,j,k){if(j in i){if(!Object.isArray(i[j])){i[j]=[i[j]]}i[j].push(k)}else{i[j]=k}return i}}else{c="";b=function(i,j,k){return i+(i?"&":"")+encodeURIComponent(j)+"="+encodeURIComponent(k)}}return h.inject(c,function(i,j){if(!j.disabled&&j.name){e=j.name;g=$(j).getValue();if(g!=null&&j.type!="file"&&(j.type!="submit"||(!a&&f!==false&&(!f||e==f)&&(a=true)))){i=b(i,e,g)}}return i})}};Form.Methods={serialize:function(b,a){return Form.serializeElements(Form.getElements(b),a)},getElements:function(e){var f=$(e).getElementsByTagName("*"),d,a=[],c=Form.Element.Serializers;for(var b=0;d=f[b];b++){a.push(d)}return a.inject([],function(g,h){if(c[h.tagName.toLowerCase()]){g.push(Element.extend(h))}return g})},getInputs:function(g,c,d){g=$(g);var a=g.getElementsByTagName("input");if(!c&&!d){return $A(a).map(Element.extend)}for(var e=0,h=[],f=a.length;e<f;e++){var b=a[e];if((c&&b.type!=c)||(d&&b.name!=d)){continue}h.push(Element.extend(b))}return h},disable:function(a){a=$(a);Form.getElements(a).invoke("disable");return a},enable:function(a){a=$(a);Form.getElements(a).invoke("enable");return a},findFirstElement:function(b){var c=$(b).getElements().findAll(function(d){return"hidden"!=d.type&&!d.disabled});var a=c.findAll(function(d){return d.hasAttribute("tabIndex")&&d.tabIndex>=0}).sortBy(function(d){return d.tabIndex}).first();return a?a:c.find(function(d){return/^(?:input|select|textarea)$/i.test(d.tagName)})},focusFirstElement:function(b){b=$(b);var a=b.findFirstElement();if(a){a.activate()}return b},request:function(b,a){b=$(b),a=Object.clone(a||{});var d=a.parameters,c=b.readAttribute("action")||"";if(c.blank()){c=window.location.href}a.parameters=b.serialize(true);if(d){if(Object.isString(d)){d=d.toQueryParams()}Object.extend(a.parameters,d)}if(b.hasAttribute("method")&&!a.method){a.method=b.method}return new Ajax.Request(c,a)}};Form.Element={focus:function(a){$(a).focus();return a},select:function(a){$(a).select();return a}};Form.Element.Methods={serialize:function(a){a=$(a);if(!a.disabled&&a.name){var b=a.getValue();if(b!=undefined){var c={};c[a.name]=b;return Object.toQueryString(c)}}return""},getValue:function(a){a=$(a);var b=a.tagName.toLowerCase();return Form.Element.Serializers[b](a)},setValue:function(a,b){a=$(a);var c=a.tagName.toLowerCase();Form.Element.Serializers[c](a,b);return a},clear:function(a){$(a).value="";return a},present:function(a){return $(a).value!=""},activate:function(a){a=$(a);try{a.focus();if(a.select&&(a.tagName.toLowerCase()!="input"||!(/^(?:button|reset|submit)$/i.test(a.type)))){a.select()}}catch(b){}return a},disable:function(a){a=$(a);a.disabled=true;return a},enable:function(a){a=$(a);a.disabled=false;return a}};var Field=Form.Element;var $F=Form.Element.Methods.getValue;Form.Element.Serializers=(function(){function b(h,i){switch(h.type.toLowerCase()){case"checkbox":case"radio":return f(h,i);default:return e(h,i)}}function f(h,i){if(Object.isUndefined(i)){return h.checked?h.value:null}else{h.checked=!!i}}function e(h,i){if(Object.isUndefined(i)){return h.value}else{h.value=i}}function a(k,n){if(Object.isUndefined(n)){return(k.type==="select-one"?c:d)(k)}var j,l,o=!Object.isArray(n);for(var h=0,m=k.length;h<m;h++){j=k.options[h];l=this.optionValue(j);if(o){if(l==n){j.selected=true;return}}else{j.selected=n.include(l)}}}function c(i){var h=i.selectedIndex;return h>=0?g(i.options[h]):null}function d(l){var h,m=l.length;if(!m){return null}for(var k=0,h=[];k<m;k++){var j=l.options[k];if(j.selected){h.push(g(j))}}return h}function g(h){return Element.hasAttribute(h,"value")?h.value:h.text}return{input:b,inputSelector:f,textarea:e,select:a,selectOne:c,selectMany:d,optionValue:g,button:e}})();Abstract.TimedObserver=Class.create(PeriodicalExecuter,{initialize:function($super,a,b,c){$super(c,b);this.element=$(a);this.lastValue=this.getValue()},execute:function(){var a=this.getValue();if(Object.isString(this.lastValue)&&Object.isString(a)?this.lastValue!=a:String(this.lastValue)!=String(a)){this.callback(this.element,a);this.lastValue=a}}});Form.Element.Observer=Class.create(Abstract.TimedObserver,{getValue:function(){return Form.Element.getValue(this.element)}});Form.Observer=Class.create(Abstract.TimedObserver,{getValue:function(){return Form.serialize(this.element)}});Abstract.EventObserver=Class.create({initialize:function(a,b){this.element=$(a);this.callback=b;this.lastValue=this.getValue();if(this.element.tagName.toLowerCase()=="form"){this.registerFormCallbacks()}else{this.registerCallback(this.element)}},onElementEvent:function(){var a=this.getValue();if(this.lastValue!=a){this.callback(this.element,a);this.lastValue=a}},registerFormCallbacks:function(){Form.getElements(this.element).each(this.registerCallback,this)},registerCallback:function(a){if(a.type){switch(a.type.toLowerCase()){case"checkbox":case"radio":Event.observe(a,"click",this.onElementEvent.bind(this));break;default:Event.observe(a,"change",this.onElementEvent.bind(this));break}}}});Form.Element.EventObserver=Class.create(Abstract.EventObserver,{getValue:function(){return Form.Element.getValue(this.element)}});Form.EventObserver=Class.create(Abstract.EventObserver,{getValue:function(){return Form.serialize(this.element)}});(function(){var C={KEY_BACKSPACE:8,KEY_TAB:9,KEY_RETURN:13,KEY_ESC:27,KEY_LEFT:37,KEY_UP:38,KEY_RIGHT:39,KEY_DOWN:40,KEY_DELETE:46,KEY_HOME:36,KEY_END:35,KEY_PAGEUP:33,KEY_PAGEDOWN:34,KEY_INSERT:45,cache:{}};var f=document.documentElement;var D="onmouseenter" in f&&"onmouseleave" in f;var a=function(E){return false};if(window.attachEvent){if(window.addEventListener){a=function(E){return !(E instanceof window.Event)}}else{a=function(E){return true}}}var r;function A(F,E){return F.which?(F.which===E+1):(F.button===E)}var o={0:1,1:4,2:2};function y(F,E){return F.button===o[E]}function B(F,E){switch(E){case 0:return F.which==1&&!F.metaKey;case 1:return F.which==2||(F.which==1&&F.metaKey);case 2:return F.which==3;default:return false}}if(window.attachEvent){if(!window.addEventListener){r=y}else{r=function(F,E){return a(F)?y(F,E):A(F,E)}}}else{if(Prototype.Browser.WebKit){r=B}else{r=A}}function v(E){return r(E,0)}function t(E){return r(E,1)}function n(E){return r(E,2)}function d(G){G=C.extend(G);var F=G.target,E=G.type,H=G.currentTarget;if(H&&H.tagName){if(E==="load"||E==="error"||(E==="click"&&H.tagName.toLowerCase()==="input"&&H.type==="radio")){F=H}}if(F.nodeType==Node.TEXT_NODE){F=F.parentNode}return Element.extend(F)}function p(F,G){var E=C.element(F);if(!G){return E}while(E){if(Object.isElement(E)&&Prototype.Selector.match(E,G)){return Element.extend(E)}E=E.parentNode}}function s(E){return{x:c(E),y:b(E)}}function c(G){var F=document.documentElement,E=document.body||{scrollLeft:0};return G.pageX||(G.clientX+(F.scrollLeft||E.scrollLeft)-(F.clientLeft||0))}function b(G){var F=document.documentElement,E=document.body||{scrollTop:0};return G.pageY||(G.clientY+(F.scrollTop||E.scrollTop)-(F.clientTop||0))}function q(E){C.extend(E);E.preventDefault();E.stopPropagation();E.stopped=true}C.Methods={isLeftClick:v,isMiddleClick:t,isRightClick:n,element:d,findElement:p,pointer:s,pointerX:c,pointerY:b,stop:q};var x=Object.keys(C.Methods).inject({},function(E,F){E[F]=C.Methods[F].methodize();return E});if(window.attachEvent){function i(F){var E;switch(F.type){case"mouseover":case"mouseenter":E=F.fromElement;break;case"mouseout":case"mouseleave":E=F.toElement;break;default:return null}return Element.extend(E)}var u={stopPropagation:function(){this.cancelBubble=true},preventDefault:function(){this.returnValue=false},inspect:function(){return"[object Event]"}};C.extend=function(F,E){if(!F){return false}if(!a(F)){return F}if(F._extendedByPrototype){return F}F._extendedByPrototype=Prototype.emptyFunction;var G=C.pointer(F);Object.extend(F,{target:F.srcElement||E,relatedTarget:i(F),pageX:G.x,pageY:G.y});Object.extend(F,x);Object.extend(F,u);return F}}else{C.extend=Prototype.K}if(window.addEventListener){C.prototype=window.Event.prototype||document.createEvent("HTMLEvents").__proto__;Object.extend(C.prototype,x)}function m(I,H,J){var G=Element.retrieve(I,"prototype_event_registry");if(Object.isUndefined(G)){e.push(I);G=Element.retrieve(I,"prototype_event_registry",$H())}var E=G.get(H);if(Object.isUndefined(E)){E=[];G.set(H,E)}if(E.pluck("handler").include(J)){return false}var F;if(H.include(":")){F=function(K){if(Object.isUndefined(K.eventName)){return false}if(K.eventName!==H){return false}C.extend(K,I);J.call(I,K)}}else{if(!D&&(H==="mouseenter"||H==="mouseleave")){if(H==="mouseenter"||H==="mouseleave"){F=function(L){C.extend(L,I);var K=L.relatedTarget;while(K&&K!==I){try{K=K.parentNode}catch(M){K=I}}if(K===I){return}J.call(I,L)}}}else{F=function(K){C.extend(K,I);J.call(I,K)}}}F.handler=J;E.push(F);return F}function h(){for(var E=0,F=e.length;E<F;E++){C.stopObserving(e[E]);e[E]=null}}var e=[];if(Prototype.Browser.IE){window.attachEvent("onunload",h)}if(Prototype.Browser.WebKit){window.addEventListener("unload",Prototype.emptyFunction,false)}var l=Prototype.K,g={mouseenter:"mouseover",mouseleave:"mouseout"};if(!D){l=function(E){return(g[E]||E)}}function w(H,G,I){H=$(H);var F=m(H,G,I);if(!F){return H}if(G.include(":")){if(H.addEventListener){H.addEventListener("dataavailable",F,false)}else{H.attachEvent("ondataavailable",F);H.attachEvent("onlosecapture",F)}}else{var E=l(G);if(H.addEventListener){H.addEventListener(E,F,false)}else{H.attachEvent("on"+E,F)}}return H}function k(K,H,L){K=$(K);var G=Element.retrieve(K,"prototype_event_registry");if(!G){return K}if(!H){G.each(function(N){var M=N.key;k(K,M)});return K}var I=G.get(H);if(!I){return K}if(!L){I.each(function(M){k(K,H,M.handler)});return K}var J=I.length,F;while(J--){if(I[J].handler===L){F=I[J];break}}if(!F){return K}if(H.include(":")){if(K.removeEventListener){K.removeEventListener("dataavailable",F,false)}else{K.detachEvent("ondataavailable",F);K.detachEvent("onlosecapture",F)}}else{var E=l(H);if(K.removeEventListener){K.removeEventListener(E,F,false)}else{K.detachEvent("on"+E,F)}}G.set(H,I.without(F));return K}function z(H,G,F,E){H=$(H);if(Object.isUndefined(E)){E=true}if(H==document&&document.createEvent&&!H.dispatchEvent){H=document.documentElement}var I;if(document.createEvent){I=document.createEvent("HTMLEvents");I.initEvent("dataavailable",E,true)}else{I=document.createEventObject();I.eventType=E?"ondataavailable":"onlosecapture"}I.eventName=G;I.memo=F||{};if(document.createEvent){H.dispatchEvent(I)}else{H.fireEvent(I.eventType,I)}return C.extend(I)}C.Handler=Class.create({initialize:function(G,F,E,H){this.element=$(G);this.eventName=F;this.selector=E;this.callback=H;this.handler=this.handleEvent.bind(this)},start:function(){C.observe(this.element,this.eventName,this.handler);return this},stop:function(){C.stopObserving(this.element,this.eventName,this.handler);return this},handleEvent:function(F){var E=C.findElement(F,this.selector);if(E){this.callback.call(this.element,F,E)}}});function j(G,F,E,H){G=$(G);if(Object.isFunction(E)&&Object.isUndefined(H)){H=E,E=null}return new C.Handler(G,F,E,H).start()}Object.extend(C,C.Methods);Object.extend(C,{fire:z,observe:w,stopObserving:k,on:j});Element.addMethods({fire:z,observe:w,stopObserving:k,on:j});Object.extend(document,{fire:z.methodize(),observe:w.methodize(),stopObserving:k.methodize(),on:j.methodize(),loaded:false});if(window.Event){Object.extend(window.Event,C)}else{window.Event=C}})();(function(){var d;function a(){if(document.loaded){return}if(d){window.clearTimeout(d)}document.loaded=true;document.fire("dom:loaded")}function c(){if(document.readyState==="complete"){document.stopObserving("readystatechange",c);a()}}function b(){try{document.documentElement.doScroll("left")}catch(f){d=b.defer();return}a()}if(document.addEventListener){document.addEventListener("DOMContentLoaded",a,false)}else{document.observe("readystatechange",c);if(window==top){d=b.defer()}}Event.observe(window,"load",a)})();Element.addMethods();Hash.toQueryString=Object.toQueryString;var Toggle={display:Element.toggle};Element.Methods.childOf=Element.Methods.descendantOf;var Insertion={Before:function(a,b){return Element.insert(a,{before:b})},Top:function(a,b){return Element.insert(a,{top:b})},Bottom:function(a,b){return Element.insert(a,{bottom:b})},After:function(a,b){return Element.insert(a,{after:b})}};var $continue=new Error('"throw $continue" is deprecated, use "return" instead');var Position={includeScrollOffsets:false,prepare:function(){this.deltaX=window.pageXOffset||document.documentElement.scrollLeft||document.body.scrollLeft||0;this.deltaY=window.pageYOffset||document.documentElement.scrollTop||document.body.scrollTop||0},within:function(b,a,c){if(this.includeScrollOffsets){return this.withinIncludingScrolloffsets(b,a,c)}this.xcomp=a;this.ycomp=c;this.offset=Element.cumulativeOffset(b);return(c>=this.offset[1]&&c<this.offset[1]+b.offsetHeight&&a>=this.offset[0]&&a<this.offset[0]+b.offsetWidth)},withinIncludingScrolloffsets:function(b,a,d){var c=Element.cumulativeScrollOffset(b);this.xcomp=a+c[0]-this.deltaX;this.ycomp=d+c[1]-this.deltaY;this.offset=Element.cumulativeOffset(b);return(this.ycomp>=this.offset[1]&&this.ycomp<this.offset[1]+b.offsetHeight&&this.xcomp>=this.offset[0]&&this.xcomp<this.offset[0]+b.offsetWidth)},overlap:function(b,a){if(!b){return 0}if(b=="vertical"){return((this.offset[1]+a.offsetHeight)-this.ycomp)/a.offsetHeight}if(b=="horizontal"){return((this.offset[0]+a.offsetWidth)-this.xcomp)/a.offsetWidth}},cumulativeOffset:Element.Methods.cumulativeOffset,positionedOffset:Element.Methods.positionedOffset,absolutize:function(a){Position.prepare();return Element.absolutize(a)},relativize:function(a){Position.prepare();return Element.relativize(a)},realOffset:Element.Methods.cumulativeScrollOffset,offsetParent:Element.Methods.getOffsetParent,page:Element.Methods.viewportOffset,clone:function(b,c,a){a=a||{};return Element.clonePosition(c,b,a)}};if(!document.getElementsByClassName){document.getElementsByClassName=function(b){function a(c){return c.blank()?null:"[contains(concat(' ', @class, ' '), ' "+c+" ')]"}b.getElementsByClassName=Prototype.BrowserFeatures.XPath?function(c,e){e=e.toString().strip();var d=/\s/.test(e)?$w(e).map(a).join(""):a(e);return d?document._getElementsByXPath(".//*"+d,c):[]}:function(e,f){f=f.toString().strip();var g=[],h=(/\s/.test(f)?$w(f):null);if(!h&&!f){return g}var c=$(e).getElementsByTagName("*");f=" "+f+" ";for(var d=0,k,j;k=c[d];d++){if(k.className&&(j=" "+k.className+" ")&&(j.include(f)||(h&&h.all(function(i){return !i.toString().blank()&&j.include(" "+i+" ")})))){g.push(Element.extend(k))}}return g};return function(d,c){return $(c||document.body).getElementsByClassName(d)}}(Element.Methods)}Element.ClassNames=Class.create();Element.ClassNames.prototype={initialize:function(a){this.element=$(a)},_each:function(a){this.element.className.split(/\s+/).select(function(b){return b.length>0})._each(a)},set:function(a){this.element.className=a},add:function(a){if(this.include(a)){return}this.set($A(this).concat(a).join(" "))},remove:function(a){if(!this.include(a)){return}this.set($A(this).without(a).join(" "))},toString:function(){return $A(this).join(" ")}};Object.extend(Element.ClassNames.prototype,Enumerable);(function(){window.Selector=Class.create({initialize:function(a){this.expression=a.strip()},findElements:function(a){return Prototype.Selector.select(this.expression,a)},match:function(a){return Prototype.Selector.match(a,this.expression)},toString:function(){return this.expression},inspect:function(){return"#<Selector: "+this.expression+">"}});Object.extend(Selector,{matchElements:function(f,g){var a=Prototype.Selector.match,d=[];for(var c=0,e=f.length;c<e;c++){var b=f[c];if(a(b,g)){d.push(Element.extend(b))}}return d},findElement:function(f,g,b){b=b||0;var a=0,d;for(var c=0,e=f.length;c<e;c++){d=f[c];if(Prototype.Selector.match(d,g)&&b===a++){return Element.extend(d)}}},findChildElements:function(b,c){var a=c.toArray().join(", ");return Prototype.Selector.select(a,b||document)}})})();
/*! RESOURCE: /scripts/lib/glide_updates/prototype.js */
Object.extendsObject = function() {
return Class.create.apply(null, arguments).prototype;
}
Prototype.ScriptFragmentDetailed = '<script(?:[^>]*type=\"([^>]*?)\")?(?:[^>]*src=\"([^>]*?)\")?[^>]*>([\\S\\s]*?)<\/script>';
var g_evalScriptCache = {};
Object.extend(String.prototype, (function() {
function extractScriptsDetailed() {
var matchAll = new RegExp(Prototype.ScriptFragmentDetailed, 'img');
var matchOne = new RegExp(Prototype.ScriptFragmentDetailed, 'im');
return (this.match(matchAll) || []).map(function(scriptTag) {
var m = scriptTag.match(matchOne) || [ '', '', '', '' ];
if (m[1] == 'application/xml')
return;
if (m[1] == 'text/html')
return;
return {
script: m[3],
src: m[2]
};
});
}
function evalScripts(evalGlobal) {
(function _executer(scripts) {
if (!scripts || scripts.length == 0)
return;
var script = scripts.shift();
if (!script)
return _executer(scripts);
if (script.src) {
if (!g_evalScriptCache[script.src]) {
g_evalScriptCache[script.src] = {
state : 'loading',
scripts : scripts
};
ajaxRequest(script.src,	null, true,	function(r) {
g_evalScriptCache[script.src].state = 'loaded';
var toEvalScripts = g_evalScriptCache[script.src].scripts;
if (r && r.responseText)
evalScript(r.responseText, evalGlobal);
return _executer(toEvalScripts);
});
}
else if (g_evalScriptCache[script.src].state == 'loading') {
g_evalScriptCache[script.src].scripts = g_evalScriptCache[script.src].scripts.concat(scripts);
return;
} else if (g_evalScriptCache[script.src].state == 'loaded')
return _executer(scripts);
} else {
if (script.script)
evalScript(script.script, evalGlobal);
return _executer(scripts);
}
})(this.extractScriptsDetailed());
}
return {
evalScripts: evalScripts,
extractScriptsDetailed: extractScriptsDetailed
};
})());
function evalScript(s, evalGlobal) {
if (s.length == 0)
return;
if (!evalGlobal)
return eval(s);
if (window.execScript)
return window.execScript(s);
return window.eval ? window.eval(s) : eval(s);
}
if (document.getElementsByClassName && typeof Element.Methods.getElementsByClassName === "function")
document.getElementsByClassName = function(instanceMethods) {
function iter(name) {
return name.blank() ? null : "[contains(concat(' ', @class, ' '), ' " + name + " ')]";
}
instanceMethods.getElementsByClassName = Prototype.BrowserFeatures.XPath ? function(element, className) {
className = className.toString().strip();
var cond = /\s/.test(className) ? $w(className).map(iter).join('') : iter(className);
return cond ? document._getElementsByXPath('.//*' + cond, element) : [];
} : function(element, className) {
className = className.toString().strip();
var elements = [], classNames = (/\s/.test(className) ? $w(className) : null);
if (!classNames && !className)
return elements;
if (Object.isString(element))
element = document.getElementById(element);
Element.extend(element);
var nodes = element.getElementsByTagName('*');
className = ' ' + className + ' ';
for (var i = 0, child, cn; child = nodes[i]; i++) {
if (child.className && (cn = ' ' + child.className + ' ')
&& (cn.include(className) || (classNames && classNames.all(function(name) {
return !name.toString().blank() && cn.include(' ' + name + ' ');
}))))
elements.push(Element.extend(child));
}
return elements;
};
return function(className, parentElement) {
return $(parentElement || document.body).getElementsByClassName(className);
};
}(Element.Methods);
Object.equals = function(o1, o2) {
var i1 = 0, i2 = 0;
for (var p in o1) {
if (!o1 || !o2 || typeof o1[p] !== typeof o2[p] || ((o1[p] === null) !== (o2[p] === null)))
return false;
switch (typeof o1[p]) {
case 'undefined':
if (typeof o2[p] != 'undefined')
return false;
break;
case 'object':
if (o1[p] !== null && o2[p] !== null && (o1[p].constructor.toString() !== o2[p].constructor.toString() || !Object.equals(o1[p], o2[p])))
return false;
break;
case 'function':
if (p != 'equals' && o1[p].toString() != o2[p].toString())
return false;
break;
default:
if (o1[p] !== o2[p])
return false;
}
i1++;
}
for (var p in o2) i2++;
if (i1 != i2)
return false;
return true;
}
document.viewport['getDimensions'] = function() {
var el = window.document.compatMode === 'CSS1Compat' && (!Prototype.Browser.Opera ||
window.parseFloat(window.opera.version()) < 9.5) ? window.document.documentElement : window.document.body;
return { width: el.clientWidth, height: el.clientHeight };
};
;
/*! RESOURCE: /scripts/functions_bootstrap.js */
var userAgentLowerCase = navigator.userAgent.toLowerCase();
var isMSIE = userAgentLowerCase.indexOf("msie") >= 0;
var ie5 = false;
if (isMSIE) {
ie5 = !!(document.all && document.getElementById);
}
var isMSIE6 = userAgentLowerCase.indexOf("msie 6") >= 0;
var isMSIE7 = userAgentLowerCase.indexOf("msie 7") >= 0;
var isMSIE8 = userAgentLowerCase.indexOf("msie 8") >= 0;
var isMSIE9 = userAgentLowerCase.indexOf("msie 9") >= 0;
var isMSIE10 = userAgentLowerCase.indexOf("msie 10") >= 0;
var isMSIE11 = userAgentLowerCase.indexOf("rv:11.0") > 0;
var isChrome = userAgentLowerCase.indexOf("chrome") >= 0;
var isFirefox = userAgentLowerCase.indexOf("firefox") >= 0;
var isSafari = !isChrome && (userAgentLowerCase.indexOf("safari") >= 0);
var isSafari5 = false;
if (isSafari) {
try {
var reSafariVersion = new RegExp("version/([\\d\\.]{3,5}) safari/");
var results = reSafariVersion.exec( userAgentLowerCase );
if ( results.length > 0 ) {
var reMajor = new RegExp("([\\d]).");
var results = reMajor.exec(results[1]);
if ( results.length > 0 ) {
var mv = parseInt( results[1] );
isSafari5 = mv < 6;
}
}
} catch(e) { }
}
var isMacintosh = userAgentLowerCase.indexOf("macintosh") >= 0;
var isWebKit = navigator.userAgent.indexOf("WebKit") >= 0;
var isTouchDevice = navigator.userAgent.indexOf('iPhone') > -1 || navigator.userAgent.indexOf('iPad') > -1;
var GJSV = 1.0;
window.g_render_functions = window.g_render_functions || [];
window.g_load_functions = window.g_load_functions || [];
window.g_late_load_functions = window.g_late_load_functions || [];
function addLoadEvent(func) {
if (window.self.loaded) {
setTimeout(func, 0);
return;
}
g_load_functions.push(func);
}
function addLateLoadEvent(func) {
if (window.self.loaded) {
setTimeout(func, 0);
return;
}
g_late_load_functions.push(func);
}
function runAfterAllLoaded() {
if (isMSIE6)
Event.observe(window, 'load', _runOnLoad, false);
else
_runAfterAllLoaded();
}
function _runOnLoad() {
_runBeforeRender();
_runAfterAllLoaded();
}
function _runAfterAllLoaded() {
var sw = new StopWatch();
jslog("runAfterAllLoaded, functions: " + g_load_functions.length);
for (var i = 0; i != g_load_functions.length; i++) {
var f = g_load_functions[i];
var t = new Date().getTime();
f.call();
t = new Date().getTime() - t;
if (t > 5000)
jslog("Time: " + t + " for: ["  + i + "] "+ f);
}
jslog("late load functions: " + g_late_load_functions.length);
for (var i = 0; i != g_late_load_functions.length; i++) {
var f = g_late_load_functions[i];
f.call();
}
window.self.loaded = true;
sw.jslog("runAfterAllLoaded finished");
}
function _addLoadEvent(func) {
if (self.unloadAlreadyCalled) {
setTimeout(func, 50);
return;
}
Event.observe(window, 'load', func, false);
}
function pageLoaded() {
CustomEvent.observe("body_clicked", contextMenuHide);
_addLoadEvent(markUnloadCalled);
setMandatoryExplained.defer();
}
function markUnloadCalled() {
window.self.unloadAlreadyCalled = true;
}
function contextMenuHide(e) {
if (typeof contextHide === 'undefined')
return;
if (!isMSIE && e) {
if (isTouchDevice && !isTouchRightClick(e)) {
if (e.type == 'touchend' && $(e.target).up('.context_menu'))
return;
contextHide();
} else if (isLeftClick(e)) {
contextHide();
}
} else
contextHide();
}
function addRenderEvent(func) {
if (isRenderEventRegistered(func))
return;
addRenderEventToArray(func);
}
function addRenderEventToArray(func) {
if (window.self.loaded) {
setTimeout(func, 0);
return;
}
g_render_functions.push(func);
}
function isRenderEventRegistered(func) {
var s = func.toString();
for(var i = 0; i < g_render_functions.length; i++)
if (g_render_functions[i].toString() == s)
return true;
return false;
}
function addRenderEventLogged(func, name, funcname) {
addRenderEventToArray(function() {
CustomEvent.fire('glide_optics_inspect_put_cs_context', funcname, 'load');
var sw = new StopWatch();
var __rtmr = new Date();
try {
func();
} catch(e) {
jslog('***************************************************');
jslog('A script has encountered an error in render events');
jslog(e.toString());
jslog('Script ends. Continuing happily');
jslog('***************************************************');
}
CustomEvent.fire('page_timing', { name: 'CSOL', child: name.substr(6), startTime: __rtmr, win: window });
sw.jslog(name);
CustomEvent.fire('glide_optics_inspect_pop_cs_context', funcname, 'load');
});
}
function addTopRenderEvent(func) {
if (window.self.loaded) {
setTimeout(func, 0);
return;
}
g_render_functions.unshift(func);
}
function runBeforeRender() {
if (!isMSIE6)
_runBeforeRender();
}
function _runBeforeRender() {
jslog("runBeforeRender");
for (var i = 0; i != g_render_functions.length; i++) {
var f = g_render_functions[i];
f.call();
}
}
var g_afterPageLoadedFunctions = [];
function addAfterPageLoadedEvent(func) {
if (window.self.loaded) {
setTimeout(func, 0);
return;
}
g_afterPageLoadedFunctions.push(func);
}
function runAfterPageLoadedEvents() {
jslog("after page loaded starting");
var sw = new StopWatch();
for (var i = 0; i != g_afterPageLoadedFunctions.length; i++) {
var f = g_afterPageLoadedFunctions[i];
f.call();
}
sw.jslog("after page loaded complete, functions called: " + g_afterPageLoadedFunctions.length);
g_afterPageLoadedFunctions = [];
}
addLateLoadEvent(function() {
setTimeout(runAfterPageLoadedEvents, 30);
});
function addUnloadEvent(func) {
Event.observe(window, 'unload', func, false);
}
function gel(id) {
if (typeof id != 'string')
return id;
return document.getElementById(id);
}
function cel(name, parent) {
var e = document.createElement(name);
if (arguments.length > 1)
parent.appendChild(e);
return e;
}
function rel(id) {
var e = gel(id);
if (e)
e.parentNode.removeChild(e);
}
function addChild(element) {
getFormContentParent().appendChild(element);
}
function inner(id, data) {
var el = gel(id);
if (el != null)
el.innerHTML = data;
}
function clearNodes(t) {
if (!t)
return;
while(t.hasChildNodes())
t.removeChild(t.childNodes[0]);
}
function getTopWindow() {
var topWindow = window.self;
try {
while (topWindow.GJSV && topWindow != topWindow.parent && topWindow.parent.GJSV) {
topWindow = topWindow.parent;
}
} catch (e) {
}
return topWindow;
}
function inFrame() {
return getTopWindow() != window.self;
}
function getMainWindow() {
var topWindow = getTopWindow();
return topWindow['gsft_main'];
}
function getMainFormWindow() {
var topWindow = getTopWindow();
return topWindow['gsft_main_form'];
}
function getNavWindow() {
var topWindow = getTopWindow();
return topWindow['gsft_nav'];
}
function reloadWindow(win) {
var href = win.location.href;
var len = href.length;
if (win.frames['iframe_live_feed'] && href.endsWith('#') && len > 2)
href = href.substring(0, len-2)
href = addDomainParameters(href);
win.location.href = href;
}
function addDomainParameters(href) {
var url = new GlideURL(href);
if (url.getParam('sysparm_domain') == 'picker') {
url.deleteParam('sysparm_domain');
} else {
var domainElement = gel('sysparm_domain');
if (domainElement) {
if (domainElement.value != 'picker') {
url.addParam('sysparm_domain', domainElement.value);
var domainScope = gel('sysparm_domain_scope');
if (domainScope) {
url.addParam('sysparm_domain_scope', domainScope.value);
}
}
}
}
url.addParam('sysparm_nostack', 'true');
url.setEncode(false);
return url.getURL();
}
function addOnSubmitEvent(form, func, funcname) {
if (!form)
return;
var oldonsubmit = form.onsubmit;
if (typeof form.onsubmit != 'function')
form.onsubmit = func;
else {
form.onsubmit = function() {
var formFuncCalled = false;
try {
if (oldonsubmit() == false)
return false;
CustomEvent.fire('glide_optics_inspect_put_cs_context', funcname, 'submit');
formFuncCalled = true;
var returnvalue = func();
formFuncCalled = false;
CustomEvent.fire('glide_optics_inspect_pop_cs_context', funcname, 'submit');
if (returnvalue == false)
return false;
return true;
}
catch (ex) {
if (formFuncCalled)
CustomEvent.fire('glide_optics_inspect_pop_cs_context', funcname, 'load');
formFuncError("onSubmit", func, ex);
return false;
}
}
}
form = null;
}
function formFuncError(type, func, ex) {
var funcStr = func.toString();
funcStr = funcStr.replace(/onSubmit[a-fA-F0-9]{32}\(/, "onSubmit(");
var msg;
if (g_user.hasRole("client_script_admin"))
msg = type + " script error: " + ex.toString() + ":<br/>" + funcStr.replace(/\n/g, "<br/>").replace(/\s/g, "&nbsp;");
else
msg = "Submit canceled due to a script error - please contact your System Administrator";
g_form.addErrorMessage(msg);
}
function hide(element) {
var e = typeof element === "string" ? gel(element) : element;
if (!e)
return;
e.style.display = 'none';
_frameChanged();
}
function show(element) {
var e = typeof element === "string" ? gel(element) : element;
if (!e)
return;
if (e.tagName == "TR" && !ie5)
e.style.display = 'table-row';
else
e.style.display = 'block';
_frameChanged();
}
function hideObject(o, visibilityOnly) {
if (!o)
return;
o.style.visibility = "hidden";
if (!visibilityOnly)
o.style.display = "none";
_frameChanged();
}
function showObject(o, visibilityOnly) {
if (!o)
return;
o.style.visibility = "visible";
if (!visibilityOnly)
o.style.display = "block";
_frameChanged();
}
function showObjectInline(o) {
if (!o)
return;
o.style.visibility="visible";
o.style.display = "inline";
_frameChanged();
}
function showObjectInlineBlock(o) {
if (!o)
return;
o.style.visibility="visible";
if (!isMSIE7)
o.style.display = "inline-block";
else
o.style.display = "inline";
o.style.zoom = 1;
_frameChanged();
}
var msgTimerID;
function showOutputMessages(message, divname, type) {
var span = getTopWindow().gel(divname);
if (span != null) {
var image = "images/info.gifx";
var map = getMessages(["Informational Message", "Error Message"]);
var imageAlt = map["Informational Message"];
if (type == "error") {
image = "images/outputmsg_error.gifx";
imageAlt = map["Error Message"];
}
var html = "<table cellpadding='0' cellspacing='0' ><tr class='header'><td align='left'>" +
"<img style='margin-right: 5px;height: 16px; width: 16px' src='" + image + "' alt = '" + imageAlt + "'/>" +
"</td><td align='left'>" +
"<span style='font-weight: normal; color: white;'>" + message + "</span>" +
"</td></tr></table>";
span.innerHTML = html;
span.style.display = 'inline';
}
timeoutOutputMessages(divname);
}
function hideOutputMessages(divname) {
var span = getTopWindow().gel(divname);
if (span != null)
span.style.display = 'none';
clearTimeout(msgTimerID);
}
function timeoutOutputMessages(divname) {
clearTimeout(msgTimerID);
msgTimerID = setTimeout("hideOutputMessages('" + divname + "')", 5000);
}
function focusFirstElement(form) {
try {
var e = findFirstEditableElement(form);
if (e) {
Field.activate(e);
triggerEvent(e, 'focus', true);
}
} catch (ex) {
}
}
function findFirstEditableElement(form) {
var tags = ['input', 'select', 'textarea'];
var elements = form.getElementsByTagName('*');
for (var i = 0, n = elements.length; i < n; i++) {
var element = elements[i];
if (element.type == 'hidden')
continue;
var tagName = element.tagName.toLowerCase();
if (!tags.include(tagName))
continue;
element = $(element);
if (element.type != 'hidden' &&
!element.disabled &&
!element.readOnly &&
element.style.visibility != 'hidden' &&
element.style.display != 'none' &&
tags.include(element.tagName.toLowerCase()))
return element;
}
return null;
}
function triggerEvent(element, eventType, canBubble) {
canBubble = (typeof(canBubble) == undefined) ? true : canBubble;
if (element && element.disabled && eventType == "change" && element.onchange) {
element.onchange.call(element);
return;
}
if (element.fireEvent) {
element.fireEvent('on' + eventType);
}  else {
var evt = document.createEvent('HTMLEvents');
evt.initEvent(eventType, canBubble, true);
element.dispatchEvent(evt);
}
}
var g_form_dirty_message;
function onWindowClose() {
if (typeof g_form != 'undefined') {
if (!g_form.submitted && g_form.modified) {
g_submitted = false;
setTimeout(function() {
CustomEvent.fireTop('glide:nav_form_dirty_cancel_stay', window);
}, 750);
return g_form_dirty_message;
}
g_form.submitted = false;
}
}
function jslog(msg, src, dateTime) {
if (window.console && window.console.log) {
console.log(msg);
}
try {
if (!src) {
var path = window.self.location.pathname;
src = path.substring(path.lastIndexOf('/') + 1);
}
if (window.self.opener && window != window.self.opener) {
if (window.self.opener.jslog) {
window.self.opener.jslog(msg, src, dateTime);
}
} else if (parent && parent.jslog && jslog != parent.jslog) {
parent.jslog(msg, src, dateTime);
}
} catch (e) {
}
}
function getXMLIsland(name) {
var xml = gel(name);
if (xml == null)
return null;
xml = "<xml>" + xml.innerHTML + "</xml>";
xml = loadXML(xml);
return xml;
}
function lock(me, ref, edit_id, nonedit_id, current_value_id, update_id) {
me.style.display = "none";
var unlock = gel(ref + '_unlock');
unlock.style.display = "inline";
var edit_span = gel(edit_id);
edit_span.style.display = "none";
var nonedit_span = gel(nonedit_id);
nonedit_span.style.display = "inline";
var current_value = gel(current_value_id);
var the_value = "";
if (current_value.options) {
for(var i=0; i<current_value.options.length ;i++) {
if (i > 0)
the_value += g_glide_list_separator;
the_value += current_value.options[i].text;
}
}
else
the_value = current_value.value;
var update_element = gel(update_id);
if (update_element.href)
update_element.href = the_value;
update_element.innerHTML = htmlEscape(the_value);
}
function unlock(me, ref, edit_id, nonedit_id) {
if (me)
me.style.display = "none";
var unlock = gel(ref + '_lock');
if (unlock)
unlock.style.display = "inline";
var edit_span = gel(edit_id);
edit_span.style.display = "inline";
var nonedit_span = gel(nonedit_id);
nonedit_span.style.display = "none";
var list_foc = gel("sys_display." + ref);
if (list_foc) {
try {
list_foc.focus();
} catch (e) {
}
}
}
function setMandatoryExplained(enforce) {
var showexp = gel('mandatory_explained');
if (!showexp)
return;
if (enforce || foundAMandatoryField())
showexp.style.display = "inline";
else
showexp.style.display = "none";
}
function foundAMandatoryField() {
var spanTags = document.getElementsByTagName('span');
if (!spanTags)
return false;
for (var c = 0, n = spanTags.length;c != n; ++c) {
var spanTag = spanTags[c];
var id = spanTag.id;
if (!id)
continue;
if (id.indexOf('status.') == 0) {
var mandatory = spanTag.getAttribute("mandatory") + "";
if (mandatory == 'true')
return true;
}
}
return false;
}
var _frameChangedTimer = null;
function _frameChanged() {
if (_frameChangedTimer)
clearTimeout(_frameChangedTimer);
_frameChangedTimer = setTimeout(function(){
_frameChangedTimer = null;
CustomEvent.fire('frame.resized');
CustomEvent.fire('refresh.event');
}, 300);
}
function getFormContentParent() {
var glideOverlay = $(document.body).select("div.glide_overlay");
var exposeMask = $('glide_expose_mask');
if (glideOverlay.length > 0 && exposeMask && exposeMask.visible())
return glideOverlay[0];
if (typeof g_section_contents == 'undefined' || !g_section_contents)
g_section_contents = $(document.body).select(".section_header_content_no_scroll");
if (g_section_contents.length > 0)
return g_section_contents[0];
return document.body;
}
function addClassName(element, name) {
if (!element)
return;
var names = element.className.split(" ");
if (names.exists(name))
return;
names.push(name);
element.className = names.join(" ");
}
function removeClassName(element, name) {
if (!element)
return;
var names = element.className.split(" ");
if (names.removeItem(name))
element.className = names.join(" ");
}
function hasClassName(element, name) {
if (!element)
return;
var names = element.className.split(" ");
return names.exists(name);
}
function getIFrameDocument(iframe) {
return iframe.contentWindow ? iframe.contentWindow.document : (iframe.contentDocument || null);
}
function writeTitle(element, title) {
element.title = title;
if (element.alt)
element.alt = title;
}
function trim(s) {
return s.replace(/^\s+|\s+$/g,'');
}
if (!String.prototype.trim) {
String.prototype.trim = function() {
return trim(this);
}
}
if (!Array.prototype.remove) {
Array.prototype.remove = function(ndx) {
if (isNaN(ndx) || ndx >= this.length)
return false;
for (var i = (ndx + 1); i < this.length; i++)
this[i - 1] = this[i];
this.length--;
return true;
};
}
if (!Array.prototype.removeItem) {
Array.prototype.removeItem = function(item) {
for (var i = 0 ; i < this.length ; i++)
if (this[i] == item) {
this.remove(i);
return true;
}
return false;
};
}
if (!Array.prototype.exists) {
Array.prototype.exists = function(item) {
for (var i = 0 ; i < this.length ; i++)
if (this[i] == item)
return true;
return false;
};
}
if (!Array.prototype.insert) {
Array.prototype.insert = function(ndx) {
if (isNaN(ndx) || ndx > this.length)
return false;
for (var i = this.length; i > ndx; i--)
this[i] = this[i - 1];
this[ndx] = null;
return true;
};
}
function isIEBrowser() {
return isMSIE || isMSIE11;
}
function getIEVersion() {
if (isMSIE6)
return "msie6";
else if (isMSIE7)
return "msie7";
else if (isMSIE8)
return "msie8";
else if (isMSIE9)
return "msie9";
else if (isMSIE10)
return "msie10";
else if (isMSIE11)
return "msie11";
else
return "";
}
addAfterPageLoadedEvent(function() {
addClassName(document.getElementsByTagName('body')[0], getIEVersion());
});
;
/*! RESOURCE: /scripts/functions.js */
var QUERY_TERM_SEPERATOR = '^';
var AJAX_KEEPALIVE_TIMEOUT = 900;
var loadingDialog;
var preloadedImages = new Object();
function isDoctype() {
return false;
}
function gsftSubmit(control,  form,  action_name) {
var f;
if (typeof form == "undefined") {
f = findParentByTag(control, 'form');
if (typeof form == "undefined") {
var sectionFormId = $("section_form_id");
if (sectionFormId)
f = $(sectionFormId.value);
}
} else
f = form;
if (g_submitted)
return false;
if (typeof action_name == "undefined" && control)
action_name = control.id;
if (action_name == 'sysverb_delete') {
if  (!confirm(getMessage("Delete this record") + "?")) {
g_submitted = false;
return false;
}
}
f.sys_action.value=action_name;
if (typeof f.onsubmit == "function" && action_name != 'sysverb_back') {
var rc = f.onsubmit();
if (rc === false) {
g_submitted = g_form.submitted = false;
return false;
}
}
if (control && control.getAttribute('gsft_id')) {
action_name = control.getAttribute('gsft_id');
f.sys_action.value=action_name;
}
if (action_name == 'sysverb_back')
g_submitted = false;
else
g_submitted = true;
if (typeof g_form != 'undefined' && g_form && g_submitted)
g_form.enableUIPolicyFields();
CustomEvent.fire("glide:form_submitted");
try {
f.submit();
} catch (ex) {
if (ex.message.indexOf('Unspecified') == -1)
throw ex;
}
return false;
}
function setCheckBox(box) {
var name = box.name;
var id = name.substring(3);
var frm = box.form;
if (frm)
frm[id].value = box.checked;
else {
var widget = $(id);
if (widget)
widget.value = box.checked;
}
if (box['onchange'])
box.onchange();
}
function populateParmQuery(form, prefix, defaultNULL, action) {
var keys = ['No records selected', 'Delete the selected item?', 'Delete these', 'items?'];
var msgs = getMessages(keys);
var keyset = getChecked(form);
if (!action)
action = form.sys_action.value;
if (action.indexOf("sysverb") != 0) {
if (keyset == '') {
if (!alert(msgs["No records selected"]))
return false;
} else {
if (action == "delete_checked") {
var items = keyset.split(",");
if (items.length == 1) {
if (!confirm(msgs["Delete the selected item?"]))
return false;
} else if (items.length > 0) {
if (!confirm(msgs["Delete these"] + " " + items.length + " " + msgs["items?"]))
return false;
}
}
}
} else if (form.sys_action.value == "sysverb_new") {
addInput(form, 'HIDDEN', 'sys_id', '-1');
}
if (keyset == '' && defaultNULL)
keyset = defaultNULL;
if (prefix)
keyset = prefix + keyset;
addInput(form, 'HIDDEN', 'sysparm_checked_items', keyset);
return true;
}
function getChecked(form) {
var keyset = '';
var lookup = form;
for (i = 0; i < lookup.elements.length; i++) {
if ( lookup.elements[i].type != "checkbox")
continue;
var v = lookup.elements[i];
if (v.checked) {
var id = v.id.substring(3);
var skip = v.name.substring(0,4);
if (skip == "SKIP")
continue;
if (id == "all")
continue;
if (keyset == '')
keyset = id;
else
keyset = keyset + ',' + id;
}
}
return keyset;
}
function iterateList(e, row, value, update) {
update = (typeof update === 'undefined') ? true : update;
if (update)
g_form.setMandatoryOnlyIfModified(true);
var form = g_form.getFormElement();
form.sys_action.value = value;
var query = e.getAttribute("query");
addInput(form, 'HIDDEN', 'sys_record_row', row);
addInput(form, 'HIDDEN', 'sys_record_list', query);
if (update && typeof form.onsubmit == "function") {
var rc = form.onsubmit();
if (!rc) {
g_submitted = false;
return false;
}
}
try {
form.submit();
} catch (ex) {
if (ex.message.indexOf('Unspecified') == -1)
throw ex;
}
return false;
}
function refreshNav() {
CustomEvent.fireTop('navigator.refresh');
}
function checkSave(tableName, urlBase, idField, refKey){
var sysid = document.getElementsByName(idField)[0].value;
checkSaveID(tableName, urlBase, sysid, refKey);
}
function checkSaveID(tableName, urlBase, sysid, refKey) {
sysid = trim(sysid);
var url = urlBase+"?sys_id="+sysid;
if (refKey)
url += "&sysparm_refkey=" + refKey;
var view = $('sysparm_view');
if (view != null) {
view = view.value;
if (view != '')
url += "&sysparm_view=" + view;
}
var nameOfStack = $('sysparm_nameofstack');
if (nameOfStack != null) {
nameOfStack = nameOfStack.value;
if (nameOfStack != '')
url += "&sysparm_nameofstack=" + nameOfStack;
}
return checkSaveURL(tableName, url);
}
function checkSaveURL(tableName, url) {
if (g_submitted)
return false;
var f = document.getElementById(tableName + ".do");
if (g_form.getTableName() == tableName) {
var fs = document.forms;
for (var z=0; z < fs.length; z++) {
if (typeof fs[z].sys_uniqueValue != 'undefined') {
f = fs[z];
break;
}
}
}
if (!g_form.isNewRecord())
g_form.setMandatoryOnlyIfModified(true);
f.sys_action.value = 'sysverb_check_save';
addInput(f, 'HIDDEN', 'sysparm_goto_url', url);
if (typeof f.onsubmit == "function") {
var rc = f.onsubmit();
if (!rc) {
g_submitted = false;
return false;
}
}
g_submitted = true;
if (typeof g_form != 'undefined' && g_form)
g_form.enableUIPolicyFields();
f.submit();
return false;
}
function submitTextSearch(event, tableName) {
if (event != true && event.keyCode != 13)
return;
var form = getControlForm(tableName);
addHidden(form, 'sysverb_textsearch', form['sys_searchtext'].value);
addHidden(form, 'sysparm_query', '');
addHidden(form, 'sysparm_referring_url', '');
form.submit();
}
function getControlForm(name) {
var form = document.forms[name + '_control'];
if (isSafari || isChrome) {
if (form) {
var collectionType = form.toString();
if (collectionType != "[object HTMLFormElement]")
form = form[0];
}
}
return form;
}
function getFormForList(listId) {
return $(listId + "_control");
}
function getFormForElement(element) {
var f = element.form;
if (f)
return f;
return findParentByTag(element, "form");
}
function hideReveal(sectionName, imagePrefix, snap) {
var el = $(sectionName);
if (!el)
return;
var img = $("img." + sectionName);
var imageName = "section";
if (imagePrefix)
imageName = imagePrefix;
if (el.style.display == "block") {
if (snap)
hide(el);
else
collapseEffect(el);
if (img) {
img.src = "images/"+imageName+"_hide.gifx";
img.alt = getMessage("Display / Hide");
}
} else {
if (snap)
show(el);
else
expandEffect(el);
if (img) {
img.src = "images/"+imageName+"_reveal.gifx";
img.alt = getMessage("Display / Hide");
}
}
}
function hideRevealWithTitle(name, hideMsg, showMsg) {
var el = $(name);
if (!el)
return;
var img = $("img." + name);
if (el.style.display == "block"){
el.style.display = "none";
img.src = "images/section_hide.gifx"
img.title = showMsg;
img.alt = showMsg;
} else {
el.style.display = "block";
img.src = "images/section_reveal.gifx"
img.title = hideMsg;
img.alt = hideMsg;
}
}
function forceHideWithTitle(name, msg) {
var el = $(name);
if (!el)
return;
var img = $("img." + name);
el.style.display = "none";
img.src = "images/section_hide.gifx"
img.title = msg;
img.alt = msg;
}
function forceHide(sectionName){
var el = $(sectionName);
if (!el)
return;
var img = $("img." + sectionName);
el.style.display = "none";
img.src = "images/section_hide.gifx";
img.alt = getMessage("Collapse");
}
function forceReveal(sectionName, sectionNameStarts, tagName){
var els = $$(tagName);
if (els) {
for(var c=0;c<els.length;++c) {
if ( els[c].id.indexOf(sectionNameStarts) == 0 ) {
forceHide(els[c].id);
}
}
}
var el = $(sectionName);
if (!el)
return;
var img = $("img." + sectionName);
el.style.display = "block";
img.src = "images/section_reveal.gif";
img.alt = getMessage("Expand");
window.location = '#' + sectionName;
}
function insertAtCursor(textField, value) {
if (document.selection) {
textField.focus();
sel = document.selection.createRange();
sel.text = value;
} else if (textField.selectionStart || textField.selectionStart == 0) {
var startPos = textField.selectionStart;
var endPos = textField.selectionEnd;
textField.value = textField.value.substring(0, startPos) + value +
textField.value.substring(endPos, textField.value.length);
} else {
textField.value += value;
}
}
function insertScriptVar(textBoxName, selectBoxName) {
var textBox = $(textBoxName);
var select = $(selectBoxName);
var options = select.options;
for (var i = 0; i != select.length; i++) {
var option = options[i];
if (!option.selected)
continue;
var label = option.text;
var v = option.value.split('.');
v = 'current.' + v[1];
insertAtCursor(textBox, v);
}
}
function clearCacheSniperly() {
var aj = new GlideAjax("GlideSystemAjax");
aj.addParam("sysparm_name", "cacheFlush");
aj.getXML(clearCacheDone);
}
function clearCacheDone() {
window.status = "Cache flushed";
}
function fieldTyped(me) {
formChangeKeepAlive();
}
function setPreference(name, value, func) {
var u = getActiveUser();
if (u)
u.setPreference(name, value);
var url = new GlideAjax("UserPreference");
url.addParam("sysparm_type", "set");
url.addParam("sysparm_name", name);
url.addParam("sysparm_value", value);
if (!func)
func = doNothing;
url.getXML(func);
}
function deletePreference(name) {
var u = getActiveUser();
if (u)
u.deletePreference(name);
var url = new GlideAjax("UserPreference");
url.addParam("sysparm_type", "delete");
url.addParam("sysparm_name", name);
url.getXML(doNothing);
}
function getPreference(name) {
var u = getActiveUser();
if (u) {
var opinion =  u.getPreference(name);
if (typeof opinion != 'undefined')
return opinion;
}
var url = new GlideAjax("UserPreference");
url.addParam("sysparm_type", "get");
url.addParam("sysparm_name", name);
var xml = url.getXMLWait();
if (!xml)
return '';
var items = xml.getElementsByTagName("item");
for (var i = 0; i < items.length; i++) {
var item = items[i];
var value = item.getAttribute("value");
return value;
}
return '';
}
function getActiveUser() {
return getTopWindow().g_active_user;
}
function labelClicked(label, elementType) {
var hFor = label.htmlFor;
if (hFor) {
var elpaco = $("sys_display." + hFor);
if (!elpaco || elpaco.type == "hidden")
elpaco = $(hFor);
if (elpaco && elpaco.type != "hidden" && elpaco.style.visibility != "hidden") {
if (elpaco.disabled != true)
if (elementType == "html" || elementType == "translated_html") {
var handler = g_form.elementHandlers[hFor];
if (handler)
handler.focusEditor();
} else
elpaco.focus();
}
}
return false;
}
function insertFieldName(textBoxName, label) {
var textBox = $(textBoxName);
var index = label.indexOf(":");
if (index > -1 )
insertAtCursor(textBox, "\n" + label);
else
insertAtCursor(textBox, label);
}
function preloadImages(srcs) {
for(var i = 0; i < srcs.length; i++) {
var imgSrc = srcs[i];
if (!preloadedImages[imgSrc]) {
var img = new Image();
img.src = imgSrc;
preloadedImages[imgSrc] = img;
}
}
}
function breakeveryheader(me) {
var mainWin = getMainWindow();
if (!mainWin)
mainWin = top;
if (mainWin && mainWin.CustomEvent && mainWin.CustomEvent.fire("print.grouped.headers", me.checked) === false)
return false;
var thestyle=(me.checked)? "always" : "auto";
var els = $$("td");
for (i = 0; i < els.length; i++) {
if (els[i].id == 'breaker') {
els[i].style.pageBreakAfter = thestyle;
}
}
}
function printList(maxRows) {
var mainWin = getMainWindow();
if (mainWin && mainWin.CustomEvent.fire("print", maxRows) === false)
return false;
var veryLargeNumber = "999999999";
var print = true;
var features = "resizable=yes,scrollbars=yes,status=yes,toolbar=no,menubar=yes,location=no";
var href = "";
var frame = top.gsft_main;
if (!frame)
frame = top;
if (frame.document.getElementById("printURL") != null) {
href = frame.document.getElementById("printURL").value;
href = printListURLDecode(href);
}
if (!href) {
if (frame.document.getElementById("sysparm_total_rows") != null) {
var mRows = parseInt(maxRows);
if (mRows < 1)
mRows = 5000;
var totalrows = frame.document.getElementById("sysparm_total_rows").value;
if (parseInt(totalrows) > parseInt(mRows))
print = confirm(getMessage("Printing large lists may affect system performance. Continue?"));
}
var formTest;
var f = 0;
var form;
while ((formTest = frame.document.forms[f++])) {
if (formTest.id == 'sys_personalize_ajax') {
form = formTest;
break;
}
}
if (!form)
form = frame.document.forms['sys_personalize'];
if (form && form.sysparm_referring_url) {
href = form.sysparm_referring_url.value;
if (href.indexOf("?sys_id=-1") != -1 && !href.startsWith('sys_report_template')) {
alert(getMessage("Please save the current form before printing."));
return false;
}
if (isMSIE) {
var isFormPage = frame.document.getElementById("isFormPage");
if (isFormPage != null && isFormPage.value == "true")
href = href.replace(/javascript%3A/gi, "_javascript_%3A");
}
href = printListURLDecode(href);
} else
href = document.getElementById("gsft_main").contentWindow.location.href;
}
if( href.indexOf("?") <0 )
href += "?";
else
href += "&";
href = href.replace("partial_page=", "syshint_unimportant=");
href = href.replace("sysparm_media=", "syshint_unimportant=");
href += "sysparm_stack=no&sysparm_force_row_count=" + veryLargeNumber + "&sysparm_media=print";
if (print) {
if (href != null && href != "") {
win = window.open(href, "Printer_friendly_format", features);
win.focus();
} else {
alert("Nothing to print");
}
}
}
function printListURLDecode(href) {
href = href.replace(/@99@/g, "&");
href = href.replace(/@88@/g, "@99@");
href = href.replace(/@77@/g, "@88@");
href = href.replace(/@66@/g, "@77@");
return href;
}
function replaceRegEx(text, doc, tableName) {
var s = "";
var re = new RegExp("%\\{\\w+[\\}]");
var m = re.exec(text);
if (m != null) {
for (i = 0; i < m.length; i++) {
s = s + m[i];
}
}
if (tableName.indexOf('.') > 0)
tableName = tableName.split('.')[0];
if (s.length > 0) {
var field = s.substring(2, s.length - 1);
var obj = doc.getElementById("sys_display." + tableName + "." +  field);
var val = "?";
if (obj != null)
val = obj.value;
if (val.length == 0) {
var labelText = "?";
var labels = doc.getElementsByTagName("label");
for(i = 0; i < labels.length; i++){
if (labels[i].htmlFor == tableName + "." + field) {
labelText = labels[i].innerHTML;
break;
}
}
if (labelText.indexOf(':') > 0)
labelText = labelText.split(':')[0];
val = labelText;
}
re = new RegExp("%\\{" + field + "[\\}]", "g");
var result = text.replace(re, val);
if (result.indexOf("%{") > 0)
result = replaceRegEx(result, doc, tableName);
return result;
} else
return text;
}
function toggleInline(name) {
_toggleDisplay(name, 'inline');
}
function _toggleDisplay(name, displayType) {
var e = $(name);
if (e.style.display == 'none' ) {
e.style.display = displayType;
setPreference(name, displayType, null);
} else {
e.style.display = 'none';
setPreference(name, 'none', null);
}
}
function textareaResizer(id, change) {
objectResizer(id, change, 'rows');
}
function textareaSizer(id, rows) {
var element = $(id);
if (element){
setAttributeValue(element, 'rows', rows);
}
}
function selectResizer(id, change) {
objectResizer(id, change, 'size');
}
function objectResizer(id, change, attrName) {
var element = $(id),
value,
doctype = (document.documentElement.getAttribute('data-doctype') == 'true');
if (!element)
return;
if(doctype){
value = parseInt(element.style.height, 10)
} else {
value = getAttributeValue(element, attrName) * 1;
}
value += change;
if (value < 1)
value = 1;
if (element.tagName == 'INPUT') {
element = $("div."+id);
if (element) {
if (change > 0) {
element.show();
} else {
element.hide();
value = 1;
}
}
} else {
var oldRows = element.rows;
if (doctype) {
element.style.height = value + 'px';
handleMaxMinHeights(element, value);
resizeTextAreaIframe(true, id, value);
} else {
setAttributeValue(element, attrName, value);
resizeTextAreaIframe(false, id, value, oldRows);
}
}
setPreference('rows.' + id, value, doNothing);
_frameChanged();
}
function handleMaxMinHeights(element, height){
if (!element || !height){
return;
}
var $element = $(element),
maxHeight = parseInt($element.getStyle('maxHeight'), 10),
minHeight = parseInt($element.getStyle('minHeight'), 10),
id = getAttributeValue($element, 'id');
if ( height >= maxHeight ){
$('sizer_plus_' + id).addClassName('disabled');
$element.setStyle({
overflowY: 'auto'
});
return;
}
if ( height <= minHeight ) {
$('sizer_minus_' + id).addClassName('disabled');
return;
}
$('sizer_plus_' + id).removeClassName('disabled');
$('sizer_minus_' + id).removeClassName('disabled');
}
function resizeTextAreaIframe() {
var args = Array.prototype.slice.call(arguments, 0),
tf = $("textarea_iframe." + id),
doctype = args[0],
id = args[1],
height,
oldRows,
rows;
if (doctype){
height = args[2];
} else {
rows = args[2];
oldRows = args[3];
}
if (!tf){
tf = $(id + '_ifr');
if (tf){
var tbl = $(id + '_tbl');
var readOnlyDiv = $(id + '_readOnlyDiv');
if (doctype){
tf.style.height = (height + 60) + "px";
if ( tbl ){
tbl.style.height = (height + 60) + "px";
}
if ( readOnlyDiv ) {
readOnlyDiv.style.height = (height + 60) + "px";
}
} else {
var elHeight = parseInt(tf.clientHeight);
if (elHeight == 0 && readOnlyDiv)
elHeight = parseInt(readOnlyDiv.style.height);
var pixelsPerRow = 12;
var newHeight = elHeight + (rows - oldRows) * pixelsPerRow;
tf.style.height = newHeight + "px";
if (tbl){
tbl.style.height = (parseInt(tbl.style.height) + (newHeight-elHeight)) + "px";
}
if (readOnlyDiv){
readOnlyDiv.style.height = newHeight + "px";
}
}
}
}
if (!tf)
return;
if (!tf.parentNode)
return;
if (!tf.parentNode.nextSibling)
return;
var nid = tf.parentNode.nextSibling.id;
if (nid != id)
return;
var elHeight = tf.clientHeight;
var pixelsPerRow = Math.round(elHeight / oldRows);
tf.style.height = rows * pixelsPerRow + "px";
}
function toggleQuestionRows(thisclass, display, fl) {
forcelabels = false;
if (fl == true)
forcelabels = true;
var rows = $(document.body).select('.' + thisclass);
for (i = 0; i < rows.length; i++) {
var element = rows[i];
var id = element.id;
if ('CATEGORY_LABEL' != id || forcelabels)
element.style.display = display;
}
var openStyle='none';
var closedStyle='none';
if ('none' == display)
openStyle = '';
else
closedStyle = '';
var s = $(thisclass+'CLOSED');
s.style.display=closedStyle;
s = $(thisclass+'OPEN');
s.style.display=openStyle;
}
function toggleWorkflow(id, expandPref) {
var map = getMessages(['Expand', 'Collapse']);
var table = $("workflow." + id);
var spans = table.getElementsByTagName("span");
for(var i = 0; i != spans.length; i++) {
var span = spans[i];
if (!span.getAttribute("stage"))
continue;
var spanImage = $(span.id + '.image');
var spanText = $(span.id + '.text');
if (span.getAttribute("selected") == 'true')
spanText.style.color = "#2050d0";
var filterImg = $('filterimg.' + id);
if (expandPref == "false") {
span.style.display = "";
spanText.style.display = "none";
filterImg.src = "images/filter_hide16.gifx";
filterImg.title = map["Expand"];
filterImg.alt = map["Expand"];
} else {
span.style.display = "block";
spanText.style.display = "";
filterImg.src = "images/filter_reveal16.gifx";
filterImg.title = map["Collapse"];
filterImg.alt = map["Collapse"];
}
}
_frameChanged();
}
function togglePreference(id) {
toggleItems(id);
}
function toggleItems(id, force) {
var tables = $$("table");
for (var i = 0; i < tables.length; i++) {
var tableId = tables[i].id;
if (tableId.indexOf("workflow.") == -1)
continue;
var idParts = tables[i].id.split(".");
if (id && tableId != "workflow." + id)
continue;
var pref = getPref(idParts[1]);
if (force != pref)
toggleWorkflow(idParts[1], pref);
if (id)
break;
}
}
function getPref(id) {
var filterImgSrc = $('filterimg.' + id).src
if (filterImgSrc.indexOf('filter_hide') != -1)
return "true";
return "false";
}
Event.observe(document, 'keyup', checkForClientKeystroke) ;
function checkForClientKeystroke(evt) {
if (evt.keyCode == 27 && window.g_popup_manager) {
g_popup_manager.destroypopDiv();
return;
}
if (evt.shiftKey && evt.ctrlKey && evt.keyCode == 74) {
var gWindow = new GlideDialogWindow("client_js");
gWindow.setTitle("JavaScript Executor");
gWindow.setPreference('table', 'javascript_executor');
gWindow.render();
Event.stop(evt);
return;
}
try {
if (typeof parent.navVisible == "function") {
if (evt.ctrlKey && evt.keyCode == 190 && !evt.shiftKey && !evt.altKey) {
Event.stop(evt);
if (parent.navVisible()) {
parent.hideNav();
parent.hide("banner_top_left");
parent.hide("banner_top_right");
} else {
parent.showNav();
parent.show("banner_top_left");
parent.show("banner_top_right");
}
}
}
} catch (e) { }
}
function toggleHelp(name) {
var wrapper = $('help_' + name + '_wrapper');
var image = $('img.help_' + name + '_wrapper');
if (wrapper.style.display=="block") {
wrapper.style.display = "none";
image.src = "images/filter_hide16.gifx";
} else {
wrapper.style.display = "block";
image.src = "images/filter_reveal16.gifx";
}
image.alt = getMessage("Display / Hide");
_frameChanged();
}
function validateHex(field) {
var num = field.value;
var valid = isHex(num);
if (!valid) {
var sName = '';
if (field.name != null)
sName = ' of '+field.name+' ';
alert("The entered value "+sName+"is not hex.  Please correct.");
}
}
function isHex(num) {
var str = num.replace(new RegExp('[0-9a-fA-F]','g'),'');
if (str.length > 0)
return false;
return true;
}
function setLightWeightLink(name) {
var v = $(name);
if (!v)
return;
var link = $(name + "LINK");
if (!link)
return;
var vis = "hidden";
if (v.value != '')
vis = "";
link.style.visibility = vis;
link.style.display = vis == 'hidden' ? 'none' : '';
}
function toggleDebug(id) {
id = id.split('.')[1];
for (var i =0; i < 1000; i++) {
var widgetName = 'debug.' + id + '.' + i;
var w = $(widgetName);
if (!w)
return;
w.toggle();
}
}
function enterSubmitsForm(e, enter_submits_form) {
if (e.keyCode != 13)
return true;
if (e.ctrlKey == true)
return false;
var source = Event.element(e);
if (source.getAttribute("data-type")  && e.keyCode == 13 && source.getAttribute("data-type") == 'ac_reference_input')
return false;
if (source && source.type=="textarea")
return true;
if (source && source.type == "submit") {
if (source.disabled == false && source.onclick) {
source.onclick();
return false;
}
}
if (enter_submits_form == 'false')
return false;
var headerElements = $(document.body).select(".header");
var eSize = headerElements.length;
for (var i=0; i < eSize; i++) {
var element = headerElements[i];
if (element.type=="submit") {
if (element.disabled == false) {
source.blur();
setTimeout(function(){element.onclick();}, 0);
return false;
}
}
}
return false;
}
function gsftPrompt(title, question, onPromptComplete, onPromptCancel) {
var dialog = new GlideDialogWindow('glide_prompt', false);
dialog.setTitle(title);
dialog.setPreference('title', question);
dialog.setPreference('onPromptComplete', onPromptComplete);
dialog.setPreference('onPromptCancel', onPromptCancel);
dialog.render();
}
function gsftConfirm(title, question, onPromptSave, onPromptCancel, onPromptDiscard) {
var dialog = new GlideDialogWindow('glide_confirm', false);
dialog.setTitle(title);
dialog.setPreference('title', question);
dialog.setPreference('onPromptSave', onPromptSave);
dialog.setPreference('onPromptCancel', onPromptCancel);
dialog.setPreference('onPromptDiscard', onPromptDiscard);
dialog.render();
}
function tsIndexCreatorPopup(tableName) {
var gDialog = new GlideDialogWindow("dialog_text_index_creator");
gDialog.setSize(400, 250);
gDialog.setPreference("table_name", tableName);
if (tableName != "")
gDialog.setTitle('Generate Text Index');
else
gDialog.setTitle('Regenerate All Text Indexes');
gDialog.render();
}
function isTextDirectionRTL() {
return g_text_direction == 'rtl' ? true : false;
}
if (typeof HTMLElement != "undefined" && !HTMLElement.prototype.insertAdjacentElement) {
HTMLElement.prototype.insertAdjacentElement = function(where, parsedNode) {
where = where.toLowerCase();
switch (where) {
case 'beforebegin':
this.parentNode.insertBefore(parsedNode, this)
break;
case 'afterbegin':
this.insertBefore(parsedNode, this.firstChild);
break;
case 'beforeend':
this.appendChild(parsedNode);
break;
case 'afterend':
if (this.nextSibling)
this.parentNode.insertBefore(parsedNode, this.nextSibling);
else
this.parentNode.appendChild(parsedNode);
break;
}
}
HTMLElement.prototype.insertAdjacentHTML = function(where, htmlStr) {
var r = this.ownerDocument.createRange();
r.setStartBefore(this);
var parsedHTML = r.createContextualFragment(htmlStr);
this.insertAdjacentElement(where, parsedHTML)
}
HTMLElement.prototype.insertAdjacentText = function(where, txtStr) {
var parsedText = document.createTextNode(txtStr)
this.insertAdjacentElement(where, parsedText)
}
}
function simpleRemoveOption(sourceSelect) {
var sourceOptions = sourceSelect.options;
var selectedIds = [];
var index = 0;
for (var i = 0; i < sourceSelect.length; i++) {
option = sourceOptions[i];
if (option.selected) {
selectedIds[index] = i;
index++;
}
}
for (var i = selectedIds.length - 1; i > -1; i--)
sourceSelect.remove(selectedIds[i]);
sourceSelect.disabled = true;
sourceSelect.disabled = false;
}
function saveAllSelected(fromSelectArray, toArray, delim, escape, emptyLabel, doEscape) {
var translatedEmptyLabel = getMessage(emptyLabel);
for (var i = 0; i < fromSelectArray.length; i++) {
if (typeof fromSelectArray[i] == 'undefined') {
toArray[i].value = '';
continue;
}
var toValue = "";
for (var j = 0; j < fromSelectArray[i].length; j++) {
if (!(fromSelectArray[i].length == 1 && fromSelectArray[i].options[0].value == translatedEmptyLabel)) {
var val = fromSelectArray[i].options[j].value;
if (doEscape)
val = encodeURIComponent(val);
val = val.replace(new RegExp(escape + escape, "g"), escape + escape);
toValue += val.replace(new RegExp(delim, "g"), escape + delim);
}
if (j + 1 < fromSelectArray[i].length)
toValue += delim;
}
toArray[i].value = toValue;
}
}
function sortSelect (obj) {
var maxSort = obj.getAttribute("max_sort");
if (!maxSort || maxSort == 0)
maxSort = 500;
if (obj.length > maxSort && isMSIE && !isMSIE9) { return; }
if (!sortSupported(obj)) { return; }
if (!hasOptions(obj)) { return; }
var o = [];
var o2 = [];
var o3 = [];
for (var i=0; i<obj.options.length; i++) {
var newOption = new Option( obj.options[i].text, obj.options[i].value, obj.options[i].defaultSelected, obj.options[i].selected);
copyAttributes(obj.options[i], newOption);
if (newOption.value.indexOf('split') > 0)
o2[o2.length] = newOption;
else if (newOption.value.indexOf('formatter') > 0 || newOption.value.indexOf('component') > 0 ||
newOption.value.indexOf('annotation') > 0 || newOption.value.indexOf('chart') > 0)
o3[o3.length] = newOption;
else
o[o.length] = newOption;
}
if (o.length == 0)
return;
o = o.sort(
function(a,b) {
if ((a.text.toLowerCase()+"") < (b.text.toLowerCase()+"")) { return -1; }
if ((a.text.toLowerCase()+"") > (b.text.toLowerCase()+"")) { return 1; }
return 0;
}
);
o3 = o3.sort(
function(a,b) {
if ((a.text.toLowerCase()+"") < (b.text.toLowerCase()+"")) { return -1; }
if ((a.text.toLowerCase()+"") > (b.text.toLowerCase()+"")) { return 1; }
return 0;
}
);
for (var i = 0; i < o.length; i++) {
var newOption = new Option(o[i].text, o[i].value, o[i].defaultSelected, o[i].selected);
copyAttributes(o[i], newOption);
obj.options[i] = newOption;
}
var counter = 0;
for (var i = o.length; i < (o.length + o2.length); i++) {
var newOption = new Option(o2[counter].text, o2[counter].value, o2[counter].defaultSelected, o2[counter].selected);
copyAttributes(o2[counter], newOption);
obj.options[i] = newOption;
counter++;
}
var counter = 0;
for (var i = (o.length + o2.length); i < (o.length + o2.length + o3.length); i++) {
var newOption = new Option(o3[counter].text, o3[counter].value, o3[counter].defaultSelected, o3[counter].selected);
copyAttributes(o3[counter], newOption);
obj.options[i] = newOption;
counter++;
}
}
function copyAttributes(from, to) {
var attributes = from.attributes;
for (var n = 0; n < attributes.length; n++) {
var attr = attributes[n];
var aname = attr.nodeName;
var avalue = attr.nodeValue;
to.setAttribute(aname, avalue);
}
if (from.style.cssText)
to.style.cssText = from.style.cssText;
}
function hasOptions(obj) {
if (obj != null && obj.options != null)
return true;
return false;
}
function sortSupported(obj) {
if (obj == null)
return false;
var noSort = obj.no_sort || obj.getAttribute('no_sort');
if (noSort) {
return false;
}
return true;
}
;
/*! RESOURCE: /scripts/functions_fontsizer.js */
function setPreferredFontSize(increment) {
var ruleStart = "BODY, TABLE, INPUT, SELECT, BUTTON, INPUT.TEXT, TEXTAREA, INPUT.button {font-size: "
var ruleEnd = "}";
var t = g_fontSize;
if (g_fontSizePreference)
t = g_fontSizePreference;
var  t = t.split('p')[0];
t = parseInt(t) + increment;
if (6 > t || t > 18)
return;
t += "pt";
if (g_fontSizePreference != t) {
g_fontSizePreference = t;
setPreference('font-size', g_fontSizePreference);
var al = getFontWindowList();
for (var i =0; i != al.length; i++) {
var w = al[i];
if (typeof w.deleteStyleSheet == 'function') {
w.deleteStyleSheet("font_size");
w.createStyleSheet(ruleStart + t + ruleEnd, "font_size");
}
}
}
deleteStyleSheet("font_size");
createStyleSheet(ruleStart + t + ruleEnd, "font_size");
if (increment) {
var e = $("font_pref_text");
if (e)
e.innerHTML = "(" + g_fontSizePreference + ")";
}
CustomEvent.fireAll("fontsize.change");
}
function getFontWindowList() {
var answer = new Array();
var m = getMainWindow();
if (m)
answer.push(m);
var m = getMainFormWindow();
if (m)
answer.push(m);
var m = getNavWindow();
if (m)
answer.push(m);
return answer;
}
function deleteStyleSheet(id) {
var sheet = document.getElementById(id);
if (sheet) {
var head = document.getElementsByTagName("head")[0];
head.removeChild(sheet);
}
}
function createStyleSheet(cssText, id) {
var head = document.getElementsByTagName("head")[0];
var rules = document.createElement("style");
rules.setAttribute("type", "text/css");
if(id)
rules.setAttribute("id", id);
if (navigator.userAgent.toLowerCase().indexOf("msie") >= 0) {
head.appendChild(rules);
var ss = rules.styleSheet;
ss.cssText = cssText;
} else {
try{
rules.appendChild(document.createTextNode(cssText));
}catch(e){
rules.cssText = cssText;
}
head.appendChild(rules);
}
}
function setPreferredFont() {
var t = getPreference('font-size');
if (!t)
return;
g_fontSizePreference = t;
setPreferredFontSize(0);
}
;
/*! RESOURCE: /scripts/utils.js */
function doNothing() {}
function valueExistsInArray(val, array) {
for(var i = 0; i < array.length; i++) {
if (val == array[i])
return true;
}
return false;
}
function doubleDigitFormat(num) {
if (num >= 10)
return num;
return "0" + num;
}
function tripleDigitFormat(num) {
if (num >= 100)
return num;
if (num >= 10)
return "0" + doubleDigitFormat(num);
return "00" + num;
}
function sGetHours(totalSecs) {
return parseInt(totalSecs / (60 * 60), 10);
}
function sGetMinutes(totalSecs) {
totalSecs -= (60*60)*sGetHours(totalSecs);
return parseInt(totalSecs / 60, 10);
}
function sGetSeconds(totalSecs) {
totalSecs -= (60*60)*sGetHours(totalSecs);
totalSecs -= (60)*sGetMinutes(totalSecs);
return parseInt(totalSecs, 10);
}
function isNumber(test) {
if (typeof test == "undefined" || test == null)
return false;
var _numer = test.search("[^0-9]");
if (_numer > -1)
return false;
return true;
}
function isAlphaNum(thchar) {
return isAlpha(thchar) || isDigit(thchar);
}
function isAlpha(thchar){
return (thchar >= 'a' && thchar <= 'z\uffff') || (thchar >= 'A' && thchar <= 'Z\uffff') || thchar == '_';
}
function isDigit(thchar) {
return (thchar >= '0' && thchar <= '9');
}
function containsOnlyChars(validChars, sText) {
if (sText == null || sText == '')
return true;
for (var i = 0; i < sText.length; i++) {
var c = sText.charAt(i);
if (validChars.indexOf(c) == -1)
return false;
}
return true;
}
function removeElementsByName(name) {
var elements = document.getElementsByName(name);
for (i = 0; i < elements.length; i++ ) {
elements[i].parentNode.removeChild(elements[i]);
}
}
function getAttributeValue(element, attrName) {
return element.getAttribute(attrName);
}
function setAttributeValue(element, attrName, value) {
element.setAttribute(attrName, value);
}
function toggleDivDisplayAndReturn(divName) {
if (!divName)
return;
var div = $(divName);
if (!div)
return;
if (div.style.display == "none")
showObject(div);
else
hideObject(div);
return div;
}
function toggleDivDisplay(divName) {
toggleDivDisplayAndReturn(divName);
}
function findParentByTag(element, tag) {
var ret;
while (element && element.parentNode && element.parentNode.tagName) {
element = element.parentNode;
if (element.tagName.toLowerCase() == tag.toLowerCase())
return element;
}
return ret;
}
function replaceAll(str, from, to) {
var idx = str.indexOf( from );
while ( idx > -1 ) {
str = str.replace( from, to );
idx = str.indexOf( from );
}
return str;
}
function useAnimation() {
if (isTouchDevice)
return false;
return true;
}
function expandEffect(el, duration, steps, stepCallback, completionCallback) {
if (!useAnimation()) {
showObject(el);
if (completionCallback)
completionCallback(el);
return;
}
var h;
if (el.originalHeight)
h = el.originalHeight;
else {
h = getHeight(el);
if (h==0) {
showObject(el);
return;
}
el.originalHeight = h;
}
if (!duration)
duration = 70;
if (!steps)
steps = 14;
el.style.overflow = "hidden";
el.style.height = "1px";
el.style.display = "block";
el.style.visibility = "visible";
expandAnimationEffect(el, h, duration, steps, stepCallback, completionCallback);
return h;
}
function expandAnimationEffect(el, height, duration, steps, stepCallback, completionCallback) {
new Rico.Effect.Size( el.id, null, height, duration, steps, {
step: function() {
if (stepCallback)
stepCallback(el);
},
complete: function() {
_expandComplete(el, completionCallback);
}
});
}
function _expandComplete(el, completionCallback) {
el.style.overflow = "";
el.style.height = "auto";
if (completionCallback)
completionCallback(el);
_frameChanged();
}
function collapseEffect(el, duration, steps) {
if (!useAnimation()) {
hideObject(el);
return;
}
var h;
if (el.originalHeight)
h = el.originalHeight;
else {
h = el.offsetHeight;
el.originalHeight = h;
}
if (!duration)
duration = 70;
if (!steps)
steps = 14;
if (!h)
h = el.offsetHeight;
el.style.overflow = "hidden";
collapseAnimationEffect(el, h, duration, steps);
}
function collapseAnimationEffect(el, height, duration, steps) {
new Rico.Effect.Size( el.id, null, 1, duration, steps, {
complete: function() {
_collapseComplete(el, height);
}
});
}
function _collapseComplete(el, height) {
el.style.display = "none";
el.style.overflow = "";
el.style.height = height;
_frameChanged();
}
function getHeight(el) {
var item;
try {
item = el.cloneNode(true);
}
catch(e) {
jslog("getHeight blew up... we caught the error and returned 0")
return 0;
}
var height = 0;
item.style.visibility = "hidden";
item.style.display = "block";
item.style.position = "absolute";
item.style.top = 0;
item.style.left = 0;
document.body.appendChild(item);
height = item.offsetHeight;
document.body.removeChild(item);
return height;
}
function getWidth(el) {
var item = el.cloneNode(true);
var width = 0;
item.style.visibility = "hidden";
item.style.display = "block";
item.style.position = "absolute";
item.style.top = 0;
item.style.left = 0;
document.body.appendChild(item);
width = item.offsetWidth;
document.body.removeChild(item);
return width;
}
function grabOffsetLeft(item) {
return getOffset(item,"offsetLeft")
}
function grabOffsetTop(item) {
return getOffset(item, "offsetTop")
}
function getOffset(item, attr) {
var parentElement = getFormContentParent();
var wb=0;
while(item) {
wb += item[attr];
item = item.offsetParent;
if (item == parentElement)
break;
}
return wb;
}
function grabScrollLeft(item) {
return getScrollOffset(item, "scrollLeft")
}
function grabScrollTop(item) {
return getScrollOffset(item, "scrollTop")
}
function getScrollOffset(item, attr) {
var parentElement = getFormContentParent();
var wb=0;
while (item && item.tagName && item != parentElement) {
wb += item[attr];
if (isMSIE)
item = item.offsetParent;
else
item = item.parentNode;
}
return wb;
}
function getValue(evt) {
evt = getEvent(evt);
if (!evt)
return null;
var elem = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
if (!elem)
return null;
try {
return elem.options[elem.selectedIndex].value;
} catch(e) {
var msg = (typeof e == "string") ? e : ((e.message) ? e.message : "Unknown Error");
alert("Unable to get data:\n" + msg);
}
return null;
}
function getEvent(event) {
var event = event || window.event || top.event;
if (!event.target)
event.target = event.srcElement;
if (typeof event.layerX == 'undefined')
event.layerX = event.offsetX;
if (typeof event.layerY == 'undefined')
event.layerY = event.offsetY;
return event;
}
function getEventCoords(e) {
var fudge = getFormContentParent();
var answer = Event.pointer(e);
answer = new Point(answer.x, answer.y);
if (fudge == document.body)
return answer;
answer.x += fudge.scrollLeft;
answer.y += fudge.scrollTop;
var fudgeTop = fudge.getStyle('top');
var fudgePos = fudge.getStyle('position');
if (fudgePos == 'absolute' && fudgeTop && fudgeTop.indexOf('px'))
answer.y -= parseInt(fudgeTop.replace('px',''), 10);
return answer;
}
function getRelativeTop() {
var port = document.viewport;
var topLeft = new Point(port.getScrollOffsets().left, port.getScrollOffsets().top)
var fudge = getFormContentParent();
if (fudge != document.body) {
topLeft.x += fudge.scrollLeft;
topLeft.y += fudge.scrollTop;
}
return topLeft;
}
function getRealEvent(e) {
e = getEvent(e);
if (isTouchDevice && isTouchEvent(e)) {
e = e.changedTouches[0];
}
return e;
}
function isTouchEvent(e) {
if (typeof e == 'undefined' || typeof e.changedTouches == 'undefined')
return false;
return true;
}
function isTouchRightClick(e) {
if (!isTouchEvent(e))
return false;
var hasTwoFingers = e.changedTouches.length > 1;
return hasTwoFingers;
}
function getTextValue(node) {
if (node.textContent)
return node.textContent;
var firstNode = node.childNodes[0];
if (!firstNode)
return null;
if (firstNode.data)
return firstNode.data;
return firstNode.nodeValue;
}
function getObjX(obj){
if(!obj.offsetParent) return 0;
var x = getObjX(obj.offsetParent);
return obj.offsetLeft + x;
}
function getObjY(obj){
if(!obj.offsetParent) return 0;
var y = getObjY(obj.offsetParent);
return obj.offsetTop + y;
}
function getScrollX(){
if (window.pageXOffset)
return window.pageXOffset;
var parentElement = getFormContentParent();
if (parentElement.scrollHeight)
return parentElement.scrollLeft;
}
function getScrollY(){
if (window.pageYOffset)
return window.pageYOffset;
var parentElement = getFormContentParent();
if (parentElement.scrollWidth)
return parentElement.scrollTop;
}
function getMouseX(evt) {
if (evt.pageX) return evt.pageX;
obj = getSrcElement(evt);
return getScrollX() + evt.x;
}
function getMouseY(evt) {
if (evt.pageY) return evt.pageY;
return getScrollY() + evt.y;
}
function getSrcElement(evt) {
if (evt.srcElement) return evt.srcElement;
if (evt.target) return evt.target;
return evt.currentTarget;
}
function addForm() {
var form = cel('form');
document.body.appendChild(form);
if (typeof g_ck != 'undefined' && g_ck != "") {
addHidden(form, "sysparm_ck", g_ck);
}
return form;
}
function addHidden(form, name, value) {
addInput(form, 'HIDDEN', name, value);
}
function addInput(form, type, name, value){
var inputs = Form.getInputs(form, '', name);
if (inputs.length > 0) {
inputs[0].value = value;
return;
}
var opt = document.createElement('input');
opt.type = type;
opt.name = name;
opt.id = name;
opt.value = value;
form.appendChild(opt);
}
function getHiddenInputValuesMap(parent) {
var valuesMap = {}
var inputs = parent.getElementsByTagName('input');
for (var i = 0; i < inputs.length; i++) {
var input = inputs[i];
if (input.type.toLowerCase() != "hidden")
continue;
valuesMap[input.id] = input.value;
}
return valuesMap;
}
function appendSelectOption(select, value, label, index) {
var opt;
opt = document.createElement("option");
opt.value = value;
opt.appendChild(label);
if (index >= 0 && index != select.length)
select.insertBefore(opt,select.children[index]);
else
select.appendChild(opt);
return opt;
}
function copySelectOptionToIndex(select, opt, index) {
var label = opt.text;
opt.innerHTML = "";
opt.appendChild(document.createTextNode(label));
if (index >= 0 && index != select.length)
select.insertBefore(opt,select.children[index]);
else
select.appendChild(opt);
return opt;
}
function selectMenuItem(id, selectName) {
var selectMenu = document.getElementById(selectName);
if (!selectMenu)
return -1;
var options = selectMenu.options;
var selectItem = selectMenu.selectedIndex;
if (id) {
for (var i = 0; i < options.length; i++) {
var option = options[i];
if (option.value == id) {
selectItem = i;
break;
}
}
}
if (selectItem > 0) {
selectMenu.selectedIndex = selectItem;
if (selectMenu["onchange"]) {
selectMenu.onchange();
}
}
return selectItem;
}
function menuIsEmpty(selectName) {
var selectMenu = document.getElementById(selectName);
if (!selectMenu || selectMenu.selectedIndex <= 0)
return true;
return false;
}
function getBounds(obj, addScroll) {
var x = grabOffsetLeft(obj);
var y = grabOffsetTop(obj);
if (addScroll) {
x += getScrollX();
y += getScrollY();
}
this.absoluteRect = {
top:    y,
left:   x,
bottom: y + obj.offsetHeight,
right:  x + obj.offsetWidth,
height: obj.offsetHeight,
width:  obj.offsetWidth,
middleX: x + (obj.offsetWidth / 2),
middleY: y + (obj.offsetHeight / 2),
cbottom: y + obj.clientHeight,
cright:  x + obj.clientWidth
};
return this.absoluteRect;
}
function guid(l) {
var l = l || 32, strResult = '';
while (strResult.length < l)
strResult += (((1+Math.random()+new Date().getTime())*0x10000)|0).toString(16).substring(1);
return strResult.substr(0, l);
}
function stopSelection(e) {
e.onselectstart = function() { return false; };
e.style.MozUserSelect = "none";
}
function restoreSelection(e) {
e.onselectstart = null;
e.style.MozUserSelect = "";
}
if (!String.prototype.endsWith) {
String.prototype.endsWith = function(s) {
if (!s)
return false;
if (this.length < s.length)
return false;
return (this.substr(this.length - s.length, s.length) == s);
};
}
function getAttributeValue(element, name) {
if (!element.attributes)
return null;
var v = element.attributes.getNamedItem(name);
if (v == null)
return null;
return v.nodeValue;
}
function getAbsPosition(el) {
var r = { x: el.offsetLeft, y: el.offsetTop };
if (el.offsetParent) {
var tmp = getAbsPosition(el.offsetParent);
r.x += tmp.x;
r.y += tmp.y;
}
return r;
}
function createImage(src, title, object, onClick) {
var img = cel('input');
img.type = 'image';
img.src = src;
img.title = title;
img.alt = title;
if (arguments.length == 4)
img.onclick = onClick.bindAsEventListener(object);
return img;
}
function createIcon(cls, title, object, onClick) {
var icn = cel('a');
icn.addClassName(cls);
icn.setAttribute('title', title);
if (arguments.length == 4)
icn.onclick = onClick.bindAsEventListener(object);
return icn;
}
function getXMLString(node) {
var xml = "???";
if (node.xml) {
xml = node.xml;
} else if (window.XMLSerializer) {
xml = (new XMLSerializer()).serializeToString(node);
}
return xml;
}
function getXMLNodeAttribute(node, attr) {
if (!node)
return null;
var a = node.attributes.getNamedItem(attr);
return (a) ? a.value : null;
}
function importNode(d, childNode) {
var oNew;
if (childNode.nodeType == 1) {
oNew = d.createElement(childNode.nodeName);
for (var i = 0; i < childNode.attributes.length; i++) {
if (childNode.attributes[i].nodeValue != null && childNode.attributes[i].nodeValue != '') {
var attrName = childNode.attributes[i].name;
if (attrName == "class")
oNew.setAttribute("className", childNode.attributes[i].value);
else
oNew.setAttribute(attrName, childNode.attributes[i].value);
}
}
if (childNode.style != null && childNode.style.cssText != null)
oNew.style.cssText = childNode.style.cssText;
} else if (childNode.nodeType == 3) {
oNew = d.createTextNode(childNode.nodeValue);
}
if (childNode.hasChildNodes()) {
for (var oChild = childNode.firstChild; oChild; oChild = oChild.nextSibling) {
oNew.appendChild(importNode(d, oChild));
}
}
return oNew;
}
function isLeftClick(e) {
if (ie5 && getEvent(e).button != 1)
return false;
if (!ie5 && getEvent(e).button != 0)
return false;
return true;
}
function formatMessage() {
if (arguments.length == 1)
return arguments[0];
var str = arguments[0];
var args = arguments;
if(arguments.length == 2 && typeof arguments[1] == 'object' && arguments[1] instanceof Array) {
args = [''].concat(arguments[1]);
}
var i = 0;
while (++i < args.length) {
str = str.replace( new RegExp( '\\{'+(i-1)+'\\}', 'g' ), args[i] );
}
return str;
}
function getFormattedDateAndTime(date) {
return getFormattedDate(date) + " " + getFormattedTime(date);
}
function getFormattedDate(date) {
var d = (date? date : new Date());
var curr_mon = d.getMonth() + 1;
var curr_day = d.getDate();
var curr_year = d.getYear() - 100;
return doubleDigitFormat(curr_mon) + "/" + doubleDigitFormat(curr_day) + "/" + doubleDigitFormat(curr_year)
}
function getFormattedTime(date) {
var d = (date? date : new Date());
var curr_hour = d.getHours();
var curr_min = d.getMinutes();
var curr_sec = d.getSeconds();
var curr_msec = d.getMilliseconds();
return doubleDigitFormat(curr_hour) + ":" + doubleDigitFormat(curr_min) + ":" + doubleDigitFormat(curr_sec) + " (" + tripleDigitFormat(curr_msec) + ")"
}
function showGoToLine(textAreaID) {
var e = gel("go_to_" + textAreaID)
if (e) {
showObjectInline(e);
gel("go_to_input_" + textAreaID).focus();
}
}
function gotoLineKeyPress(evt, textAreaObject, input) {
evt = getEvent(evt);
if (evt.keyCode == 13) {
Event.stop(evt);
gotoLinePopup(textAreaObject, input.value);
input.value = "";
hideObject(input.parentNode);
}
}
function gotoLinePopup(textAreaObject, lineText) {
if (lineText) {
lineText = trim(lineText);
if (lineText) {
var line = parseInt(lineText, 10);
g_form._setCaretPositionLineColumn(textAreaObject, line, 1);
}
}
}
function getBrowserWindowHeight() {
var myHeight = 0;
if ( typeof( window.innerHeight ) == 'number' )
myHeight = window.innerHeight;
else if ( document.documentElement && document.documentElement.clientHeight )
myHeight = document.documentElement.clientHeight;
else if ( document.body && document.body.clientHeight )
myHeight = document.body.clientHeight;
return myHeight;
}
function getBrowserWindowWidth() {
var myWidth = 0;
if ( typeof( window.innerWidth ) == 'number' )
myWidth = window.innerWidth;
else if ( document.documentElement && document.documentElement.clientWidth )
myWidth = document.documentElement.clientWidth;
else if ( document.body && document.body.clientWidth )
myWidth = document.body.clientWidth;
return myWidth;
}
var WindowSize = Class.create({
initialize: function() {
this.width = getBrowserWindowWidth();
this.height = getBrowserWindowHeight();
}
});
function getScrollBarWidthPx() {
var inner = cel("p");
inner.style.width = "100%";
inner.style.height = "200px";
var outer = cel("div");
outer.style.position = "absolute";
outer.style.top = "0px";
outer.style.left = "0px";
outer.style.visibility = "hidden";
outer.style.width = "200px";
outer.style.height = "150px";
outer.style.overflow = "hidden";
outer.appendChild(inner);
document.body.appendChild(outer);
var w1 = inner.offsetWidth;
outer.style.overflow = "scroll";
var w2 = inner.offsetWidth;
if (w1 == w2) w2 = outer.clientWidth;
document.body.removeChild(outer);
return (w1 - w2);
}
function showOpticsDebugger() {
var mainWindow = getMainWindow();
if (mainWindow)
mainWindow.CustomEvent.fire('glide_optics_inspect_window_open');
}
function opticsLog(tablename, fieldname, message, oldvalue, newvalue) {
var info = {};
info.table = tablename;
info.field = fieldname;
info.message = message;
info.message_type = "static";
if (oldvalue && newvalue) {
info.oldvalue = oldvalue;
info.newvalue = newvalue;
info.message_type = "change";
}
CustomEvent.fire('glide_optics_inspect_log_message', info);
}
;
/*! RESOURCE: /scripts/functions/xmlhttp.js */
var isMicrosoftXMLHTTP = false;
var XML_HTTP = "xmlhttp.do";
function AJAXEvaluateSynchronously(expression) {
var ajax = new GlideAjax("AJAXEvaluator");
ajax.addParam("sysparm_expression", expression);
ajax.getXMLWait();
return ajax.getAnswer();
}
function AJAXEvaluate(expression, callbackAndArgs) {
var ajax = new GlideAjax("AJAXEvaluator");
ajax.addParam("sysparm_expression", expression);
ajax.getXML(AJAXEvaluateResponse, "", callbackAndArgs);
}
function AJAXEvaluateResponse(response, callbackAndArgs) {
var xml = response.responseXML;
var answer = xml.documentElement.getAttribute("answer");
if (callbackAndArgs != null) {
var callback = callbackAndArgs;
var args = new Array();
if (typeof callbackAndArgs != "function" && callbackAndArgs.length > 1) {
callback = callbackAndArgs.splice(0, 1)[0];
args = callbackAndArgs;
}
callback.call(answer, answer, response, args);
}
}
function AJAXFunction(func, args, callback, callbackArgs) {
for(var i = 0; i < args.length; i++) {
if (typeof args[i] == "function")
continue;
args[i] = args[i].replace(/"/g, "\\\"");
}
var expression = func + '("' + args.join('","') + '");';
var newArgs = new Array();
newArgs.push(callback);
newArgs = newArgs.concat(callbackArgs);
AJAXEvaluate(expression, newArgs);
}
function serverRequest(url, loadedFunction, args) {
ajaxRequest(url, null, true, loadedFunction, args);
}
function serverRequestWait(url, postString) {
var req = ajaxRequest(url, postString, false);
if (req.status == 200)
return req;
}
function serverRequestPost(url, postString, loadedFunction, args) {
ajaxRequest(url, postString, true, loadedFunction, args);
}
function ajaxRequest(url, postString, async, responseFunction, responseFunctionArgs) {
var req = getRequest();
showLoading();
if (req) {
if (async && (responseFunction != null))
req.onreadystatechange = function() { processReqChange(req, responseFunction, responseFunctionArgs); };
req.open((postString ? "POST" : "GET"), url, async);
if (typeof g_ck != 'undefined' && g_ck != "")
req.setRequestHeader('X-UserToken', g_ck);
if (postString) {
req.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
req.send(postString);
} else {
if (isMicrosoftXMLHTTP)
req.send();
else
req.send(null);
}
}
if (!async)
hideLoading();
return req;
}
function getRequest() {
var req = null;
if (window.XMLHttpRequest) {
req = new XMLHttpRequest();
} else if (window.ActiveXObject) {
isMicrosoftXMLHTTP = true;
req = new ActiveXObject("Microsoft.XMLHTTP");
}
return req;
}
function processReqChange(r, docLoadedFunction, docLoadedFunctionArgs) {
if (r.readyState == 4) {
hideLoading();
if (r.status == 200) {
lastActivity = new Date();
docLoadedFunction(r, docLoadedFunctionArgs);
} else {
try {
window.status = "There was a problem retrieving the XML data: " + r.statusText;
} catch (e) { }
}
}
}
function showLoading() {
try {
CustomEvent.fireAll("ajax.loading.start");
} catch(e) {}
}
function hideLoading() {
try {
CustomEvent.fireAll("ajax.loading.end");
} catch(e) {}
}
;
/*! RESOURCE: /scripts/classes/GwtMessage.js */
var GwtMessage = Class.create({
DEFAULT_LANGUAGE: "en",
PREFETCH_ENTRY_KEY : "PREFETCH_ENTRY_KEY",
initialize: function() {},
set: function(n, v) {
if (!v)
GwtMessage._messages[n] = true;
else
GwtMessage._messages[n] = v;
},
format: function(msg) {
if (!msg)
return "";
var str = msg;
for (var i = 1; i < arguments.length; i++) {
var paramIndex = i - 1;
var rx = new RegExp("\{[" + paramIndex + "]\}", "g");
str = str.replace(rx, arguments[i]);
}
return str;
},
getMessage: function(strVal) {
var valList = [];
valList.push(strVal);
var messages = this.getMessages(valList);
var msg = messages[strVal];
if (arguments.length > 1) {
var realArray = [].slice.call(arguments, 0);
realArray[0] = msg;
msg = this.format.apply(this, realArray);
}
return msg;
},
getMessages: function(resolveList) {
var pageMsgs = {};
var dataRequiringAjaxCall = [];
var results = {};
for (var i = 0; i < resolveList.length; i++) {
var v = GwtMessage._messages[resolveList[i]];
if (v === true)
pageMsgs[resolveList[i]] = resolveList[i];
else if (v)
pageMsgs[resolveList[i]] = v;
else
dataRequiringAjaxCall.push(resolveList[i]);
}
if (dataRequiringAjaxCall.length > 0) {
this._loadNewMessages(dataRequiringAjaxCall);
results = this._buildListFromCache(dataRequiringAjaxCall);
}
for (var key in pageMsgs)
results[key] = pageMsgs[key];
return results;
},
_loadNewMessages: function(resolveList) {
var cachedMessages = this._findCachedKeys(resolveList);
var keysToResolve = this._removeCachedEntries(resolveList, cachedMessages);
if (keysToResolve.length == 0)
return;
var ajax = new GlideAjax("SysMessageAjax");
ajax.addParam("sysparm_keys", keysToResolve.length);
ajax.addParam("sysparm_prefetch", this._shouldPrefetch() ? "true" : "false");
for (var i = 0; i < keysToResolve.length; i++) {
var keyVal = "key" + i;
ajax.addParam(keyVal, keysToResolve[i]);
}
var rxml = ajax.getXMLWait();
this._processResponse(rxml);
},
_removeCachedEntries: function(resolveList) {
var messagesToResolve = new Array();
for (var i = 0; i < resolveList.length; i++) {
var key = resolveList[i];
if (this._getCache().get(key))
continue;
messagesToResolve.push(key);
}
return messagesToResolve;
},
_processResponse: function(rxml) {
this._processItems(rxml, "preitem");
this._processItems(rxml, "item");
},
_shouldPrefetch : function() {
var pf = this._getCache().get(this._PREFETCH_ENTRY_KEY);
var now = new Date().getTime();
if (typeof pf == 'undefined' || (pf + 60000) < now) {
this._getCache().put(this._PREFETCH_ENTRY_KEY, now);
return true;
}
return false;
},
_processItems: function(xml, name) {
var items = xml.getElementsByTagName(name);
for (var i=0; i < items.length; i++) {
var key = items[i].getAttribute("key");
var value = items[i].getAttribute("value");
this.setMessage(key, value);
}
},
setMessage: function(key, msg) {
this._getCache().put(key, msg);
},
isDefaultLanguage: function() {
return this.getLanguage() == this.getDefaultLanguage();
},
getLanguage: function() {
return g_lang;
},
getDefaultLanguage: function() {
return this.DEFAULT_LANGUAGE;
},
_findCachedKeys: function(resolveList) {
var answer = new Array();
var cache = this._getCache();
for (var i =0; i< resolveList.length; i++) {
var key = resolveList[i];
var value = cache.get(key);
if (value)
answer.push(key);
}
return answer;
},
_buildListFromCache: function(resolveList) {
var answer = {};
var cache = this._getCache();
for (var i =0; i < resolveList.length; i++) {
var key = resolveList[i];
var value = cache.get(key);
answer[key] = value;
}
return answer;
},
_getCache: function() {
try {
if (getTopWindow().g_cache_message)
return getTopWindow().g_cache_message;
} catch (e) { }
if (typeof(g_cache_message) != "undefined")
return g_cache_message;
g_cache_message = new GlideClientCache(500);
return g_cache_message;
},
fetch: function(resolveList, callback) {
var cachedMessages = this._findCachedKeys(resolveList);
var keysToResolve = this._removeCachedEntries(resolveList, cachedMessages);
if (keysToResolve.length == 0) {
var answer = this.getMessages(resolveList);
callback(answer);
return;
}
var ajax = new GlideAjax("SysMessageAjax");
ajax.addParam("sysparm_keys", keysToResolve.length);
ajax.addParam("sysparm_prefetch", this._shouldPrefetch() ? "true" : "false");
for (var i = 0; i < keysToResolve.length; i++) {
var keyVal = "key" + i;
ajax.addParam(keyVal, keysToResolve[i]);
}
ajax.getXML(this.fetched.bind(this), null, {
fn : callback,
list : resolveList
});
},
fetched: function(response, parms) {
this._processResponse(response.responseXML);
var answer = this.getMessages(parms.list);
parms.fn(answer);
}
});
GwtMessage._messages = {};
function getMessage(msg) {
if (typeof msg == "object")
return new GwtMessage().getMessages(msg);
return new GwtMessage().getMessage(msg);
}
function getMessages(msgs) {
return new GwtMessage().getMessages(msgs);
}
;
/*! RESOURCE: /scripts/functions/textutil.js */
function htmlEscape(s) {
return s.replace(/&/g,"&amp;").replace(/'/g,"&#39;").replace(/"/g,"&quot;").replace(/</g,"&#60;").replace(/>/g,"&#62;");
}
function htmlEscapeQuote(s) {
return s.replace(/'/g,"&#39;");
}
function htmlEscapeDoubleQuote(s) {
return s.replace(/"/g,"&quot;");
}
function loadXML(r) {
var xml = r.responseXML;
if (typeof xml != 'undefined')
return xml;
var dom = null;
if (window.DOMParser) {
try {
dom = (new DOMParser()).parseFromString(r, 'text/xml');
}
catch (e) { dom = null; }
} else if (window.ActiveXObject) {
try {
dom = new ActiveXObject('Microsoft.XMLDOM');
dom.async = false;
if (!dom.loadXML(r))
jslog('ERROR: ' + dom.parseError.reason + dom.parseError.srcText);
} catch (e) { dom = null; }
} else
jslog('ERROR: Cannot parse xml string - "' + r + '".');
return dom;
}
;
/*! RESOURCE: /scripts/classes/event/GwtObservable.js */
var GwtObservable = Class.create({
initialize: function() {
this.events = {};
},
on: function(name, func) {
if (!func || typeof func != 'function')
return;
this.events = this.events || {};
if (!this.events[name])
this.events[name] = [];
this.events[name].push(func);
},
forward: function(name, element, func) {
GwtObservable.prototype.on.call(this, name, func);
Event.observe(element, name, function(e) {
this.fireEvent(e.type, this, e);
}.bind(this));
},
un: function(name, func) {
if (!this.events[name])
return;
var i = this.events[name].indexOf(func);
if(i !== -1)
this.events[name].splice(i, 1);
},
unAll: function(name) {
if (this.events[name])
delete this.events[name];
},
isFiring: function() {
return this._isFiring;
},
fireEvent: function() {
if (this.suppressEvents === true)
return true;
this.events = this.events || {};
var args = $A(arguments);
var name = args.shift();
var event = this.events[name];
if (!event)
return true;
this._isFiring = true;
for (var i = 0, l = event.length; i < l; i++) {
var ev = event[i];
if (ev == null)
continue;
if (ev.apply(this, args) === false) {
this._isFiring = false;
return false;
}
}
this._isFiring = false;
return true;
},
toString: function() { return 'GwtObservable'; }
});
;
/*! RESOURCE: /scripts/classes/event/CustomEventManager.js */
var CustomEventManager = Class.create(GwtObservable, {
trace: false,
initialize: function($super) {
$super();
},
observe: function(eventName, fn){
if (this.trace)
jslog("$CustomEventManager observing: " + eventName);
this.on(eventName, fn);
},
fire: function(eventName, args){
if (this.trace)
jslog("$CustomEventManager firing: " + eventName + " args: " + arguments.length);
return this.fireEvent.apply(this, arguments);
},
fireTop: function(eventName, args){
if (this.trace)
jslog("$CustomEventManager firing: " + eventName + " args: " + arguments.length);
this.fireEvent.apply(this, arguments);
var t = getTopWindow();
if (t != null && window != t)
t.CustomEvent.fireEvent(eventName, args);
},
fireAll: function(eventName, args) {
if (this.trace)
jslog("$CustomEventManager firing: " + eventName + " args: " + arguments.length);
var t = getTopWindow();
if (t == null) {
this.fireEvent.apply(this, arguments);
return;
}
t.CustomEvent.fireEvent(eventName, args);
for (var i = 0; i < t.length; i++) {
try {
if (!t[i])
continue;
if (t[i].CustomEvent && typeof t[i].CustomEvent.fireEvent == "function")
t[i].CustomEvent.fireEvent(eventName, args);
} catch(e) {
}
}
},
toString: function() { return 'CustomEventManager'; }
});
window.NOW = window.NOW || {};
window.NOW.CustomEvent = new CustomEventManager();
if (typeof CustomEvent !== "undefined") {
CustomEvent.observe = NOW.CustomEvent.observe.bind(NOW.CustomEvent);
CustomEvent.fire = NOW.CustomEvent.fire.bind(NOW.CustomEvent);
CustomEvent.fireTop = NOW.CustomEvent.fireTop.bind(NOW.CustomEvent);
CustomEvent.fireAll = NOW.CustomEvent.fireAll.bind(NOW.CustomEvent);
CustomEvent.on = NOW.CustomEvent.on.bind(NOW.CustomEvent);
CustomEvent.un = NOW.CustomEvent.un.bind(NOW.CustomEvent);
CustomEvent.unAll = NOW.CustomEvent.unAll.bind(NOW.CustomEvent);
CustomEvent.forward = NOW.CustomEvent.forward.bind(NOW.CustomEvent);
CustomEvent.isFiring = NOW.CustomEvent.isFiring.bind(NOW.CustomEvent);
CustomEvent.fireEvent = NOW.CustomEvent.fireEvent.bind(NOW.CustomEvent);
} else {
window.CustomEvent = NOW.CustomEvent;
}
;
/*! RESOURCE: /scripts/classes/GwtContextMenu.js */
var gActiveContext;
var contextMenus = new Object();
var shortcuts = new Object();
var GwtContextMenu = Class.create({
SUBMENU_INDICATOR: "<img src='images/context_arrow.gifx' class='context_item_menu_img' alt='Add' />",
initialize: function(id, useBodyAsParent) {
this.timeout = null;
this.properties = new Object();
this.setID(id);
this.getMenu();
this.onshow = null;
this.onhide = null;
this.beforehide = null;
this.docRoot = this._getDocRoot();
this.hasItems = false;
this.hideOnlySelf = false;
this.trackSelected = false;
if (typeof useBodyAsParent == "undefined")
useBodyAsParent = false;
this._getParentElement(useBodyAsParent);
},
isEmpty: function() {
return !this.hasItems;
},
_getParentElement: function(useBodyAsParent) {
if (useBodyAsParent) {
this.parentElement = document.body;
return;
}
this.parentElement = getFormContentParent();
},
_getDocRoot: function() {
var docRoot = window.location.protocol + "//" + window.location.host;
if (window.location.pathname.indexOf("/") > -1) {
var fp = window.location.pathname;
fp = fp.substring(0, fp.lastIndexOf("/"));
if (fp.substring(0, 1).indexOf("/") != -1)
docRoot = docRoot + fp;
else
docRoot = docRoot + "/" + fp;
}
docRoot += "/";
return docRoot;
},
add: function(label, id, keys) {
this.hasItems = true;
var m = this.getMenu();
var d = document.createElement("div");
d.setAttribute("item_id", id);
d.className = "context_item";
d.isMenuItem = true;
var l = !keys ? label : (label + ' (' + keys + ')');
d.innerHTML = l;
if(keys)
d.setAttribute("data-label", label);
m.appendChild(d);
return d;
},
addHref: function(label, href, img, title, id, keys) {
keys = this.addKeyShortcut(keys, href);
var d = this.add(label, id, keys);
d.setAttribute("href", href);
if (title && title != null)
d.setAttribute("title", title);
this.setImage(d, img);
return d;
},
addFunc: function(label, func, id) {
var d = this.add(label, id);
d.setAttribute("func_set", "true");
d.func = func;
return d;
},
addURL: function(label, url, target, id) {
var d = this.add(label, id);
d.setAttribute("url", url);
if (target)
d.setAttribute("target", target);
return d;
},
addHrefNoSort: function(label, href, id) {
var item = this.addHref(label, href, null, null, id);
item.setAttribute("not_sortable", "true");
return item;
},
addHrefNoFilter: function(label, href, id) {
var item = this.addHref(label, href, null, null, id);
item.setAttribute("not_filterable", "true");
return item;
},
addMenu: function(label, menu, id) {
var item = this.add(label + this.SUBMENU_INDICATOR, id);
item.setAttribute("label", "true");
menu.setParent(this);
item.subMenu = menu;
return item;
},
addAction: function(label, action, id) {
return this.addHref(label, "contextAction('" + this.getTableName() + "', '" + action + "')", null, null, id);
},
addConfirmedAction: function(label, action, id) {
return this.addHref(label, "contextConfirm('" + this.getTableName() + "', '" + action + "')", null, null, id);
},
addLine: function() {
this.hasItems = true;
var m = this.getMenu();
var d = document.createElement("div");
d.className = "context_item_hr";
d.isMenuItem = true;
d.disabled = "disabled";
m.appendChild(d);
return d;
},
addLabel: function(label, id) {
var m = this.getMenu();
var d = document.createElement("div");
d.setAttribute("item_id", id);
d.className = "context_item";
d.isMenuItem = true;
d.innerHTML = label;
d.disabled = "disabled";
m.appendChild(d);
return d;
},
addKeyShortcut: function(keys, href) {
var topWindow = getTopWindow();
var keyboardEnabled = topWindow.com && topWindow.com.glide && topWindow.com.glide.ui && topWindow.com.glide.ui.keyboard;
if(!keyboardEnabled)
return null;
if(!keys)
return keys;
if(shortcuts[keys])
return keys;
shortcuts[keys] = {};
var callback = function(e) {
var start = e.data.href.indexOf('javascript:') == 0 ? 11 : 0;
var startParen = e.data.href.indexOf('(');
var functionName = startParen > start ? e.data.href.substring(start, startParen) : {};
var func = eval(functionName);
if(typeof func == 'function')
eval(e.data.href);
else
document.location.href = e.data.href;
};
addLoadEvent(function() {
var keyboard = getTopWindow().com.glide.ui.keyboard;
var isMainFrame = window.frameElement.id == keyboard.mainFrame;
var isFormFrame = window.frameElement.id == keyboard.formFrame;
if(isMainFrame)
shortcuts[keys] = keyboard.bind(keys, callback, {href:href}).global(keyboard.formFrame);
else if(isFormFrame)
shortcuts[keys] = keyboard.bind(keys, callback, {href:href}).formFrame();
else
shortcuts[keys] = null;
});
return keys;
},
getItem: function(itemId) {
var items = this.getMenu().getElementsByTagName("div");
for (var i = 0; i < items.length; i++) {
var item = items[i];
if (item.getAttribute("item_id") == itemId)
return item;
}
return null;
},
setImage: function(item, img) {
if (item && img) {
item.style.backgroundImage = "url(" + this.docRoot + img + ")";
item.style.backgroundRepeat = "no-repeat";
}
},
setChecked: function(item) {
if (item)
this.setImage(item, "images/checked.pngx");
},
clearImage: function(item) {
if (item) {
item.style.backgroundImage = "";
item.style.backgroundRepeat = "";
}
},
setDisabled: function(item) {
if (!item)
return;
this._dullItem(item);
},
setEnabled: function(item) {
if (!item)
return;
this._undullItem(item);
},
setHidden : function(item) {
if (!item)
return;
this._hideItem(item);
},
setVisible : function(item) {
if (!item)
return;
this._showItem(item);
},
setLabel: function(item, label) {
if (item)
item.innerHTML = label;
},
setHideOnlySelf: function(hideSelf) {
this.hideOnlySelf = hideSelf;
},
clearSelected: function() {
var items = this.getMenu().getElementsByTagName("div");
for (var i = 0; i < items.length; i++) {
var item = items[i];
if (item.isMenuItem)
this.clearImage(item);
}
},
clear: function() {
var m = this.getMenu();
clearNodes(m);
this._setMinWidth();
this.hasItems = false;
},
destroy: function() {
this.parentElement = null;
this.menu.context = null;
this.menu.onmouseover = null;
this.menu.onmouseout = null;
this.menu.onclick = null;
if (isMSIE)
this.menu.outerHTML = null;
this.parentMenu = null;
this.onshow = null;
this.onhide = null;
this.properties = null;
this.timeout = null;
this.menu = null;
this.shim = null;
},
display: function(e) {
if (!this.getParent())
CustomEvent.fireAll('body_clicked', null);
menuSort = true;
this._dullMenu();
this._toggleMenuItems("not_sortable", this.getProperty('sortable'));
this._toggleMenuItems("not_filterable", this.getProperty('filterable'));
this.setFiringObject(this._getElement(e));
e = this._getRealEvent(e);
var menu = this.getMenu();
if (this._isEmpty(menu))
return;
menu.style.left = "0";
menu.style.top = "0";
this.parentElement.appendChild(menu);
if (this.getProperty("top") > 0 && ((this.getProperty("left") > 0) || (this.getProperty("right") > 0))) {
menu.style.visibility = 'hidden';
menu.style.display = 'block';
this.moveMenuToXY(e, this.getProperty("left"), this.getProperty("top"), this.getProperty("right"));
} else if (this.getParent()) {
var x = this._getElement(e);
menu.style.visibility = 'hidden';
menu.style.display = 'block';
this.moveMenuToParent(e, x);
} else {
var x = this._getElement(e);
menu.style.visibility = 'hidden';
menu.style.display = 'block';
this.moveMenuToCursor(e);
}
gActiveContext = this;
showObject(menu);
this._showShim(menu);
if (ie5) {
for(var i = 0; i < menu.childNodes.length; i++) {
var item = menu.childNodes[i];
addClassName(item, "fix-for-ie");
removeClassName(item, "fix-for-ie");
}
}
},
hide: function() {
gActiveContext = "";
this._hideShim();
hideObject(this.getMenu());
if (this.getMenu().parentNode)
this.getMenu().parentNode.removeChild(this.getMenu());
if (this.onhide)
this.onhide();
CustomEvent.fire('refresh.event');
},
hideAll: function() {
var m = this;
while(m) {
m.hide();
m = m.getParent();
}
},
execute: function(e) {
var x = this._getElement(e);
if (x.isMenuItem && !x.disabled) {
if (x.getAttribute("label") == "true") {
this._getRealEvent(e).cancelBubble = true;
return;
}
if (x.getAttribute("target")) {
window.open(x.getAttribute("url"), x.getAttribute("target"));
} else if (x.getAttribute("href")) {
var expression = x.getAttribute("href");
gActiveContext = this;
eval(expression);
} else if (x.getAttribute("func_set") == "true") {
x.func();
} else {
window.location = x.getAttribute("url");
}
if (this.trackSelected) {
this.clearSelected();
this.setChecked(x);
}
}
if (x.subMenu)
x.subMenu.hideAll();
else
this.hideAll();
return false;
},
menuLowLight: function(e) {
var x = this._getElement(e);
this._handleTimeout(false, x);
if (!x.isMenuItem)
return;
if (!x.subMenu || x.subMenu.getMenu().style.display == 'none')
this._disableItem(x);
window.status = '';
CustomEvent.fire('refresh.event');
},
menuHighLight: function(e) {
var x = this._getElement(e);
this._handleTimeout(true, x);
if (!x.isMenuItem)
return;
this._hideAllSubs(x.parentNode);
this._enableItem(x);
if (x.subMenu) {
x.subMenu.setParent(this);
x.subMenu.display(e);
}
},
moveMenuToXY: function(e, left, top, right) {
var menu = this.getMenu();
if (right)
left = right - menu.offsetWidth;
var offsetTop = ie5 ? this.parentElement.scrollTop + top : window.pageYOffset + top;
var offsetLeft = ie5 ? this.parentElement.scrollLeft + left : window.pageXOffset + left;
this.moveMenu(top, left, 0, 0, offsetTop, offsetLeft);
},
moveMenuToCursor: function(e) {
var offsetTop = 0;
var offsetLeft = 0;
if (isTouchDevice) {
offsetTop = e.pageY;
offsetLeft = e.pageX;
} else {
var offsets = this._getScrollOffsets(this.parentElement);
offsetTop = offsets.top + e.clientY;
offsetLeft = offsets.left + e.clientX;
}
this.moveMenu(e.clientY, e.clientX, 0, 0, offsetTop, offsetLeft);
},
moveMenuToParent: function(e, firingObject) {
var parent = this.getParent().getMenu();
var offsetTop = grabOffsetTop(firingObject) - parent.scrollTop;
var offsetLeft = grabOffsetLeft(parent);
this.moveMenu(offsetTop, offsetLeft, firingObject.offsetHeight, parent.offsetWidth, offsetTop, offsetLeft);
},
moveMenu: function(top, left, height, width, offsetTop, offsetLeft) {
var menu = this.getMenu();
menu.style.overflowY = "visible";
menu.setAttribute('gsft_has_scroll', false);
if (menu.getAttribute('gsft_width'))
menu.style.width = menu.getAttribute('gsft_width') + "px";
if (menu.getAttribute('gsft_height'))
menu.style.height = menu.getAttribute('gsft_height') + "px";
var leftPos;
var viewport = new WindowSize();
if ((left + width + menu.offsetWidth) > viewport.width)
leftPos = offsetLeft - menu.offsetWidth;
else
leftPos = offsetLeft + width;
var scrollOffsets = this._getScrollOffsets(this.parentElement);
var scrollTop = scrollOffsets.top;
var scrollLeft = scrollOffsets.left;
if (leftPos < scrollLeft)
leftPos = scrollLeft;
menu.style.left = leftPos + "px";
var direction = 'down';
var clip = 0;
if ((top + menu.offsetHeight) > viewport.height) {
var bottomClip = menu.offsetHeight - (viewport.height - top);
var topClip = menu.offsetHeight - top + height;
if (topClip < bottomClip) {
direction = 'up';
clip = topClip;
} else
clip = bottomClip;
}
var topPos;
if (direction == 'up')
topPos = offsetTop + height - menu.offsetHeight;
else
topPos = offsetTop;
if (topPos < scrollTop) {
topPos = scrollTop;
}
if ((topPos - scrollTop + menu.offsetHeight) > viewport.height)
clip = (topPos - scrollTop + menu.offsetHeight) - viewport.height;
menu.style.top = topPos + "px";
if (clip > 0) {
if (!menu.getAttribute('gsft_width')) {
menu.setAttribute('gsft_width', menu.offsetWidth);
menu.setAttribute('gsft_height', menu.offsetHeight);
}
menu.setAttribute('gsft_has_scroll', true);
menu.style.overflowY = "auto";
var w = menu.offsetWidth + 18;
menu.style.width = w + "px";
var h = menu.offsetHeight - clip - 4;
menu.style.height = h + "px";
}
},
_getScrollOffsets: function(e) {
var offsets = {};
if (e.nodeName.toUpperCase() == "BODY") {
offsets.top = window.pageYOffset || document.documentElement.scrollTop  || document.body.scrollTop;
offsets.left = window.pageXOffset || document.documentElement.scrollLeft  || document.body.scrollLeft;
} else {
offsets.top = e.scrollTop;
offsets.left = e.scrollLeft;
}
return offsets;
},
getFiringObject: function() {
return this.eventObject;
},
getID: function() {
return this.id;
},
getMenu: function() {
if (!this.menu) {
this.menu = contextMenus[this.getID()];
if (!this.menu) {
this._createMenu();
}
this._setMenuAttrs();
this._setMinWidth();
}
return this.menu;
},
getParent: function() {
return this.parentMenu;
},
getProperty: function(c) {
if (this.properties)
return this.properties[c];
else
return "";
},
getTableName: function() {
return this.tableName;
},
setFiringObject: function(e) {
this.eventObject = e;
},
setID: function(id) {
this.id = id;
},
setOnShow: function(onshow) {
this.onshow = onshow;
},
setOnHide: function(oh) {
this.onhide = oh;
},
setBeforeHide: function(beforeHide) {
this.beforehide = beforeHide;
},
setParent: function(m) {
this.parentMenu = m;
},
setProperty: function(c, v) {
this.properties[c] = v;
},
setTableName: function(name) {
this.tableName = name;
},
setTimeout: function(t) {
this.timeout = t;
},
setTrackSelected: function(flag) {
this.trackSelected = flag;
},
_createMenu : function() {
this.menu = document.createElement("div");
this.menu.name = this.menu.id = this.getID();
contextMenus[this.getID()] = this.menu;
},
_disableItem: function(item) {
if (item && !item.disabled) {
removeClassName(item, "context_menu_hover");
}
},
_dullMenu: function() {
var items = this.getMenu().childNodes;
for(var i = 0; i < items.length; i++) {
var item = items[i];
this._disableItem(item);
}
},
_enableItem: function(item) {
if (item && !item.disabled) {
addClassName(item, "context_menu_hover");
}
},
_getElement: function(e) {
e = this._getRealEvent(e);
var x = ie5? e.srcElement : e.target;
try {
if (!x.isMenuItem && x.parentNode.isMenuItem)
x = x.parentNode;
} catch (err) {}
return x;
},
_getRealEvent: function(e) {
if (typeof e == 'undefined') e = window.event;
return e;
},
_handleTimeout: function(lght, firingObject) {
if (this.getProperty("timeout") > 0) {
if (lght) {
clearTimeout(this.timeout);
} else {
if (!firingObject.subMenu || firingObject.subMenu != gActiveContext)
this.timeout = setTimeout('contextHide()', this.getProperty("timeout"));
}
}
},
_hideAllSubs : function(el) {
var list = el.getElementsByTagName("div");
for (var i = 0; i < list.length; i++) {
var element = list[i];
if (element.subMenu) {
var subMenu = element.subMenu.getMenu();
this._hideAllSubs(element.subMenu.getMenu());
element.subMenu._hideShim();
hideObject(subMenu);
this._disableItem(element);
}
}
},
_setMenuAttrs : function() {
this.menu.context = this;
this.menu.className = "context_menu";
this.menu.style.display = "none";
this.menu.style.zIndex = (this.getParent() ? GwtContextMenu.zIndex+1 : GwtContextMenu.zIndex);
this.menu.onmouseover = this.menuHighLight.bind(this);
this.menu.onmouseout = this.menuLowLight.bind(this);
if ("ontouchstart" in window  && (typeof FastButton != 'undefined'))
new FastButton(this.menu, this.execute.bind(this));
else
this.menu.onclick = this.execute.bind(this);
},
_setMinWidth: function() {
var widther = document.createElement("div");
widther.style.width = "120px";
widther.style.height = "1px";
widther.style.overflow = "hidden";
this.menu.appendChild(widther);
},
_showShim: function(menu) {
if (this._hasTabs() && !ie5)
return;
var shim = this._getShim();
if (!shim) {
shim = cel("iframe");
shim.id = this.getID() + "_shim";
shim.className = "popup";
shim.style.width = "1px";
shim.style.height = "1px";
shim.scrolling = "no";
shim.src = "javascript:false;";
this.parentElement.appendChild(shim);
this.shim = shim;
}
shim.style.zIndex = this.getMenu().style.zIndex - 1;
shim.style.left = grabOffsetLeft(this.getMenu()) + "px";
shim.style.top = grabOffsetTop(this.getMenu()) + "px";
var zWidth = this.getMenu().offsetWidth;
var zHeight = this.getMenu().offsetHeight;
if (!ie5) {
zWidth -= 4;
zHeight -= 4;
}
if (menu.getAttribute('gsft_has_scroll'))
zWidth -= 18;
shim.style.width = zWidth + "px";
shim.style.height = zHeight + "px";
showObject(shim);
},
_hideShim : function () {
var shim = this._getShim();
if (shim)
hideObject(shim);
},
_getShim: function () {
if (this.shim)
return this.shim;
var shimName = this.getID() + "_shim";
return gel(shimName);
},
_hasTabs: function() {
if (gel('TabSystem1'))
return true;
return false;
},
_toggleMenuItems: function(attr, enabled) {
var items = this.getMenu().childNodes;
for(var i = 0; i < items.length; i++) {
var item = items[i];
if (item.getAttribute(attr) == "true") {
if (enabled) {
this._undullItem(item);
} else {
this._dullItem(item);
}
}
}
},
_dullItem: function(item) {
item.disabled = "disabled";
item.style.color = "#cccccc";
removeClassName(item, "context_menu_hover");
},
_undullItem: function(item) {
item.disabled = "";
item.style.color = "";
},
_hideItem: function(item) {
item.style.display = 'none';
},
_showItem: function(item) {
item.style.display = '';
},
_isEmpty: function(menu) {
if (!menu)
return true;
if (!menu.firstChild)
return true;
return false;
},
z: function() {
}
});
GwtContextMenu.zIndex = 1100;
function displayContextMenu(e, name, filterable) {
if (!getMenuByName(name))
return;
var contextMenu = getMenuByName(name).context;
contextMenu.setProperty('sortable', true);
contextMenu.setProperty('filterable', filterable);
contextMenu.display(e);
}
function contextShow(e, tableName, timeoutValue, ttop, lleft, rright){
var frameWindow = null;
try {
frameWindow = window.frameElement;
if (frameWindow && frameWindow.id == "dialog_frame" && frameWindow.noContext == true)
return true;
} catch(err) { }
if (shouldSkipContextMenu(e))
return true;
e = getRealEvent(e);
menuTable = tableName;
var name = tableName;
if (name && name.substring(0, 8) != "context_")
name = "context_" + name;
if (document.readyState && document.readyState != "complete" && document.readyState != "interactive" && typeof window.g_hasCompleted == "undefined") {
jslog("Ignored context menu show for " + name + " because document was not ready");
return false;
}
window.g_hasCompleted = true;
if (getMenuByName(name)) {
var contextMenu = getMenuByName(name).context;
contextMenu.setProperty('timeout', timeoutValue);
contextMenu.setProperty('top', ttop);
contextMenu.setProperty('left', lleft);
contextMenu.setProperty('right', rright);
contextMenu.display(e);
if (contextMenu.onshow)
contextMenu.onshow();
}
return false;
}
function contextQuestionLabel(e, sys_id) {
if (shouldSkipContextMenu(e))
return true;
e = getRealEvent(e);
var name = "context_question_label";
menuTable = "not_important";
menuField = "not_important";
rowSysId = sys_id;
if (getMenuByName(name)) {
var contextMenu = getMenuByName(name).context;
contextMenu.setProperty('sysparm_sys_id', sys_id);
contextMenu.display(e);
}
return false;
}
function shouldSkipContextMenu(e) {
if (e.ctrlKey && trustCtrlKeyResponse())
return true;
return false;
}
function trustCtrlKeyResponse() {
return isMacintosh || !isSafari;
}
function contextTimeout(e, tableName, waitCount) {
var name = "context_" + tableName;
if (!getMenuByName(name))
return;
var contextMenu = getMenuByName(name).context;
if (typeof waitCount == "undefined")
waitCount = 500;
contextMenu.setProperty("timeout", waitCount);
var hideParam;
if (contextMenu.hideOnlySelf == true)
hideParam = '"' + name + '"';
contextMenu.setTimeout(setTimeout('contextHide(' + hideParam + ')', waitCount));
}
function getMenuByName(name) {
return contextMenus[name];
}
function getRowID(e) {
var id = null;
var cell = e.srcElement;
if (cell == null)
cell = e.target;
var row = cell.parentNode;
var id = row.id;
if (id == null || id.length == 0)
id = row.parentNode.id;
return id;
}
function contextHide(name) {
if (!gActiveContext)
return;
if (typeof name != "undefined" && gActiveContext.getID() != name)
return;
if (gActiveContext.beforehide) {
if (gActiveContext.beforehide() == false)
return;
}
gActiveContext.hideAll();
}
function elementAction(e, event, gcm) {
var type = e.getAttribute("type");
var choice = e.getAttribute("choice");
var id = e.id;
var fName = id.substring(id.indexOf('.') + 1);
var tableName = fName.substring(0, fName.indexOf('.'));
var haveAccess = $("personalizer_" + tableName);
if (typeof (g_user) != 'undefined') {
var count = 1;
if (!gcm)
gcm = addActionItems(fName, tableName, type, choice);
if (gcm)
return contextShow(event, gcm.getID(), -1, 0, 0);
}
return true;
}
function addActionItems(id, table, type, choice) {
var jr = new GlideAjax("AJAXJellyRunner", "AJAXJellyRunner.do");
jr.addParam('template', 'element_context.xml');
jr.addParam('sysparm_id', id);
jr.addParam('sysparm_table', table);
jr.addParam('sysparm_type', type);
jr.addParam('sysparm_choice', choice);
jr.addParam('sysparm_contextual_security', g_form.hasAttribute('contextual_security'));
jr.setWantRequestObject(true);
var response = jr.getXMLWait();
if (!response)
return;
var html = response.responseText;
html.evalScripts(true);
return gcm;
}
Event.observe(window, 'unload', clearMenus, false);
function clearMenus() {
for (av in contextMenus) {
if (contextMenus[av]) {
var c = contextMenus[av].context;
if (c) {
c.destroy();
}
contextMenus[av] = null;
}
}
for ( var keys in shortcuts) {
if (shortcuts[keys])
shortcuts[keys].clear();
}
shortcuts = null;
}
;
/*! RESOURCE: /scripts/classes/GlideClientCache.js */
var GlideClientCacheEntry = Class.create({
initialize: function(value) {
this.value = value;
this.bump();
},
bump: function() {
this.stamp = new Date().getTime();
}
});
var GlideClientCache = Class.create({
_DEFAULT_SIZE : 50,
initialize: function(maxEntries) {
if (maxEntries)
this.maxEntries = maxEntries;
else
this.maxEntries = this._DEFAULT_SIZE;
this._init('default');
},
_init : function(stamp) {
this._cache = new Object();
this._stamp = stamp;
},
put: function(key, value) {
var entry = new GlideClientCacheEntry(value);
this._cache[key] = entry;
this._removeEldest();
},
get : function(key) {
var entry = this._cache[key];
if (!entry)
return null;
entry.bump();
return entry.value;
},
stamp : function(stamp) {
if (stamp == this._stamp)
return;
this._init(stamp);
},
_removeEldest : function() {
var count = 0;
var eldest = null;
var eldestKey = null;
for (key in this._cache) {
count++;
var current = this._cache[key];
if (eldest == null || eldest.stamp > current.stamp) {
eldestKey = key;
eldest = current;
}
}
if (count <= this.maxEntries)
return;
if (eldest != null)
delete this._cache[key];
}
});
;
/*! RESOURCE: /scripts/classes/ajax/GlideURL.js */
var GlideURL = Class.create({
initialize: function(contextPath) {
this.contextPath = '';
this.params = new Object();
this.encodedString = '';
this.encode = true;
this.setFromString(contextPath ? contextPath : '');
},
setFromCurrent: function() {
this.setFromString(window.location.href);
},
setFromString: function(href) {
var pos = href.indexOf('?');
if (pos < 0) {
this.contextPath = href;
return;
}
this.contextPath = href.slice(0, pos);
var hashes = href.slice(pos + 1).split('&');
var i = hashes.length;
while (i--) {
var pos = hashes[i].indexOf('=');
this.params[hashes[i].substring(0, pos)] = hashes[i].substring(++pos);
}
},
getContexPath: function() {
return this.contextPath;
},
getContextPath: function() {
return this.contextPath;
},
setContextPath: function(c) {
this.contextPath = c;
},
getParam: function(p) {
return this.params[p];
},
getParams: function() {
return this.params;
},
addParam: function(name, value) {
this.params[name] = value;
return this;
},
addToken: function() {
if (typeof g_ck != 'undefined' && g_ck != "")
this.addParam('sysparm_ck', g_ck);
return this;
},
deleteParam: function(name) {
delete this.params[name];
},
addEncodedString: function(s) {
if (!s)
return;
if (s.substr(0, 1) != "&")
this.encodedString += "&";
this.encodedString += s;
return this;
},
getQueryString: function(additionalParams) {
qs = this._getParamsForURL(this.params);
qs += this._getParamsForURL(additionalParams);
qs += this.encodedString;
if (qs.length == 0)
return "";
return qs.substring(1);
},
_getParamsForURL: function(params) {
if (!params)
return '';
var url = '';
for (var n in params) {
var p = params[n] || '';
url += '&' + n + '=' + (this.encode ? encodeURIComponent(p + '') : p);
}
return url;
},
getURL: function(additionalParams) {
var url = this.contextPath;
var qs = this.getQueryString(additionalParams);
if (qs)
url += "?" + qs;
return url;
},
setEncode: function(b) {
this.encode = b;
},
toString: function() { return 'GlideURL'; }
});
GlideURL.refresh = function() {
window.location.replace( window.location.href );
};
;
/*! RESOURCE: /scripts/classes/ajax/GlideAjax.js */
var GlideAjax = Class.create(GlideURL, {
URL: "xmlhttp.do",
initialize: function initialize($super, processor, url) {
var u = this.URL;
if (url)
u = url;
$super(u);
this.setProcessor(processor);
this.callbackFunction;
this.callbackArgs;
this.additionalProcessorParams;
this.errorCallbackFunction;
this.wantRequestObject = false;
this.setScope("global");
this.setWantSessionMessages(true);
},
getProcessor: function() {
return this.processor;
},
getAnswer: function() {
if (!(this.requestObject && this.requestObject.responseXML))
return null;
return this.requestObject.responseXML.documentElement.getAttribute("answer");
},
setProcessor: function(p) {
this.processor = p;
this.addParam("sysparm_processor", p);
},
setQueryString: function(qs) {
this.queryString = qs;
},
preventLoadingIcon: function() {
this._preventLoadingIcon = true;
},
preventCancelNotification: function() {
this._suppressCancelNotification = true;
},
getXMLWait: function(additionalParams) {
this.addParam("sysparm_synch", "true");
this.additionalProcessorParams = additionalParams;
this.async = false;
var sw = new StopWatch();
this._makeRequest();
var m = "*** WARNING *** GlideAjax.getXMLWait - synchronous function - processor: " + this.processor
sw.jslog(m);
if (window.console && window.console.log)
console.log("%c " + m, 'background: darkred; color: white;');
if (this.requestObject.status != 200)
this._handleError();
return this._responseReceived();
},
getXML: function(callback, additionalParams, responseParams) {
this.wantAnswer = false;
this._getXML0(callback, additionalParams, responseParams);
},
getXMLAnswer:function(callback, additionalParams, responseParams) {
this.wantAnswer = true;
this._getXML0(callback, additionalParams, responseParams);
},
_getXML0: function(callback, additionalParams, responseParams) {
this.callbackFunction = callback;
this.callbackArgs = responseParams;
this.additionalProcessorParams = additionalParams;
this.async = true;
setTimeout(function() {this._makeRequest();}.bind(this), 0);
},
_makeRequest: function() {
this.requestObject = this._getRequestObject();
if (this.requestObject == null)
return null;
if (!GlideAjax.want_session_messages)
this.setWantSessionMessages(false);
var refUrl = this._buildReferringURL();
if (refUrl != "") {
this.addParam('ni.nolog.x_referer', 'ignore');
this.addParam('x_referer', refUrl);
}
if (typeof g_autoRequest != 'undefined' && 'true' == g_autoRequest)
this.addParam('sysparm_auto_request', g_autoRequest);
this.postString = this.getQueryString(this.additionalProcessorParams);
if (this.queryString) {
if (this.postString)
this.postString += "&";
this.postString += this.queryString;
}
this._sendRequest();
return this.requestObject;
},
_sendRequest: function() {
this._showLoading();
if (this.async)
this.requestObject.onreadystatechange = this._processReqChange.bind(this);
CustomEvent.fireTop("request_start", document);
this.requestObject.open("POST", this.contextPath, this.async);
this.requestObject.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
if (typeof g_ck != 'undefined' && g_ck != "")
this.requestObject.setRequestHeader('X-UserToken', g_ck);
try {
this.requestObject.send(this.postString);
} catch (e) {}
if (!this.async || (this.callbackFunction == null))
this._hideLoading();
},
_processReqChange: function() {
if (this.requestObject.readyState != 4)
return;
this.requestObject.onreadystatechange = function() { };
this._hideLoading();
if (!this._errorCheck()) {
this._responseReceived();
return;
}
try {
this._handleError();
} catch (e) {
jslog("GlideAjax error: " + e);
}
},
_errorCheck: function() {
this._cancelErrorXML = this._getCancelError();
return this._getResponseCode() != 200 || this._wasCanceled();
},
_handle401Error: function() {
if (getTopWindow().loggingOut)
return false;
var sessionLoggedIn =  this.requestObject.getResponseHeader("X-SessionLoggedIn");
if ( "true"!=sessionLoggedIn ) {
if (window.confirm(new GwtMessage().getMessage("ajax_session_timeout_goto_login_confirm"))) {
getTopWindow().location.href = "/navpage.do";
return true;
}
} else {
var allowResubmit = this.requestObject.getResponseHeader("X-UserToken-AllowResubmit");
if ("true"==allowResubmit) {
var autoResubmit = this.requestObject.getResponseHeader("X-AutoResubmit");
if ("true" == autoResubmit) {
this._sendRequest();
return true;
}
if (window.confirm(new GwtMessage().getMessage("ajax_session_timeout_resubmit_request_confirm"))) {
this._sendRequest();
return true;
}
} else {
if ("true" == sessionLoggedIn)
return false;
var msg = new GwtMessage().getMessage("ajax_session_timeout_refresh_screen");
if (!msg)
msg = "Your session has expired. Click OK to continue.";
if (window.confirm(msg)) {
getTopWindow().location.href = "/navpage.do";
return true;
}
}
}
return false;
},
_handleError: function() {
var responseCode = this._getResponseCode();
if (responseCode == 401) {
var requestedToken = this.requestObject.getResponseHeader("X-UserToken-Request");
var respondedToken = this.requestObject.getResponseHeader("X-UserToken-Response");
if (requestedToken && respondedToken && requestedToken != respondedToken)
CustomEvent.fireAll("ck_updated", respondedToken);
var handleTimeOut = this.requestObject.getResponseHeader("X-HandleTimeOut");
if ("true"==handleTimeOut)
if (this._handle401Error())
return;
}
else if (responseCode == 404 && this._outOfScope()) {
var err_options = {
text: "Access to Script Include " + this.processor +" blocked from scope: " + (this.getParam("sysparm_scope") ? this.getParam("sysparm_scope") : "global"),
type: "system",
attributes: { type: "error" }
};
if (typeof GlideUI != 'undefined')
GlideUI.get().fire(new GlideUINotification(err_options));
}
else if (this._wasCanceled() && this.callbackFunction && !this._getSuppressCancelNotification()) {
var err_options = {
text: this._getCancelErrorText(),
type: "system",
attributes: { type: "error" }
};
if (typeof GlideUI != 'undefined')
GlideUI.get().fire(new GlideUINotification(err_options));
}
if (this.errorCallbackFunction)
this.errorCallbackFunction(this.requestObject, this.callbackArgs);
},
_getRequestObject: function() {
var req = null;
if (window.XMLHttpRequest)
req = new XMLHttpRequest();
else if (window.ActiveXObject)
req = new ActiveXObject("Microsoft.XMLHTTP");
return req;
},
_getResponseCode: function() {
return this.requestObject.status;
},
_wasCanceled: function() {
if (!this._cancelErrorXML)
return false;
var answer = this._cancelErrorXML.getAttribute('transaction_canceled');
return answer == 'true';
},
_getSuppressCancelNotification: function() {
if (this._suppressCancelNotification)
return true;
if (this._cancelErrorXML) {
var suppress = this._cancelErrorXML.getAttribute("suppress_notification");
if (suppress && suppress == 'true')
return true;
}
return false;
},
_getCancelErrorText: function() {
if (this._cancelErrorXML) {
var cancelMessage = this._cancelErrorXML.getAttribute('cancel_message');
if (cancelMessage)
return cancelMessage;
}
return "Information could not be downloaded from the server because the transaction was canceled.";
},
_getCancelError: function() {
var xml = this.requestObject.responseXML;
if (!xml) {
var responseText = this.requestObject.responseText;
var errorPattern = /<xml?[^>]*id="transaction_canceled_island"?[^>]*>/;
var matches = responseText.match(errorPattern);
if (!matches)
return false;
xml = loadXML(matches[0]);
}
return xml.documentElement;
},
_outOfScope: function() {
var callerScope = this.getParam("sysparm_scope") ? this.getParam("sysparm_scope") : "global";
var isAppScope = callerScope != "global";
return isAppScope && this.requestObject.responseXML.documentElement.getAttribute("error").indexOf("HTTP Processor class not found") == 0;
},
_responseReceived: function() {
lastActivity = new Date();
CustomEvent.fireTop("request_complete", document);
this._fireUINotifications();
this._showSessionNotifications();
if (this.callbackFunction) {
if (this.wantAnswer)
this.callbackFunction(this.getAnswer(), this.callbackArgs);
else
this.callbackFunction(this.requestObject, this.callbackArgs);
}
if (this.wantRequestObject)
return this.requestObject;
return this.requestObject? this.requestObject.responseXML : null;
},
_showLoading: function() {
if (!this._preventLoadingIcon)
CustomEvent.fireAll("ajax.loading.start", this);
},
_hideLoading: function() {
if (!this._preventLoadingIcon && window.CustomEvent)
CustomEvent.fireAll("ajax.loading.end", this);
},
_buildReferringURL: function() {
var path = location.pathname;
var args = location.search;
if (path.substring(path.length-1) == '/') {
if (args)
return args;
return "";
}
return path.substring(path.lastIndexOf('/') + 1) + args;
},
_fireUINotifications: function() {
if (!this.requestObject || !this.requestObject.responseXML)
return;
var notifications = this.requestObject.responseXML.getElementsByTagName('ui_notifications');
if (!notifications || notifications.length == 0)
return;
var spans = notifications[0].childNodes;
for (var i = 0; i < spans.length; i++) {
var span = spans[i];
if (typeof GlideUI != 'undefined')
GlideUI.get().fire(new GlideUINotification({xml: span}));
}
},
_showSessionNotifications: function() {
if (!this.requestObject || !this.requestObject.responseXML)
return;
var notifications = this.requestObject.responseXML.getElementsByTagName('session_notifications');
if (!notifications || notifications.length == 0)
return;
var spans = notifications[0].childNodes;
for (var i = 0; i < spans.length; i++) {
var span = spans[i];
if (typeof GlideUI != 'undefined')
GlideUI.get().addOutputMessage({msg:span.getAttribute("data-text"), type:span.getAttribute("data-type")});
}
},
setScope: function(scope) {
if(scope) {
this.addParam('sysparm_scope', scope);
}
return this;
},
setErrorCallback: function(callback) {
this.errorCallbackFunction = callback;
},
setWantRequestObject: function(want) {
this.wantRequestObject = want;
},
setWantSessionMessages: function(want) {
this.addParam('sysparm_want_session_messages', want);
},
toString: function() { return "GlideAjax"; }
});
GlideAjax.disableSessionMessages = function() {
GlideAjax.want_session_messages = false;
};
GlideAjax.enableSessionMessages = function() {
GlideAjax.want_session_messages = true;
};
GlideAjax.enableSessionMessages();
;
/*! RESOURCE: /scripts/switchmenu.js */
var ignoreNextSwitch = false;
Event.observe(window, 'load', function() {
var t = $(window.document.body);
t.on("click", ".app_menu_div", onNavClick);
t.on("click", "a.menu", onModuleClick);
t.on("click", "a.menulabel", onModuleClick);
CustomEvent.observe('navigator.expand.all', navExpandAll);
CustomEvent.observe('navigator.collapse.all', navCollapseAll);
})
function onNavClick(event, element) {
var t = element.getAttribute("appid");
switchMenu(t);
}
function switchMenu(id) {
var el = gel(id);
var effect = true;
if (el.noEffect)
effect = false;
if (!window['Rico'])
effect = false;
var arrowImage = gel("img." + id);
if (el.style.display != "block") {
if (!effect) {
el.style.display = "block";
el.style.visibility = "visible";
el.style.height = "auto";
} else {
var div = gel("div." + el.id);
var allowExpansion =  (div.offsetTop - document.body.scrollTop + (div.offsetHeight * 2)) > document.body.clientHeight;
el.setAttribute('allowExpansion', allowExpansion.toString());
expandEffect(el, null, null, menuExpandCallback, menuExpandCallback);
}
arrowImage.src = "images/arrows_collapse_sm.gifx?v=2";
arrowImage.alt = g_appCollapseMsg;
setPreference("menu." + id + ".expanded", "true");
var topWin = getTopWindow();
if (topWin['toggleCollapseIcon'])
topWin.toggleCollapseIcon('collapse_apps','expand_apps');
CustomEvent.fire('navmenu.expanded', id);
} else {
if (ignoreNextSwitch == false) {
if (!effect)
el.style.display = "none";
else
collapseEffect(el);
arrowImage.src = "images/arrows_expand_sm.gifx?v=2";
arrowImage.alt = g_appExpandMsg;
deletePreference("menu." + id + ".expanded");
}
CustomEvent.fire('navmenu.collapsed', id);
}
ignoreNextSwitch = false;
}
function menuExpandCallback(el) {
if (getAttributeValue(el, 'allowExpansion') != 'true')
return;
var id = el.id;
var div = gel("div." + id);
var h = el.clientHeight + (el.offsetTop - div.offsetTop);
if ((div.offsetTop + h) > document.body.clientHeight) {
var scrollTop = (div.offsetTop + h) - document.body.clientHeight;
if (scrollTop > div.offsetTop)
scrollTop = div.offsetTop;
if (scrollTop > document.body.scrollTop)
document.body.scrollTop = scrollTop;
else
el.setAttribute('allowExpansion', 'false');
} else
el.setAttribute('allowExpansion', 'false');
}
var g_lastAppLink;
function onModuleClick(event, element) {
if (g_lastAppLink)
g_lastAppLink.style.fontWeight = "";
element.style.fontWeight = "bold";
g_lastAppLink = element;
}
function ignoreSwitch() {
ignoreNextSwitch = true;
}
function navExpandAll() {
var tags = $$('.app_menu_div');
for (var i = 0; i < tags.length; i++) {
var div = tags[i];
var scid = div.getAttribute("appid");
if (scid && div.style.display != "none") {
var subMenu = $(scid);
if (subMenu.style.display == "none") {
subMenu.noEffect = true;
switchMenu(scid);
subMenu.noEffect = false;
}
}
}
}
function navCollapseAll() {
var tags = $$('.app_menu_div');
for(var i = 0; i < tags.length; i++) {
var div = tags[i];
var scid = div.getAttribute("appid");
if (scid) {
var subMenu = $(scid);
if (subMenu.style.display == "block") {
subMenu.noEffect = true;
switchMenu(scid);
subMenu.noEffect = false;
}
}
}
}
;
/*! RESOURCE: /scripts/section.js */
function expandCollapseAllSections(expandFlag) {
var spans = document.getElementsByTagName('span');
for (var i = 0; i < spans.length; i++) {
if (spans[i].id.substr(0, 8) != "section.")
continue;
var id = spans[i].id.substring(8);
var state = collapsedState(id);
if (state == expandFlag)
toggleSectionDisplay(id);
}
CustomEvent.fire('toggle.sections', expandFlag);
}
function collapsedState(sectionName) {
var el = $(sectionName);
if (el)
return (el.style.display == "none");
}
function setCollapseAllIcons(action, sectionID) {
var exp = gel('img.' + sectionID + '_expandall');
var col = gel('img.' + sectionID + '_collapseall');
if (!exp || !col)
return;
if (action == "expand") {
exp.style.display = "none";
col.style.display = "inline";
return;
}
exp.style.display = "inline";
col.style.display = "none";
}
function toggleSectionDisplay(id,imagePrefix,sectionID) {
var collapsed = collapsedState(id);
setPreference("collapse.section." + id, !collapsed, null);
hideReveal(id, imagePrefix);
toggleDivDisplay(id + '_spacer');
if (collapsed) {
CustomEvent.fire("section.expanded", id);
setCollapseAllIcons("expand",sectionID);
}
}
;
/*! RESOURCE: /scripts/classes/GlideUser.js */
var GlideUser = Class.create({
initialize: function(userName, firstName, lastName, commaRoles, userID, departmentID) {
this.userName = userName;
this.firstName = firstName;
this.lastName = lastName;
this.setFullName(this.firstName + " " + this.lastName);
this.setRoles(commaRoles);
this.userID = userID;
this.departmentID = departmentID;
this.preferences = new Object();
this.clientData = new Object();
},
hasRoleExactly: function(role) {
if (!role || typeof role != 'string')
return false;
for (var x = 0, l = this.roles.length; x < l; x++) {
if (this.roles[x].toLowerCase() == role.toLowerCase())
return true;
}
return false;
},
hasRoles: function() {
return this.roles.length > 0;
},
hasRole: function(role) {
if (this.hasRoleExactly('maint'))
return true;
if (this.hasRoleExactly(role))
return true;
if (role == 'maint')
return false;
if (this.hasRoleExactly('admin'))
return true;
return false;
},
hasRoleFromList: function(roles) {
var rolesToMatch = new Array();
if (roles)
rolesToMatch = roles.split(/\s*,\s*/);
if (rolesToMatch.length == 0)
return true;
for(var i = 0; i < rolesToMatch.length; i++) {
var r = rolesToMatch[i];
if (r && this.hasRole(r))
return true;
}
return false;
},
getFullName: function() {
return this.fullName;
},
getUserName: function() {
return this.userName;
},
getUserID: function() {
return this.userID;
},
getDepartmentID: function() {
return this.departmentID;
},
setFullName: function(fn) {
this.fullName = fn;
},
getRoles: function() {
return this.roles;
},
getAvailableElevatedRoles: function() {
return this.elevatedRoles;
},
setRoles: function(r) {
if (r)
this.roles = r.split(/\s*,\s*/);
else
this.roles = new Array();
},
setElevatedRoles: function(r) {
if (r)
this.elevatedRoles = r.split(/\s*,\s*/);
else
this.elevatedRoles = new Array();
},
setActiveElevatedRoles: function(r) {
if (r)
this.activeElevatedRoles = r.split(/\s*,\s*/);
else
this.activeElevatedRoles = new Array();
},
getActiveElevatedRoles: function() {
return this.activeElevatedRoles;
},
setDomain: function(d) {
this.domain = d;
},
getPreference: function(n) {
return this.preferences[n];
},
setPreference: function(n, v) {
this.preferences[n] = v;
},
deletePreference: function(n) {
delete this.preferences[n];
},
getClientData: function(n) {
return this.clientData[n];
},
setClientData: function(n, v) {
this.clientData[n] = v;
},
setBannerImage: function(s) {
this.bannerImage = s;
},
getBannerImage: function() {
return this.bannerImage;
},
setBannerText: function(s) {
this.bannerText = s;
},
getBannerText: function() {
return this.bannerText;
},
setHomePages: function(s) {
this.homePages = s;
},
getHomePages: function() {
return this.homePages;
},
type: "GlideUser"
});
;
/*! RESOURCE: /scripts/classes/Select.js */
var Select = Class.create({
initialize: function(select) {
this.select = $(select);
},
addOption: function(value, label) {
addOption(this.select, value, label);
},
addOptions: function(glideRecord, nameField, valueField) {
if (!valueField)
valueField = 'sys_id';
if (!nameField)
nameField = 'name';
while (glideRecord.next())
addOption(this.select, glideRecord[valueField], glideRecord[nameField]);
},
clear: function() {
this.select.options.length = 0;
},
getSelect: function() {
return this.select;
},
getValue: function() {
return this.select.options[this.select.selectedIndex].value;
},
selectValue: function(value) {
this.select.selectedIndex = -1;
var options = this.select.options;
for (oi = 0; oi < options.length; oi++) {
var option = options[oi];
var optval = option.value;
if (optval != value)
continue;
option.selected = true;
this.select.selectedIndex = oi;
}
},
contains: function(value) {
var options = this.select.options;
for (oi = 0; oi < options.length; oi++) {
if (options[oi].value == value)
return true;
}
return false;
},
getClassName: function() {
return "SelectList";
}
});
function addOption(select, value, label, selected, optionalTitle) {
var o;
if (select.multiple == true)
o = new Option(label, value, true, selected || false);
else
o = new Option(label, value);
if (optionalTitle)
o.title = optionalTitle;
select.options[select.options.length] = o;
if (select.multiple != true && selected)
select.selectedIndex = select.options.length - 1;
return o;
}
function addOptionAt(select, value, label, idx, optionalTitle) {
for (var i = select.options.length; i > idx; i--) {
var oldOption = select.options[i - 1];
select.options[i] = new Option(oldOption.text, oldOption.value);
if (oldOption.id)
select.options[i].id = oldOption.id;
if (oldOption.style.cssText)
select.options[i].style.cssText = oldOption.style.cssText;
}
var o = new Option(label, value);
if (optionalTitle)
o.title = optionalTitle;
select.options[idx] = o;
return o;
}
function getSelectedOption(select) {
if (typeof select == "undefined" || select.multiple == true || select.selectedIndex < 0)
return null;
return select.options[select.selectedIndex];
}
;
/*! RESOURCE: /scripts/classes/GlideManager.js */
var GlideManager = Class.create({
initialize: function(options) {
this.options = Object.extend({
preferences: {},
properties: {},
settings: {}
}, options || {});
this._browserFocused = true;
CustomEvent.observe(GlideEvent.WINDOW_BLURRED, function() { this._browserFocused = false; }.bind(this));
CustomEvent.observe(GlideEvent.WINDOW_FOCUSED, function() { this._browserFocused = true; }.bind(this));
},
hasPreference: function(prefName) {
return this.options.preferences.hasOwnProperty(prefName);
},
getPreference: function(prefName, defaultValue) {
if (!this.hasPreference(prefName))
return defaultValue;
var v = this.options.preferences[prefName];
if (v !== undefined && typeof v == 'string')
return v.match(/^true$/i) ? true : (v.match(/^false$/i) ? false : v);
return v;
},
setPreference: function(name, value) {
setPreference(name, value);
this.options.preferences[name] = value;
},
loadPreferences: function(o) {
this.options.preferences = Object.extend(this.options.preferences, o);
},
hasProperty: function(key) {
return this.options.properties.hasOwnProperty(key);
},
getProperty: function(key, defaultValue) {
if (!this.hasProperty(key))
return defaultValue;
var v = this.options.properties[key];
if (v !== undefined && typeof v == 'string')
return v.match(/^true$/i) ? true : (v.match(/^false$/i) ? false : v);
return v;
},
setProperty: function(name, value) {
setProperty(name, value);
this.options.properties[name] = value;
},
loadProperties: function(o) {
this.options.properties = Object.extend(this.options.properties, o);
},
hasSetting: function(setting) {
return this.options.settings.hasOwnProperty(setting);
},
getSetting: function(setting) {
var v = this.options.settings[setting];
if (v !== undefined && typeof v == 'string')
return v.match(/^true$/i) ? true : (v.match(/^false$/i) ? false : v);
return v;
},
loadSettings: function(o) {
this.options.settings = Object.extend(this.options.settings, o);
},
isBrowserFocused: function() {
return this._browserFocused;
},
toString: function() { return 'GlideManager'; }
});
GlideManager.init = function(options) {
var topWindow = getTopWindow();
if (topWindow == window.self)
window.g_glideManager = new GlideManager(options);
else
window.g_glideManager = topWindow.g_glideManager;
};
GlideManager.get = function() {
return window.g_glideManager || getTopWindow().g_glideManager;
};
;
/*! RESOURCE: /scripts/consts/GlideEvent.js */
var GlideEvent = {
WINDOW_CLICKED:					'glide:window_clicked',
WINDOW_BLURRED:					'glide:window_blurred',
WINDOW_FOCUSED:					'glide:window_focused',
IMAGE_PICKED:					'glide:image_picked',
NAV_MANAGER_LOADED:				'glide:nav_manager_loaded',
NAV_FORM_DIRTY_CANCEL_STAY:		'glide:nav_form_dirty_cancel_stay',
NAV_SYNC_LIST_WITH_FORM:		'glide:nav_sync_list_with_form',
NAV_LOAD_FORM_FROM_LIST:		'glide:nav_load_form_from_list',
NAV_SAVE_PREFERENCES:			'glide:nav_save_preferences',
NAV_UPDATE_EDGE_BUTTON_STATES:	'glide:nav_update_edge_button_states',
NAV_OPEN_URL:					'glide:nav_open_url',
NAV_ADD_BOOKMARK:				'glide:nav_add_bookmark',
NAV_REMOVE_BOOKMARK:			'glide:nav_remove_bookmark',
NAV_UPDATE_BOOKMARK:			'glide:nav_update_bookmark',
NAV_DRAGGING_BOOKMARK_START:	'glide:nav_dragging_bookmark_start',
NAV_DRAGGING_BOOKMARK_STOP:		'glide:nav_dragging_bookmark_stop',
NAV_HIDE_ALL_TOOLTIPS:			'glide:nav_hide_all_tooltips',
NAV_QUEUE_BOOKMARK_OPEN_FLYOUT:	'glide:nav_queue_bookmark_open_flyout',
NAV_OPEN_BOOKMARK:              'glide:nav_open_bookmark',
NAV_EAST_PANE_RESIZED:			'glide:nav_east_pane_resized',
NAV_ADD_FLYOUT:					'glide:nav_add_flyout',
NAV_REMOVE_FLYOUT:				'glide:nav_remove_flyout',
NAV_TOGGLE_FLYOUT:				'glide:nav_toggle_flyout',
NAV_HIDE_FLYOUTS:				'glide:nav_hide_flyouts',
NAV_PANE_CLICKED:				'glide:nav_window_clicked'
};
;
/*! RESOURCE: /scripts/classes/util/StopWatch.js */
var StopWatch = Class.create({
MILLIS_IN_SECOND: 1000,
MILLIS_IN_MINUTE: 60 * 1000,
MILLIS_IN_HOUR: 60 * 60 * 1000,
initialize: function(started) {
this.started = started || new Date();
},
getTime: function() {
var now = new Date();
return now.getTime() - this.started.getTime();
},
restart: function() {
this.initialize();
},
jslog: function(msg, src, date) {
if (window.jslog) {
jslog('[' + this.toString() + '] ' + msg, src, date);
return;
}
if (window.console && window.console.log)
console.log('[' + this.toString() + '] ' + msg);
},
toString : function() {
return this.formatISO(this.getTime());
},
formatISO: function(millis) {
var hours = 0, minutes = 0, seconds = 0, milliseconds = 0;
if (millis >= this.MILLIS_IN_HOUR) {
hours = parseInt(millis / this.MILLIS_IN_HOUR);
millis = millis - (hours * this.MILLIS_IN_HOUR);
}
if (millis >= this.MILLIS_IN_MINUTE) {
minutes = parseInt(millis / this.MILLIS_IN_MINUTE);
millis = millis - (minutes * this.MILLIS_IN_MINUTE);
}
if (millis >= this.MILLIS_IN_SECOND) {
seconds = parseInt(millis / this.MILLIS_IN_SECOND);
millis = millis - (seconds * this.MILLIS_IN_SECOND);
}
milliseconds = parseInt(millis);
return doubleDigitFormat(hours) + ":" + doubleDigitFormat(minutes) + ":" + doubleDigitFormat(seconds) +
"." + tripleDigitFormat(milliseconds);
},
type: "StopWatch"
});
;
/*! RESOURCE: /scripts/functions_onchange.js */
function onChange(elementName){
var eChanged = gel(elementName);
var eOriginal = gel("sys_original." + elementName);
if (eOriginal == null) {
return;
}
var vOriginal = eOriginal.value;
var vChanged = eChanged.value;
eChanged.changed = (vOriginal != vChanged);
onChangeLabelProcess(elementName);
setMandatoryExplained();
if (hasDepends != null && hasDepends(elementName))
onSelChange(elementName);
clientScriptOnChange(elementName, eChanged, vOriginal, vChanged);
fieldChanged(elementName, eChanged.changed);
}
function onChangeLabelProcess(elementName, value) {
var el = gel(elementName);
var statusNode = gel('status.' + elementName);
onChangeLabelProcessByEl(el, statusNode, value);
}
function onChangeLabelProcessByEl(elementNode, statusLabel, value) {
if (!elementNode || !statusLabel)
return;
var mandatory = elementNode.getAttribute("mandatory") + "";
var readonly = elementNode.disabled || hasClassName(elementNode,'disabled');
if (mandatory == null || mandatory == "null")
mandatory = statusLabel.getAttribute("mandatory") + "";
else
statusLabel.setAttribute("mandatory", mandatory);
var newClassName = statusLabel.getAttribute("oclass");
var newFieldClassName = "";
var newTitle = statusLabel.getAttribute("title");
if (value == undefined)
value = elementNode.value;
if (mandatory == "true") {
if (value == "") {
newClassName = "mandatory";
newFieldClassName = "is-required";
newTitle = getMessage("Mandatory - must be populated before Submit");
} else if (elementNode.changed) {
newClassName = "changed";
newFieldClassName = "is-filled";
newTitle = getMessage("Field value has changed since last update");
} else if (!readonly) {
newClassName = "mandatory_populated";
newFieldClassName = "is-prefilled";
newTitle = getMessage("Mandatory - preloaded with saved data");
} else {
newClassName = "read_only";
newTitle = getMessage("Read only - cannot be modified");
}
} else {
if (elementNode.changed) {
newClassName = "changed";
newTitle = getMessage("Field value has changed since last update");
} else if (readonly) {
newClassName = "read_only";
if (newTitle == "" || newTitle == null)
newTitle = "Read only - cannot be modified";
} else if (newClassName != "read_only" && newClassName != "changed") {
newClassName = "";
newTitle = "";
}
}
var slm = gel("section508." + elementNode.id);
if (slm) {
slm.setAttribute("title", statusLabel.getAttribute("title"));
slm.setAttribute("alt", statusLabel.getAttribute("title"));
}
newClassName += ' label_description';
if (statusLabel.className == newClassName)
return;
statusLabel.className = newClassName;
statusLabel.setAttribute("title", newTitle);
if (document.documentElement.getAttribute('data-doctype') == 'true') {
if (mandatory == 'true') {
statusLabel.className = "required-marker label_description";
}
if (newFieldClassName) {
var formGroup = elementNode.up('.form-group');
formGroup.removeClassName('is-prefilled');
formGroup.removeClassName('is-required')
formGroup.removeClassName('is-filled');
formGroup.addClassName(newFieldClassName);
}
statusLabel.setAttribute('aria-label', newTitle);
}
CustomEvent.fire("mandatory.changed", elementNode.id, newClassName);
}
function  clientScriptOnChange(elementName, eChanged, vOriginal, vChanged) {
var splitMe = elementName.split('.');
var tableName = splitMe[0];
var fieldName = splitMe.slice(1).join('.');
callChangeHandlers(tableName, fieldName, eChanged, vOriginal, vChanged);
}
function callChangeHandlers(tableName, fieldName, eChanged, vOriginal, vChanged) {
var widgetName = tableName + "." + fieldName;
if (typeof (g_form) != "undefined")
g_form.hideFieldMsg(fieldName, true);
template = false;
if (eChanged.templateValue == 'true')
template = true;
eChanged.templateValue = 'false';
for (var i = 0; i < g_event_handlers.length; i++) {
var handler = g_event_handlers[i];
if (handler.fieldName != widgetName && handler.fieldName != fieldName)
continue;
callChangeHandler(handler, this, eChanged, vOriginal, vChanged, false, template);
}
CustomEvent.fire("change.handlers.run", tableName, fieldName);
}
function fireAllChangeHandlers() {
for (var x = 0; x < g_event_handlers.length; x++) {
var handler = g_event_handlers[x];
var elementName = handler.fieldName;
var theWidget = gel(elementName);
if (!theWidget)
continue;
var original = gel("sys_original." + elementName);
var oldVal = 'unknown';
if (original)
oldVal = original.value;
var newVal;
if ($(theWidget).getAttribute("type") == "radio") {
newVal = oldVal;
var elems = $$('#'+$(theWidget).getAttribute("id")).each(function(el){
var checkedValue = el.getAttribute("checked");
if (checkedValue != null && checkedValue.length > 0)
newVal = el.value;
});
} else
newVal = theWidget.value;
callChangeHandler(handler, this, theWidget, oldVal, newVal, true, false);
}
CustomEvent.fire("change.handlers.run.all");
}
function callChangeHandler(handler, control, theWidget, oldVal, newVal, loading, template) {
try {
callChangeHandler0(handler, control, theWidget, oldVal, newVal, loading, template);
} catch (ex) {
if (g_user.hasRole('client_script_admin')) {
g_form.showFieldMsg(theWidget, "onChange script error: " + ex.toString() + "\n" +
handler.handler.toString(), "error", false);
} else {
g_form.showFieldMsg(theWidget,
"Script error encountered when changing this field - please contact your System Administrator",
"error", false);
}
}
}
function callChangeHandler0(handler, control, theWidget, oldVal, newVal, loading, template) {
CustomEvent.fire('glide_optics_inspect_put_cs_context', handler.handlerName, 'change');
var startTimer = new Date();
handler.handler.call(control, theWidget, oldVal, newVal, loading, template);
var n = g_event_handlers_onChange[handler.handlerName];
if (n)
CustomEvent.fire('page_timing', { name: 'CSOC', child: n, startTime: startTimer, win: window });
CustomEvent.fire('glide_optics_inspect_pop_cs_context', handler.handlerName, 'change');
}
function multiKeyDown(me) {
if ($(me.id).getAttribute("isquestionhtml") == "true")
return;
var eOriginal = 'g_' + me.id.replace(/\./g, '_');
var eOriginalSet = eval("typeof " + eOriginal + " != 'undefined'");
if (eOriginalSet)
return;
var oValue = escape(me.value);
eval(eOriginal + '="' + oValue + '";');
var form = findParentByTag(me, "form");
if (me.id && form) {
var elementName = me.id;
addInput(form, 'hidden', "sys_original." + elementName, "XXmultiChangeXX");
}
}
function multiModified(me, type, currentValue) {
if ($(me.id).getAttribute("isquestionhtml") == "true") {
$(me.id).onchange();
return;
}
multiKeyDown(me);
var form = findParentByTag(me, "form");
var changeFlag = true;
if (me.id && form) {
var elementName = me.id;
var vOriginal = unescape(eval('g_' + me.id.replace(/\./g, '_')));
if (currentValue == undefined)
currentValue = me.value;
if (type == undefined)
type = 'htmlarea'
if (currentValue == vOriginal)
changeFlag = false;
me.changed = changeFlag;
onChangeLabelProcess(elementName, currentValue);
if (type == 'tinymce'){
clientScriptOnChange(elementName, me, 'unknown', currentValue);
}else{
if ((typeof me.isFocused) == "boolean")
if (me.isFocused == false)
clientScriptOnChange(elementName, me, 'unknown', currentValue);
}
}
fieldChanged(elementName, changeFlag);
}
function formChangeKeepAlive() {
var AJAX_KEEPALIVE_TIMEOUT = 900;
var nowsecs = parseInt((new Date()).getTime() / 1000);
var secs = parseInt(lastActivity.getTime() / 1000);
var difference = nowsecs - secs;
if (difference > AJAX_KEEPALIVE_TIMEOUT) {
var aj = new GlideAjax("GlideSystemAjax");
aj.addParam("sysparm_name", "isLoggedIn");
aj.getXML(doNothing);
lastActivity = new Date();
}
}
function fieldChanged(elementName, changeFlag) {
formChangeKeepAlive();
if (typeof(g_form) != "undefined")
g_form.fieldChanged(elementName, changeFlag);
}
function addOnChangeEvent(fields, tableName, callfunc) {
for (var i = 0; i < fields.length; i++) {
var field = fields[i];
if (typeof field == "string") {
if (tableName)
field = tableName + "." + field;
field = gel(field);
}
if (field && field.tagName)
Event.observe(field, 'change', callfunc);
}
}
function setColorSwatch(fieldName) {
var colorValue = $(fieldName).value;
var colorDisplay = $("color_swatch." + fieldName);
try {
colorDisplay.style.backgroundColor = colorValue;
} catch (ex) {
g_form.showErrorBox(fieldName, getMessage("Invalid color") + ":" + colorValue);
$(fieldName).value = "";
colorDisplay.style.backgroundColor = "";
}
}
;
/*! RESOURCE: /scripts/classes/GlideUI.js */
var GlideUI = Class.create({
initialize: function() {
this.topWindow = getTopWindow() || window;
this.outputMessagesTag = "output_messages";
this.outputMsgDivClass = ".outputmsg_div";
CustomEvent.observe(GlideUI.UI_NOTIFICATION_SYSTEM, this._systemNotification.bind(this));
CustomEvent.observe(GlideUI.UI_NOTIFICATION_INFO, this._systemNotification.bind(this));
CustomEvent.observe(GlideUI.UI_NOTIFICATION_ERROR, this._systemNotification.bind(this));
CustomEvent.observe(GlideUI.UI_NOTIFICATION_SYSTEM_EVENT, this._eventNotification.bind(this));
},
setMsgTags: function(msgTag,msgDivClass) {
this.outputMessagesTag = msgTag;
this.outputMsgDivClass = msgDivClass;
},
display: function(htmlTextOrOptions) {
alert('GlideUI.display() needs to be implemented in an overriding class');
},
fireNotifications: function() {
var spans = $$('span.ui_notification');
for (var i = 0; i < spans.length; i++) {
var span = spans[i];
this.fire(new GlideUINotification({xml: span}));
}
},
fire: function( notification) {
this.topWindow.CustomEvent.fireTop(GlideUI.UI_NOTIFICATION + '.' + notification.getType(), notification);
},
_systemNotification: function( notification) {
var options = {
text: notification.getText(),
type: notification.getType()
}
if (!options.text)
return;
this.display(options);
},
_eventNotification: function( notification) {
var type = notification.getAttribute('event');
if (type == 'refresh_nav' && window.gsftReloadNav != undefined)
gsftReloadNav();
},
addOutputMessage: function(options) {
options = Object.extend({
msg: '',
id: '',
type: 'info'
}, options || {});
var divs = this._getOutputMessageDivs();
if (!divs)
return false;
var newMsg;
if (typeof options.id == 'undefined' || options.id == '')
newMsg = GlideUI.OUTPUT_MESSAGE_TEMPLATE.evaluate(options);
else
newMsg = GlideUI.OUTPUT_MESSAGE_TEMPLATE_WITH_ID.evaluate(options);
divs.container.insert(newMsg);
divs.messages.show();
return true;
},
clearOutputMessages: function( closeImg) {
var divs;
if (closeImg) {
closeImg = $(closeImg);
divs = {
messages: closeImg.up(),
container:  closeImg.up().select(this.outputMsgDivClass)[0]
}
} else
divs = this._getOutputMessageDivs();
if (!divs)
return false;
divs.messages.hide();
divs.container.innerHTML = '';
return true;
},
_getOutputMessageDivs: function() {
var divs = {};
divs.messages = $(this.outputMessagesTag);
if (!divs.messages)
return null;
divs.container = divs.messages.select(this.outputMsgDivClass)[0];
if (!divs.container)
return null;
return divs;
},
toString: function() {
return 'GlideUI';
}
});
GlideUI.UI_NOTIFICATION = 'glide:ui_notification';
GlideUI.UI_NOTIFICATION_SYSTEM = GlideUI.UI_NOTIFICATION + '.system';
GlideUI.UI_NOTIFICATION_INFO = GlideUI.UI_NOTIFICATION + '.info';
GlideUI.UI_NOTIFICATION_ERROR = GlideUI.UI_NOTIFICATION + '.error';
GlideUI.UI_NOTIFICATION_SYSTEM_EVENT = GlideUI.UI_NOTIFICATION + '.system_event';
GlideUI.OUTPUT_MESSAGE_TEMPLATE = new Template(
'<div class="outputmsg outputmsg_#{type} notification notification-#{type}">' +
'<img class="outputmsg_image" src="images/outputmsg_#{type}_24.gifx" />' +
'#{msg}' +
'</div>'
);
GlideUI.OUTPUT_MESSAGE_TEMPLATE_WITH_ID = new Template(
'<div class="outputmsg outputmsg_#{type} notification notification-#{type}" id="#{id}">' +
'<img class="outputmsg_image" src="images/outputmsg_#{type}_24.gifx" />' +
'#{msg}' +
'</div>'
);
window.g_GlideUI = new GlideUI();
GlideUI.get = function() {
return window.g_GlideUI;
};
;
/*! RESOURCE: /scripts/classes/GlideUINotification.js */
var GlideUINotification = Class.create({
initialize: function(options) {
options = Object.extend({
type: 'system',
text: '',
attributes: {},
xml: null,
window: window
}, options || {});
this.window = options.window;
if (!options.xml) {
this.type = options.type;
this.text = options.text;
this.attributes = options.attributes;
} else
this.xml = options.xml;
},
getType: function() {
if (this.xml)
return this.xml.getAttribute('data-type') || '';
return this.type;
},
getText: function() {
if (this.xml)
return this.xml.getAttribute('data-text') || '';
return this.text;
},
getAttribute: function(n) {
var v;
if (this.xml)
v = this.xml.getAttribute('data-attr-' + n) || '';
else
v = this.attributes[n] || '';
return v;
},
getWindow: function() {
return this.window;
},
getChildren: function() {
if (!this.xml)
return [];
var children = [];
var spans = this.xml.childNodes;
for (var i = 0; i < spans.length; i++) {
if ((spans[i].getAttribute('class') == 'ui_notification_child') || (spans[i].getAttribute('className') == 'ui_notification_child'))
children.push(new GlideUINotification({xml: spans[i], window: this.window}));
}
return children;
},
toString: function() { return 'GlideUINotification'; }
});
;
/*! RESOURCE: /scripts/classes/GlideUIDefault.js */
var GlideUIDefault = {
init: function() {},
display: function(htmlTextOrOptions) {
if (typeof htmlTextOrOptions == 'string')
new NotificationMessage({ text: htmlTextOrOptions });
else
new NotificationMessage(htmlTextOrOptions);
}
};
if (GlideUI.get())
Object.extend(GlideUI.get(), GlideUIDefault).init();
;
/*! RESOURCE: /scripts/lib/glide_updates/prototype.template.js */
var Template = Class.create({
initialize: function (template) {
this.template = template.toString();
this.pattern = /(^|.|\r|\n)(#\{((JS|HTML):)?(.*?)\})/;
},
evaluate: function (object) {
if (object && Object.isFunction(object.toTemplateReplacements))
object = object.toTemplateReplacements();
return this.template.gsub(this.pattern, function (match) {
if (object === null)
return (match[1] + '');
var before = match[1] || '';
if (before ==='\\')
return match[2];
var ctx = object, expr = match[5], escape = match[4],
pattern = /^([^.[]+|\[((?:.*?[^\\])?)\])(\.|\[|$)/;
match = pattern.exec(expr);
if (match === null)
return before;
while (match != null) {
var comp = match[1].startsWith('[') ? match[2].replace(/\\\\]/g, ']') : match[1];
ctx = ctx[comp];
if (null === ctx || '' === match[3])
break;
expr = expr.substring('[' === match[3] ? match[1].length : match[0].length);
match = pattern.exec(expr);
}
ctx = ctx || '';
switch (escape || '') {
case 'HTML':
ctx = ctx.replace(/'/g, '&#39;').replace(/"/g, '&#34;').replace(/&(?![#|l|g])/g, '&amp;').replace(/\</g, '&lt;').replace(/\>/g, '&gt;');
break;
case 'JS':
ctx = ctx.replace(/'/g, '&#39;').replace(/"/g, '&#34;');
break;
}
return before + String.interpret(ctx);
});
}
});
var XMLTemplate = Class.create(Template, {
initialize: function ($super, id) {
var s = $(id);
$super(s && s.innerHTML ? s.innerHTML.replace(/%7B/g, '{').replace(/%7D/g, '}') : '');
},
toString: function () {
'XMLTemplate';
}
});
;
/*! RESOURCE: /scripts/lib/glide_updates/prototype.effects.js */
(function() {
var elemdisplay = {};
var rfxtypes = /^(?:toggle|show|hide)$/;
var ralpha = /alpha\([^)]*\)/i;
var rdigit = /\d/;
var ropacity = /opacity=([^)]*)/;
var rfxnum = /^([+\-]=)?([\d+.\-]+)(.*)$/;
var rnumpx = /^-?\d+(?:px)?$/i;
var rnum = /^-?\d/;
var timerId;
var fxAttrs = [
[ "height", "marginTop", "marginBottom", "paddingTop", "paddingBottom" ],
[ "width", "marginLeft", "marginRight", "paddingLeft", "paddingRight" ],
[ "opacity" ]
];
var shrinkWrapBlocks = false;
var inlineBlockNeedsLayout = false;
var cssFloat = false;
var curCSS;
var opacitySupport;
document.observe("dom:loaded", function() {
var div = document.createElement("div");
div.style.width = div.style.paddingLeft = "1px";
document.body.appendChild(div);
if ("zoom" in div.style) {
div.style.display = "inline";
div.style.zoom = 1;
inlineBlockNeedsLayout = div.offsetWidth === 2;
div.style.display = "";
div.innerHTML = "<div style='width:4px;'></div>";
shrinkWrapBlocks = div.offsetWidth !== 2;
document.body.removeChild(div);
}
div = document.createElement("div");
div.style.display = "none";
div.innerHTML = "<link/><table></table><a href='/a' style='color:red;float:left;opacity:.55;'>a</a><input type='checkbox'/>";
document.body.appendChild(div);
var a = div.getElementsByTagName("a")[0];
opacitySupport = /^0.55$/.test(a.style.opacity);
cssFloat =  !!a.style.cssFloat;
document.body.removeChild(div);
if (!opacitySupport) {
Prototype.cssHooks.opacity = {
get: function(elem, computed) {
return ropacity.test((computed && elem.currentStyle ? elem.currentStyle.filter : elem.style.filter) || "") ?
(parseFloat(RegExp.$1) / 100) + "" :
computed ? "1" : "";
},
set: function(elem, value) {
var style = elem.style;
style.zoom = 1;
var opacity = Prototype.isNaN(value) ?
"" :
"alpha(opacity=" + value * 100 + ")",
filter = style.filter || "";
style.filter = ralpha.test(filter) ?
filter.replace(ralpha, opacity) :
style.filter + ' ' + opacity;
}
};
}
});
if (document.defaultView && document.defaultView.getComputedStyle) {
curCSS = function(elem, newName, name) {
var ret;
var defaultView;
var computedStyle;
name = name.replace(rupper, "-$1").toLowerCase();
if (!(defaultView = elem.ownerDocument.defaultView))
return undefined;
if ((computedStyle = defaultView.getComputedStyle(elem, null))) {
ret = computedStyle.getPropertyValue(name);
if (ret === "" && !contains(elem.ownerDocument.documentElement, elem))
ret = style(elem, name);
}
return ret;
};
} else if (document.documentElement.currentStyle) {
curCSS = function(elem, name) {
var left;
var rsLeft;
var ret = elem.currentStyle && elem.currentStyle[name];
var style = elem.style;
if (!rnumpx.test(ret) && rnum.test(ret)) {
left = style.left;
rsLeft = elem.runtimeStyle.left;
elem.runtimeStyle.left = elem.currentStyle.left;
style.left = name === "fontSize" ? "1em" : (ret || 0);
ret = style.pixelLeft + "px";
style.left = left;
elem.runtimeStyle.left = rsLeft;
}
return ret === "" ? "auto" : ret;
};
}
function contains(a, b) {
return document.compareDocumentPosition ?  a.compareDocumentPosition(b) & 16 :
(a !== b && (a.contains ? a.contains(b) : true));
}
function style(elem, name, value, extra) {
if (!elem || elem.nodeType === 3 || elem.nodeType === 8 || !elem.style)
return;
var ret;
var origName = name.camelize();
var s = elem.style;
var hooks = Prototype.cssHooks[origName];
name = Prototype.cssProps[origName] || origName;
if (value !== undefined) {
if (typeof value === "number" && isNaN(value) || value == null)
return;
if (typeof value === "number" && !Prototype.cssNumber[origName])
value += "px";
if (!hooks || !("set" in hooks) || (value = hooks.set(elem, value)) !== undefined) {
try {
s[name] = value;
} catch(e) {}
}
} else {
if (hooks && "get" in hooks && (ret = hooks.get(elem, false, extra)) !== undefined)
return ret;
return s[name];
}
}
function isEmptyObject(obj) {
for (var name in obj)
return false;
return true;
}
function isWindow(obj) {
return obj && typeof obj === "object" && "setInterval" in obj;
}
function arrayMerge(first, second) {
var i = first.length;
var j = 0;
if (typeof second.length === "number") {
for (var l = second.length; j < l; j++)
first[ i++ ] = second[ j ];
} else {
while (second[j] !== undefined)
first[ i++ ] = second[ j++ ];
}
first.length = i;
return first;
}
function makeArray(array) {
var ret = [];
if (array != null) {
var type = typeof array;
if (array.length == null || type === "string" || type === "function" || type === "regexp" || isWindow(array))
Array.prototype.push.call(ret, array);
else
arrayMerge(ret, array);
}
return ret;
}
function genFx(type, num) {
var obj = {};
fxAttrs.concat.apply([], fxAttrs.slice(0, num)).each(function(context) {
obj[context] = type;
});
return obj;
}
function defaultDisplay(nodeName) {
if (elemdisplay[nodeName])
return elemdisplay[nodeName];
var e = $(document.createElement(nodeName));
document.body.appendChild(e);
var display = e.getStyle("display");
e.remove();
if (display === "none" || display === "")
display = "block";
elemdisplay[nodeName] = display;
return display;
}
Prototype.effects = {
speed: function(speed, easing, fn) {
var opt = speed && typeof speed === "object" ? Object.extend({}, speed) : {
complete: fn || !fn && easing || typeof speed == 'function' && speed,
duration: speed,
easing: fn && easing || easing && !(typeof easing == 'function') && easing
};
opt.duration = Prototype.effects.fx.off ? 0 : typeof opt.duration === "number" ? opt.duration :
opt.duration in Prototype.effects.fx.speeds ? Prototype.effects.fx.speeds[opt.duration] : Prototype.effects.fx.speeds._default;
opt.old = opt.complete;
opt.complete = function() {
if (opt.queue !== false)
$(this).dequeue();
if (typeof opt.old == 'function')
opt.old.call(this);
};
return opt;
},
easing: {
linear: function(p, n, firstNum, diff) {
return firstNum + diff * p;
},
swing: function(p, n, firstNum, diff) {
return ((-Math.cos(p*Math.PI)/2) + 0.5) * diff + firstNum;
}
},
timers: [],
fx: function(elem, options, prop) {
this.elem = elem;
this.options = options;
this.prop = prop;
if (!options.orig)
options.orig = {};
}
};
Prototype.effects.fx.prototype = {
update: function() {
if (this.options.step)
this.options.step.call(this.elem, this.now, this);
(Prototype.effects.fx.step[this.prop] || Prototype.effects.fx.step._default)(this);
},
cur: function() {
if (this.elem[this.prop] != null && (!this.elem.style || this.elem.style[this.prop] == null))
return this.elem[this.prop];
var r = parseFloat(this.elem.getStyle(this.prop));
return r || 0;
},
custom: function(from, to, unit) {
var self = this;
var fx = Prototype.effects.fx;
this.startTime = new Date().getTime()
this.start = from;
this.end = to;
this.unit = unit || this.unit || "px";
this.now = this.start;
this.pos = this.state = 0;
function t(gotoEnd) {
return self.step(gotoEnd);
}
t.elem = this.elem;
if (t() && Prototype.effects.timers.push(t) && !timerId)
timerId = setInterval(fx.tick, fx.interval);
},
show: function() {
this.options.orig[this.prop] = style(this.elem, this.prop);
this.options.show = true;
this.custom(this.prop === "width" || this.prop === "height" ? 1 : 0, this.cur());
$(this.elem).show();
},
hide: function() {
this.options.orig[this.prop] = style(this.elem, this.prop);
this.options.hide = true;
this.custom(this.cur(), 0);
},
step: function(gotoEnd) {
var t = new Date().getTime();
var done = true;
if (gotoEnd || t >= this.options.duration + this.startTime) {
this.now = this.end;
this.pos = this.state = 1;
this.update();
this.options.curAnim[this.prop] = true;
for (var i in this.options.curAnim) {
if (this.options.curAnim[i] !== true)
done = false;
}
if (done) {
if (this.options.overflow != null && !shrinkWrapBlocks) {
var elem = this.elem;
var options = this.options;
var overflowArray = ["", "X", "Y"];
for (var ii = 0, ll = overflowArray.length; ii < ll; ii++)
elem.style[ "overflow" + overflowArray[ii] ] = options.overflow[ii];
}
if (this.options.hide) {
$(this.elem).hide();
if (Prototype.Browser.IE)
$(this.elem).setStyle({filter: ''});
}
if (this.options.hide || this.options.show) {
for (var p in this.options.curAnim)
style(this.elem, p, this.options.orig[p]);
}
this.options.complete.call(this.elem);
}
return false;
} else {
var n = t - this.startTime;
this.state = n / this.options.duration;
var specialEasing = this.options.specialEasing && this.options.specialEasing[this.prop];
var defaultEasing = this.options.easing || (Prototype.effects.easing.swing ? "swing" : "linear");
this.pos = Prototype.effects.easing[specialEasing || defaultEasing](this.state, n, 0, 1, this.options.duration);
this.now = this.start + ((this.end - this.start) * this.pos);
this.update();
}
return true;
}
};
Object.extend(Prototype.effects.fx, {
tick: function() {
var timers = Prototype.effects.timers;
for (var i = 0; i < timers.length; i++) {
if (!timers[i]())
timers.splice(i--, 1);
}
if (!timers.length)
Prototype.effects.fx.stop();
},
interval: 13,
stop: function() {
clearInterval(timerId);
timerId = null;
},
speeds: {
slow: 600,
fast: 200,
_default: 400
},
step: {
opacity: function(fx) {
fx.elem.setStyle({opacity: fx.now});
},
_default: function(fx) {
if (fx.elem.style && fx.elem.style[fx.prop] != null)
fx.elem.style[fx.prop] = (fx.prop === "width" || fx.prop === "height" ? Math.max(0, fx.now) : fx.now) + fx.unit;
else
fx.elem[fx.prop] = fx.now;
}
}
});
Object.extend(Prototype, {
isNaN: function(obj) {
return obj == null || !rdigit.test(obj) || isNaN(obj);
},
queue: function(elem, type, data) {
if (!elem)
return;
type = (type || "fx") + "queue";
var q = elem.retrieve(type);
if (!data)
return q || [];
if (!q || Object.isArray(data))
q = elem.store(type, makeArray(data));
else
q.push(data);
return q;
},
dequeue: function(elem, type) {
type = type || "fx";
var queue = Prototype.queue(elem, type);
var fn = queue.shift();
if (fn === "inprogress")
fn = queue.shift();
if (fn) {
if (type === "fx")
queue.unshift("inprogress");
fn.call(elem, function() {
Prototype.dequeue(elem, type);
});
}
},
cssHooks: {
opacity: {
get: function(elem, computed) {
if (computed) {
var ret = curCSS(elem, "opacity", "opacity");
return ret === "" ? "1" : ret;
}
return elem.style.opacity;
}
}
},
cssProps: {
"float": cssFloat ? "cssFloat" : "styleFloat"
},
cssNumber: {
"zIndex": true,
"fontWeight": true,
"opacity": true,
"zoom": true,
"lineHeight": true
}
});
function show(elem, speed, easing, callback) {
if (speed || speed === 0)
return animate(elem, genFx("show", 3), speed, easing, callback);
var display = elem.style.display;
if (!elem.retrieve("olddisplay") && display === "none")
display = elem.style.display = "";
if (display === "" && elem.getStyle("display") === "none")
elem.store("olddisplay", defaultDisplay(elem.nodeName));
display = elem.style.display;
if (display === "" || display === "none")
elem.style.display = elem.retrieve("olddisplay") || "";
return elem;
}
function hide(elem, speed, easing, callback) {
if (speed || speed === 0)
return animate(elem, genFx("hide", 3), speed, easing, callback);
var display = elem.getStyle('display');
if (display !== "none")
elem.store("olddisplay", elem.getStyle('display'));
elem.style.display = "none";
return elem;
}
function toggle(elem, fn, fn2, callback) {
var bool = typeof fn === "boolean";
if (typeof fn == 'function' && typeof fn2 == 'function')
toggle.apply(this, arguments);
else if (fn == null || bool) {
var state = bool ? fn : !elem.visible();
elem[state ? "show" : "hide"]();
} else
animate(elem, genFx("toggle", 3), fn, fn2, callback);
return elem;
}
function fadeTo(elem, speed, to, easing, callback) {
elem.setStyle({opacity: 0});
if (!elem.visible())
elem.show();
return animate(elem, {opacity: to}, speed, easing, callback);
}
function animate(elem, prop, speed, easing, callback) {
var optall = Prototype.effects.speed(speed, easing, callback);
if (isEmptyObject(prop))
return optall.complete;
return elem[optall.queue === false ? "_execute" : "queue"](function() {
var opt = Object.extend({}, optall);
var p;
var isElement = elem.nodeType === 1;
var hidden = isElement && !elem.visible();
for (p in prop) {
var name = p.camelize();
if (p !== name) {
prop[name] = prop[p];
delete prop[p];
p = name;
}
if (prop[p] === "hide" && hidden || prop[p] === "show" && !hidden)
return opt.complete.call(this);
if (isElement && (p === "height" || p === "width")) {
opt.overflow = [elem.style.overflow, elem.style.overflowX, elem.style.overflowY];
if (elem.getStyle("display") === "inline" && elem.getStyle("float") === "none") {
if (!inlineBlockNeedsLayout)
elem.style.display = "inline-block";
else {
var display = defaultDisplay(this.nodeName);
if (display === "inline")
elem.style.display = "inline-block";
else {
elem.style.display = "inline";
elem.style.zoom = 1;
}
}
}
}
if (Object.isArray(prop[p])) {
(opt.specialEasing = opt.specialEasing || {})[p] = prop[p][1];
prop[p] = prop[p][0];
}
}
if (opt.overflow != null)
elem.style.overflow = "hidden";
opt.curAnim = Object.extend({}, prop);
for (var i in prop) {
var name = i;
var val = prop[i];
var e = new Prototype.effects.fx(elem, opt, name);
if (rfxtypes.test(val)) {
e[val === "toggle" ? hidden ? "show" : "hide" : val](prop);
} else {
var parts = rfxnum.exec(val);
var start = e.cur() || 0;
if (parts) {
var end = parseFloat(parts[2]);
var unit = parts[3] || "px";
if (unit !== "px") {
style(elem, name, (end || 1) + unit);
start = ((end || 1) / e.cur()) * start;
style(name, start + unit);
}
if (parts[1])
end = ((parts[1] === "-=" ? -1 : 1) * end) + start;
e.custom(start, end, unit);
} else {
e.custom(start, val, "");
}
}
}
return true;
});
}
function stop(elem, clearQueue, gotoEnd) {
var timers = Prototype.effects.timers;
if (clearQueue)
elem.queue([]);
for (var i = timers.length - 1; i >= 0; i--) {
if (timers[i].elem === elem) {
if (gotoEnd) {
timers[i](true);
}
timers.splice(i, 1);
}
}
if (!gotoEnd)
elem.dequeue();
return elem;
}
function queue(elem, type, data) {
if (typeof type !== "string") {
data = type;
type = "fx";
}
if (data === undefined)
return Prototype.queue(elem, type);
var queue = Prototype.queue(elem, type, data);
if (type === "fx" && queue[0] !== "inprogress")
Prototype.dequeue(elem, type);
return elem;
}
function dequeue(elem, type) {
Prototype.dequeue(elem, type);
return elem;
}
function delay(elem, time, type) {
time = Prototype.effects.fx ? Prototype.effects.fx.speeds[time] || time : time;
type = type || "fx";
return elem.queue(type, function() {
setTimeout(function() {
Prototype.dequeue(elem, type);
}, time);
});
}
function clearQueue(elem, type) {
return elem.queue(type || "fx", []);
}
return Element.addMethods({
show: show,
hide: hide,
toggle: toggle,
fadeTo: fadeTo,
animate: animate,
slideDown: function(elem, speed, easing, callback) {
return animate(elem, genFx('show', 1), speed, easing, callback);
},
slideUp: function(elem, speed, easing, callback) {
return animate(elem, genFx('hide', 1), speed, easing, callback);
},
slideToggle: function(elem, speed, easing, callback) {
return animate(elem, genFx('toggle', 1), speed, easing, callback);
},
fadeIn: function(elem, speed, easing, callback) {
return animate(elem, {opacity: 'show'}, speed, easing, callback);
},
fadeOut: function(elem, speed, easing, callback) {
return animate(elem, {opacity: 'hide'}, speed, easing, callback);
},
fadeToggle: function(elem, speed, easing, callback) {
return animate(elem, {opacity: 'toggle'}, speed, easing, callback);
},
stop: stop,
queue: queue,
dequeue: dequeue,
delay: delay,
clearQueue: clearQueue,
_execute: function(elem, f) {
f();
return elem;
}
});
}());
;
/*! RESOURCE: /scripts/classes/Table.js */
var Table = Class.create({
REF_ELEMENT_PREFIX: 'ref_',
REFERENCE: "reference",
initialize: function(tableName, parentTable, cols, callback) {
this.tableName = tableName;
this.parentTable = parentTable;
this.label = tableName;
this.callback = callback;
this.columns = null;
this.elements = {};
this.elementsArray = [];
this.extensions = {};
this.extensionsArray = [];
this.choiceExtensions = {};
this.choiceExtensionsArray = [];
this.tablesArray = [];
this.sys_id = null;
this.set_id = null;
Table.setCachable(this);
if (cols && this.cacheable)
this.readResponse(cols);
else
this.readColumns();
this.textIndex = null;
},
readColumns: function() {
var ajax = new GlideAjax("SysMeta");
ajax.addParam("sysparm_type", "column");
ajax.addParam("sysparm_include_sysid", "true");
ajax.addParam("sysparm_table_name", "false");
ajax.addParam("sysparm_value", this.tableName);
if (this.sys_id)
ajax.addParam("sysparm_sys_id", this.sys_id);
if (this.set_id)
ajax.addParam("sysparm_set_id", this.set_id);
if (this.parentTable)
ajax.addParam("sysparm_parent_table", this.parentTable);
if (this.callback)
ajax.getXML(this.readColumnsResponse.bind(this));
else {
var xml = ajax.getXMLWait();
this.readResponse(xml);
}
},
readColumnsResponse: function(response) {
if (!response || !response.responseXML)
return;
var xml = response.responseXML;
this.readResponse(xml);
this.callback();
},
readResponse: function(xml) {
this.columns = xml;
var root = this.columns.getElementsByTagName("xml");
if (root != null && root.length == 1) {
root = root[0];
this.textIndex = root.getAttribute("textIndex");
this.label = root.getAttribute("label");
}
var items = xml.getElementsByTagName("item");
this.elements = {};
this.elementsArray = [];
for (var i = 0; i < items.length; i++) {
var item = items[i];
var t = item.getAttribute("value");
var label = item.getAttribute("label");
var e = new TableElement(t, label);
e.setClearLabel(item.getAttribute("cl"));
e.setType(item.getAttribute("type"));
e.setReference(item.getAttribute("reference"));
e.setDynamicCreation(item.getAttribute("dynamic_creation") == "true");
e.setRefQual(item.getAttribute("reference_qual"));
e.setRefKey(item.getAttribute("reference_key"));
e.setArray(item.getAttribute("array"));
e.setChoice(item.getAttribute("choice"));
e.setMulti(item.getAttribute("multitext"));
e.setDependent(item.getAttribute("dependent"));
e.setMaxLength(item.getAttribute("max_length"));
e.setDisplayChars(item.getAttribute("display_chars"));
e.setNamedAttributes(item.getAttribute("attributes"));
e.setTableName(item.getAttribute("table"));
e.setTable(this);
if (e.isReference()) {
e.setRefLabel(item.getAttribute("reflabel"));
e.setRefDisplay(item.getAttribute("refdisplay"));
e.setRefRotated(item.getAttribute("reference_rotated"));
}
this.elements[t] = e;
this.elementsArray[this.elementsArray.length] = e;
var attrs = item.attributes;
for (var x = 0; x < attrs.length; x++)
e.addAttribute(attrs[x].nodeName,attrs[x].nodeValue);
}
var tables = xml.getElementsByTagName("tables");
if (tables.length != 0)
this.setTables(tables);
var choice_items = xml.getElementsByTagName("sys_choice_extensions");
if (choice_items.length != 0)
this.setChoiceExtensions(choice_items);
var items = xml.getElementsByTagName("extensions");
if (items.length != 0)
this.setExtensions(items);
this.setDependencies();
},
setExtensions: function(items) {
items = items[0].getElementsByTagName("extension");
this.extensionsArray = [];
for (var i = 0; i < items.length; i++) {
var item = items[i];
var t = item.getAttribute("name");
var label = item.getAttribute("label");
var e = new TableExtension(t, label);
e.setTable(this);
this.extensions[t] = e;
this.extensionsArray[this.extensionsArray.length] = e;
}
},
setChoiceExtensions: function(items) {
items = items[0].getElementsByTagName("extension");
this.choiceExtensionsArray = [];
for (var i = 0; i < items.length; i++) {
var item = items[i];
var t = item.getAttribute("name");
var label = item.getAttribute("label");
var e = new TableExtension(t, label);
e.setTable(this);
this.choiceExtensions[t] = e;
this.choiceExtensionsArray[this.choiceExtensionsArray.length] = e;
}
},
setDependencies: function() {
for (var i = 0; i < this.elementsArray.length; i++) {
var element = this.elementsArray[i];
if (element.isDependent()) {
var parent = this.getElement(element.getDependent());
if (parent)
parent.addDependentChild(element.getName())
}
}
},
setTables: function(tables) {
var tableList = tables[0].getAttribute("table_list");
this.tablesArray = [];
this.tablesArray = tableList.split(',');
},
getColumns: function() {
return this.columns;
},
getElements: function() {
return this.elementsArray;
},
getTableElements: function(tableName) {
jslog("Getting fields for table " + tableName);
var elements = new Array();
var items = this.getElements();
for (var i = 0; i < items.length; i++) {
var item = items[i];
if (item.getTableName() != tableName)
continue;
elements.push(item);
}
return elements;
},
getElement: function(elementName) {
if (this.elements[elementName])
return this.elements[elementName];
if (this._nameIsExtension(elementName))
return this._genExtensionElement(elementName);
return null;
},
_genExtensionElement: function(name) {
name = name.substring(this.REF_ELEMENT_PREFIX.length);
var ext = this.extensions[name];
var e = new TableElement(ext.getExtName(), ext.getLabel());
e.setType(this.REFERENCE);
e.setReference(ext.getName());
e.setRefLabel(ext.getLabel());
e.setExtensionElement(true);
return e;
},
_nameIsExtension: function(name) {
if (name.indexOf(this.REF_ELEMENT_PREFIX) != 0)
return false;
name = name.substring(this.REF_ELEMENT_PREFIX.length);
if (this.extensions[name])
return true;
return false;
},
getExtensions: function() {
return this.extensionsArray;
},
getChoiceExtensions: function() {
return this.choiceExtensionsArray;
},
getTables: function() {
return this.tablesArray;
},
getName: function() {
return this.tableName;
},
getLabel: function() {
return this.label;
},
getDisplayName: function(column) {
return this.getElement(column).getRefDisplay();
},
getSysId: function() {
return this.sys_id;
},
setSysId: function() {
return this.sys_id;
},
type : function() {
return "Table";
}
});
Table.get = function(tableName, parentTable) {
return getTopWindow().Table.getInTopWindow(tableName, parentTable);
}
Table.setColumns = function(tableName, parentTable, xmlString) {
var cachedName = (parentTable? parentTable + "." : "") + tableName;
var parentCache = Table.getCache();
if (parentCache) {
var table = parentCache.get(cachedName);
if (table)
return table;
}
var xml = loadXML(xmlString);
var answer = new Table(tableName,parentTable,xml);
if (parentCache && answer.cacheable)
parentCache.put(cachedName, answer);
}
Table.isCached = function(tableName,parentTable) {
var cachedName = (parentTable? parentTable + "." : "") + tableName;
var parentCache = Table.getCache();
if (parentCache) {
var table = parentCache.get(cachedName);
if (table)
return true;
}
return false;
}
Table.getInTopWindow = function(tableName, parentTable) {
var t = new Object();
Table.setCachable(t);
if (t.cacheable) {
var cachedName = (parentTable? parentTable + "." : "") + tableName;
var parentCache = Table.getCache();
if (parentCache) {
var table = parentCache.get(cachedName);
if (table)
return table;
}
}
var answer = new Table(tableName, parentTable);
if (parentCache && answer.cacheable)
parentCache.put(cachedName, answer);
return answer;
}
Table.setCachable = function(t) {
t.cacheable = true;
if (typeof g_table_sys_id != 'undefined') {
t.sys_id = g_table_sys_id;
t.cacheable = false;
}
if (typeof g_table_set_id != 'undefined') {
t.set_id = g_table_set_id;
t.cacheable = false;
}
}
Table.getCache = function() {
var cache = getTopWindow().g_cache_td;
if (cache)
return cache;
if (!window.g_cache_td)
window.g_cache_td = new GlideClientCache(50);
return window.g_cache_td;
}
;
/*! RESOURCE: /scripts/classes/TableElement.js */
var TableElement = Class.create({
REF_ELEMENT_PREFIX: 'ref_',
initialize: function(elementName, elementLabel) {
this.name = elementName;
this.label = elementLabel;
this.clearLabel = '';
this.tableName = '';
this.type = 'string';
this.isRef = false;
this.refLabel = null;
this.refDisplay = null;
this.refQual = null;
this.reference = null;
this.refKey = null;
this.refRotated = false;
this.array = null;
this.canread = 'unknown';
this.canwrite = 'unknown';
this.saveastemplate = 'unknown';
this.choice = '';
this.multi = false;
this.active = 'unknown';
this.table = null;
this.dependent = null;
this.maxLength = null;
this.displayChars = "-1";
this.attributes = {};
this.dependentChildren = {};
this.namedAttributes = {};
this.extensionElement = false;
this.dynamicCreation = false;
},
addAttribute: function(name, value) {
this.attributes[name] = value;
},
getAttribute: function(name) {
return this.attributes[name];
},
getBooleanAttribute: function(name) {
var v = this.getAttribute(name);
if (v == null)
return true;
if (v == 'false' || v == 'no')
return false;
return true;
},
isDependent: function() {
return this.dependent != null;
},
hasDependentChildren: function() {
for (var key in this.dependentChildren)
return true;
return false;
},
getDependentChildren: function() {
return this.dependentChildren;
},
setTable: function(t) {
this.table = t;
},
setType: function(type) {
this.type = type;
if (type == 'glide_list')
this.isRef = false;
if (type == 'glide_var')
this.isRef = true;
},
setReference: function(reference) {
if (reference && reference != '')
this.reference = reference;
if ((this.type == 'glide_list' && this.reference) || this.type == 'reference' || this.type == 'domain_id' || this.type == 'glide_var')
this.isRef = true;
},
setRefRotated: function(rotated) {
if ('yes' == rotated)
this.refRotated = true;
else
this.refRotated = false;
},
setCanWrite: function(ra) {
if ('no' == ra)
this.canwrite = false;
else
this.canwrite = true;
},
setSaveAsTemplate: function(ra) {
if ('no' == ra)
this.saveastemplate = false;
else
this.saveastemplate = true;
},
setCanRead: function(ra) {
if ('no' == ra)
this.canread = false;
else
this.canread = true;
},
setActive: function(active) {
if ('no' == active)
this.active = false;
else
this.active = true;
},
setRefQual: function(refQual) {
this.refQual = refQual;
},
setRefKey: function(refKey) {
this.refKey = refKey;
},
setRefLabel: function(label) {
this.refLabel = label;
},
setRefDisplay: function(display) {
this.refDisplay = display;
},
setArray: function(array) {
this.array = array;
},
setClearLabel: function(cl) {
this.clearLabel = cl;
},
setChoice: function(choice) {
this.choice = choice;
},
setMulti: function(multi) {
this.multi = multi;
},
setExtensionElement: function(b) {
this.extensionElement = b;
},
setDependent: function(dep) {
if (dep && dep != '')
this.dependent = dep;
},
addDependentChild: function(name) {
if (name)
this.dependentChildren[name] = true;
},
setMaxLength: function(maxLength) {
this.maxLength = maxLength;
},
setDisplayChars: function(displayChars) {
this.displayChars = displayChars;
},
setNamedAttributes: function(attrs) {
if (!attrs)
return;
var pairs = attrs.split(',');
for (var i = 0; i < pairs.length; i++) {
var parts = pairs[i].split('=');
if (parts.length == 2)
this.namedAttributes[parts[0]] = parts[1];
}
},
setDynamicCreation: function(dynamic) {
this.dynamicCreation = dynamic;
},
isReference: function() {
return this.isRef;
},
isRefRotated: function() {
return this.refRotated;
},
isExtensionElement: function() {
return this.extensionElement;
},
isDate: function() {
return dateTypes[this.type];
},
isDateOnly: function() {
if (dateOnlyTypes[this.type])
return true;
else
return false;
},
isDateTime: function() {
if (dateTimeTypes[this.type])
return true;
else
return false;
},
getName: function() {
return this.name;
},
getLabel: function() {
return this.label;
},
getClearLabel: function() {
return this.clearLabel;
},
getReference: function() {
return this.reference;
},
getMulti: function() {
return this.multi;
},
isMulti: function() {
return this.getMulti() == 'yes';
},
getDependent: function() {
return this.dependent;
},
getRefQual: function() {
return this.refQual;
},
getRefKey: function() {
return this.refKey;
},
getRefLabel: function() {
return this.refLabel;
},
getRefDisplay: function() {
return this.refDisplay;
},
getType: function() {
return this.type;
},
getChoice: function() {
return this.choice;
},
getTable: function() {
return this.table;
},
getTableName: function() {
return this.tableName;
},
setTableName: function(t) {
this.tableName = t;
},
isChoice: function() {
return (this.choice == 1 ||
this.choice == 3 ||
this.type == "day_of_week" ||
this.type == "week_of_month" ||
this.type == "month_of_year");
},
getMaxLength: function() {
return this.maxLength;
},
getDisplayChars: function() {
return this.displayChars;
},
canRead: function() {
if (this.canread == 'unknown')
return this.getBooleanAttribute("canread");
return this.canread;
},
canSaveAsTemplate: function() {
if (this.saveastemplate == 'unknown')
return this.getBooleanAttribute("save_as_template");
return this.saveastemplate;
},
canWrite: function() {
if (this.canwrite == 'unknown')
return this.getBooleanAttribute("canwrite");
return this.canwrite;
},
isActive: function() {
if (this.active == 'unknown')
return this.getBooleanAttribute("active");
return this.active;
},
isNumber: function() {
return this.type == 'integer' ||
this.type == 'decimal' ||
this.type == 'numeric' ||
this.type == 'float' ||
this.type == 'percent_complete';
},
isArray: function() {
if (this.array && this.array == 'yes')
return true;
return false;
},
canSort: function() {
if (!this.getBooleanAttribute("cansort"))
return false;
if (this.name.indexOf("password") > -1)
return false;
if (this.name == 'sys_id')
return false;
if (this.type == "journal" || this.type == "journal_input")
return false;
if (this.isArray())
return false;
return true;
},
canGroup: function() {
if (this.getNamedAttribute("can_group") == "true")
return true;
if (!this.canSort())
return false;
if (this.isMulti())
return false;
if (this.name.indexOf(".") > -1 && this.name.indexOf(this.REF_ELEMENT_PREFIX) > -1)
return false;
if (this.type == "glide_duration")
return true;
if (this.type == 'glide_date_time' ||
this.type == 'glide_date' ||
this.type == 'glide_time' ||
this.type == 'due_date')
return false;
return true;
},
getAttributes: function() {
return this.attributes['attributes'];
},
getNamedAttribute: function(name) {
if (this.namedAttributes[name])
return this.namedAttributes[name];
else
return null;
},
type : function() {
return "TableElement";
},
isDynamicCreation: function() {
return this.dynamicCreation;
}
});
TableElement.get = function(name) {
var names = name.split('.');
var table = names[0];
var tableDef = Table.get(table);
var e = null;
for (var i = 1; i < names.length; i++) {
e = tableDef.getElement(names[i]);
if (i == names.length - 1)
break;
if (!e.isReference())
break;
tableDef = Table.get(e.getReference());
}
return e;
}
;
/*! RESOURCE: /scripts/classes/TableExtension.js */
var TableExtension = Class.create({
REF_ELEMENT_PREFIX: 'ref_',
initialize: function(elementName, elementLabel) {
this.name = elementName;
this.label = elementLabel;
this.table = null;
this.fields = null;
},
getName: function() {
return this.name;
},
getExtName: function() {
return this.REF_ELEMENT_PREFIX + this.getName();
},
getLabel: function() {
return this.label;
},
setTable: function(t) {
this.table = t;
},
addOption: function(select, namePrefix, labelPrefix) {
var t = this.getName();
var ext = this.getExtName();
if (namePrefix && namePrefix != '') {
var idx = namePrefix.lastIndexOf(".");
var s = namePrefix.substring(idx + 1);
var previousIsExtension = true;
if (s.indexOf(this.REF_ELEMENT_PREFIX) == 0)
ext = namePrefix.substring(0,idx + 1) + ext;
else {
ext = namePrefix + "." + ext;
previousIsExtension = false;
}
}
var label = this.getLabel();
var reflabel = label;
if (labelPrefix && labelPrefix != '')
if (previousIsExtension)
reflabel = labelPrefix.substring(0,labelPrefix.lastIndexOf(".")) + "." + reflabel;
else
reflabel = labelPrefix + "." + reflabel;
tlabel = label + " (+)";
appendSelectOption(select, ext, document.createTextNode(tlabel));
var opt = select.options[select.options.length-1];
if (labelPrefix != '')
opt.innerHTML = "&nbsp;&nbsp;&nbsp;"+tlabel;
else
opt.innerHTML = tlabel;
opt.cl = reflabel;
opt.cv = ext;
opt.tl = reflabel;
opt.style.color = 'darkred';
opt.style.cursor = 'pointer';
opt.title = "Show extended fields from " + label + " table";
opt.doNotDelete = 'true';
opt.doNotMove = 'true'
opt.reference =  t;
opt.bt = this.table.getName();
opt.btl = this.table.getLabel();
opt.headerAttr = 'true';
opt.tl = reflabel;
},
type : function() {
return "TableExtension";
}
});
;
/*! RESOURCE: /scripts/condition.js */
var MAIN_LAYER = "filterdiv";
var TEXTQUERY = "123TEXTQUERY321";
var PLACEHOLDER = "123PLACEHOLDER321";
var PLACEHOLDERFIELD = '-- choose field --';
var DEFAULT_NAME = "report";
var DEFAULT_WIDTH = "10px";
var DEFAULT_BORDER = 0;
var JS_GS = 'javascript:gs.';
var useTextareas = false;
var noConditionals = false;
var noOps = false;
var noSort = false;
var gotShowRelated = false;
var gotoPart = false;
var calendars = 0;
var refcount = 0;
var sortIndex = 0;
var queryNumber = 0;
var calendarPopups = [];
var filter;
var orderBy;
var columns = null;
var currentTable = '';
var firstTable = '';
var oldStatus = '';
var showRelated = '';
var filterExpanded = false;
var queueTables = new Array();
var queueFilters = new Array();
var queueColumns = new Array();
var operators = [
"BETWEEN",
"!=",
">=",
"<=",
"=",
">",
"<",
"NOT IN",
"IN",
"NOT LIKE",
"LIKE",
"ON",
"NOTON",
"DATEPART",
"RELATIVE",
"STARTSWITH",
"ENDSWITH",
"EMPTYSTRING",
"ISEMPTY",
"ISNOTEMPTY",
"INSTANCEOF",
"ANYTHING",
"VALCHANGES",
"CHANGESFROM",
"CHANGESTO",
"MATCH_PAT",
"MATCH_RGX",
"SAMEAS",
"NSAMEAS",
"MORETHAN",
"LESSTHAN",
"DYNAMIC",
"GT_FIELD",
"LT_FIELD",
"GT_OR_EQUALS_FIELD",
"LT_OR_EQUALS_FIELD",
"HASVARIABLE" ,
"HASITEMVARIABLE",
"HASQUESTION",
"HASLABEL"
];
var fieldComparisonOperators = ["SAMEAS", "NSAMEAS", "MORETHAN","LESSTHAN", "GT_FIELD", "LT_FIELD", "GT_OR_EQUALS_FIELD", "LT_OR_EQUALS_FIELD" ];
var dateTypes = new Array();
dateTypes['glide_date_time'] = 1;
dateTypes['glide_date'] = 1;
dateTypes['date'] = 1;
dateTypes['datetime'] = 1;
dateTypes['due_date'] = 1;
var dateOnlyTypes = new Object();
dateOnlyTypes['glide_date'] = 1;
dateOnlyTypes['date'] = 1;
var dateTimeTypes = new Object();
dateTimeTypes['glide_date_time'] = 1;
dateTimeTypes['datetime'] = 1;
dateTimeTypes['due_date'] = 1;
var numericTypes = new Array();
numericTypes['integer'] = 1;
numericTypes['decimal'] = 1;
numericTypes['numeric'] = 1;
numericTypes['float'] = 1;
numericTypes['domain_number'] = 1;
numericTypes['auto_increment'] = 1;
var opersNS = {};
opersNS.opdef = {
'af'  : [ '>',          'after'              ],
'ataf': [ '>=',         'at or after'        ],
'any' : [ 'ANYTHING',   'is anything'        ],
'are' : [ '=',          'are'                ],
'asc' : [ 'ascending',  'a to z'             ],
'avg' : [ 'avg',        'average'            ],
'bf'  : [ '<',          'before'             ],
'atbf': [ '<=',          'at or before'      ],
'btw' : [ 'BETWEEN',    'between'            ],
'dsc' : [ 'descending', 'z to a'             ],
'dtpt': [ 'DATEPART',   'trend'              ],
'em'  : [ 'ISEMPTY',    'is empty'           ],
'es'  : [ 'EMPTYSTRING',   'is empty string' ],
'enwt': [ 'ENDSWITH',   'ends with'          ],
'eq'  : [ '=',          'is'                 ],
'eqd' : [ 'DYNAMIC',    'is (dynamic)'       ],
'fvc' : [ 'VALCHANGES', 'changes'            ],
'fvf' : [ 'CHANGESFROM', 'changes from'      ],
'fvt' : [ 'CHANGESTO',  'changes to'         ],
'gt'  : [ '>',          'greater than'       ],
'gteq': [ '>=',         'greater than or is' ],
'inna': [ 'IN',         'is one of'          ],
'inst': [ 'INSTANCEOF', 'is a'               ],
'lk'  : [ 'LIKE',       'contains'           ],
'lt'  : [ '<',          'less than'          ],
'lteq': [ '<=',         'less than or is'    ],
'max' : [ 'max',        'maximum'            ],
'min' : [ 'min',        'minimum'            ],
'mpat': [ 'MATCH_PAT',  'matches pattern'    ],
'mreg': [ 'MATCH_RGX',  'matches regex'      ],
'ntem': [ 'ISNOTEMPTY', 'is not empty'       ],
'nteq': [ '!=',         'is not'             ],
'ntin': [ 'NOT IN',     'is not one of'      ],
'ntlk': [ 'NOT LIKE',   'does not contain'   ],
'nton': [ 'NOTON',      'not on'             ],
'on'  : [ 'ON',         'on'                 ],
'oper': [ '-- oper --', '-- oper --'         ],
'rltv': [ 'RELATIVE',   'relative'           ],
'saas': [ 'SAMEAS',     'is same'            ],
'nsas': [ 'NSAMEAS',    'is different'       ],
'snc' : [ 'SINCE',      'since baseline'     ],
'stwt': [ 'STARTSWITH', 'starts with'        ],
'sum' : [ 'sum',        'Total'              ],
'date_more': [ 'MORETHAN',   'is more than'  ],
'date_less': [ 'LESSTHAN',   'is less than'  ],
'gtfd': [ 'GT_FIELD',   'greater than field' ],
'ltfd': [ 'LT_FIELD',   'less than field'    ],
'gteqfd' : [ 'GT_OR_EQUALS_FIELD', 'greater than or is field' ],
'lteqfd' : [ 'LT_OR_EQUALS_FIELD', 'less than or is field' ]
};
opersNS.opdef_template = {
'eq'  : [ '=',          'To'                 ],
'saas': [ 'SAMEAS',     'Same as'            ],
'eqd' : [ 'DYNAMIC',    'To (dynamic)'       ]
}
opersNS.compile = function(ops_input, opsdef) {
for (var fieldType in ops_input) {
var proto = ops_input[fieldType];
if (proto.charAt(0) == '=')
continue;
var opers = proto.split(",");
var opArray = [];
for (var i = 0; i < opers.length; i++) {
var oper = opers[i];
if (oper)
opArray.push(opsdef[oper]);
}
ops_input[fieldType] = opArray;
}
for (var fieldType in ops_input) {
var proto = ops_input[fieldType];
if (typeof proto != 'string')
continue;
ops_input[fieldType] = ops_input[proto.substring(1)];
}
}
var sysopers = {
'auto_increment'	  : '=integer',
'aggspec'             : 'sum,avg,min,max,any,fvc,fvf,fvt',
'boolean'             : 'eq,nteq,em,ntem,any,fvc,fvf,fvt,saas,nsas',
'calendar'            : 'on,nton,bf,atbf,af,ataf,btw,dtpt,rltv,snc,em,ntem,any,fvc,saas,nsas,date_more,date_less',
'choice'              : 'eq,nteq,inna,ntin,lk,stwt,enwt,ntlk,any,fvc,fvf,fvt,saas,nsas',
'referencechoice'     : 'eq,nteq,inna,ntin,lk,stwt,enwt,ntlk,any',
'composite_field'     : 'stwt,lk,ntlk,any',
'composite_name'      : '=string',
'conditions'          : '=string',
'condition_string'    : '=string',
'currency'			  : 'eq,nteq,em,ntem,lt,gt,lteq,gteq,btw',
'decimal'             : '=integer',
'default'             : 'eq,nteq,any,fvc,fvf,fvt',
'email'               : '=string',
'email_script'        : '=string',
'field_name'          : '=string',
'glide_duration'      : 'eq,nteq,em,ntem,lt,gt,lteq,gteq,btw,any,fvc',
'glide_list'          : 'lk,ntlk,em,ntem,fvc,fvf,fvt',
'GUID'                : '=string',
'html'                : 'lk,ntlk,em,ntem,any,fvc,fvf,fvt',
'html_script'         : '=string',
'integer'             : 'eq,nteq,em,ntem,lt,gt,lteq,gteq,btw,any,fvc,fvf,fvt,saas,nsas,gtfd,ltfd,gteqfd,lteqfd',
'integer_choice'      : 'eq,nteq,inna,ntin,em,ntem,lt,gt,lteq,gteq,btw,any,fvc,fvf,fvt,saas,nsas',
'journal'             : 'fvc',
'journal_input'       : '=journal',
'keyword'             : 'are',
'multi_two_lines'     : '=string',
'ph_number'           : '=string',
'phone_number_e164'   : '=string',
'placeholder'         : 'oper',
'price'				  : 'eq,nteq,em,ntem,lt,gt,lteq,gteq,btw',
'reference'           : 'eq,nteq,em,ntem,stwt,enwt,lk,ntlk,any,saas,nsas,es,eqd,fvc,fvf,fvt',
'referencevariable'   : 'eq,nteq,em,ntem',
'replication_payload' : '=string',
'script'              : 'lk,ntlk,ntem,any,fvc,fvf,fvt',
'script_plain'        : '=script',
'sortspec'            : 'asc,dsc,fvc,fvf,fvt',
'string'              : 'stwt,enwt,lk,ntlk,eq,nteq,em,ntem,mpat,mreg,any,inna,es,fvc,fvf,fvt,lteq,gteq,btw,saas,nsas',
'string_choice'       : '=choice',
'string_clob'         : 'lk,ntlk,stwt,enwt,em,ntem,any,fvc,fvf,fvt',
'string_numeric'      : 'eq,nteq,lk,ntlk,stwt,enwt,btw,any,fvc,fvf,fvt,saas,nsas',
'sys_class_name'      : 'eq,nteq,inst,any,fvc,fvf,fvt',
'table_name'          : '=string',
'timer'               : '=integer',
'translated_field'    : '=string',
'translated_html'     : '=html',
'translated_text'     : '=string',
'cons_translated'	  : 'eq,nteq,em,ntem',
'url'                 : '=string',
'workflow'            : '=choice',
'xml'                 : '=html',
'domain_path'         : '=string',
'tree_code'           : '=string',
'tree_path'           : '=string',
'source_id' 	      : '=string',
'source_name'  	      : '=string',
'source_table' 	      : '=string'
};
var sysopers_template = {
'default'             : 'eq,saas,eqd'
}
opersNS.compile(sysopers, opersNS.opdef);
opersNS.compile(sysopers_template, opersNS.opdef_template);
var extopers = {};
extopers['MATCH_PAT'] = true;
extopers['MATCH_RGX'] = true;
extopers['VALCHANGES'] = true;
extopers['CHANGESTO'] = true;
extopers['CHANGESFROM'] = true;
var calNS = {};
calNS.protoVal = [
'Today: [0d   ]0d  ]0d  ',
'Yesterday: [1d   ]1d  ]1d  ',
'Tomorrow: [-1d  ]-1d ]-1d ',
'This week: [=w   ]=w  ]=w  ',
'Last week: [<w   ]<w  ]<w  ',
'Next week: [>w   ]>w  ]>w  ',
'This month: [=m   ]=m  ]=m  ',
'Last month: [<m   ]<m  ]<m  ',
'Next month: [>m   ]>m  ]>m  ',
'Last 3 months: [3m   ]=m  [3m  ',
'Last 6 months: [6m   ]=m  [6m  ',
'Last 9 months: [9m   ]=m  [9m  ',
'Last 12 months: [12m  ]=m  [12m ',
'This quarter: [=q   ]=q  ]=q  ',
'Last quarter: [1q   ]1q  ]1q  ',
'Last 2 quarters: [1q   ]=q  ]2q  ',
'Next quarter: [-1q  ]-1q ]-1q ',
'Next 2 quarters: [-1q  ]-2q ]-2q ',
'This year: [=y   ]=y  ]=y  ',
'Next year: [>y   ]>y  ]>y  ',
'Last year: [<y   ]<y  ]<y  ',
'Last 2 years: [<y   ]=y  [<y  ',
'Last 7 days: [7d   ]0d  [7d  ',
'Last 30 days: [30d  ]0d  [30d ',
'Last 60 days: [60d  ]0d  [60d ',
'Last 90 days: [90d  ]0d  [90d ',
'Last 120 days: [120d ]0d  [120d',
'Current hour: [0h   ]0h  ]0h  ',
'Last hour: [1h   ]1h  ]1h  ',
'Last 2 hours: |2h   |0h  |2h  ',
'Current minute: [0n   ]0n  ]0n  ',
'Last minute: [1n   ]1n  [1n  ',
'Last 15 minutes: [15n  ]0n  [15n ',
'Last 30 minutes: [30n  ]0n  [30n ',
'Last 45 minutes: [45n  ]0n  [45n ',
'One year ago: |12m  ]=m  |12m '
];
calNS.agoUnits = {d: 'days', m: 'months', q: 'quarters', h: 'hours', n: 'minutes'};
calNS.agoStartEnd = {'[':'Start', ']':'End', '|':''};
calNS.ofUnits = {w: 'Week', m: 'Month', q: 'Quarter', y: 'Year'};
calNS.ofBeginningEnd = {'[':'beginning', ']':'end', '|':''};
calNS.ofWhich = {'<':'Last', '=':'This', '>':'Next'};
calNS.compileCal = function compileCal() {
var result = [];
for (var i = 0; i < calNS.protoVal.length; i++) {
var proto = calNS.protoVal[i];
var parts = /^(.*?)\: *([^ ]*) *([^ ]*) *([^ ]*) *$/.exec(proto);
var row = [];
row.push(parts[1]);
for (var j = 2; j <= 4; j++)
row.push(encode(parts[j]));
result.push(row);
}
result.BETWEEN = ['Now', JS_GS + 'nowNoTZ()', JS_GS + 'nowNoTZ()'];
result.RELATIVE = [
[ 'on or after',  'GE' ],
[ 'on or before', 'LE' ],
[ 'after',        'GT' ],
[ 'before',       'LT' ],
[ 'on',           'EE' ] ];
result.TRENDVALUES = [
[ 'Hours',    'hour'      ],
[ 'Minutes',  'minute'    ],
[ 'Days',     'dayofweek' ],
[ 'Months',   'month'     ],
[ 'Quarters', 'quarter'   ],
[ 'Years',    'year'      ] ];
result.WHEN = [
[ 'ago',      'ago'  ],
[ 'from now', 'ahead'] ];
result.TRENDVALUES_WITH_FIELDS_PLURIAL = [
[ 'Days',     'day' ],
[ 'Weeks',    'week' ],
[ 'Months',   'month'     ],
[ 'Quarters', 'quarter'   ],
[ 'Years',    'year'      ],
[ 'Hours',    'hour'      ]];
result.TRENDVALUES_WITH_FIELDS = [
[ 'Day',     'day' ],
[ 'Week',    'week' ],
[ 'Month',   'month'     ],
[ 'Quarter', 'quarter'   ],
[ 'Year',    'year'      ],
[ 'Hour',    'hour'      ]];
result.WHEN_WITH_FIELDS = [
[ 'before',			'before'  		 ],
[ 'after', 			'after'   		 ],
[ 'before or after',	'before or after'] ];
result.DATEPART = compileDatePart();
return result;
function encode(part) {
var parts = /^([\[\]\|])([\-0-9]+)([dmqhn])$/.exec(part);
return parts ?
JS_GS + calNS.agoUnits[parts[3]] + 'Ago' + calNS.agoStartEnd[parts[1]] + '(' + parts[2] + ')' :
JS_GS + calNS.ofBeginningEnd[part.charAt(0)] + 'Of' + calNS.ofWhich[part.charAt(1)] +
calNS.ofUnits[part.charAt(2)] + '()';
}
function compileDatePart() {
var result = [];
compileDaysOfWeek(result);
compileMonths(result);
compileQuarters(result);
compileYears(result);
compileWeeks(result);
compileHours(result);
return result;
function compileDaysOfWeek(result) {
var dow = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
for (var i = 0; i < dow.length; i++)
result.push([dow[i], JS_GS + "datePart('dayofweek','" + dow[i].toLowerCase() + "')"]);
}
function compileMonths(result) {
var ml = ['January','February','March','April','May','June','July','August','September','October','November','December'];
var ms = ['jan','feb','mar','apr','may','june','july','aug','sep','oct','nov','dec'];
for (var i = 0; i < ml.length; i++)
result.push([ml[i], JS_GS + "datePart('month', '" + ms[i] + "')"]);
}
function compileQuarters(result) {
for (var i = 1; i <= 4; i++)
result.push(['Quarter ' + i, JS_GS + "datePart('quarter','" + i + "')"]);
}
function compileYears(result) {
for (var i = 2000; i <= 2020; i++)
result.push(['' + i, JS_GS + "datePart('year','" + i + "')"]);
}
function compileWeeks(result) {
for (var i = 0; i <= 53; i++)
result.push(['Week ' + i, JS_GS + "datePart('week','" + i + "')"]);
}
function compileHours(result) {
for (var i = 0; i < 24; i++) {
var hr = (i == 0) ? 'Midnight' : ((i < 12) ? '' + i + ' am' : ((i == 12) ? 'Noon' : '' + (i - 12) + ' pm'));
result.push([hr, JS_GS + "datePart('hour', '" + i + "')"]);
}
}
}
}
var sysvalues = {};
sysvalues['boolean']        = [[ "true", "true" ], [ "false",  "false" ]];
sysvalues['catalog_boolean']        = [[ "Yes", "Yes" ], [ "No",  "No" ]];
sysvalues['string_boolean'] = [[ "1", "true" ], [ "0",  "false" ]];
sysvalues['calendar']       = calNS.compileCal();
var MESSAGES_CONDITION_RELATED_FILES = ['lowercase_fields','Keywords','Show Related Fields','Remove Related Fields', '-- choose field --', '-- value --', '-- None --'];
var g_current_table = '';
var g_filter_extension_map = {};
function deleteFilterByID(tablename, id) {
var td = getThing(tablename, id);
deleteTD(tablename, td);
_frameChanged();
}
function deleteTD(tableName, butTD) {
var butTR = butTD.parentNode;
if (butTR.conditionObject)
butTR.conditionObject.remove();
else {
var parent = butTR.parentNode;
if (parent.conditionObject) {
parent.conditionObject.remove();
}
}
}
function sortByFilter(item) {
return item.canSort();
}
function seeIfItHasFilters(name) {
var noItemsDiv = getThing(name, 'nofilteritems');
if (noItemsDiv) {
var fs = getThing(name,'gcond_filters');
if (fs && fs.hasChildNodes()) {
noItemsDiv.style.display = "none";
} else {
noItemsDiv.style.display = "inline";
}
}
var itemsActions = getThing(name, 'filteractions');
if (itemsActions) {
var fs = getThing(name, 'gcond_filters');
if (fs && fs.hasChildNodes()) {
itemsActions.style.display = "inline";
} else {
itemsActions.style.display = "none";
}
}
}
function displayGroupList(element, name, groupField, groupValue, groupQuery) {
var form = getFormForElement(element);
var query = getQueryForForm(form);
var view = gel('sysparm_view');
if (view != null)
view = view.value;
var gfilters = query.split("^");
var filter = '';
for (var i = 0; i < gfilters.length; i++) {
var idx = gfilters[i].indexOf('GROUPBY');
if (idx > -1)
continue;
idx = gfilters[i].indexOf('ORDERBY');
if (idx > -1)
continue;
if (filter.length > 0 )
filter += "^";
filter += gfilters[i];
}
if (filter.length > 0 )
filter += "^";
filter += groupQuery;
for (var i = 0; i < gfilters.length; i++) {
var idx = gfilters[i].indexOf('GROUPBY');
if (idx > -1)
continue;
idx = gfilters[i].indexOf('ORDERBY');
if (idx == -1)
continue;
if (filter.length > 0 )
filter += "^";
filter += gfilters[i];
}
var url = name + "_list.do?sysparm_query=" + filter;
if (view != null && view.indexOf("rpt-") != 0)
url = url + '&sysparm_view=' + view;
window.location = url;
}
function getQueryForForm(form) {
var elements = Form.getElements($(form));
for (var i = 0; i < elements.length; i++) {
var thisElement = elements[i];
if (thisElement.id == 'sysparm_query' || thisElement.name == 'sysparm_query')
return thisElement.value;
}
return '';
}
function getFilter(name, doEscape, fDiv) {
var fullFilter = "";
orderBy = "";
var spanName = ".encoded_query";
var fSpan = getThing(name, spanName);
if (fSpan != null)
return fSpan.innerHTML;
var divName = "gcond_filters";
if (fDiv != null)
divName = fDiv + divName;
var fDiv = getThing(name, divName);
if (fDiv == null)
return "";
if ('gcond_filters' == divName)
addOrderBy();
var fQueries = fDiv.getElementsByTagName("tr");
for (var i = 0; i < fQueries.length; i++) {
var queryTR = fQueries[i];
if (queryTR.queryPart != 'true')
continue;
var queryID = queryTR.queryID;
var query = getThing(name, queryID);
filter = "";
var queryString = getQueryString(query);
if (fullFilter.length > 0 && queryString.length > 0)
fullFilter += "^NQ";
fullFilter = fullFilter + queryString;
}
if (fullFilter.length > 0)
fullFilter += "^EQ";
fullFilter += orderBy;
filter = fullFilter;
if (doEscape)
filter = encodeURIComponent(filter);
return filter;
function addOrderBy() {
'use strict';
var fDiv = $('gcond_sort_order');
if (!fDiv)
return;
var fQueries = fDiv.getElementsByTagName("tr");
for (var i = 0; i < fQueries.length; i++) {
var queryTR = fQueries[i];
if (queryTR.queryPart != 'true')
continue;
var queryID = queryTR.queryID;
var query = getThing(name, queryID);
if (!query)
continue;
getQueryString(query);
}
}
}
function reconstruct(table, column) {
if (!column)
return column;
if (column.indexOf("...") < 0)
return column;
var ngfi = column.indexOf("...");
var ngf = column.substring(0, ngfi);
var te = new Table(table);
var recon = ngf + "." + te.getDisplayName(ngf);
return recon;
}
function getQueryString(query) {
var tableTRs = query.getElementsByTagName("tr");
for (var i = 0; i < tableTRs.length; i++) {
var tr = tableTRs[i];
if (!tr)
continue;
if (tr.basePart != 'true')
continue;
getQueryForTR(tr);
}
return filter;
}
function getQueryForTR(trItem) {
var trs = trItem.getElementsByTagName("tr");
for (var i = 0; i < trs.length; i++) {
var tr = trs[i];
var type = tr.varType;
var field = getTDFieldValue(tr.tdField);
if (field == PLACEHOLDER || !tr.operSel)
continue;
var oper = getSelectedOption(tr.operSel).value;
if (!tr.sortSpec && !tr.aggSpec) {
var filterPart = getTRFilter(tr, field, oper);
if (filter.length > 0)
filter += "^";
if (tr.gotoPart)
filter += "GOTO";
if (i != 0)
filter += "OR";
filter += filterPart;
var ips = tr.getElementsByTagName("input");
for (var ti = 0; ti < ips.length; ti++) {
var iput = ips[ti];
if (iput.type == "hidden" && iput.name == "subcon") {
filter += "^" + iput.jop + iput.field + iput.oper
+ iput.value;
}
}
} else if (!tr.aggSpec) {
if (oper == 'ascending') {
orderBy += "^" + "ORDERBY" + field;
} else if (oper == 'descending') {
orderBy += "^" + "ORDERBYDESC" + field;
}
}
}
}
function escapeEmbeddedQueryTermSeparator(val) {
return val.replace(/(\w)\^(\w)/g,"$1^^$2");
}
function getTRFilter(tr, field, oper) {
var val;
if (tr.handler) {
var answer = tr.handler.getFilterText(oper);
if (answer != '')
return answer;
val = tr.handler.getValues();
if (oper == 'SINCE')
oper = '>';
}
return field + oper + escapeEmbeddedQueryTermSeparator(val);
}
function getTDFieldValue(td) {
var fType = td.fieldType ? td.fieldType : "select";
var tags = td.getElementsByTagName(fType);
var field = tags[0];
var input;
if (fType == "select") {
var options = field.options;
if (field.multiple == true) {
var retVal = new Array();
for (var i = 0; i < options.length; i++) {
if (options[i].selected)
retVal[retVal.length] = options[i].value;
}
return retVal.join(",");
} else {
return options[field.selectedIndex].value;
}
} else {
input = field;
}
return input.value;
}
function refreshFilter(name) {
var fDiv = getThing(name,'gcond_filters');
var fQueries = fDiv.getElementsByTagName("tr");
for (var i = 0; i < fQueries.length; i++ ) {
var queryTR = fQueries[i];
if (queryTR.queryPart != 'true')
continue;
var queryID = queryTR.queryID;
var query = getThing(name, queryID);
refreshQuery(query);
}
}
function refreshQuery(query) {
var tableTRs = query.getElementsByTagName("tr");
for(var i = 1; i < tableTRs.length; i++) {
var tr = tableTRs[i];
if (!tr)
continue;
if (tr.basePart != 'true')
continue;
var fieldValue = tr.tdValue;
refreshSelect(tr, fieldValue);
}
}
function refreshSelect(tr, td) {
if (typeof td == 'undefined')
return;
var fType = td.fieldType ? td.fieldType : "select";
var tags = td.getElementsByTagName(fType);
if (tags == null || tags.length == 0)
return;
var field = tags[0];
if (fType == "select") {
var options = field.options;
if (field.multiple == true) {
var choices = field.choices;
choicesGet(tr.tableField, field, choices);
}
}
}
function getThing(table, name) {
var thing = gel(table+name);
if (thing != null)
return thing;
thing = gel(name);
if (thing != null)
return thing;
if (table != null) {
var fperiod = table.indexOf(".");
if (fperiod > 0) {
table = table.substring(fperiod+1);
thing = gel(table+name);
}
}
return thing;
}
function setup(name) {
if (name == null || name == '') {
name = firstTable;
if (name == null || name == '') {
alert("Choose a table before adding filters");
return false;
}
}
g_current_table = name;
columns = queueColumns[name];
if (columns == null) {
var tname = (name.split("."))[0];
columns = queueColumns[tname];
if (columns == null) {
columnsGet(name, setup);
columns = queueColumns[tname];
if (columns == null)
return false;
}
}
if (columns == null) {
alert("Choose a table before adding filters");
return false;
}
currentTable = name;
return true;
}
function addFilter1(name, queryID) {
addFilter(name, queryID);
}
function addFilterFor(name, isTableName, fDiv) {
if (isTableName)
addFilter(name, '', '', '', '', fDiv);
else {
var parts = name.split(".");
var systable = parts[0];
var sysfield = parts[2];
var dep = gel(systable + '.' + sysfield);
var table = null;
if (dep != null && dep.tagName == 'SELECT' && getSelectedOption(dep).value)
table = getSelectedOption(dep).value;
else if (dep != null)
table = dep.value;
if (table != null) {
addFilter(table+"."+parts[0]+"."+parts[1]);
}
}
}
function addFilter(tableName, queryID, fField, fOper, fValue, fDiv) {
addConditionSpec(tableName, queryID, fField, fOper, fValue, fDiv);
}
function addFirstLevelFields(s, target, fValue, filterMethod, fieldName, filter) {
var forFilter;
var onlyRestrictedFields;
if (filter) {
forFilter = filter.getOpsWanted();
onlyRestrictedFields = filter.onlyRestrictedFields;
}
var messages = getMessages(MESSAGES_CONDITION_RELATED_FILES);
while (s.length > 0)
s.remove(0);
if (!gotShowRelated) {
gotShowRelated = true;
if (typeof g_filter_description != 'undefined')
showRelated = g_filter_description.getShowRelated();
else
showRelated = getPreference("filter.show_related");
}
var placeholder = false;
var selindex = 0;
var indentLabel = false;
var savedItems = {};
var savedLabels = [];
var labelPrefix = '';
var headersAdded = false;
var parts = target.split(".");;
var tableName = parts[0];
var tableDef = getTableReference(tableName);
var extension = '';
var prefix = '';
if (parts.length > 1 && parts[1] != null && parts[1] != '') {
var o = null;
if (filterExpanded && parts.length > 2) {
var tableLabel = tableDef.getLabel();
if (tableLabel == null)
tableLabel = "Parent";
o = addOption(s, tableDef.getName()+"...", tableLabel + " " + messages['lowercase_fields'], false);
o.tableName = tableDef.getName();
o.style.color = 'blue';
}
if (parts[1] == PLACEHOLDERFIELD) {
o = addOption(s, PLACEHOLDER, messages['-- choose field --'], true);
o.style.color = 'blue';
o.tableName = tableDef.getName();
o.fullLabel = messages['-- choose field --'];
placeholder = true;
}
var sPeriod = "";
var cname = '';
for (var i = 1; i < parts.length-1; i++) {
var f = parts[i];
if (f == null || f == '')
break;
var elementDef = tableDef.getElement(parts[i]);
if (elementDef == null)
break;
var childTable = tableName;
if (elementDef.isReference()) {
childTable = elementDef.getReference();
if (elementDef.isExtensionElement())
extension = childTable;
else
extension = '';
} else {
if (fieldName != null && fieldName.indexOf("...") > -1) {
childTable = parts[0];
} else {
break;
}
}
var parentTable = (extension != '')? extension:elementDef.getTable().getName();
var tableDef = getTableReference(childTable, parentTable);
if (cname.length)
cname = cname + ".";
cname += elementDef.getName();
sPeriod = "." + sPeriod;
var clabel =  sPeriod + elementDef.getLabel() + "-->" + elementDef.getRefLabel() + " " + messages['lowercase_fields'];
o = addOption(s, cname+"...", clabel, false);
o.tablename = tableDef.getName();
o.style.color = 'blue';
selindex++;
indentLabel = true;
headersAdded = true;
if (labelPrefix.length)
labelPrefix += ".";
labelPrefix += elementDef.getLabel();
if (prefix.length)
prefix += ".";
prefix += elementDef.getName();
}
}
columns = tableDef.getColumns();
queueColumns[tableDef.getName()] = columns;
var textIndex = false;
if (!noOps && !indentLabel) {
var root = columns.getElementsByTagName("xml");
if (root != null && root.length == 1) {
root = root[0];
textIndex = root.getAttribute("textIndex");
}
}
var items = (extension != '')? tableDef.getTableElements(extension):tableDef.getElements();
for (var i = 0; i < items.length; i++) {
var item = items[i];
var t = item.getName();
if (filterMethod != null && t != fValue) {
if (filterMethod(item) == false) {
continue;
}
}
var t = item.getName();
if (prefix != '')
t = prefix + '.' + t;
if (!noOps && item.getAttribute("filterable") == "no" && !allowConditionsForJournal(item.getAttribute("type"), filter))
continue;
if (!item.canRead()) {
if (t != fValue) {
continue;
} else {
item.setCanRead('yes');
}
}
if (!item.isActive()) {
if (t != fValue) {
continue;
} else {
item.setActive('yes');
}
}
var label = item.getLabel();
if (!elementDef || elementDef.getType() != "glide_var") {
savedItems[label] = t;
savedLabels[savedLabels.length] = label;
}
if (item.isReference() && !item.isRefRotated() && item.getType() != 'glide_list' && filterExpanded && showRelated == 'yes') {
label += "-->" + item.getRefLabel();
label += " " + messages['lowercase_fields'];
t += "...";
savedItems[label] = t;
savedLabels[savedLabels.length] = label;
}
}
items = tableDef.getExtensions();
for (var i = 0; i < items.length; i++) {
var item = items[i];
var label = item.getLabel() + " (+)";
t = item.getExtName() + "...";
if (prefix != '')
t = prefix + '.' + t;
savedItems[label] = t;
savedLabels[savedLabels.length] = label;
}
if (!onlyRestrictedFields && ((fValue == TEXTQUERY || textIndex) && filterMethod == null || forFilter)) {
o = addOption(s, TEXTQUERY, messages['Keywords'], (fValue == TEXTQUERY));
o.fullLabel = messages['Keywords'];
}
for (var i = 0; i < savedLabels.length; i++) {
var sname = savedLabels[i];
var o = addOption(s, savedItems[sname], sname, savedItems[sname] == fValue);
o.tableName = tableDef.getName();
if (labelPrefix != '')
o.fullLabel = labelPrefix + "." + sname;
else
o.fullLabel = sname;
if (indentLabel) {
var yyy = o.innerHTML;
o.innerHTML = "&nbsp;&nbsp;&nbsp;"+yyy;
}
var v = o.value;
if (v.indexOf("...") != -1)
if (o.fullLabel.indexOf("(+)") == -1)
o.style.color = 'blue';
else
o.style.color = 'darkred';
}
if (filterExpanded  && !onlyRestrictedFields) {
if (showRelated != 'yes') {
var o = addOption(s, "...Show Related Fields...", messages['Show Related Fields'], false);
o.style.color = 'blue';
} else {
var o = addOption(s, "...Remove Related Fields...", messages['Remove Related Fields'], false);
o.style.color = 'blue';
}
}
if (!placeholder && (s.selectedIndex == 0 && ((textIndex && fValue != TEXTQUERY) || headersAdded)))
s.selectedIndex = selindex;
if (s.selectedIndex >= 0) {
fValue = getSelectedOption(s).value;
}
return s;
}
function allowConditionsForJournal(type, filter) {
if (type != "journal" && type !="journal_input" )
return false;
if (!filter || filter.getUsageContext() != "element_conditions")
return false;
var ie = filter.getIncludeExtended();
if (ie["VALCHANGES"])
return true;
return false;
}
function updateSortFields(name, select) {
if (setup(name) == false)
return;
name = currentTable;
var o = getSelectedOption(select);
var fieldName = o.value;
name = name.split(".")[0];
var idx = fieldName.indexOf("...");
if (idx != -1) {
if (fieldName == '...Show Related Fields...') {
gotShowRelated = true;
showRelated = 'yes';
setPreference("filter.show_related", "yes");
}
else if (fieldName == '...Remove Related Fields...') {
gotShowRelated = true;
showRelated = 'no';
setPreference("filter.show_related", "no");
}
var f = fieldName.substring(0, idx);
if (f != name)
f = name + "." + f;
f = f + ".";
addFirstLevelFields(select, f, '', null, fieldName);
return;
}
name = currentTable = getTableFromOption(o);
var options = select.options;
for (var i = 0; i < options.length; i++) {
var option = options[i];
if (optionWasSelected(option)) {
option.innerHTML = getNormalLabel(option);
option.style.color = 'black';
option.wasSelected = 'false';
break;
}
}
if (setup(name) == false)
return;
var tr = select.parentNode.parentNode;
o.normalLabel = o.innerHTML;
o.innerHTML = getFullLabel(o);
o.style.color = 'green';
o.wasSelected = 'true';
select.style.width = "240px";
return;
}
function updateFields(name, select, fOper, fValue, includeExtended, filterClass) {
if (!setup(name))
return;
var tableNameFull = name;
name = currentTable;
var o = getSelectedOption(select);
var fieldName = o.value;
name = name.split(".")[0];
var idx = fieldName.indexOf("...");
if (idx != -1) {
if (fieldName == '...Show Related Fields...') {
gotShowRelated = true;
showRelated = 'yes';
setPreference("filter.show_related", "yes");
}
if (fieldName == '...Remove Related Fields...') {
gotShowRelated = true;
showRelated = 'no';
setPreference("filter.show_related", "no");
}
var f = fieldName.substring(0, idx);
if (f != name)
f = name + "." + f;
f = f + ".";
addFirstLevelFields(select, f, '', null, fieldName);
return;
}
name = currentTable = getTableFromOption(o);
var options = select.options;
for (var i = 0; i < options.length; i++) {
var option = options[i];
if (optionWasSelected(option)) {
option.innerHTML = getNormalLabel(option);
option.style.color = 'black';
option.wasSelected = 'false';
break;
}
}
if (setup(name) == false)
return;
var tr = select.parentNode.parentNode;
o.normalLabel = o.innerHTML;
o.innerHTML = getFullLabel(o);
o.style.color = 'green';
o.wasSelected = 'true';
select.style.width = "240px";
buildFieldsPerType(name, tr, fieldName, fOper, fValue, includeExtended, tableNameFull, filterClass);
}
function buildFieldsPerType(tableName, tr, descriptorName, fOper, fValue, includeExtended, tableNameFull, filterClass) {
var tableName = tableName.split(".")[0];
var parts = descriptorName.split('.');
descriptorName = parts[parts.length-1];
var tableDef = getTableReference(tableName);
if (tableDef == null)
return;
var type;
var multi;
var isChoice;
var elementDef = tableDef.getElement(descriptorName);
var msg = new GwtMessage();
if (elementDef == null) {
if (descriptorName != TEXTQUERY && descriptorName != PLACEHOLDER)
return;
if (descriptorName == TEXTQUERY) {
type = 'keyword';
multi = true;
isChoice = false;
} else {
type = 'placeholder';
multi = false;
isChoice = false;
fValue = msg.getMessage('-- value --');
}
} else {
type = elementDef.getType();
multi = elementDef.getMulti();
isChoice = elementDef.isChoice();
if (!elementDef.getBooleanAttribute("canmatch"))
if (type != "variables" && type != "related_tags")
type = "string_clob";
}
var tdField = tr.tdField;
var tdOperator = tr.tdOper;
var tdValue = tr.tdValue;
tr.varType = type;
tr.gotoPart = gotoPart;
if (tr.handler)
tr.handler.destroy();
tr.handler = null;
if (tr.sortSpec == true) {
tr.varType = 'sortspec';
type = 'sortspec';
} else if (tr.aggSpec == true) {
tr.varType = 'aggspec';
type = 'aggspec';
}
tr.tableField = tableName + "." + descriptorName;
tdOperator.innerHTML = "";
tdValue.innerHTML = "";
if (type == "float")
type = "integer";
else if (type == 'domain_number')
type = "integer";
else if (type == "wide_text" || type == "ref_ext")
type = "string";
else if (dateTypes[type]) {
type = "calendar";
if (fValue && fValue.indexOf("datePart") > -1 )
fOper = 'DATEPART';
else if (fValue && (fValue.indexOf('getBaseFilter') > 0))
fOper = "SINCE";
}
var showDynamicReferenceOperator = shouldShowDynamicReferenceOperator(type, elementDef);
var operSel = addOperators(tdOperator, type, fOper, isChoice, includeExtended, showDynamicReferenceOperator, filterClass);
tr.operSel = operSel;
if (fOper == null && operSel)
fOper = tdOperator.currentOper;
if ((type == "boolean") || (type == 'string_boolean')) {
tr.handler = new GlideFilterChoice(tableName, elementDef);
var keys = new Array();
for (var i =0; i< sysvalues[type].length; i++) {
keys.push(sysvalues[type][i][0]);
}
var msg = new GwtMessage();
var map = msg.getMessages(keys);
for (var i =0; i < sysvalues[type].length; i++) {
var v = sysvalues[type][i][0];
sysvalues[type][i][1] = map[v];
}
tr.handler.setChoices(sysvalues[type]);
} else if (type == 'calendar')
tr.handler = new GlideFilterDate(tableName, elementDef);
else if (type == "reference") {
tr.handler = new GlideFilterReference(tableName, elementDef);
tr.handler.setOriginalTable(tableNameFull);
} else if (type == "related_tags") {
tr.handler = new GlideFilterLabels(tableName, elementDef);
tr.handler.setOriginalTable(tableNameFull);
} else if (type == "variables") {
if (tableName == 'sc_task')
tr.handler = new GlideFilterItemVariables(tableName, elementDef);
else
tr.handler = new GlideFilterVariables(tableName, elementDef);
tr.handler.setOriginalTable(tableNameFull);
} else if (type == "questions") {
tr.handler = new GlideFilterQuestions(tableName, elementDef);
tr.handler.setOriginalTable(tableNameFull);
} else if (type == "glide_list")
tr.handler = isTemplate(tableNameFull) ? new GlideFilterReferenceMulti(tableName, elementDef) : new GlideFilterReference(tableName, elementDef);
else if (type == 'sortspec' || type == 'aggspec')
{}
else if (type == 'mask_code' || isChoice)
tr.handler = new GlideFilterChoiceDynamic(tableName, elementDef);
else if (type == 'glide_duration' || type == 'timer')
tr.handler = new GlideFilterDuration(tableName, elementDef);
else if (isFilterExtension(type))
tr.handler = initFilterExtension(type, tableName, elementDef);
else if ((multi == 'yes') && (useTextareas))
tr.handler = new GlideFilterStringMulti(tableName, elementDef);
else if (type == 'integer')
tr.handler = new GlideFilterNumber(tableName, elementDef);
else if (type == 'currency' || type == 'price')
tr.handler = new GlideFilterCurrency(tableName, elementDef)
else
tr.handler = new GlideFilterString(tableName, elementDef);
if (tr.handler) {
tr.handler.setFilterClass(filterClass)
tr.handler.create(tr, fValue);
}
}
function shouldShowDynamicReferenceOperator(type, elementDef) {
if (type != "reference")
return false;
if (typeof g_dynamic_filter_options == "undefined" || g_dynamic_filter_options == '')
return false;
var table = elementDef.getReference();
var gotOne = false;
var arr = g_dynamic_filter_options.split("##");
for (var i = 0; i < arr.length; i++) {
var aItem = arr[i];
if (aItem.length == 0)
continue;
var aItemArr = aItem.split("::");
if (aItemArr.length < 3)
continue;
if (table == aItemArr[2]) {
gotOne = true;
break;
}
}
return gotOne;
}
function isFilterExtension(type) {
if (g_filter_extension_map[type])
return true;
return false;
}
function initFilterExtension(type, tableName, elementDef) {
var o = g_filter_extension_map[type];
return o.call(this, tableName, elementDef);
}
function resetMenuMulti(td, menu, multiple) {
if (multiple == false) {
var selected = 0;
for(var i = 0; i < menu.options.length; i++) {
if (menu.options[i].selected) {
selected = i;
break;
}
}
menu.multiple = false;
menu.selectedIndex = selected;
menu.size = 1;
} else {
menu.options[menu.selectedIndex].selected = true;
menu.multiple = true;
menu.size = 4;
}
}
function addTextInput(td, dValue, type) {
var input = cel("input");
if (type)
input.type = type;
if (td.parentNode.conditionObject)
if (td.parentNode.conditionObject.isPlaceHolder())
input.disabled = true;
if (isMSIE) {
input.onkeypress = function() { return enterKey(event) };
if (isMSIE7 || isMSIE6)
input.style.marginTop = "-1px";
} else
input.onkeypress =enterKey;
td.fieldType = "input";
if (dValue)
input.value = dValue;
input.className = "filerTableInput";
input.title = 'input value';
if (useTextareas) {
input.style.width="80%";
input.maxlength=80;
}
input.style.verticalAlign = "top";
td.appendChild(input);
return input;
}
function addTextArea(td, dValue) {
if (!useTextareas)
return addTextInput(td, dValue);
var input = cel("textarea");
td.fieldType = "textarea";
if (dValue)
input.value = dValue;
input.className = "filerTableInput";
input.title = 'input value';
input.wrap="soft";
input.rows=5;
input.style.width="80%";
input.maxlength=80;
td.appendChild(input);
return input;
}
function getTableFromOption(option) {
var tableName = option.tableName || option.getAttribute('tableName');
if (tableName === undefined || tableName == null || tableName == '' )
tableName = "";
return tableName;
}
function getFullLabel(option) {
var answer = option.fullLabel || option.getAttribute('fullLabel');
if (answer === undefined || answer == null || answer == '' )
answer = "";
return answer;
}
function getNormalLabel(option) {
var answer = option.normalLabel || option.getAttribute('normalLabel');
if (answer === undefined || answer == null || answer == '' )
answer = "";
return answer;
}
function optionWasSelected(option) {
var answer = option.wasSelected || option.getAttribute('wasSelected');
if (answer === undefined || answer == null || answer == '' )
return false;
if (answer == 'true')
return true;
return false;
}
function addFields(tableName, fValue, isSort, extendedFields) {
setup(tableName);
var s = _createFilterSelect();
if (!isSort)
s.onchange =  function() { updateFields(tableName, this, null, null, extendedFields); };
else
s.onchange =  function() { updateSortFields(tableName, this); };
var sname = tableName.split(".")[0];
if (fValue)
sname = sname + "." + fValue;
if (isSort) {
addFirstLevelFields(s, sname, fValue, sortByFilter);
} else {
addFirstLevelFields(s, sname, fValue, null);
}
return s;
}
function addOperators(td, type, dValue, isChoice, includeExtended, showDynamicReferenceOperator, filterClass) {
var msg = new GwtMessage();
var s = _createFilterSelect("150");
s.title = 'choose operator';
if (td.parentNode.conditionObject)
if (td.parentNode.conditionObject.isPlaceHolder())
s.disabled = true;
var opers;
if (isChoice)
opers = sysopers[type + "_choice"];
if (!opers && sysopers[type])
opers = sysopers[type];
if (type && type.indexOf(':') > 0) {
var complexTypeArray = type.split(':');
if(null != complexTypeArray[0])
opers = sysopers[complexTypeArray[0]];
}
var translated = type == 'translated_field' || type == 'translated_html' || type == 'translated_text';
if (translated == true && (g_lang != 'en' || g_system_lang != 'en') ) {
opers = sysopers['cons_translated'];
}
if (!opers)
opers = sysopers['default'];
if (noOps)
dValue = '=';
if (filterClass ==  "GlideTemplateFilter") {
opers = sysopers_template['default'];
}
var keys = buildMap(opers, 1);
map = msg.getMessages(keys);
for(var ii=0; ii < opers.length; ii++) {
var opInfo = opers[ii];
if (opInfo[0] == 'SINCE') {
var base = new GlideRecord('cmdb_baseline');
base.query();
if (!base.hasNext())
continue;
}
if (extopers[opInfo[0]] && !includeExtended[opInfo[0]])
continue;
if (opInfo[0] == "DYNAMIC" && !showDynamicReferenceOperator)
continue;
addOption(s, opInfo[0], map[opInfo[1]], dValue && opInfo[0] == dValue);
}
var so = getSelectedOption(s);
if (dValue && (!so || so.value != dValue)) {
addOption(s, dValue, msg.getMessage(dValue));
s.selectedIndex = s.length - 1;
}
td.fieldType = "select";
if (so)
td.currentOper = getSelectedOption(s).value;
td.subType = type;
td.appendChild(s);
return s;
}
function addChoices(response, args) {
if (!response)
return;
xml = response.responseXML;
var msg = new GwtMessage();
var input = args[0];
var dValue = args[1];
var defaultSelected = new Object();
input.title = 'choose value';
if (input.multiple == true) {
var na = dValue.split(",");
for(var i = 0; i < na.length; i++) {
var str = na[i];
defaultSelected[str] = str;
}
} else {
defaultSelected[dValue] = dValue;
}
input.options.length = 0;
if (xml) {
var items = xml.getElementsByTagName("item");
var addNone = true;
for (var i = 0; i < items.length; i++) {
var item = items[i];
if (item.getAttribute("value") == '' && item.getAttribute("label") == msg.getMessage('-- None --'))
addNone = false;
}
if (addNone)
addOption(input, '', msg.getMessage('-- None --'), false);
for (var i = 0; i < items.length; i++) {
var item = items[i];
var v = item.getAttribute("value");
var l = item.getAttribute("label");
addOption(input, v, l, defaultSelected[v]);
}
}
}
function buildMap(values, position) {
var map = new Object();
var keys = new Array();
for (var i=0; i < values.length; i++) {
var thisOp = values[i];
var thisMsg = thisOp[position];
keys.push(thisMsg);
}
return keys;
}
function resetFilters() {
var t = getThing(currentTable,'gcond_filters');
clearNodes(t);
}
function columnRequest(evt, x) {
resetFilters();
if (evt) {
if (x) {
if (x && x.options)
g_filter_description.setMainFilterTable(getSelectedOption(x).value);
} else
g_filter_description.setMainFilterTable(getValue(evt));
}
if (g_filter_description.getMainFilterTable() == null || g_filter_description.getMainFilterTable() == "") {
columns = null;
return;
}
queueTables[g_filter_description.getMainFilterTable()] = g_filter_description.getMainFilterTable();
queueFilters[g_filter_description.getMainFilterTable()] = null;
currentTable = g_filter_description.getMainFilterTable();
args = new Array(g_filter_description.getMainFilterTable());
if (x) {
conditionColumnResponse(evt, args);
} else {
columnsGet(g_filter_description.getMainFilterTable());
}
}
function processQueue() {
var x = queueTables;
for (var i in x)
{
if (queueColumns[i] == null) {
queueColumns[i] = "requested";
columnsGet(x[i], processQueue);
}
}
}
function columnsGetWithFilter(mft, filter, nu) {
queueFilters[mft] = filter;
queueTables[mft] = mft;
columnsGet(mft, nu);
}
function columnsGet(mft, nu) {
loadFilterTableReference(mft);
conditionColumnResponse(columns, mft, nu);
}
function loadFilterTableReference(mft) {
var tablepart = mft.split(".")[0];
currentTable = mft;
if (typeof g_filter_description != 'undefined')
if (g_filter_description.getMainFilterTable() == null || g_filter_description.getMainFilterTable() == "")
g_filter_description.setMainFilterTable(mft);
var tableDef = getTableReference(tablepart);
var columns = tableDef.getColumns();
queueColumns[mft] = columns;
queueColumns[tablepart] = columns;
return tableDef;
}
function getTableReference(tableName, parentTable) {
if (firstTable == '')
firstTable = tableName;
return Table.get(tableName, parentTable);
}
function choicesGet(tableField, input, dValue) {
var ajax = new GlideAjax('PickList');
ajax.addParam('sysparm_chars', '*');
ajax.addParam('sysparm_nomax', 'true');
ajax.addParam('sysparm_name', tableField);
ajax.getXML(addChoices, null, new Array(input, dValue));
}
function conditionColumnResponse(columns, tableName, mfunc) {
decodeFilter(tableName);
queueFilters[tableName] = null;
seeIfItHasFilters(tableName);
if (mfunc && (typeof mfunc != "undefined") && mfunc != "undefined") {
mfunc(tableName);
}
}
function decodeFilter(tableName) {
currentTable = tableName;
var query = queueFilters[tableName];
queueFilters[tableName] = null;
var fDiv = getThing(tableName,'gcond_filters');
if (query == null) {
query = fDiv.initialQuery;
if (query != null && fDiv.filterObject != null) {
var fo = fDiv.filterObject;
if (fo.isQueryProcessed())
return;
}
}
var runable = false;
var defaultPH = true;
var filterObject = fDiv.filterObject;
if (filterObject) {
runable = filterObject.isRunable();
defaultPH = filterObject.defaultPlaceHolder;
}
var filterObject = new GlideFilter(tableName);
filterObject.setRunable(runable);
filterObject.setDefaultPlaceHolder(defaultPH);
filterObject.setQuery(query);
}
function slushbucketDOMcheck() {
var epObject;
if(epObject= gel("ep")) {
var tdArr = epObject.getElementsByTagName("TD");
for(var tdArrIndex = 0;
tdArrIndex < tdArr.length;
tdArrIndex++) {
if (tdArr[tdArrIndex].className == "slushbody")
return true;
}
}
return false;
}
function listDOMcheck(el) {
while (el) {
el = findParentByTag(el, "div");
if (!el)
return null;
if (el.id.endsWith(MAIN_LAYER))
return el.id.substring(0, el.id.length - MAIN_LAYER.length);
}
return null;
}
function enterKey(event) {
if (event.keyCode == 13 || event.keyCode == 3) {
var timeout;
if (slushbucketDOMcheck()) {
var elem = Event.element(getEvent(event)).up(".list_name");
if (elem && elem.getAttribute) {
var name = elem.getAttribute("name");
if (name)
timeout = name + "acRequest();";
}
if (!timeout)
timeout = "acRequest();";
} else {
var name = listDOMcheck(Event.element(getEvent(event)));
if (name)
timeout = "runFilter('" + name + "');";
}
if (timeout)
setTimeout(timeout, 0);
Event.stop(event);
return false;
}
return true;
}
function _createFilterSelect(width, multi, size) {
var s = cel('select');
s.className = "filerTableSelect form-control";
s.title = "choose input";
if (width)
s.style.width = width + "px";
if (multi)
s.multiple = true;
s.size = size || 1;
s.valign = "top";
s.style.verticalAlign="top";
return s;
}
function _createFilterSelectForType(type, val) {
var s = _createFilterSelect();
for (var i = 0; i < sysvalues[type].length; i++) {
var opInfo = sysvalues[type][i];
addOption(s, opInfo[0], opInfo[1], val && opInfo[0] == val);
}
return s;
}
function isTemplate(tableNameFull) {
return (tableNameFull.endsWith(".template"));
}
;
/*! RESOURCE: /scripts/popups.js */
var popupCurrent = null;
var lastMouseX;
var lastMouseY;
if (window.opener && !window.opener.closed && window.opener != window.self) {
Event.observe(window, 'beforeunload', function () {
if (window.opener && !window.opener.closed && window.opener.popupCurrent && window.opener.popupCurrent == window.self)
window.opener.popupCurrent = null;
});
}
function popupClose() {
if (!popupCurrent)
return;
try {
if (!popupCurrent.closed)
popupCurrent.close();
} catch (e) {
}
popupCurrent = null;
}
function mousePositionSave(e) {
if (navigator.appName.indexOf("Microsoft") != -1)
e = window.event;
lastMouseX = e.screenX;
lastMouseY = e.screenY;
}
function imageListOpen(elementName, img_dirs, ignore, name) {
var url = new GlideURL("image_picker.do");
url.addParam("sysparm_element", elementName);
url.addParam("sysparm_img_dirs", img_dirs);
url.addParam("sysparm_ignore", ignore);
url.addParam("sysparm_name", name || "");
popupOpenStandard(url.getURL(), "imagepicker");
}
function imageBrowseOpen(elementName, directory, name, color, icon) {
if (!color)
color = "color-normal";
var url = new GlideURL("icon_browse.do");
url.addParam("sysparm_dir", directory);
url.addParam("sysparm_name", name || "");
url.addParam("sysparm_element", elementName);
url.addParam("sysparm_color", color);
url.addParam("sysparm_icon", icon);
popupOpenStandard(url.getURL(), "imagepicker");
}
var g_IconBrowseHelpers = {
getIconColor : function(){
var spanElem = jQuery("span.bookmark_image");
if (spanElem.length) {
var color = jQuery.grep(spanElem.prop('class').split(" "), function (v) {
return v.indexOf('color-') === 0;
});
return color.length ? color[0] : '';
}
},
getIcon : function(){
var spanElem = jQuery("span.bookmark_image");
if (spanElem.length) {
var fontIcon = jQuery.grep(spanElem.prop('class').split(" "), function (v) {
return v.indexOf('icon-') === 0;
});
return fontIcon.length ? fontIcon[0] : '';
}
}
};
function imageListPick(elementName, value) {
var element = document.getElementById(elementName);
if (element.nodeName == "IMG" || element.nodeName == "INPUT") {
var imgel = document.getElementById("img." + elementName);
element.value = value;
if (element['onchange'])
element.onchange();
if (imgel != null) {
if (value && value.length > 0)
imgel.src = value;
else
imgel.src = "images/s.gifx";
}
} else {
element.className = "";
element.className = "image-browse-icon " + value;
}
popupClose();
return false;
}
function reflistOpen(target, elementName, refTableName, dependent, useQBE, refQualElements, additionalQual, parentID, forceReference){
var url = reflistOpenUrl(target, target, elementName, refTableName, dependent, useQBE, refQualElements, additionalQual, parentID, forceReference);
popupOpenStandard(url, "lookup");
}
function reflistOpenUrl(target, targetElementID, elementName, refTableName, dependent, useQBE, refQualElements, additionalQual, parentID, forceReference) {
var url;
if (useQBE == 'true')
url = new GlideURL(refTableName + '_search.do');
else
url = new GlideURL(refTableName + '_list.do');
url.addParam("sysparm_target", target);
var et = gel(targetElementID);
if (et)
url.addParam("sysparm_target_value", et.value);
var dspEl = gel("sys_display." + targetElementID);
if (dspEl && !et.value)
url.addParam("sysparm_reference_value", dspEl.value);
url.addParam("sysparm_nameofstack", "reflist");
url.addParam("sysparm_clear_stack", "true");
url.addParam("sysparm_element", elementName);
url.addParam("sysparm_reference", refTableName);
url.addParam("sysparm_view", "sys_ref_list");
url.addParam("sysparm_additional_qual", additionalQual);
if (parentID != null && parentID != '')
url.addParam("sysparm_parent_id", parentID);
if(forceReference)
url.addParam("sysparm_force_ref", "true");
var v = getDependentValue(target, dependent);
if (v != null)
url.addParam("sysparm_dependent", v);
var refQual = getRefQualURI(target, refQualElements);
return url.getURL() + refQual;
}
function emailClientOpen(e, table, row, rows) {
var query = e.getAttribute("query");
var addOn = '&sysparm_record_row=' + row + '&sysparm_record_rows=' + rows + '&sysparm_record_list=' + encodeURIComponent(query);
emailClientOpenPop(table, false, null, null, addOn);
}
function showPopupLiveFeedList(sysId, table) {
var box = GlideBox.get('showLiveFeed');
if (box)
box.close(0);
var iframe_src = 'show_live_feed.do?sysparm_stack=no&sysparm_sys_id=' + sysId + '&sysparm_table=' + table;
box = new GlideBox({
id : 'showLiveFeed',
iframe : iframe_src,
width : 600,
height : "95%",
title : "Live Feed",
noTitle : true
});
box.render();
var g_feedResizer;
Event.observe(window, 'resize', function() {
g_feedResizer = setTimeout(function() {
box.autoPosition();
box.autoDimension();
}, 50);
});
}
function emailClientOpenPop(table, immediate, replyType, replyID, addOn) {
var id = document.getElementsByName("sys_uniqueValue")[0];
if (!id)
return;
var url = new GlideURL("email_client.do");
url.addParam("sysparm_table", table);
url.addParam("sysparm_sys_id", id.value);
url.addParam("sysparm_target", table);
if (replyType != null) {
url.addParam("replytype", replyType);
url.addParam("replyid", replyID);
}
popupOpenEmailClient(url.getURL() + g_form.serializeChangedAll());
}
function reflistPick(elementName, value, display) {
"use strict";
var listName = "select_0" + elementName;
var list = $(listName);
if (list) {
addGlideListChoice(listName, value, display, true);
popupClose();
return false;
}
if (gel("sys_display.LIST_EDIT_" + elementName))
elementName = "LIST_EDIT_" + elementName;
var element = $("sys_display." + elementName);
if (element && element.onRefPick)
element.onRefPick(element);
if (element && element.ac && typeof(element.ac.referenceSelect) == "function") {
element.ac.referenceSelectTimeout(value, display);
popupClose();
return;
}
var elementActual = $(elementName);
elementActual.value = value;
element = $("sys_display." + elementName);
element.value = display;
if (typeof(elementActual.onchange) == "function")
elementActual.onchange();
if (typeof(element.onchange) == "function")
element.onchange();
var eDep = element;
var itemName = eDep.getAttribute("function");
if (itemName != null) {
eval(itemName);
}
element = document.getElementsByName("sys_select." + elementName)[0];
if (element != null) {
var options = element.options;
var optionFound = false;
for (var i=0; i < options.length; i++) {
var option = options[i];
option.selected = false;
var o = option.value;
if (o == value ) {
option.selected = true;
optionFound = true;
}
}
if (!optionFound) {
element.selectedIndex = -1;
var opt = document.createElement("option");
opt.value = value;
opt.appendChild(document.createTextNode(display));
opt.selected = true;
element.appendChild(opt);
var options = element.options;
element.selectedIndex = options.length-1;
element.disabled = true;
element.disabled = false;
}
element.onchange();
} else {
var fcs = "updateRelatedGivenNameAndValue('" + elementName + "','" + value + "');";
setTimeout(fcs, 0);
}
popupClose();
return false;
}
function picklistOpen(baseURL, width, modified, searchParam, target, dependent) {
if (modified == '1')
baseURL = baseURL + searchParam;
baseURL += getDependent(target, dependent);
popupOpenStandard(baseURL, "lookup");
}
function getDependent(target, dependent){
var value = getDependentValue(target, dependent);
if (value == null)
return "";
return "&sysparm_dependent=" + encodeURIComponent(value);
}
function getDependentValue(target, dependent) {
if (dependent == null)
return null;
var table = target.split('.')[0];
var tfield = dependent.split(',')[0];
var elname = table + '.' + tfield;
if (tfield == 'sys_id') {
tfield = 'sys_uniquevalue';
elname = 'sys_uniquevalue';
}
var el = document.getElementsByName(elname)[0];
if (el == null)
return null;
var selectValue = "";
if (el.tagName == "INPUT")
var selectValue = el.value;
else
selectValue = el.options[el.selectedIndex].value;
return selectValue;
}
function getRefQualURI(target, refQualElements) {
if (!refQualElements || typeof g_form == "undefined")
return "";
var aj = new GlideAjax("FormStateAjax");
aj.addEncodedString(g_form.serialize());
aj.getXMLWait();
return "&sysparm_client_record=session";
}
function picklistPick(elementName, value) {
var element = document.getElementsByName(elementName)[0];
element.value = value;
if (element["onchange"]) {
element.onchange();
}
element.value = replaceRegEx(element.value, document, elementName);
popupClose();
return false;
}
function popupOpenStandard(url, name) {
var width = document.documentElement.getAttribute('data-doctype') == 'true' ? 800 : 700;
var height = 480;
var features = "width="+ width +",height="+ height +",toolbar=no,status=no,directories=no,menubar=no,resizable=yes,scrollbars=1";
popupOpen(url, name, width, height, features, true );
}
function popupOpenEmailClient(url) {
var width = 875;
var height = 575;
var features = "width="+ width +",height="+ height +",toolbar=no,status=no,directories=no,menubar=no,resizable=yes,scrollbars=1";
popupOpenFocus(url, "Email_Client", width, height, features, false, false );
}
function popupOpen(url, name, pWidth, pHeight, features, snapToLastMousePosition) {
popupOpenFocus (url, name, pWidth, pHeight, features, snapToLastMousePosition, true);
}
function popupOpenFocus(url, name, pWidth, pHeight, features, snapToLastMousePosition, closeOnLoseFocus) {
popupClose();
if (url.indexOf("?") != -1)
url += "&";
else
url += "?";
url += "sysparm_domain_restore=false";
var domain = gel("sysparm_domain");
if (domain)
url += "&sysparm_domain=" + domain.value;
if (url.indexOf("sysparm_nameofstack") == -1)
url += "&sysparm_stack=no";
if (snapToLastMousePosition) {
if (lastMouseX - pWidth < 0) {
lastMouseX = pWidth;
}
if (lastMouseY + pHeight > screen.height) {
lastMouseY -= (lastMouseY + pHeight + 50) - screen.height;
}
lastMouseX -= pWidth;
lastMouseY += 10;
features += ",screenX=" + lastMouseX + ",left=" + lastMouseX + ",screenY=" + lastMouseY + ",top=" + lastMouseY;
}
if (closeOnLoseFocus) {
popupCurrent = window.open(url, name, features, false);
if (!popupCurrent) {
alert('Please disable your popup blocker to use this feature');
return null;
} else {
popupCurrent.focus();
popupCurrent.opener = window.self;
return popupCurrent;
}
} else {
popupCurrent = null;
var win = window.open(url, name, features, false);
if (win) {
win.focus();
win.opener = window.self;
}
return win;
}
}
function xmlView(ref, id) {
var mytable = ref.split('.')[0];
var myfield = ref.substring(mytable.length + 1);
var w = 700;
var h = 500;
var url = new GlideURL(mytable + ".do");
url.addParam("sys_id", id);
url.addParam("sys_target", myfield);
url.addParam("XML", "");
popupOpen(url.getURL(), "xmlview", w, h,
"width="+w+",height="+h+",toolbar=no,status=no,directories=no,menubar=no,resizable=yes,scrollbars=1");
}
function htmlView(ref, id) {
var mytable = ref.split('.')[0];
var myfield = ref.split('.')[1];
var w = 1000;
var h = 500;
var url = new GlideURL("diff_html_page.do");
url.addParam("sysparm_id", id);
url.addParam("sysparm_table", mytable);
popupOpen(url.getURL(), "htmlview", w, h,
"width="+w+",height="+h+",toolbar=no,status=no,directories=no,menubar=no,resizable=yes,scrollbars=1");
}
function tearOffReference(table, fieldName, view, navigate, refKey) {
var widget = gel(fieldName);
if (widget == null) {
alert('Tear off called for a non existent reference field');
return false;
}
var sys_id = widget.value;
if (sys_id == null || sys_id == '') {
alert('Please select a reference before trying to tear it off');
return false;
}
tearOff(table, sys_id, view, navigate, refKey);
}
function tearOff(table, sys_id, view, navigate, refKey) {
var key = sys_id;
var url = new GlideURL(table + '.do');
url.addParam("sys_id", key);
url.addParam("sysparm_view", view);
url.addParam("sysparm_stack", "no");
url.addParam("sysparm_referring_url", "tear_off");
if (refKey)
url.addParam("sysparm_refkey", refKey);
window.open(url.getURL(), "",
"toolbar=no,menubar=no,personalbar=no,width=800,height=600," +
"scrollbars=yes,resizable=yes");
if (navigate) {
gsftSubmit(document.getElementById('sysverb_back'));
}
}
function tearOffAttachment(sys_id) {
var url = new GlideURL("sys_attachment.do");
url.addParam("sysparm_referring_url", "tear_off");
url.addParam("view", "true");
url.addParam("sys_id", sys_id);
window.open(url.getURL(), sys_id,
"toolbar=no,menubar=no,personalbar=no,width=800,height=600," +
"scrollbars=yes,resizable=yes");
}
;
/*! RESOURCE: /scripts/ac.js */
var g_isInternetExplorer = isMSIE;
var KEY_RETURN		= 3;
var KEY_BACKSPACE	= 8;
var KEY_TAB			= 9;
var KEY_ENTER		= 13;
var KEY_PAGEUP		= 33;
var KEY_PAGEDOWN	= 34;
var KEY_END			= 35;
var KEY_HOME		= 36;
var KEY_ARROWLEFT	= 37;
var KEY_ARROWUP		= 38;
var KEY_ARROWRIGHT	= 39;
var KEY_ARROWDOWN	= 40;
var KEY_INSERT		= 45;
var KEY_DELETE		= 46;
var NO_INVISIBLE	= 0;
var itemHeight		= 16;
var ctimeVal;
var TAG_DIV = "div";
var TAG_SPAN = "span";
var ONE_TO_MANY = "OTM";
var g_ac_objects = new Array();
function acKeyDown(evt, elementName, type, dependent) {
var typedChar = getKeyCode(evt);
if (typedChar == KEY_ARROWDOWN || typedChar == KEY_ARROWUP)
fieldChange(evt, elementName, type, dependent);
}
function acKeyUp(evt, elementName, type, dependent) {
var typedChar = getKeyCode(evt);
if (typedChar != KEY_ARROWDOWN && typedChar != KEY_ARROWUP)
fieldChange(evt, elementName, type, dependent);
}
function fieldChange(event, elementName, type, dependent) {
if (document.readyState && document.readyState != "complete") {
jslog("fieldChange delayed due to document not being ready");
return;
}
var table = elementName.split('.')[0];
var additional = null;
if (dependent != null) {
var dparts = dependent.split(",");
var el = document.getElementsByName(table + "." + dparts[0])[0];
if (el != null) {
var selectValue = "";
if (el.tagName == "INPUT") {
var selectValue = el.value;
} else {
selectValue = el.options[el.selectedIndex].value;
}
additional = "sysparm_value=" + selectValue;
}
}
fieldProcess(event, elementName, type, false, true, null, additional);
}
function fieldProcess(evt, elementName, type, noMax, useInvisible, uFieldName, additional, refField) {
var typedChar = getKeyCode(evt);
var evalText = "fieldProcessNow('" + typedChar + "', " +
"'" + elementName + "', " +
"'" + type + "', " +
noMax + ", " +
useInvisible + ", " +
(uFieldName != null ? "'" + uFieldName + "'" : "null") + ", " +
(additional != null ? "\"" + additional + "\"" : "null") + ", " +
(refField != null ? "'" + refField + "'" : "null") +
");";
if (ctimeVal > 0 && typedChar != 0)
clearTimeout(ctimeVal);
var displayField;
var invisibleField;
if (type == "Reference") {
displayField = gel("sys_display." + elementName);
if (useInvisible)
invisibleField = gel(elementName);
} else {
displayField = gel(elementName);
if (useInvisible)
invisibleField = gel("sys_display." + elementName);
}
var updateField;
if (uFieldName != null)
updateField = gel(uFieldName);
var ac = displayField.ac;
if (ac == null) {
ac = getAC(displayField.name);
if (ac == null) {
ac = newAC(displayField, invisibleField, updateField, elementName, type);
if (ac.isOTM())
ac.refField = refField;
}
}
if (typedChar != KEY_TAB) {
ac.fieldChanged = true;
ac.matched = false;
ac.ignoreAJAX = false;
if (ac.type == 'Reference')
ac.dirty = true;
}
var waitTime = 50;
if (typedChar == KEY_ARROWDOWN || typedChar == KEY_ARROWUP || typedChar == NO_INVISIBLE)
waitTime = 0;
ctimeVal = setTimeout(evalText, g_acWaitTime || waitTime);
}
function initAutoCompleteField(ac) {
if (ac.getUpdateField())
return;
Event.observe(ac.getField(), 'blur', fieldBlurred.bind(ac.getField()), false);
setDropDownSizes();
setStyle(ac.getMenu(), "dropDownTableStyle");
window.onresize = setDropDownSizes;
setSavedText(ac, new Array((ac.getInvisibleField() ? ac.getInvisibleField().value : null), ac.getField().value));
var request = new Object();
request.responseXML = new Object();
request.responseXML.ac = ac;
storeResults(ac, "", request);
}
function setDropDownSizes() {
for(var i = 0; i < g_ac_objects.length; i++) {
var ac = g_ac_objects[i];
if (!ac)
continue;
setDropDownSize(ac);
}
}
function setDropDownSize(ac) {
var field = ac.getField();
var mLeft = grabOffsetLeft(field) + "px";
var mTop = grabOffsetTop(field) + (field.offsetHeight - 1) + "px";
var mWidth = estimateWidth(ac) + "px";
var menu = ac.getMenu();
if (menu.offsetWidth > parseInt(mWidth))
mWidth = menu.offsetWidth + "px";
acSetTopLeftWidth(menu.style, mTop, mLeft, mWidth);
var iframe = ac.getIFrame();
if (iframe)
acSetTopLeftWidth(iframe.style, mTop, mLeft, mWidth);
}
function acSetTopLeftWidth(style, top, left, width) {
style.left = left;
style.top = top;
style.width = width;
}
function estimateWidth(ac) {
var field = ac.getField();
if (g_isInternetExplorer)
return field.offsetWidth - (ac.menuBorderSize * 2);
else
return field.offsetWidth;
}
function fieldBlurred() {
var theField = this;
var ac = theField.ac;
ac.ignoreAJAX = true;
var cc = ac.getField().value;
if (cc.indexOf("javascript:") != 0) {
if (ac.type == 'Reference' && ac.matched == false && ac.fieldChanged == true) {
setReferenceField(ac, cc);
}
}
ac.matched = false;
ac.fieldChanged = false;
ac.previousTextValue = '';
checkForDirty(ac);
ac.hideDropDown();
}
function setReferenceField(ac, cc) {
var encodedText = encodeText(cc);
var url = "xmlhttp.do?sysparm_processor=" + ac.type +
"&sysparm_name=" + ac.elementName +
"&sysparm_exact_match=yes" +
"&sysparm_chars=" + encodedText +
"&sysparm_type=" + ac.type;
var response = serverRequestWait(url);
var items = response.responseXML.getElementsByTagName("item");
if (items.length == 1) {
var item = items[0];
var name = trim(item.getAttribute("name"));
var label = trim(item.getAttribute("label"));
ac.getField().value = label;
ac.getInvisibleField().value = name;
} else {
var e = ac.getField();
var f = e.filter;
if (!f || f == '') {
ac.getInvisibleField().value = "x";
ac.getField().value = "";
ac.getInvisibleField().value = "";
}
}
fieldSet(ac);
refFlipImage(ac.getField(), ac.elementName);
ac.dirty = true;
}
function stripNewlines(data) {
var retData = "";
var Ib = "\n\r";
for(var c=0; c < data.length; c++) {
if (Ib.indexOf(data.charAt(c))==-1)
retData += data.charAt(c);
else
retData += " ";
}
return retData;
}
function grabMenuInfo(j) {
var spanTag=j.getElementsByTagName(TAG_SPAN);
var spanInfo = new Array();
if (!spanTag)
return spanInfo;
for(var i = 0; i < spanTag.length; i++) {
var e = spanTag[i];
if ( e.className != "selected_item" )
continue;
var spanData = e.innerHTML;
if ( spanData != "&nbsp;" ) {
spanInfo = new Array(e.gname, stripNewlines(e.glabel));
}
break;
}
return spanInfo;
}
function storeResults(ac, searchString, req) {
ac.resultsStorage[searchString] = req;
}
function retrieveStorage(ac, textStr) {
return ac.resultsStorage[textStr];
}
function storeZeroString(ac, searchString, req) {
ac.emptyResults[searchString] = req;
}
function findRelatedZeroString(ac, searchString) {
for(var str in ac.emptyResults) {
if (searchString.substring(0, str.length) == str) {
return ac.emptyResults[str];
}
}
}
var handleClickedDropDown=function() {
setAllText(this.ac, grabMenuInfo(this));
this.ac.dirty = false;
}
var handleMouseOverDropDown = function() {
setStyle(this,"selectedItemStyle");
}
var handleMouseOutDropDown = function() {
setStyle(this, "nonSelectedItemStyle");
}
function dropDownHilight(ac, direction) {
setTextField(ac, new Array((ac.getInvisibleField() ? ac.savedInvisibleTextValue : null), ac.savedTextValue));
ac.matched = true;
if (!ac.currentMenuItems || ac.currentMenuCount <= 0 )
return;
ac.showDropDown();
var toSelect = ac.selectedItemNum + direction;
if (toSelect >= ac.currentMenuCount)
toSelect = ac.currentMenuCount - 1;
if (ac.selectedItemNum != -1 && toSelect != ac.selectedItemNum) {
setStyle(ac.selectedItemObj,"nonSelectedItemStyle");
ac.selectedItemNum = -1;
}
if (toSelect < 0) {
ac.selectedItemNum = -1;
ac.getField().focus();
return;
}
ac.selectItem(toSelect);
setStyle(ac.selectedItemObj, "selectedItemStyle");
setTextField(ac, grabMenuInfo(ac.selectedItemObj));
ac.dirty = true;
}
function setPreviousText(ac, textArray) {
if (textArray[1] != null)
ac.previousTextValue = textArray[1];
}
function setSavedText(ac, textArray) {
ac.setSavedText(textArray);
}
function setTextValue(ac, textArray) {
ac.textValue = textArray[1].replace(/\r\n/g, "\n");
if (textArray[0] != null && ac.getInvisibleField()) {
ac.invisibleTextValue = textArray[0];
}
}
function setTextField(ac, textArray) {
var f;
if (textArray[0] != null && ac.getInvisibleField()) {
f = ac.getInvisibleField();
f.value = textArray[0];
}
f = ac.getField();
f.value = textArray[1];
fireOnFormat(ac);
}
function setAllText(ac, textArray) {
setSavedText(ac, textArray);
setTextValue(ac, textArray);
setTextField(ac, textArray);
setPreviousText(ac, textArray);
fieldSet(ac);
}
function fieldSet(ac) {
ac.dirty = false;
ac.matched = true;
updateRelated(ac);
fireChange(ac);
fireOnFormat(ac);
}
function fireChange(ac) {
callOnChange(ac.getInvisibleField());
callOnChange(ac.getField());
}
function callOnChange(f) {
if (!f)
return;
if (f["onchange"])
f.onchange();
}
function fireOnFormat(ac) {
var f = ac.getField();
if (f.getAttribute("onformat"))
eval(f.getAttribute("onformat"));
}
function updateRelated(ac) {
var elementName = ac.elementName;
var elementValue = ac.invisibleTextValue;
if (elementValue != '')
updateRelatedGivenNameAndValue(elementName, elementValue);
if (ac["fCall"]) {
var onset = ac["fCall"];
eval(onset);
}
}
function clearRelated(ac) {
var elementName = ac.elementName;
var nodes = document.getElementsByTagName('input');
var sName = elementName+".";
for (var i=0; i<nodes.length; i++ ) {
var current = nodes[i];
var id = current.id;
var index = id.indexOf(sName);
if (index == -1)
continue;
index = id.lastIndexOf(".");
var fName = id.substring(index+1, id.length);
var select = gel(elementName + "." + fName);
if (select != null) {
var x = select.tagName;
if (x == 'select' || x == 'SELECT') {
var selindex = select.selectedIndex;
if (selindex != -1) {
var option = select.options[selindex];
option.selected = false;
}
var options = select.options;
for (oi=0; oi<options.length; oi++) {
var option=options[oi];
var optval = option.value;
if (optval == '') {
option.selected = true;
break;
}
}
}
}
current.value='';
}
}
function setStyle(child, styleName) {
child.className = styleName;
var style = child.style;
var ac = child.ac;
if (styleName == "dropDownTableStyle") {
style.fontSize="13px";
style.fontFamily="arial,sans-serif";
style.wordWrap="break-word";
} else if (styleName == "nonSelectedItemStyle") {
ac.setNonSelectedStyle(child);
} else if (styleName == "selectedItemStyle") {
ac.setSelectedStyle(child);
} else if (styleName == "dropDownRowStyle") {
style.display="block";
style.paddingLeft= 3;
style.paddingRight= 3;
style.height = itemHeight + "px";
style.overflow ="hidden";
style.whiteSpace = "nowrap";
}
}
function createDropDown(ac, foundStrings) {
ac.clearDropDown();
for(var c = 0; c < foundStrings.length; c++) {
var child = createChild(ac, foundStrings[c]);
ac.appendItem(child);
}
setSavedText(ac, new Array((ac.getInvisibleField()? ac.invisibleTextValue : null), ac.textValue));
if ( ac.currentMenuCount != 0 ) {
var height = (itemHeight * ac.currentMenuCount) + 4;
ac.setHeight(height);
}
ac.selectedItemObj = null;
ac.selectedItemNum = -1;
}
function createChild(ac, sa) {
var theDiv = cel(TAG_DIV);
theDiv.ac = ac;
setStyle(theDiv, "nonSelectedItemStyle");
theDiv.onmousedown = handleClickedDropDown;
theDiv.onmouseover = handleMouseOverDropDown;
theDiv.onmouseout = handleMouseOutDropDown;
var menuRow = cel(TAG_SPAN);
setStyle(menuRow, "dropDownRowStyle");
if (false && sa.length == 4) {
var r = cel(TAG_SPAN);
r.innerHTML = sa[3];
menuRow.appendChild(r);
r = cel(TAG_SPAN);
r.innerHTML = "&nbsp;";
menuRow.appendChild(r);
}
var itemInRow = cel(TAG_SPAN);
itemInRow.innerHTML = sa[1].escapeHTML();
itemInRow.gname = sa[0];
if (ac.type == "PickList")
itemInRow.glabel = sa[2];
else
itemInRow.glabel = sa[1];
itemInRow.className = "selected_item";
menuRow.appendChild(itemInRow);
theDiv.appendChild(menuRow);
return theDiv;
}
function encodeText(txt) {
if (encodeURIComponent)
return encodeURIComponent(txt);
if (escape)
return escape(txt);
}
function newAC(fld, invfld, ufld, elementName, type) {
var name = fld.name + "_form";
var ac = new AJAXOtherCompleter(name, elementName);
ac.setType(type);
ac.setField(fld);
ac.setInvisibleField(invfld);
ac.setUpdateField(ufld);
var oCount = g_ac_objects.length;
g_ac_objects[oCount] = ac;
initAutoCompleteField(ac);
ac.firstUse = true;
return ac;
}
function removeAC(name) {
for(var i = 0; i < g_ac_objects.length; i++) {
if (g_ac_objects[i] == null)
continue;
if (g_ac_objects[i].elementName == name)
g_ac_objects[i] = null;
}
}
function getAC(name) {
for(var i = 0; i < g_ac_objects.length; i++) {
if (g_ac_objects[i] == null)
continue;
if (g_ac_objects[i].name == name)
return g_ac_objects[i];
}
return getacPerInput(name);
}
function getacPerInput(elementName) {
var f = gel("sys_display." + elementName);
if (f != null && f.ac != null)
return f.ac;
f = gel(elementName);
if (f != null && f.ac != null)
return f.ac;
return null;
}
function checkEnter(e, elementName) {
var ac = getAC(elementName);
if (ac == null)
return true;
var keyCode = getKeyCode(e);
if (keyCode == KEY_ENTER) {
if (ac.type != 'PickList') {
Event.stop(e);
return false;
}
}
return true;
}
function checkForDirty(ac) {
if (!ac.dirty)
return;
setTextValue(ac, new Array((ac.getInvisibleField() ? ac.getInvisibleField().value : null), ac.getField().value));
fieldSet(ac);
}
function fieldChangeSlush(event, elementName, type, noMax, uFieldName, additional) {
fieldProcess(event, elementName, type, noMax, false, uFieldName, additional);
}
function fieldChangeSlush1(event, elementName, fieldName, type, noMax, uFieldName) {
var filter = getFilter();
displayField = document.getElementsByName(elementName)[0];
displayField.value = filter;
fieldProcess(event, elementName, ONE_TO_MANY, noMax, false, uFieldName, 1, fieldName);
}
function fieldChangeSlush2(event, elementName, fieldName, type, noMax, uFieldName, queryAddOn, additional, fDiv) {
var filter = getFilter(elementName, '', fDiv);
filter += "^" + queryAddOn;
displayField = gel(elementName);
displayField.value = filter;
fieldProcess(event, elementName, ONE_TO_MANY, noMax, false, uFieldName, additional, fieldName);
}
function updateSlushField(ac, values) {
var updateField = ac.getUpdateField();
destroyUpdateField(ac);
if (values != null) {
for(var zi = 0; zi < values.length; zi++) {
updateField.options[zi] = new Option(values[zi][1], values[zi][0]);
}
}
if (updateField["onchange"])
updateField.onchange();
}
function destroyUpdateField(ac) {
ac.getUpdateField().options.length = 0;
}
function getKeyCode(e) {
if (e == null)
return 0;
return g_isInternetExplorer && window.event ? event.keyCode : e.keyCode;
}
function fieldProcessNow(typedChar, elementName, type, noMax, useInvisible, uFieldName, additional, refField) {
var displayField;
var invisibleField;
var updateField;
if (type == "Reference") {
displayField = gel("sys_display." + elementName);
if (useInvisible)
invisibleField = gel(elementName);
} else {
displayField = gel(elementName);
if (useInvisible)
invisibleField = gel("sys_display." + elementName);
}
if (uFieldName != null)
updateField = gel(uFieldName);
var ac = displayField.ac;
if (ac == null) {
ac = getAC(displayField.name);
if (ac == null) {
ac = newAC(displayField, invisibleField, updateField, elementName, type);
if (ac.isOTM())
ac.refField = refField;
}
}
var eDep = displayField;
var itemName = eDep.getAttribute("function");
if (itemName != null)
ac.fCall = itemName;
setTextValue(ac, new Array((invisibleField ? invisibleField.value : null), displayField.value));
if ( typedChar == KEY_TAB )
return;
ac.fieldChanged = true;
if ( typedChar != 0 || updateField || ac.isOTM() ) {
if ( ac.isOTM() || ((typedChar == KEY_ARROWDOWN || typedChar == KEY_ARROWUP) && !updateField )) {
if (ac.isOTM() || !ac.isVisible()) {
if (ac.isOTM())
searchForData(ac, elementName, 'M2MList', noMax, additional);
else
searchForData(ac, elementName, type, noMax, additional);
} else {
ac.showDropDown();
dropDownHilight(ac, typedChar == KEY_ARROWUP ? -1 : 1 );
}
} else {
if (!updateField)
setSavedText(ac, new Array((invisibleField ? ac.invisibleTextValue : null), ac.textValue));
if (typedChar != KEY_ENTER && typedChar != KEY_RETURN) {
if (ac.firstUse || ac.previousTextValue != ac.textValue) {
searchForData(ac, elementName, type, noMax, additional);
ac.firstUse = false;
} else
clearRelated(ac);
} else {
var selectedItemNum = ac.selectedItemNum;
ac.hideDropDown();
if (ac.matched == false && selectedItemNum == -1) {
jslog("Enter hit without matches, ignoring it");
return;
}
fieldSet(ac);
ac.previousTextValue = '';
}
}
}
}
function updateRelatedGivenNameAndValue(elementName, elementValue) {
var viewField = gel("view." + elementName);
if (viewField == null)
return;
if(isDoctype())
viewField.style.display = '';
else
viewField.style.display = "inline";
var viewRField = gel("viewr." + elementName);
var viewHideField = gel("view." + elementName + ".no");
if (viewRField != null) {
if(isDoctype())
viewRField.style.display = '';
else
viewRField.style.display = "inline";
}
if (viewHideField != null)
viewHideField.style.display = "none";
if (typeof(g_form) == 'undefined')
return;
var list = g_form.getDerivedFields(elementName);
if (list == null)
return;
var url = "xmlhttp.do?sysparm_processor=GetReferenceRecord" +
"&sysparm_name=" + elementName +
"&sysparm_value=" + elementValue;
var args = new Array(elementName,list.join(','));
serverRequest(url, refFieldChangeResponse, args);
}
function emptySubstr(ac) {
return findRelatedZeroString(ac, ac.textValue);
}
function searchForData(ac, elementName, type, noMax, additional) {
var cachedData;
if (!additional && !ac.isOTM())
cachedData = retrieveStorage(ac, ac.textValue);
window.status = "Searching for: " + ac.textValue;
if (emptySubstr(ac))
cachedData = emptySubstr(ac);
if (cachedData) {
fieldChangeResponse(cachedData, true);
} else {
var encodedText = encodeText(ac.textValue);
var url = "sysparm_processor=" + type +
"&sysparm_name=" + elementName +
"&sysparm_chars=" + encodedText +
"&sysparm_nomax=" + noMax +
"&sysparm_type=" + type;
if (ac.isOTM())
url += "&sysparm_field=" + ac.refField;
if (additional)
url += "&" + additional;
if (type != "Reference" && typeof(g_form) != "undefined")
url += "&" + g_form.serialize();
serverRequestPost("xmlhttp.do", url, fieldChangeResponse);
var target = ac.getField();
if (target.type != 'hidden' && ac.ignoreAJAX != true)
ac.getField().focus();
}
setPreviousText(ac, new Array(ac.invisibleTextValue, ac.textValue));
}
function fieldChangeResponse(request, nozero) {
if (request == null)
return;
var ac = request.responseXML.ac;
if (request.responseXML.documentElement) {
var xml = request.responseXML;
var items = xml.getElementsByTagName("item");
var e = xml.documentElement;
var elementName = e.getAttribute("sysparm_name");
var searchText = e.getAttribute("sysparm_chars");
var type = e.getAttribute("sysparm_type");
var displayField;
var invisibleField;
if (type == "Reference") {
displayField = gel("sys_display." + elementName);
invisibleField = gel(elementName);
} else {
displayField = gel(elementName);
invisibleField = gel("sys_display." + elementName);
}
var ac = displayField.ac;
if (ac.ignoreAJAX == true)
return;
var values = new Array();
window.status = "Matches" + (searchText? " for " + searchText : "") + ": " + items.length;
if (items.length == 0) {
if (ac.getInvisibleField())
ac.getInvisibleField().value = "";
if (nozero != true)
storeZeroString(ac, searchText, request);
}
if (searchText && ac.textValue && searchText != ac.textValue)
return;
storeResults(ac, (searchText? searchText : ""), request);
for(var iCnt = 0; iCnt < items.length; iCnt++) {
var item = items[iCnt];
var name = item.getAttribute("name");
var label = item.getAttribute("label");
var value = item.getAttribute("value");
var className = item.getAttribute("sys_class_name");
value = replaceRegEx(value, document, elementName.split(".")[0]);
values[values.length] = new Array(name, label, value, className);
}
if (type == "Reference") {
if (items.length == 1 && searchText != null && fieldMatches(searchText, items[0].getAttribute("label"))) {
displayField.value = items[0].getAttribute("label");
invisibleField.value = items[0].getAttribute("name");
fieldSet(ac);
} else {
var viewField = document.getElementById("view." + elementName);
var viewHideField = document.getElementById("view." + elementName + ".no");
if (viewField != null)
viewField.style.display = "none";
if (viewHideField != null)
viewHideField.style.display = "inline";
invisibleField.value = "";
ac.dirty = true;
}
}
if (ac.getUpdateField()) {
updateSlushField(ac, values);
} else {
createDropDown(ac, values);
ac.showDropDown();
}
} else {
window.status = "";
if (ac.getUpdateField())
updateSlushField(ac, null);
else {
clearRelated(ac);
ac.clearDropDown();
}
}
if ( !ac.getUpdateField() && ac.currentMenuCount < 1 )
ac.hideDropDown();
}
function fieldMatches(search, retitem) {
if (search.length >= retitem.length) {
var cc = retitem.substring(0, search.length);
if (search.toLowerCase() == cc.toLowerCase()) {
return true;
}
}
return false;
}
function lightWeightReferenceLink(inputName, tableName) {
if (typeof(g_cart) != 'undefined') {
g_cart.showReferenceForm(inputName, tableName);
return;
}
var input = gel(inputName);
var sys_id = input.value;
var url = tableName + ".do?sys_id=" + sys_id;
var frame = top.gsft_main;
if (!frame)
frame = top;
frame.location = url;
}
function clearDependents(name) {
var nodes = document.getElementsByTagName('input');
for (var i = 0; i < nodes.length; i++ ) {
var current = nodes[i];
var dependentField = current.dependent_field;
if (!dependentField)
continue;
if (name == dependentField) {
current.value = "";
var ac = getAC(current.name);
if (ac) {
ac.resultsStorage = new Object();
ac.emptyResults = new Object();
}
clearDependents(current.id);
}
}
}
;
/*! RESOURCE: /scripts/context_actions.js */
function switchView(type, tableName, viewName) {
ScriptLoader.getScripts('scripts/classes/GlideViewManager.js', function() {
if (type == 'list')
new GlideViewManager(tableName, viewName).refreshList();
else
new GlideViewManager(tableName, viewName).refreshDetail();
})
}
function copyRowToClipboard(base, ref, sysId, view) {
var url = base + "nav_to.do?uri=" + ref + ".do?sys_id=" + sysId;
if (view)
url += "%26sysparm_view=" + view;
copyToClipboard(url);
}
function doUpdate(scope) {
var name = gActiveContext.getTableName();
var temp = name + '_update.do';
var form = getControlForm(name);
var msg = [ 'There are no rows selected', 'Update the entire list?', 'records' ];
var answer = getMessages(msg);
if (scope == 'selected' && getChecked(form) == '') {
alert(answer['There are no rows selected']);
return;
}
form.action = temp;
addInput(form, 'HIDDEN', 'sys_action', 'sysverb_multiple_update');
addInput(form, 'HIDDEN', 'sysparm_multiple', 'true');
addInput(form, 'HIDDEN', 'sysparm_nostack', 'yes');
if (scope == 'selected')
populateParmQuery(form, 'sys_idIN', 'NULL');
else {
if (!confirm(answer['Update the entire list?'] + " ("
+ form.sysparm_total_rows.value + " " + answer['records'] + ")")) {
return;
}
}
form.submit();
}
function contextAction(tableName, actionName) {
var form = getControlForm(tableName);
addInput(form, 'HIDDEN', 'sys_action', actionName);
form.submit();
}
function contextConfirm(tableName, actionName) {
var sysparm_rows = gel('sysparm_total_rows').value;
var num_rows = parseInt(sysparm_rows);
var sysparm_query = gel('sysparm_query');
if (sysparm_query)
sysparm_query = sysparm_query.value;
else
sysparm_query = '';
var sysparm_view = getView(tableName);
if (num_rows < g_export_warn_threshold) {
var dialog = new GwtPollDialog(tableName, sysparm_query, sysparm_rows, sysparm_view, actionName);
dialog.execute();
return;
}
var dialog = new GwtExportScheduleDialog(tableName, sysparm_query, sysparm_rows, sysparm_view, actionName);
dialog.execute();
}
function executeRecentSearch(searchTerm, url) {
parent.document.getElementById('sysparm_search').value = decodeURIComponent(searchTerm);
window.open(url,'gsft_main');
CustomEvent.fire('adjustsearch');
}
function getView(tableName) {
var sysparm_view = '';
if (isReport()) {
var form = getControlForm(tableName);
if (form) {
var temp = form['sysparm_view'];
if (temp)
sysparm_view = temp.value;
}
}
if (sysparm_view != '')
return sysparm_view;
var sp = gel('sysparm_view');
if (sp)
sysparm_view = sp.value;
return sysparm_view;
function isReport() {
var list = gel('reportform_control');
if (list)
return true;
return false;
}
}
function copyToClipboard(str) {
if (ie5) {
var textArea = document.createElement("textarea");
textArea.value = str;
var CopiedText = textArea.createTextRange();
CopiedText.execCommand("copy");
} else {
nonIECopy_clip(str);
}
}
function nonIECopy_clip(meintext) {
prompt("Because of a browser limitation the URL can not be placed directly in the clipboard.  Please use Ctrl-C to copy the data and escape to dismiss this dialog", meintext);
return;
netscape.security.PrivilegeManager.enablePrivilege('UniversalXPConnect');
var clip = Components.classes['@mozilla.org/widget/clipboard;1'].createInstance(Components.interfaces.nsIClipboard);
if (!clip)
return;
var trans = Components.classes['@mozilla.org/widget/transferable;1'].createInstance(Components.interfaces.nsITransferable);
if (!trans)
return;
trans.addDataFlavor('text/unicode');
var str = new Object();
var len = new Object();
var str = Components.classes["@mozilla.org/supports-string;1"].createInstance(Components.interfaces.nsISupportsString);
var copytext=meintext;
str.data=copytext;
trans.setTransferData("text/unicode",str,copytext.length*2);
var clipid=Components.interfaces.nsIClipboard;
if (!clip)
return false;
clip.setData(trans,null,clipid.kGlobalClipboard);
}
function showQuickForm(id, action, width, height) {
var form;
var tableName;
var srcElement;
var keyset;
if (window.lastEvent) {
srcElement = getSrcElement(window.lastEvent);
form = srcElement.form;
if (srcElement.tagName == "SELECT") {
var o = srcElement.options[srcElement.selectedIndex];
tableName = o.getAttribute("table");
} else
tableName = srcElement.getAttribute("table");
if ((action == undefined || action == '') && srcElement.value)
action = srcElement.value;
if (!form)
keyset = g_list.getChecked();
else
keyset = getChecked(form);
window.lastEvent = null;
}
if (tableName == undefined) {
if (typeof(gcm) == 'undefined')
gcm = crumbMenu;
tableName = gcm.getTableName();
form = getFormForList(tableName);
if (typeof(rowSysId) != 'undefined')
keyset = rowSysId;
else
keyset = getChecked(form);
gcm.setFiringObject();
}
if ( (!form && !tableName) || (!tableName && g_list))
return;
if (!keyset || keyset == '') {
alert("No records selected");
return;
}
var gForm = new GlideDialogForm("", tableName+"_update");
if (width && height)
gForm.setDialogSize(width, height);
gForm.addParm('sysparm_view', id);
gForm.setMultiple(form);
gForm.addParm('sysparm_checked_items', "sys_idIN" + keyset);
if (action && action != '')
gForm.addParm('sysparm_action_name', action);
gForm.render();
}
function personalizeResponses(id) {
var parts = id.split('.');
var mytable = parts[0];
var myfield = parts[1];
var myreferurl = document.getElementById('sysparm_this_url_enc');
var url = "response_list.do?sysparm_name=" + mytable +
"&sysparm_element=" + myfield +
"&sysparm_target=" + id +
"&sysparm_view=sys_response_tailor";
if (myreferurl)
url += "&sysparm_referring_url=" + myreferurl.value;
self.location = url;
}
function personalizeChoices(id) {
var mytable = id.split('.')[0];
var mydependent = document.getElementById('ni.dependent_reverse.' + id);
var url = new GlideURL("slushbucket_choice.do");
url.addParam('sysparm_ref', id);
url.addParam('sysparm_form', 'sys_choice');
url.addParam('sysparm_dependent', (mydependent? mydependent.value : ""));
url.addParam('sysparm_stack', 'no');
if (mydependent != null) {
var el = document.getElementsByName(mytable + "." + mydependent.value)[0];
if (el != null) {
var selectValue;
if (el.options)
selectValue = el.options[el.selectedIndex].value;
else
selectValue = el.value;
url.addParam('sysparm_dependent_value', selectValue);
}
}
self.location = url.getURL();
}
function personalizeControl(strIdent, id, query) {
var url = 'sys_ui_list_control.do?sys_id=' + id;
if (query && query != '')
url += "&sysparm_query=" + query;
window.location = url;
}
function personalizer(strIdent, strForm, strSysId) {
if (strIdent == 'auto' && window.$j) {
strIdent = $j('[data-section-id]').first().attr('data-section-id');
}
var parentForm = getControlForm(strIdent);
var form = document.forms['sys_personalize'];
if (parentForm && parentForm['sysparm_collection_relationship'])
addInput(form, 'HIDDEN', 'sysparm_collection_relationship', parentForm['sysparm_collection_relationship'].value);
else
addInput(form, 'HIDDEN', 'sysparm_collection_relationship', '');
addInput(form, 'HIDDEN', 'sysparm_list', strIdent);
addInput(form, 'HIDDEN', 'sysparm_form', strForm);
addInput(form, 'HIDDEN', 'sysparm_sys_id', strSysId);
if (parentForm && parentForm['sysparm_collection'])
addInput(form, 'HIDDEN', 'sysparm_collection', parentForm['sysparm_collection'].value);
var scopeElement = gel('sysparm_domain_scope');
if (scopeElement && scopeElement.value) {
addInput(form, 'HIDDEN', 'sysparm_domain_scope', scopeElement.value);
}
form.submit();
}
function personalizeList(listId, tableName) {
var parentForm = getFormForList(listId);
var form = document.forms['sys_personalize'];
if (parentForm && parentForm['sysparm_collection_relationship'])
addInput(form, 'HIDDEN', 'sysparm_collection_relationship', parentForm['sysparm_collection_relationship'].value);
else
addInput(form, 'HIDDEN', 'sysparm_collection_relationship', '');
addInput(form, 'HIDDEN', 'sysparm_list', tableName);
addInput(form, 'HIDDEN', 'sysparm_form', 'list');
if (parentForm && parentForm['sysparm_collection'])
addInput(form, 'HIDDEN', 'sysparm_collection', parentForm['sysparm_collection'].value);
else
addInput(form, 'HIDDEN', 'sysparm_collection', '');
form.submit();
}
function personalizeField(identifier, formName) {
var form = document.forms['sys_personalize'];
var fields = 'name.element.language';
if (formName && formName.indexOf('sys_dictionary') == 0)
fields = 'name.element';
addQueryFilter(form, fields, identifier, '', formName);
form.action = formName;
form.submit();
}
function personalizeFields(identifier, formName) {
var form = document.forms['sys_personalize'];
addQueryFilter(form, 'name', identifier);
form.action = formName;
form.submit();
}
function personalizeSecurity(identifier, field_name) {
var a = field_name.split('.');
var g_dialog = new GlideDialogWindow('security_mechanic');
g_dialog.setPreference('table_name', a[0]);
g_dialog.setPreference('field_name', a[1]);
g_dialog.setSize(600, '');
g_dialog.setTitle('Security Mechanic');
g_dialog.render();
}
function showDictionary(identifier, field_id) {
var a = field_id.split('.');
var g_dialog = new GlideDialogWindow('dictionary_viewer');
g_dialog.setPreference('table_name', a[0]);
g_dialog.setPreference('field_name', a[1]);
g_dialog.setTitle('Dictionary Info: ' + field_id);
g_dialog.render();
}
function listSecurity(identifier, field_name) {
var form = document.forms['sys_personalize'];
addQueryFilter(form, 'CALCULATED:SecurityQueryCalculator', field_name);
form.action = "sys_security_acl_list.do";
form.submit();
}
function listCollection(coll_table, coll_field, of_table, view_name) {
var form = document.forms['sys_personalize'];
addQueryFilter(form, 'CALCULATED:CollectionQueryCalculator', of_table + ',' + coll_field + ',' + view_name);
addInput(form, 'HIDDEN', 'sysparm_domain_restore', 'false');
form.action = coll_table + "_list.do";
form.submit();
}
function exportToPDF(table, sys_id, isLandscape, sysparm_view){
var relatedListFilters = "";
if (window.g_tabs2List && g_tabs2List.tabIDs) {
var relatedLists = g_tabs2List.tabIDs;
var relatedListCount = relatedLists.length;
if (relatedListCount > 0) {
for (var i = 0; i < relatedListCount; i++) {
var relatedListName = relatedLists[i].substring(0, relatedLists[i].lastIndexOf("_list"));
var filter = getFilter(relatedListName);
if (filter && filter.length > 0) {
if (i == relatedListCount - 1)
relatedListFilters += relatedListName + "=" + encodeURIComponent(encodeURIComponent(filter));
else
relatedListFilters += relatedListName + "=" + encodeURIComponent(encodeURIComponent(filter)) + "^";
}
}
}
}
var url = table + ".do?sys_id=" + sys_id + "&PDF" + "&sysparm_view=" + sysparm_view + "&related_list_filter=" + relatedListFilters;
if (isLandscape)
url += "&landscape=true";
window.location = url;
}
function showList(tableName, fields, ids) {
if (!ids)
ids = gActiveContext.getTableName();
self.location = tableName + "_list.do?sysparm_query=" + addQueryFilter('', fields, ids, tableName);
}
function showItem(tableName, fields, ids, view) {
if (!ids)
ids = gActiveContext.getTableName();
var url = tableName + ".do?sysparm_query=" + addQueryFilter('', fields, ids, tableName);
if (typeof(view) != "undefined") {
url += "&sysparm_view=" + view;
}
self.location = url;
}
function addQueryFilter(form, names, values, table, formName) {
var tableName = table;
if ((names == '' || names == null) || (values == '' || values == null))
return;
if (names.indexOf("CALCULATED") == 0) {
var ec = "";
if (names.indexOf("CollectionQueryCalculator") > 0)
ec = collectionQueryCalculator(values);
else
ec = securityQueryCalculator(values);
addInput(form, "HIDDEN", "sysparm_query", ec);
addInput(form, "HIDDEN", "sysparm_query_encoced", ec);
return;
}
var vNames = names.split(".");
var vValues = values.split(".");
if (names.indexOf("name.element") == 0) {
if (vValues.length > 2) {
var tableElement = TableElement.get(values);
vValues[0] = tableElement.getTableName();
vValues[1] = tableElement.getName();
} else {
var tableR = new Table(vValues[0]);
var element = tableR.getElement(vValues[1]);
var label = '';
if (formName && formName.indexOf("sys_documentation") == 0)
label = getTableLabel(tableR.getName(), element.getName());
if (label == '' && element != null)
vValues[0] = element.getTableName();
}
}
if (names.indexOf("name.element.language") == 0) {
vValues[2] = g_lang;
}
var query = new Array();
for (var i = 0; i < vNames.length; i++) {
if ("sys_choice" == tableName && "name" == vNames[i]) {
query.push("nameINjavascript:getTableExtensions('" + vValues[i] +"')");
}
else if ("sys_ui_style" == tableName && "name" == vNames[i]) {
query.push(buildQueryClause(values.split(".")[0], "name"));
}
else
query.push(vNames[i] + "=" + vValues[i]);
}
if(tableName)
return query.join('^');
addInput(form, "HIDDEN", "sysparm_query", query.join('^'));
addInput(form, "HIDDEN", "sysparm_query_encoded", query.join('^'));
setStack(form);
}
function getTableLabel(tabel, element) {
var ajax = new GlideAjax('ContextActionsAjax');
ajax.addParam("sysparm_name", "getLabel");
ajax.addParam("sysparm_type", tabel);
ajax.addParam("sysparm_value", element);
ajax.getXMLWait();
return ajax.getAnswer();
}
function collectionQueryCalculator(args) {
var sa = args.split(",");
var tableName = sa[0];
var collField = sa[1];
return buildQueryClause(tableName, collField);
}
function buildQueryClause(tableName, collField) {
var tableDef = Table.get(tableName);
var tables = tableDef.getTables();
var result = new Array();
result.push(collField);
result.push("=");
result.push(tableName);
result.push("^OR");
result.push(collField);
result.push("IN");
result.push(tables.join());
return result.join("");
}
function securityQueryCalculator(values) {
var sa = values.split(".");
var fieldName = null;
var element = null;
var tableName = sa[0];
if (sa.length > 1)
fieldName = sa[1];
var allTables = new Array();
var table = new Table(tableName);
if (fieldName == null)
allTables = table.getTables();
else {
allTables.push(tableName);
element = table.getElement(fieldName);
if (element != null && element.getTableName() != tableName)
allTables.push(element.getTableName());
allTables.push("*");
}
var rc = getRules(allTables, fieldName);
return rc;
}
function getRules(allTables, fieldName) {
var rules = null;
if (fieldName == null) {
rules = "name=*^ORnameSTARTSWITH*.";
for ( var i = 0; i < allTables.length; i++)
rules += "^ORname=" + allTables[i] + "^ORnameSTARTSWITH" + allTables[i] + ".";
return rules;
}
var rc = new Array();
for ( var x = 0; x < allTables.length; x++) {
var tableName = allTables[x];
rc.push(tableName);
rc.push(tableName + ".*");
if (fieldName != null)
rc.push(tableName + "." + fieldName);
}
rules = "nameIN" + rc.join();
return rules;
}
function setWatchField(id) {
var ajax = new GlideAjax('ContextActionsAjax');
ajax.addParam("sysparm_name", "setWatchField");
ajax.addParam("sysparm_id", id);
ajax.getXML(function() {CustomEvent.fire('glide_optics_inspect_watchfield', id)});
}
function showWatchField(id) {
var ajax = new GlideAjax('ContextActionsAjax');
ajax.addParam("sysparm_name", "setWatchField");
ajax.addParam("sysparm_id", id);
ajax.getXML(function() {CustomEvent.fire('glide_optics_inspect_show_watchfield', id)});
}
function clearWatchField(id) {
var ajax = new GlideAjax('ContextActionsAjax');
ajax.addParam("sysparm_name", "clearWatchField");
ajax.getXML();
ajax.getXML(function() {CustomEvent.fire('glide_optics_inspect_clear_watchfield', id)});
}
function setStack(form) {
var url = new GlideURL(window.location.href);
var stack = url.getParam('sysparm_nameofstack');
if (stack)
addInput(form, 'HIDDEN', 'sysparm_nameofstack', stack);
}
;
/*! RESOURCE: /scripts/classes/ajax/AJAXCompleter.js */
var AJAXCompleter = Class.create({
KEY_BACKSPACE: 8,
KEY_TAB:       9,
KEY_RETURN:   13,
KEY_ESC:      27,
KEY_LEFT:     37,
KEY_UP:       38,
KEY_RIGHT:    39,
KEY_DOWN:     40,
KEY_DELETE:   46,
KEY_HOME:     36,
KEY_END:      35,
KEY_PAGEUP:   33,
KEY_PAGEDOWN: 34,
initialize: function(name, elementName) {
this.guid = guid();
this.className = "AJAXCompleter";
this.name = name;
this.elementName = elementName;
this.field = null;
this.menuBorderSize = 1;
this.resetSelected();
this.ieIFrameAdjust = 4;
this.initDropDown();
this.initIFrame();
},
initDropDown: function() {
var dd = gel(this.name);
if (!dd) {
dd = cel("div");
dd.id = this.name;
dd.className = "ac_dropdown";
var style = dd.style;
style.border = "black " + this.menuBorderSize + "px solid";
this._setCommonStyles(style);
style.backgroundColor = "white";
style.zIndex = 20000;
}
this.dropDown = $(dd);
addChild(dd);
this.clearDropDown();
this.currentMenuItems = new Array();
this.currentMenuCount = this.currentMenuItems.length;
},
initIFrame: function() {
var iFrame = gel(this.name + "_shim");
if (!iFrame) {
iFrame = cel("iframe");
iFrame.name = this.name + "_shim";
iFrame.scrolling = "no";
iFrame.frameborder = "no";
iFrame.src = "javascript:false;";
iFrame.id = this.name + "_shim";
var style = iFrame.style;
style.height = 0;
this._setCommonStyles(style);
style.zIndex = this.dropDown.style.zIndex - 1;
addChild(iFrame);
}
this.iFrame = $(iFrame);
},
_setCommonStyles: function(style) {
style.padding = 1;
style.visibility = "hidden";
style.display = "none";
style.position = "absolute";
},
setWidth: function(w) {
this.dropDown.style.width = w + "px";
this.iFrame.style.width = w + "px";
},
setHeight: function(height) {
this.dropDown.height = height;
if (g_isInternetExplorer)
height += this.ieIFrameAdjust;
this._setIframeHeight(height);
},
_setIframeHeight: function(height) {
this.iFrame.style.height = height;
},
resetSelected: function() {
this.selectedItemObj = null;
this.selectedItemNum = -1;
},
clearDropDown: function() {
this.hideDropDown();
var dropDown = this.dropDown;
while(dropDown.childNodes.length > 0)
dropDown.removeChild(dropDown.childNodes[0]);
this.currentMenuItems = new Array();
this.currentMenuCount = this.currentMenuItems.length;
this._setInactive();
},
_setActive: function() {
g_active_ac = this;
},
_setInactive: function() {
g_active_ac = null;
},
hideDropDown: function() {
if (this.dropDown.style.visibility == "hidden")
return;
this._showHide("hidden", "none");
this.resetSelected();
},
onDisplayDropDown: function() {
},
showDropDown: function() {
if (this.dropDown.style.visibility == "visible")
return;
this._showHide("visible", "inline");
this.onDisplayDropDown();
},
_showHide: function(type, display) {
this.dropDown.style.visibility = type;
this.iFrame.style.visibility = type;
this.dropDown.style.display = display;
this.iFrame.style.display = display;
},
isVisible: function() {
return this.dropDown.style.visibility == "visible";
},
appendElement: function(element) {
this.getDropDown().appendChild(element);
},
appendItem: function(item) {
this.appendElement(item);
if (this.currentMenuItems == null)
this.currentMenuItems = new Array();
item.acItemNumber = this.currentMenuItems.length;
this.currentMenuItems.push(item);
this.currentMenuCount = this.currentMenuItems.length;
},
selectNext: function() {
var itemNumber = this.selectedItemNum;
if (this.selectedItemNum < this.getMenuCount() - 1)
itemNumber++;
this.setSelection(itemNumber);
},
selectPrevious: function() {
var itemNumber = this.selectedItemNum;
if (this.selectedItemNum <= 0)
return false;
itemNumber--;
this.setSelection(itemNumber);
return true;
},
unsetSelection: function()  {
if (this.selectedItemNum == -1)
return;
this.setNonSelectedStyle(this.selectedItemObj);
this.resetSelected();
},
setSelection: function(itemNumber) {
this.unsetSelection();
this.selectItem(itemNumber);
this.setSelectedStyle(this.selectedItemObj);
},
selectItem: function(itemNumber) {
this.selectedItemNum = itemNumber;
this.selectedItemObj = this.currentMenuItems[itemNumber];
},
getMenuItems: function() {
return this.currentMenuItems;
},
getObject: function(itemNumber) {
return this.currentMenuItems[itemNumber];
},
getSelectedObject: function() {
return this.getObject(this.selectedItemNum);
},
setSelectedStyle: function(element) {
$(element).addClassName("ac_highlight");
if (typeof element.displaySpan != "undefined") {
alert("element.displaySpan.style.color");
element.displaySpan.style.color = "white";
}
},
setNonSelectedStyle: function(element) {
$(element).removeClassName("ac_highlight");
if (element.displaySpan)
element.displaySpan.style.color = "green";
},
setTargetTable: function(targetTable) {
this.targetTable = targetTable;
},
getTargetTable: function() {
return this.targetTable;
},
isPopulated: function() {
return this.getMenuCount() > 0;
},
log: function(msg) {
jslog(this.className + ": " + msg);
},
getIFrame: function() { return this.iFrame; },
getField: function() { return this.field; },
getDropDown: function() { return this.dropDown; },
getMenuCount: function() { return this.currentMenuCount; }
});
;
/*! RESOURCE: /scripts/classes/ajax/AJAXReferenceCompleter.js */
function acReferenceKeyDown(element, evt) {
if (!element.ac)
return true;
return element.ac.keyDown(evt);
}
function acReferenceKeyPress(element, evt) {
if (!element.ac)
return true;
var rv =  element.ac.keyPress(evt);
if (rv == false)
evt.cancelBubble = true;
return rv;
}
function acReferenceKeyUp(element, evt) {
if (!element.ac)
return true;
return element.ac.keyUp(evt);
}
var AJAXReferenceCompleter = Class.create(AJAXCompleter, {
PROCESSOR: "Reference",
initialize: function(element, reference, dependentReference, refQualElements, targetTable, referenceValid) {
AJAXCompleter.prototype.initialize.call(this, 'AC.' + reference, reference);
this.className = "AJAXReferenceCompleter";
this.element = $(element);
this.keyElement = gel(reference);
this.setDependent(dependentReference);
this.setRefQualElements(refQualElements);
this.setTargetTable(targetTable);
this.additionalValues = {};
CustomEvent.observe('domain_scope_changed', this.cacheClear.bind(this));
this._commonSetup();
this.oneMatchSelects = true;
this.clearDerivedFields = true;
this.allowInvalid = this.element.readAttribute('allow_invalid') == 'true';
this.dynamicCreate = this.element.readAttribute('data-ref-dynamic') == 'true';
this.isList = this.element.readAttribute('islist') == 'true';
if (!this.simpleQualifier)
this.refQual = "";
this.isFilterUsingContains = this.element.readAttribute('is_filter_using_contains') == 'true';
this.referenceValid = referenceValid;
},
_commonSetup: function() {
this.element.ac = this;
Event.observe(this.element, 'blur', this.onBlurEvent.bind(this));
Event.observe(this.element, 'focus', this.onFocus.bind(this));
this.saveKeyValue = this.getKeyValue();
this.currentDisplayValue = this.getDisplayValue();
this.searchChars = "";
this.rowCount = 0;
this.ignoreFocusEvent = false;
this.max = 0;
this.cacheClear();
this.hasFocus = true;
this.isResolvingFlag = false;
var f = this.element.readAttribute("function");
if (f)
this.selectionCallBack = f;
addUnloadEvent(this.destroy.bind(this));
this._setUpDocMouseDown();
},
isResolving: function() {
return this.isResolvingFlag;
},
destroy: function() {
this.element = null;
this.keyElement = null;
},
keyDown: function(evt) {
var typedChar = getKeyCode(evt);
if (typedChar == KEY_ARROWUP) {
if( !this.selectPrevious())
this.hideDropDown();
}  else if (typedChar == KEY_ARROWDOWN) {
if (!this.isVisible()) {
if (!this.isPopulated())
return;
this.showDropDown();
}
this.selectNext();
} else if (typedChar == KEY_TAB) {
if (this.hasDropDown() && this.select())
this.clearTimeout();
else
this.onBlur();
}
},
keyUp: function(evt) {
var typedChar = getKeyCode(evt);
if (!this.isDeleteKey(typedChar))
return;
this.clearTimeout();
this.timer = setTimeout(this.ajaxRequest.bind(this), g_acWaitTime || 50);
},
_handleDeleteKey: function() {
},
clearTimeout: function() {
if (this.timer != null)
clearTimeout(this.timer);
this.timer = null;
},
keyPress: function(eventArg) {
var evt = getEvent(eventArg);
var typedChar = getKeyCode(evt);
if (typedChar != KEY_ENTER && typedChar != KEY_RETURN)
this.clearTimeout();
if (this.isNavigation(typedChar))
return true;
if (!evt.shiftKey && (typedChar == KEY_ARROWDOWN || typedChar == KEY_ARROWUP))
return false;
if (this.isDeleteKey(typedChar))
return true;
if (typedChar == KEY_ENTER || typedChar == KEY_RETURN) {
if (this.hasDropDown() && this.select())
this.clearTimeout();
else
this.onBlur();
if (this.enterSubmits) {
this.element.setValue(trim(this.element.getValue()));
return true;
}
return false;
}
if (typedChar == this.KEY_ESC) {
this.clearDropDown();
return false;
}
this.timer = setTimeout(this.ajaxRequest.bind(this), g_acWaitTime || 50);
return true;
},
isNavigation: function(typedChar) {
if (typedChar == this.KEY_TAB)
return true;
if (typedChar == this.KEY_LEFT)
return true;
if (typedChar == this.KEY_RIGHT)
return true;
},
isDeleteKey: function(typedChar) {
if (typedChar == this.KEY_BACKSPACE || typedChar == this.KEY_DELETE)
return true;
},
_getSearchChars: function() {
return this.getDisplayValue();
},
ajaxRequest: function() {
var s = this._getSearchChars();
if (s.length == 0 && !this.isDoctype()) {
this.clearDropDown();
this.searchChars = null;
return;
}
if (s == "*")
return;
this.searchChars = s;
var xml = this.cacheGet(s);
if (xml) {
this.processXML(xml);
return;
}
if (this.cacheEmpty()) {
this.clearDropDown();
this.hideDropDown();
return;
}
var url = "";
url += this.addSysParms();
url += this.addDependentValue();
url += this.addRefQualValues();
url += this.addTargetTable();
url += this.addAdditionalValues();
url += this.addAttributes("ac_");
this.callAjax(url);
},
callAjax: function(url) {
this.isResolvingFlag = true;
var ga = new GlideAjax(this.PROCESSOR);
ga.setQueryString(url);
ga.setErrorCallback(this.errorResponse.bind(this));
ga.getXML(this.ajaxResponse.bind(this), null, null);
},
ajaxResponse: function(response) {
if (!response.responseXML || !response.responseXML.documentElement) {
this.isResolvingFlag = false;
return;
}
var xml = response.responseXML;
var e = xml.documentElement;
var timer = e.getAttribute("sysparm_timer");
if (timer != this.timer)
return;
this.timer = null;
this.clearDropDown();
this.cachePut(this.searchChars, xml);
this.processXML(xml);
this.isResolvingFlag = false;
if (this.onResolveCallback)
this.onResolveCallback();
},
errorResponse: function() {
this.isResolvingFlag = false;
},
processXML: function(xml) {
var e = xml.documentElement;
this._processDoc(e);
var values = this._processItems(xml);
var recents = this._processRecents(xml);
if (!this.hasFocus) {
this._processBlurValue(values, recents);
return;
}
this.createDropDown(values, recents);
},
_processItems: function(xml) {
var items = xml.getElementsByTagName("item");
var values = [];
for(var i = 0; i < items.length; i++) {
var item = items[i];
var array = this.copyAttributes(item);
array['XML'] = item;
values[values.length] = array;
}
return values;
},
_processRecents: function(xml) {
var recents = [];
var items = xml.getElementsByTagName("recent");
for (var i = 0; i < items.length; i++) {
var rec = this.copyAttributes(items[i]);
rec.XML = items[i];
recents.push(rec);
}
return recents;
},
_processBlurValue: function(values, recents) {
this.ignoreFocusEvent = false;
values = values || [];
recents = recents || [];
if (values.length + recents.length === 0 && this.searchChars.length > 0) {
this.setInvalid();
return;
}
if (!this.oneMatchSelects || this.getDisplayValue() === '')
return;
var targetLabel, targetValue;
if (values.length + recents.length == 1) {
var target = recents.length == 1 ? recents[0] : values[0];
targetLabel = target.label;
targetValue = target.name;
}
if (recents[0] && recents[0].label == this.getDisplayValue()) {
var matchesRecent = recents[1] && recents[0].label == recents[1].label;
var matchesValue = values[0] && recents[0].label == values[0].label;
if (!matchesRecent && !matchesValue) {
targetLabel = recents[0].label;
targetValue = recents[0].name;
}
} else if (values[0] && values[0].label == this.getDisplayValue()) {
var matchesSecondValue = values[1] && values[0].label == values[1].label;
if (!matchesSecondValue) {
targetLabel = values[0].label;
targetValue = values[0].name;
}
}
if (targetLabel)
this.referenceSelect(targetValue, targetLabel);
},
_processDoc: function(doc) {
this.rowCount = doc.getAttribute('row_count');
this.max = doc.getAttribute('sysparm_max');
},
addSysParms: function() {
var sp = "sysparm_name=" + this.elementName +
"&sysparm_timer=" + this.timer +
"&sysparm_max=" + this.max +
"&sysparm_chars=" + encodeText(this.searchChars);
if (this.guid)
sp += "&sysparm_completer_id=" + this.guid;
if (this.ignoreRefQual)
sp += "&sysparm_ignore_ref_qual=true";
else if (this.refQual != "" && typeof this.refQual != "undefined")
sp += "&sysparm_ref_qual=" + this.refQual;
var domain = gel("sysparm_domain");
if (domain)
sp += "&sysparm_domain=" + domain.value;
return sp;
},
addTargetTable: function() {
var answer = "";
if (this.getTargetTable()) {
answer = "&sysparm_reference_target=" + this.getTargetTable();
}
return answer;
},
addAdditionalValues: function() {
var answer = "";
for (var n in this.additionalValues)
answer += "&" + n + "=" + encodeText(this.additionalValues[n]);
return answer;
},
addAttributes: function(prefix) {
var answer = "";
var attributes = this.element.attributes;
for (var n = 0; n < attributes.length; n++) {
var attr = attributes[n];
var name = attr.nodeName;
if (name.indexOf(prefix) != 0)
continue;
var v = attr.nodeValue;
answer += "&" + name + "=" + v;
}
return answer;
},
copyAttributes: function(node) {
var attributes = new Array();
for (var n = 0; n < node.attributes.length; n++) {
var attr = node.attributes[n];
var name = attr.nodeName;
var v = attr.nodeValue;
attributes[name] = v;
}
return attributes;
},
createDropDown: function(foundStrings, foundRecents) {
this.clearDropDown();
this.createInnerDropDown();
if (foundRecents && foundRecents.length > 0) {
this._showRecents();
for (var i = 0; i < foundRecents.length; i++) {
var rec = foundRecents[i];
var recchild = this.createChild(rec);
recchild.acItem = rec;
this.appendItem(recchild)
this.addMouseListeners(recchild);
}
}
if (foundStrings && foundStrings.length > 0) {
this._showMax(foundStrings, foundRecents);
for (var c = 0; c < foundStrings.length; c++) {
if (this.max > 0 && c >= this.max)
break;
var x = foundStrings[c];
var child = this.createChild(x);
child.acItem = x;
this.appendItem(child);
this.addMouseListeners(child);
}
}
if (this.currentMenuCount ) {
this.setDropDownSize();
this.showDropDown();
if (isTextDirectionRTL()) {
var diff = parseInt(this.dropDown.style.width) - this.getWidth();
if(diff < 0)
diff = 0;
var w = 0;
if (isMSIE8 || isMSIE7 || isMSIE6 || (isMSIE9 && (getPreference('glide.ui11.use') == "false"))) {
if (typeof g_form != "undefined")
w =  this.element.offsetParent ? this.element.offsetParent.clientWidth : 0;
}
this.dropDown.style.left = (parseInt(this.dropDown.style.left) - diff) + w + "px";
this.iFrame.style.left = (parseInt(this.iFrame.style.left) - diff) + w + "px";
if (parseInt(this.dropDown.style.left) < 0) {
this.dropDown.style.left = 0 + "px";
this.iFrame.style.left = 0 + "px";
}
}
var height = this.dropDown.clientHeight;
this.setHeight(height);
this.firefoxBump();
}
this._setActive();
_frameChanged();
},
createInnerDropDown: function() {
},
_showRecents: function() {
this._addHeaderRow("Recent selections");
},
_showMax: function(foundStrings, foundRecents) {
if (foundRecents && foundRecents.length > 0)
this._addHeaderRow("Search");
},
_addHeaderRow: function(message) {
var row = cel("div");
row.className = "ac_header";
row.setAttribute("width", "100%");
row.innerHTML = new GwtMessage().getMessage(message);
this.appendElement(row);
},
select: function() {
if (this.selectedItemNum < 0)
return false;
var o = this.getSelectedObject().acItem;
this.referenceSelect(o['name'], o['label']);
this.clearDropDown();
return true;
},
_setDisplayValue: function(v) {
var e = this.getDisplayElement();
if (e.value == v)
return;
e.value = v;
},
referenceSelectTimeout: function(sys_id, displayValue) {
this.selectedID = sys_id;
this.selectedDisplayValue = displayValue;
if (typeof reflistModalPick == "function")
this._referenceSelectTimeout();
else
setTimeout(this._referenceSelectTimeout.bind(this), 0);
},
_referenceSelectTimeout: function() {
this.referenceSelect(this.selectedID, this.selectedDisplayValue);
},
referenceSelect: function(sys_id, displayValue, referenceInvalid) {
this._setDisplayValue(displayValue);
var e = this.getKeyElement();
if (e.value != sys_id) {
e.value = sys_id;
callOnChange(e);
}
this.searchChars = displayValue;
this.currentDisplayValue = displayValue;
this.showViewImage();
if (!referenceInvalid)
this.clearInvalid();
this._clearDerivedFields();
if (this.selectionCallBack && sys_id) {
eval(this.selectionCallBack);
}
if (e["filterCallBack"]) {
e.filterCallBack();
}
},
setFilterCallBack: function(f) {
var e = this.getKeyElement();
e["filterCallBack"] = f
},
_clearDerivedFields: function() {
if (this.clearDerivedFields && window['DerivedFields']) {
var df = new DerivedFields(this.keyElement.id);
df.clearRelated();
df.updateRelated(this.getKeyValue());
}
},
showViewImage: function() {
var element = gel("view." + this.keyElement.id);
if (element == null)
return;
var elementR = gel("viewr." + this.keyElement.id);
var noElement = gel("view." + this.keyElement.id + ".no");
var sys_id = this.getKeyValue();
if (sys_id == "") {
hideObject(element);
hideObject(elementR);
showObjectInlineBlock(noElement);
} else {
showObjectInlineBlock(element);
showObjectInlineBlock(elementR);
hideObject(noElement);
}
},
createChild: function(item) {
return this._createChild(item, item['label']);
},
_createChild: function(item, text) {
var div = cel(TAG_DIV);
div.ac = this;
div.acItem = item;
var itemInRow = cel(TAG_SPAN, div);
itemInRow.innerHTML = (text + '').escapeHTML();
return div;
},
addMouseListeners: function(element) {
element.onmousedown = this.onMouseDown.bind(this, element);
element.onmouseup = this.onMouseUp.bind(this, element);
element.onmouseover = this.onMouseOver.bind(this, element);
element.onmouseout = this.onMouseOut.bind(this, element);
},
onMouseUp: function(element) {
this.select();
},
onMouseDown: function(element) {
if (g_isInternetExplorer) {
this.select();
window.event.cancelBubble = true;
window.event.returnValue = false;
setTimeout(this.focus.bind(this), 50);
}
return false;
},
onMouseOut: function(element) {
this.unsetSelection();
},
onMouseOver: function(element) {
this.setSelection(element.acItemNumber);
},
focus: function() {
this.element.focus();
},
setDropDownSize: function() {
var e, mLeft, mTop;
if (window.$j) {
e = $j(this.element);
var offset = e.offset();
var parent = $j(getFormContentParent());
var parentOffset = parent.offset();
var parentScrolltop = parent.css('overflow') == 'visible' ? 0 : parent.scrollTop();
mLeft = offset.left - parentOffset.left + 1 + 'px';
mTop = offset.top - parentOffset.top + 1 + (e.outerHeight() - 1) + parentScrolltop + 'px';
} else {
e = this.element;
mLeft = grabOffsetLeft(e) + "px";
mTop =  grabOffsetTop(e) + (e.offsetHeight - 1) + "px";
}
var mWidth = this.getWidth();
var dd = this.dropDown;
if (dd.offsetWidth > parseInt(mWidth))
mWidth = dd.offsetWidth;
this.setTopLeft(dd.style, mTop, mLeft);
this.setTopLeft(this.iFrame.style, mTop, mLeft);
this.setWidth(mWidth);
},
setTopLeft: function (style, top, left) {
style.left = left;
style.top = top;
},
getWidth: function () {
var field = this.element;
if (g_isInternetExplorer)
return field.offsetWidth - (this.menuBorderSize * 2);
return field.clientWidth;
},
onFocus: function() {
if (this.ignoreFocusEvent)
return;
this.hasFocus = true;
this.currentDisplayValue = this.getDisplayValue();
this._setUpDocMouseDown();
if (this.isDoctype() && this.currentDisplayValue == '')
this.timer = setTimeout(this.ajaxRequest.bind(this), g_acWaitTime || 50);
},
isTablet: function() {
return !(typeof isTablet == "undefined");
},
isDoctype: function() {
return document.documentElement.getAttribute('data-doctype') == 'true';
},
_setUpDocMouseDown: function() {
if (this.isTablet()) {
this.blurPause = true;
this._boundOnDocMouseDown = this.onDocMouseDown.bind(this);
Event.observe(document.body, 'mousedown', this._boundOnDocMouseDown);
}
},
onDocMouseDown: function(evt) {
if (evt.target == this.element)
return;
this.blurPause = false;
},
onBlurEvent: function(evt) {
if (this.isTablet() && this.blurPause == true)
setTimeout(this.onBlur.bind(this), 4000);
else
this.onBlur();
},
onBlur: function() {
if (this._boundOnDocMousedown) {
Event.stopObserving(document.body, 'mousedown', this._boundOnDocMouseDown);
delete this._boundOnDocMouseDown;
}
this.hasFocus = false;
if (this.getDisplayValue().length == 0) {
if (this.currentDisplayValue != "") {
if (!this.isList)
this.referenceSelect("", "");
} else {
this.clearInvalid();
}
} else if (this.selectedItemNum > -1) {
this.select();
} else if ((this.getKeyValue() == "") || (this.currentDisplayValue != this.getDisplayValue())) {
if (!this.isFilterUsingContains) {
var refInvalid = true;
if (this.isExactMatch()) {
if (this.oneMatchSelects != false) {
var o = this.getObject(0).acItem;
this.referenceSelect(o['name'], o['label']);
refInvalid = false;
}
}
if (refInvalid)
this.setInvalid();
if (refInvalid || !this.isPopulated()) {
this.clearTimeout();
this.searchChars = null;
this.ignoreFocusEvent = true;
this.timer = setTimeout(this.ajaxRequest.bind(this), 0);
}
}
}
this.clearDropDown();
},
isExactMatch: function() {
if (this.isPopulated()) {
if (this.getMenuCount() == 1) {
var o0 = this.getObject(0).acItem;
if ((o0['label'].toUpperCase().startsWith(this.getDisplayValue().toUpperCase())))
return true;
return false;
}
var o0 = this.getObject(0).acItem;
var o1 = this.getObject(1).acItem;
if ((o0['label'] == this.getDisplayValue()) && (o1['label'] != this.getDisplayValue()))
return true;
}
},
getDisplayValue: function() {
return this.getDisplayElement().value;
},
getKeyValue: function() {
return this.getKeyElement().value;
},
clearKeyValue: function() {
this.referenceSelect("", this.getDisplayValue());
},
getKeyElement: function() {
return this.keyElement;
},
getDisplayElement: function() {
return this.element;
},
setResolveCallback: function(f) {
this.onResolveCallback = f;
},
setDependent: function(dependentReference) {
this.dependentReference = dependentReference;
var el = this.getDependentElement();
if (!el)
return;
var n = dependentReference.replace(/\./, "_");
n = this.getTableName() + "_" + n;
var h = new GlideEventHandler('onChange_' + n, this.onDependentChange.bind(this), dependentReference);
g_event_handlers.push(h);
},
onDependentChange: function() {
this.cacheClear();
},
getDependentElement: function() {
if (!this.dependentReference || 'null' == this.dependentReference)
return null;
var table = this.getTableName();
var dparts = this.dependentReference.split(",");
return gel(table + "." + dparts[0]);
},
addDependentValue: function() {
var el = this.getDependentElement();
if (!el)
return "";
var depValue = "";
if (el.tagName == "INPUT")
depValue = el.value;
else
depValue = el.options[el.selectedIndex].value;
return "&sysparm_value=" + depValue;
},
setRefQualElements: function(elements) {
this.simpleQualifier = false;
if (!elements)
this.refQualElements = null;
else {
if (elements.startsWith("QUERY:")) {
this.setRefQual(elements.substring(6));
this.simpleQualifier = true;
return;
}
var tableDot = g_form.getTableName() + '.';
this.refQualElements = [];
var a = elements.split(';');
if (a == "*") {
a = [];
var form = gel(tableDot + 'do');
var elements = Form.getElements(form);
for (var i = 0; i < elements.length; i++) {
if ((elements[i].id != this.keyElement.id) && (elements[i].id.startsWith(tableDot)))
a.push(elements[i].id);
}
}
for (var i = 0; i < a.length; i++) {
var n = a[i];
var el = gel(n);
if (!el)
continue;
this.refQualElements.push(n);
var h = new GlideEventHandler('onChange_' + n.replace(/\./, "_"), this.onDependentChange.bind(this), a[i]);
g_event_handlers.push(h);
}
}
},
setRefQual: function(refQual) {
this.refQual = refQual;
},
setIgnoreRefQual: function(ignoreRefQual) {
this.ignoreRefQual = ignoreRefQual;
},
addRefQualValues: function() {
if (this.refQualElements) {
return "&" + g_form.serializeChanged();
} else
return "";
},
setAdditionalValue: function(name, value) {
this.additionalValues[name] = value;
},
getTableName: function() {
return this.elementName.split('.')[0];
},
setInvalid: function() {
this.messages = new GwtMessage().getMessages(
["A new record with this value will be created automatically", "Invalid reference"]);
this.referenceValid = false;
if (this.dynamicCreate) {
this.getDisplayElement().title = this.messages["A new record with this value will be created automatically"];
addClassName(this.getDisplayElement(), "ref_dynamic");
} else {
this.getDisplayElement().title = this.messages["Invalid reference"];
addClassName(this.getDisplayElement(), "ref_invalid");
}
if (!this.allowInvalid && !this.isList) {
this.getKeyElement().value = "";
}
this.showViewImage();
var e = this.getKeyElement();
callOnChange(e);
},
clearInvalid: function() {
this.referenceValid = true;
if (this.dynamicCreate) {
removeClassName(this.getDisplayElement(), "ref_dynamic");
} else {
removeClassName(this.getDisplayElement(), "ref_invalid");
}
this.getDisplayElement().title = "";
},
isReferenceValid: function() {
return this.referenceValid;
},
firefoxBump: function() {
var children = this.getMenuItems();
for(var i = 0 ; i < children.length; i++) {
if (children[i] && children[i].firstChild) {
var dparentDivWidth = children[i].offsetWidth;
var dchildSpanWidth = children[i].firstChild.offsetWidth;
if (dchildSpanWidth > dparentDivWidth)
this.setWidth(dchildSpanWidth);
}
}
},
_setIframeHeight: function(height) {
this.iFrame.style.height = height - 2;
},
hasDropDown:function() {
if (!this.dropDown)
return false;
return this.dropDown.childNodes.length > 0;
},
cachePut: function (name, value) {
if (this.refQualElements)
return;
this.cache[name] = value;
},
cacheGet: function(name) {
if (this.refQualElements)
return;
return this.cache[name];
},
cacheClear: function() {
this.cache = new Object();
},
cacheEmpty: function() {
var s = this.searchChars;
if (!s)
return false;
while (s.length > 2) {
s = s.substring(0, s.length - 1);
var xml = this.cacheGet(s);
if (!xml)
continue;
var e = xml.documentElement;
var rowCount = e.getAttribute('row_count');
if (rowCount == 0)
return true;
break;
}
return false;
}
});
;
/*! RESOURCE: /scripts/classes/ajax/AJAXTableCompleter.js */
var AJAXTableCompleter = Class.create(AJAXReferenceCompleter, {
_processDoc: function(doc) {
AJAXReferenceCompleter.prototype._processDoc.call(this, doc);
this.showDisplayValue = doc.getAttribute('show_display_value');
this.queryType = doc.getAttribute('query_type');
this.queryText = doc.getAttribute('sysparm_chars');
this.columnsSearch = doc.getAttribute('columns_search');
},
appendElement: function(element) {
this.tbody.appendChild(element);
},
createInnerDropDown: function() {
if (this.dropDown.childNodes.length > 0)
return;
this._createTable();
},
createChild: function(item) {
if ( this.currentMenuCount == 0) {
this.createInnerDropDown();
}
var tr = cel("tr");
if (this.showDisplayValue != "false") {
var displayValue = item['label'];
this._createTD(tr, displayValue);
}
this._addColumns(tr, item);
return tr;
},
onDisplayDropDown: function() {
var width = this.table.offsetWidth + 2;
var height = this.table.offsetHeight + 2;
this.getDropDown().style.width = width + "px";
if (!g_isInternetExplorer) {
width = width - 4;
height = height - 4;
}
this.getIFrame().style.width = width + "px";
this.getIFrame().style.height = height + "px";
},
_addColumns: function(tr, item) {
var xml = item["XML"];
var fields = xml.getElementsByTagName("field");
for(var i = 0; i < fields.length; i++) {
var field = fields[i];
var value	 = field.getAttribute("value");
var td = $(this._createTD(tr, value));
if (this.prevText[i] == value)
td.addClassName("ac_additional_repeat");
else
this.prevText[i] = value;
td.addClassName("ac_additional");
}
},
_showMax: function(foundStrings, foundRecents) {
if (!this.rowCount)
return;
var max = 1 * this.max;
var showing = Math.min(foundStrings.length, max);
var recentsLength = foundRecents ? foundRecents.length : 0;
var total = this.rowCount - recentsLength;
var tr = cel("tr");
$(tr).addClassName("ac_header");
var td = cel("td", tr);
td.setAttribute("colSpan", 99);
td.setAttribute("width", "100%");
var a = cel("a", td);
a.onmousedown = this._showAll.bindAsEventListener(this);
var x = "";
if (this.rowCount >= 250)
x = " more than ";
a.innerHTML = new GwtMessage().getMessage("Showing 1 through {0} of {1}", showing, x + total);
this.appendElement(tr);
},
_showRecents: function() {
var tr = cel("tr");
tr.className = "ac_header";
var td = cel("td", tr);
td.setAttribute('colspan', 99);
td.setAttribute("width", "100%");
td.innerHTML = new GwtMessage().getMessage("Recent selections");
this.appendElement(tr);
},
_showAll: function() {
this.clearTimeout();
this.max = this.rowCount;
this.timer = setTimeout(this.ajaxRequest.bind(this), g_key_delay);
},
_createTD: function(tr, text) {
var td = cel("td", tr);
$(td).addClassName("ac_cell");
td.innerHTML = text.escapeHTML();
return td;
},
_createTable: function() {
this.table = cel("table");
$(this.table).addClassName("ac_table_completer");
this.tbody = cel("tbody", this.table);
this.dropDown.appendChild(this.table);
this.prevText = new Object();
}
});
;
/*! RESOURCE: /scripts/AJAXTextSearchCompleter.js */
var AJAXTextSearchCompleter = Class.create(AJAXTableCompleter, {
PROCESSOR: "TSSuggestProcessor",
initialize: function(name, elementName, horizontalAlign, searchContainer) {
AJAXCompleter.prototype.initialize.call(this, name, elementName);
this.className = "AJAXTextSearchCompleter";
this.element = $(elementName);
this.keyElement = this.element;
this.horizontalAlign = horizontalAlign;
this.enterSubmits = true;
this.searchContainer = searchContainer;
this.allowInvalid = true;
this.ieIFrameAdjust = 2;
this.oneMatchSelects = false;
AJAXReferenceCompleter.prototype._commonSetup.call(this);
},
copyAttributes: function(node) {
var text = node.childNodes[0].nodeValue;
var attributes = new Array();
attributes['label'] = text;
attributes['name'] = text;
return attributes;
},
setTopLeft: function (style, top, left) {
if (this.horizontalAlign == "right")
this._rightAlign(style, parseInt(left, 10));
else
style.left = left;
style.top = top;
},
setInvalid: function() {
},
clearInvalid: function() {
},
onDisplayDropDown: function() {
AJAXTableCompleter.prototype.onDisplayDropDown.call(this);
if (this.horizontalAlign == "right") {
var mLeft = grabOffsetLeft(this.element);
var x = this._rightAlign(this.dropDown.style, mLeft);
this.iFrame.style.left = x;
}
},
_rightAlign: function(style, left) {
var containerWidth = this._getContainerWidth();
var dropWidth = this.dropDown.getWidth();
var adjust = 0;
if (isWebKit)
adjust = 2;
this.log("_rightAlign: " + left + "+" + containerWidth + "-" + dropWidth + "-" + adjust);
var x = left + containerWidth - dropWidth - adjust + "px";
style.left = x;
return	x;
},
_createTable: function() {
AJAXTableCompleter.prototype._createTable.call(this);
var tableWidth = this._getContainerWidth();
if (!g_isInternetExplorer)
tableWidth -= 2;
this.table.style.width = tableWidth + "px";
},
_getContainerWidth: function() {
var adjust = 1;
if (!g_isInternetExplorer)
adjust = 2;
var width = 0;
if (this.searchContainer)
width = $(this.searchContainer).getWidth() - adjust;
return width;
}
});
;
/*! RESOURCE: /scripts/classes/GlideWindow.js */
var GlideWindow = Class.create(GwtObservable, {
DEFAULT_BODY: "<center> Loading... <br/><img src='images/ajax-loader.gifx' alt='Loading...' /></center>",
FORWARD_EVENTS: {
"mouseover" : true,
"mouseout" : true,
"mousemove" : true,
"click" : true,
"dblclick" : true,
"keyup" : true,
"mouseenter" : true,
"mouseleave" : true
},
initialize: function(id, readOnly) {
this.id = id;
this.window = null;
this.windowClass = "drag_section_picker";
this.zIndex = 1;
this.position = "absolute";
this.padding = 3;
this.container = null;
this._readOnly = readOnly;
this.preferences = new Object();
this.titleHTML = null;
this.elementToFocus = null;
this.offsetLeft = 0;
this.offsetTop = 0;
this.gd = null;
this.shim = null;
this.valid = true;
this.closeDecoration = null;
this._draw(id);
this.initDecorations();
this.headerWrap = false;
this.setScope("global");
this.doctype = document.documentElement.getAttribute('data-doctype') == 'true';
},
addDecoration: function(decorationElement, leftSide) {
if (leftSide) {
var ld = this.leftDecorations;
ld.style.display = "block";
if (ld.hasChildNodes()) {
ld.insertBefore(decorationElement, ld.childNodes[0].nextSibling);
} else {
ld.appendChild(decorationElement);
}
} else {
if	(this.rightDecorations) {
var rd = this.rightDecorations;
if (rd.hasChildNodes()) {
rd.insertBefore(decorationElement, rd.childNodes[0]);
} else {
rd.appendChild(decorationElement);
}
}
else {
}
}
},
addFunctionDecoration: function(imgSrc, imgAlt, func, side) {
var span = cel('span');
var img = cel("img", span);
img.id = 'popup_close_image';
img.height = "12"
img.width = "13"
img.style.cursor = 'pointer';
img.src = imgSrc;
img.alt = getMessage(imgAlt);
img.gWindow = this;
img.onclick = func;
this.addDecoration(span, side);
img = null;
return span;
},
addHelpDecoration: function(func) {
this.addFunctionDecoration('images/help.gif', 'Help', func);
},
clearLeftDecorations: function() {
clearNodes(this.leftDecorations);
},
clearRightDecorations: function() {
clearNodes(this.rightDecorations);
},
dragging: function(me, x, y) {
x = Math.max(x, 0);
y = Math.max(y, 0);
this.fireEvent("dragging", this);
me.draggable.style.left = x + 'px';
me.draggable.style.top = y + 'px';
this._setShimBounds(x, y, "", "");
},
destroy: function() {
this.fireEvent("beforeclose", this);
if (this.container) {
var parent = this.container.parentNode;
if (parent)
parent.removeChild(this.container);
} else {
var gWindow = this.getWindowDOM();
var parent = gWindow.parentNode;
if (parent)
parent.removeChild(gWindow);
}
this.setShim(false);
if (isMSIE)
this.container.outerHTML = '';
this.release();
this.valid = false;
this.closeDecoration = null;
},
getAbsoluteRect: function(addScroll) {
return getBounds(this.getWindowDOM(), addScroll);
},
getBody: function() {
return this.body;
},
getContainer: function() {
var obj;
if (this.container) {
obj = this.container;
} else {
obj = this.getWindowDOM();
}
return obj;
},
getClassName: function() {
return this.getWindowDOM().className;
},
getDecorations: function(left) {
if (left)
return this.leftDecorations;
return this.rightDecorations;
},
getDescribingXML : function() {
var section = document.createElement("section");
section.setAttribute("name", this.getID());
var preferences = this.getPreferences();
for(var name in preferences) {
var p = document.createElement("preference");
var v = preferences[name];
p.setAttribute("name", name);
if (v != null && typeof v == 'object') {
if (typeof v.join == "function") {
v = v.join(",");
} else if (typeof v.toString == "function") {
v = v.toString();
}
}
if (v && typeof v.escapeHTML === "function")
v = v.escapeHTML();
if (v)
p.setAttribute("value", v);
section.appendChild(p);
}
return section;
},
getDescribingText : function() {
var gxml = document.createElement("gxml");
var x = this.getDescribingXML();
gxml.appendChild(x);
return gxml.innerHTML;
},
getHeader: function() {
return this.header;
},
getID: function() {
return this.id;
},
getPosition: function() {
return this.position;
},
getPreferences : function() {
return this.preferences;
},
getPreference : function(id) {
return this.preferences[id];
},
getTitle: function() {
return this.title;
},
locate: function(domElement) {
while (domElement.parentNode) {
domElement = domElement.parentNode;
if (domElement.gWindow)
return domElement.gWindow;
if (window.$j && $j(domElement).data('gWindow')) {
return $j(domElement).data('gWindow');
}
}
alert('GlideWindow.locate: window not found');
return null;
},
get: function(id) {
if (!id || !gel('window.' + id))
return this;
return gel('window.' + id).gWindow;
},
getWindowDOM: function() {
return this.window;
},
getZIndex: function() {
return this.zIndex;
},
initDecorations: function() {
if (!this.isReadOnly()) {
this.closeDecoration = this.addFunctionDecoration("images/x.gifx", 'Close', this._onCloseClicked.bind(this));
}
},
removeCloseDecoration: function() {
if (this.closeDecoration)
this.closeDecoration.parentNode.removeChild(this.closeDecoration);
this.closeDecoration = null;
},
showCloseOnMouseOver: function() {
Event.observe(this.window, "mouseover", this.showCloseButton.bind(this));
Event.observe(this.window, "mouseout", this.hideCloseButton.bind(this));
this.hideCloseButton();
},
showCloseButton: function() {
if (this.closeDecoration)
this.closeDecoration.style.visibility="visible";
},
hideCloseButton: function() {
if (this.closeDecoration)
this.closeDecoration.style.visibility="hidden";
},
insert: function(element, beforeElement, invisible) {
var id = this.getID();
element = $(element);
var div = $(id);
if (!div) {
var div = cel("div");
div.name = div.id = id;
div.gWindow = this;
div.setAttribute("dragpart", id);
div.className += " drag_section_part";
div.style.position = this.getPosition();
div.style.zIndex = this.getZIndex();
div.style.left = this.offsetLeft + "px";
div.style.top = this.offsetTop + "px";
div.appendChild(this.getWindowDOM());
if (invisible)
div.style.visibility = "hidden";
if (beforeElement)
element.insertBefore(div, beforeElement);
else
element.appendChild(div);
}
this.container = div;
this._enableDragging(div);
},
isActive: function() {
return this.active;
},
isReadOnly: function() {
return this._readOnly;
},
isValid: function() {
return this.valid;
},
moveTo: function(x, y) {
var o = this.getContainer();
o.style.left = x + 'px';
o.style.top = y + 'px';
this._setShimBounds(x, y, "", "");
},
release: function() {
this.window.gWindow = null;
this.window = null;
this.container = null;
this.body = null;
if (this.gd)
this.gd.destroy();
this.title = null;
this.header = null;
this.shim = null;
this.rightDecorations = null;
this.leftDecorations = null;
},
removePreference: function(name, value) {
delete this.preferences[name];
},
render: function() {
var id = this.getID();
var description = this.getDescribingText();
var ajax = new GlideAjax("RenderInfo");
if (this.getPreference("sysparm_scope"))
ajax.setScope(this.getPreference("sysparm_scope"))
ajax.addParam("sysparm_value", description);
ajax.addParam("sysparm_name", id);
ajax.getXML(this._bodyRendered.bind(this));
},
invisible: function() {
var e = this.getContainer();
e.style.visibility = "hidden";
},
visible: function() {
var e = this.getContainer();
e.style.visibility = "visible";
},
setAlt: function(alt) {
this.window.title = alt;
},
setEscapedBody: function(body) {
if (!body)
return;
body = body.replace(/\t/g, "");
body = body.replace(/\r/g, "");
body = body.replace(/\n+/g, "\n");
body = body.replace(/%27/g, "'");
body = body.replace(/%3c/g, "<");
body = body.replace(/%3e/g, ">");
body = body.replace(/&amp;/g, "&");
this.setBody(body, true);
},
setBody: function(html, noEvaluate, setAlt) {
this.body.innerHTML = "";
if (typeof html == 'string') {
var showBody = true;
if (html.length == 0)
showBody = false;
this.showBody(showBody);
html = this._substituteGet(html);
html = this._fixBrowserTags(html);
this.body.innerHTML = html;
if (setAlt)
this.setBodyAlt(html);
if (!noEvaluate)
this._evalScripts(html);
} else {
this.body.appendChild(html);
}
var prefs = this.body.getElementsByTagName("renderpreference");
if (prefs.length > 0) {
for(var i = 0; i < prefs.length; i++) {
var pref = prefs[i];
var name = pref.getAttribute("name");
var valu = pref.getAttribute("value");
if (name == "render_time") {
this.debugTD.innerHTML = valu;
this.debugTD.style.display = "table-cell";
continue;
}
this.setPreference(name, valu);
if (name == "title")
this.setTitle(valu);
if (name == "render_title" && valu == "false")
this.header.style.display = "none";
if (name == "hide_close_decoration" && valu == "true")
this.removeCloseDecoration();
}
}
var decorations = this.body.getElementsByTagName("decoration");
if (decorations.length > 0) {
for (var x = 0; x < decorations.length; x++) {
var thisDecoration = new GlideDecoration(decorations[x]);
thisDecoration.attach(this);
}
}
if (this.elementToFocus) {
if (gel(this.elementToFocus)) {
self.focus();
gel(this.elementToFocus).focus();
}
}
this._shimResize();
},
showBody: function(show) {
if (this.divMode)
var tr = this.body;
else
var tr = this.body.parentNode.parentNode;
if (show)
tr.style.display = "";
else
tr.style.display = "none";
},
setBodyAlt: function(alt) {
this.body.title = alt;
},
setClassName: function(className) {
this.windowClass = className;
if (this.getWindowDOM())
this.getWindowDOM().className = className;
},
setColor: function(color) {
this.windowBackground = color;
if (this.getBody())
this.getBody().parentNode.style.backgroundColor = color;
},
setFocus: function(id) {
this.elementToFocus = id;
},
setFont: function(family, size, fontUnit, weight) {
this.setFontSize(size, fontUnit);
this.setStyle("fontFamily", family);
this.setFontWeight(weight);
},
setFontSize: function(size, fontUnit) {
if (!fontUnit)
fontUnit = "pt";
this.setStyle("fontSize", size + fontUnit);
},
setFontWeight: function(weight) {
this.setStyle("fontWeight", weight);
},
setStyle: function(name, value) {
if (!value)
return;
this.getTitle().style[name] = value;
this.getBody().style[name] = value;
},
setHeaderClassName: function(className) {
this.getHeader().className = className;
},
setHeaderColor: function(background) {
this.header.style.backgroundColor = background;
},
setHeaderColors: function(color, background) {
this.setHeaderColor(background);
this.title.style.color = color;
},
setOpacity: function(opacity) {
if (this.divMode) {
var element = this.getBody().parentNode;
element.style.filter = "alpha(opacity=" + (opacity * 100) + ")";
element.style.MozOpacity = opacity + "";
element.style.opacity = opacity + "";
element.style.opacity = opacity;
}
},
setPreferences : function(preferences) {
this.preferences = preferences;
},
setPreference: function(name, value) {
this.preferences[name] = value;
},
setPosition: function (name) {
if (this.getContainer() != this.getWindowDOM())
this.getContainer().style.position = name;
this.position = name;
},
setReadOnly: function(r) {
this._readOnly = r;
},
setWidth: function(width) {
this.setSize(width, "");
},
getWidth: function() {
if (this.window)
return this.window.clientWidth;
else
return;
},
getHeight: function() {
if (this.window)
return this.window.clientHeight;
},
setSize: function(w, h) {
var obj = this.getContainer();
var bo = this.getBody();
var setWidth = w;
if (!isNaN(setWidth))
setWidth = setWidth + 'px';
bo.style.width = setWidth;
obj.style.width = setWidth;
if (obj != this.window)
this.window.style.width = setWidth;
var setHeight = h;
if (h && !isNaN(setHeight))
setHeight = setHeight + 'px';
if (h && isNaN(setHeight))
obj.style.height = setHeight;
this._setShimBounds("", "", w, h);
},
adjustBodySize: function() {
var obj = this.getContainer();
var bo = this.getBody();
var h = obj.clientHeight;
if ((h - this.header.clientHeight) > 0) {
var headerClientHeight = h - this.header.clientHeight;
bo.style.height = headerClientHeight + 'px';
} else if (!(isMSIE9 && getTopWindow().document.doctype))
bo.style.height = 0;
this.window.style.height = obj.style.height;
},
removeBody: function() {
var element = this.getBody();
element = element.parentNode;
element = element.parentNode;
var tbody = element.parentNode;
tbody.removeChild(element);
},
clearSpacing: function() {
this.window.style.padding = "0px";
this.body.style.padding = "0px";
if (!this.divMode) {
this.window.cellSpacing = 0;
this.window.cellPadding = 0;
}
},
setWindowActive: function() {
this.setHeaderClassName("drag_section_header_active");
this.active = true;
},
setWindowInactive: function() {
this.setHeaderClassName("drag_section_header");
this.active = false;
},
toggleActive: function() {
if (this.active)
this.setWindowInactive();
else
this.setWindowActive();
},
setHeaderWrap: function(wrap) {
this.headerWrap = wrap;
if (wrap)
this.title.style.whiteSpace = "normal";
else
this.title.style.whiteSpace = "nowrap";
},
isHeaderWrap: function() {
return this.headerWrap;
},
setShim: function(b) {
if (!ie5)
return;
if (b == false) {
if (this.shim) {
var parent = this.shim.parentNode;
parent.removeChild(this.shim);
}
} else {
var iframeShim = cel("iframe");
iframeShim.id = iframeShim.name = "iframeDragShim_" + this.id;
iframeShim.src = "blank.do";
iframeShim.style.position = "absolute";
iframeShim.style.top = 0;
iframeShim.style.left = 0;
iframeShim.style.width = 0;
iframeShim.style.height = 0;
iframeShim.frameBorder = 0;
this.container.parentNode.appendChild(iframeShim);
this.shim = iframeShim;
var win = this.getWindowDOM();
Event.observe(win, 'resize', this._shimResize.bind(this));
}
},
setTitle: function(html) {
this.titleValue = html;
if (typeof html == 'string')
this.title.innerHTML = html;
else {
this.title.innerHTML = "";
this.title.appendChild(html || "");
}
},
setTitleAlign: function(align) {
this.title.style["text-align"] = align;
var children = this.title.children;
for (var i = 0; i < children.length; i++) {
children[0].style["text-align"] = align;
}
},
setTitleSize: function(size) {
this.title.style["font-size"] = size;
var children = this.title.children;
for (var i = 0; i < children.length; i++) {
children[0].style["font-size"] = size;
}
},
setTitleFont: function(font) {
this.title.style["font-family"] = font;
var children = this.title.children;
for (var i = 0; i < children.length; i++) {
children[0].style["font-family"] = font;
}
},
setTitleColor: function(color) {
this.title.style.color = color;
var children = this.title.children;
for (var i = 0; i < children.length; i++) {
children[0].style.color = color;
}
},
setBorderVisibility: function(visible) {
var window = this.getWindowDOM();
if (visible !== "false" && visible) {
window.style["border"] = "";
window.style["box-shadow"] = "";
} else {
window.style["border"] = "none";
window.style["box-shadow"] = "none";
}
},
setBorderWidth: function(width) {
this.getWindowDOM().style["border-width"] = width;
},
setBorderColor: function(color) {
this.getWindowDOM().style["border-color"] = color;
},
setHeaderBorderVisibility: function(visible) {
if (visible !== "false" && visible)
this.header.style.border = "solid";
else
this.header.style.border = "none";
},
setHeaderBorderWidth: function(width) {
this.header.style["border-width"] = width;
},
setHeaderBorderColor: function(color) {
this.header.style["border-color"] = color;
},
setHeaderBackgroundColor: function(color) {
this.header.style["background-color"] = color;
},
setTitleVisibility: function(visible) {
if (visible !== "false" && visible)
this.setTitle(this.titleValue);
else
this.title.innerHTML = "";
},
setZIndex: function(i) {
if (this.getContainer() != this.getWindowDOM())
this.getContainer().style.zIndex = i;
this.zIndex = i;
},
on: function(name, func) {
if (this.FORWARD_EVENTS[name])
this.forward(name, this.window, func);
else
GwtObservable.prototype.on.call(this, name, func);
if (name == "dblclick") {
if (isMSIE)
this.window.style.cursor = "hand";
else
this.window.style.cursor = "pointer";
}
},
_bodyRendered: function(request) {
var xml = request.responseXML;
var uid = xml.documentElement.getAttribute("sysparm_name");
var newBody = xml.getElementsByTagName("html")[0];
if (!this.body)
return;
if (newBody.xml) {
xml = newBody.xml;
} else if (window.XMLSerializer) {
xml = (new XMLSerializer()).serializeToString(newBody);
}
if (!xml)
return;
this.setEscapedBody(xml);
this._evalScripts(xml);
this.fireEvent("bodyrendered", this);
_frameChanged();
},
_centerOnScreen: function(width, height) {
var bounds = this.getAbsoluteRect();
var viewport = new WindowSize();
var w = viewport.width;
var h = viewport.height;
var windowWidth = (width? width : bounds.width);
var windowHeight = (height? height: bounds.height);
var scrollX = getScrollX();
if (typeof scrollX == "undefined")
scrollX = 0;
var scrollY = this._getScrollTop();
var leftX = parseInt((w / 2) - (windowWidth / 2)) + scrollX;
var topY = parseInt((h / 2) - (windowHeight / 2)) + scrollY;
var topWindow = getTopWindow();
var browserHeight = topWindow.innerHeight || topWindow.document.documentElement.clientHeight || topWindow.document.body.clientHeight;
if ($(topWindow.document.body).select('table.navpage').length == 0) {
var currentIframe = this._findCurrentIframe(window);
if (currentIframe && currentIframe.getBoundingClientRect) {
var rectTop = parseInt(currentIframe.getBoundingClientRect().top);
var d = h + rectTop;
topY = scrollY;
if (rectTop < 0) {
if (d > browserHeight)
topY += parseInt((browserHeight - windowHeight) / 2) - rectTop;
else
topY += parseInt((d - windowHeight) / 2) - rectTop;
} else {
if (d > browserHeight)
topY += parseInt((browserHeight - rectTop - windowHeight) / 2);
else {
topY += parseInt((h - windowHeight) / 2);
if (scrollY == 0 && (isMSIE6 || isMSIE7 || isMSIE8))
topY += window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
}
}
} else {
if (this.container) {
var containerParentHeight = this.container.parentNode.scrollHeight;
if (containerParentHeight < browserHeight)
topY = parseInt((containerParentHeight - windowHeight) / 2);
else {
if (scrollY == 0 && (isMSIE6 || isMSIE7 || isMSIE8))
topY += topWindow.pageYOffset || topWindow.document.documentElement.scrollTop || topWindow.document.body.scrollTop;
}
}
}
}
if (topY < 0)
topY = 0;
if (leftX < 0)
leftX = 0;
if (this.container) {
var headerSpacer = $(this.container.parentNode).select(".section_header_spacer");
if (headerSpacer.length > 0) {
headerSpacer = headerSpacer[0];
if (topY < headerSpacer.offsetHeight)
topY = headerSpacer.offsetHeight;
}
}
this.moveTo(leftX, topY);
},
_findCurrentIframe: function(win) {
try {
if (win && win.parent) {
var e = win.parent.document.getElementsByTagName('iframe');
for (var i =0; i < e.length; i++) {
if (e[i].contentWindow == win)
return e[i];
}
}
} catch(e) {}
return null;
},
_getScrollTop: function() {
if (this.container.parentNode != document.body)
return this.container.parentNode.scrollTop;
return getScrollY();
},
_draw: function(id) {
var e;
if (this.divMode) {
e = cel("DIV");
e.style.overflow = "hidden";
e.appendChild(this._drawTitle(id));
e.appendChild(this._drawBody(id));
} else {
e = cel("TABLE");
var dragTableBody = cel("TBODY");
dragTableBody.appendChild(this._drawTitle(id));
dragTableBody.appendChild(this._drawBody(id));
e.appendChild(dragTableBody);
}
e.id = "window." + id;
this.window = e;
this.window.className = this.windowClass;
this.window.gWindow = this;
},
_drawTitle: function(id) {
if (!this.divMode) {
var baseTR = cel("TR");
baseTR.style.verticalAlign = "top";
var baseTD = cel("TD");
}
var dragTableHeader = cel("TABLE");
var dragTableHeaderBody = cel("TBODY");
dragTableHeader.className = "drag_section_header";
dragTableHeader.style.width = "100%";
this.header = dragTableHeader;
var dragTableHeaderTR = cel("TR");
var leftDecorations = cel("TD");
leftDecorations.style.display = "none";
leftDecorations.style.top = "0px";
leftDecorations.style.left = "0px";
leftDecorations.style.verticalAlign = "top";
leftDecorations.style.whiteSpace = "nowrap";
this.leftDecorations = leftDecorations;
dragTableHeaderTR.appendChild(leftDecorations);
var dragTableHeaderTD = cel("TD");
dragTableHeaderTD.className = "drag_section_movearea";
dragTableHeaderTD.style.verticalAlign = "top";
dragTableHeaderTD.id = id + "_header";
this.title = dragTableHeaderTD;
dragTableHeaderTR.appendChild(dragTableHeaderTD);
var headerDebugTD = cel("TD");
headerDebugTD.className = "drag_section_debug";
headerDebugTD.id = id + "_debug";
this.debugTD = headerDebugTD;
dragTableHeaderTR.appendChild(headerDebugTD);
var rightDecorations = cel("TD");
rightDecorations.style.top = "0px";
rightDecorations.style.right = "0px";
rightDecorations.style.verticalAlign = "top";
rightDecorations.style.whiteSpace = "nowrap";
rightDecorations.style.textAlign = "right";
this.rightDecorations = rightDecorations;
dragTableHeaderTR.appendChild(rightDecorations);
dragTableHeaderBody.appendChild(dragTableHeaderTR);
dragTableHeader.appendChild(dragTableHeaderBody);
if (!this.divMode) {
baseTD.appendChild(dragTableHeader);
baseTR.appendChild(baseTD);
}
dragTableHeaderTD = null;
dragTableHeaderTR = null;
dragTableHeaderBody = null;
dragTableHeader = null;
leftDecorations = null;
rightDecorations = null;
if (!this.divMode)
return baseTR;
else
return this.header;
},
_drawBody: function(id) {
var e;
if (this.divMode) {
e = cel("DIV");
this.body = e;
} else {
e = cel("TR");
e.style.height = "100%";
e.style.verticalAlign = "top";
var dragTableTD = cel("TD");
this.body = cel("SPAN");
dragTableTD.appendChild(this.body);
e.appendChild(dragTableTD);
}
this.body.id = "body_" + id;
this.body.style.overflow = "auto";
this.body.innerHTML = this.DEFAULT_BODY;
this.body.gWindow = this;
return e;
},
_enableDragging: function(element) {
var id = element.getAttribute("dragpart");
if (!id || this.isReadOnly() || this.getPreference('pinned'))
return;
var titlebar = gel(id + "_header");
this.gd = new GwtDraggable(titlebar, element);
if (typeof this.dragStart == "function")
this.gd.setStart(this.dragStart.bind(this));
if (typeof this.dragEnd == "function")
this.gd.setEnd(this.dragEnd.bind(this));
if (typeof this.dragging == "function")
this.gd.setDrag(this.dragging.bind(this));
titlebar = null;
},
_evalScripts: function(html) {
html = this._substituteGet(html);
var x = loadXML("<xml>" + html + "</xml>");
if (x) {
var scripts = x.getElementsByTagName("script");
for(var i = 0; i < scripts.length; i++)	{
var script = scripts[i];
var s = "";
if (script.getAttribute("type") == "application/xml")
continue;
if (script.getAttribute("src")) {
var url = script.getAttribute("src");
var req = serverRequestWait(url);
s = req.responseText;
} else {
s = getTextValue(script);
if (!s)
s = script.innerHTML;
}
if (s)
evalScript(s, true);
}
}
if (!window.G_vmlCanvasManager)
return;
window.G_vmlCanvasManager.init_(document)
},
_fixBrowserTags: function(html) {
if (!html)
return html;
var tags = [ "script", "a ", "div", "span", "select" ];
for(var i = 0; i < tags.length; i++) {
var tag = tags[i];
html = html.replace(new RegExp('<' + tag + '([^>]*?)/>', 'img'), '<' + tag + '$1></' + tag + '>');
}
return html;
},
_onCloseClicked: function() {
if (!this.fireEvent("closeconfirm", this))
return false;
if (this.window){
var gWindow = $(this.window.gWindow);
if (gWindow)
gWindow.destroy();
}
},
_setShimBounds: function(x, y, w, h) {
if (x !== "")
this.cacheX = parseInt(x);
if (y !== "")
this.cacheY = parseInt(y);
if (w != "" && !isNaN(w))
this.cacheWidth = parseInt(w);
if (h != "" && !isNaN(h))
this.cacheHeight = parseInt(h);
if (!this.shim)
return;
if (x !== "")
this.shim.style.left = x + 'px';
if (y !== "")
this.shim.style.top = y + 'px';
if (w != "") {
if (!isNaN(w))
this.shim.style.width = w + 'px';
else
this.shim.style.width = w;
}
if (h != "") {
if (!isNaN(h))
this.shim.style.height = h + 'px';
else
this.shim.style.height = h;
}
},
_shimResize: function() {
if (!this.shim)
return;
var bounds = this.getAbsoluteRect();
this._setShimBounds(bounds.left, bounds.top, bounds.width, bounds.height);
},
_substituteGet: function(html) {
if (!html)
return html;
var substitutions = [this.type(), 'GlideDialogWindow', 'GlideDialogForm'];
for (var i = 0; i < substitutions.length; i++) {
var reg = new RegExp(substitutions[i] + ".get\\(", "g");
html = html.replace(reg, this.type() + ".prototype.get('" + this.getID() + "'");
}
return html;
},
getLowerSpacing : function() {
return "6px";
},
type : function() {
return "GlideWindow";
},
addClass: function(className) {
var domEl = this.getWindowDOM();
if (domEl) {
var classes = domEl.className;
if (classes.indexOf(className) < 0) {
domEl.className += " " + className;
}
}
},
removeClass: function(className) {
var domEl = this.getWindowDOM();
if (domEl) {
var classes = domEl.className;
domEl.className = classes.replace(className, "");
}
},
setScope: function(scope) {
if(scope) {
this.setPreference('sysparm_scope', scope);
}
return this;
}
});
;
/*! RESOURCE: /scripts/classes/GlideDialogWindow.js */
var GlideDialogWindow = Class.create(GlideWindow, {
BACKGROUND_COLOR: "#DDDDDD",
DEFAULT_RENDERER: "RenderForm",
WINDOW_INVISIBLE: 1,
ZINDEX: 1050,
initialize: function(id, readOnly, width, height) {
GlideWindow.prototype.initialize.call(this, id, readOnly);
if (width) {
this.setSize(width, height);
this.adjustBodySize();
}
this.grayBackground = null;
this.setTitle("Dialog");
this.setDialog(id);
this.parentElement = getFormContentParent();
this.insert(this.parentElement);
this._initDefaults();
this.setShim(true);
},
destroy: function() {
var self = this;
window.setTimeout(function(){
Event.stopObserving(self.getWindowDOM(), 'resize', self.resizeFunc);
self._hideBackground();
self.parentElement = null;
GlideWindow.prototype.destroy.call(self);
}, 0);
},
insert: function(element) {
this.setZIndex(this._determineZIndex());
this._showBackground();
GlideWindow.prototype.insert.call(this, element, "", this.WINDOW_INVISIBLE);
this.onResize();
this.visible();
},
setBody: function(html, noEvaluate, setAlt) {
GlideWindow.prototype.setBody.call(this, html, noEvaluate, setAlt);
if (typeof this.elementToFocus != 'undefined' && !this.elementToFocus) {
self.focus();
this.getWindowDOM().focus();
}
this.onResize();
},
setDialog: function(dialogName) {
this.setPreference('table', dialogName);
},
onResize: function() {
this._centerOnScreen();
},
_eventKeyUp: function(e) {
e = getEvent(e);
if (e.keyCode == 27)
this.destroy();
},
hideBackground: function() {
return this._hideBackground();
},
_hideBackground: function() {
if (this.grayBackground)
this.parentElement.removeChild(this.grayBackground);
this.grayBackground = null;
},
_initDefaults: function() {
this.setPreference('renderer', this.DEFAULT_RENDERER);
this.setPreference('type', 'direct');
if (!this.isReadOnly())
Event.observe(this.getWindowDOM(), 'keyup', this._eventKeyUp.bind(this));
this.resizeFunc = this.onResize.bind(this);
Event.observe(this.getWindowDOM(), 'resize', this.resizeFunc);
},
_showBackground: function() {
var parent = document.viewport;
if (document.compatMode == 'BackCompat' && this.parentElement != document.body)
parent = this.parentElement;
if (!gel('grayBackground')) {
var gb = cel("div");
gb.id = gb.name = "grayBackground";
gb.style.top = gb.style.left = 0;
gb.style.width = "100%";
var hgt = this._getOverlayHeight();
gb.style.height =  hgt + "px";
gb.style.position = "absolute";
gb.style.display = "block";
gb.style.zIndex = this.ZINDEX - 1;
gb.style.zIndex = this.getZIndex() - 1;
gb.style.backgroundColor = this.BACKGROUND_COLOR;
gb.style.opacity = 0.33;
gb.style.filter = "alpha(opacity=33)";
this.parentElement.appendChild(gb);
this.grayBackground = gb;
}
},
_getOverlayHeight: function() {
var elements = $$('body > div.section_header_content_no_scroll');
if (elements && elements.length > 0)
return elements[0].scrollHeight;
elements = $$('body div.form_document');
if (elements && elements.length > 0)
return elements[0].scrollHeight;
if (document.body.scrollHeight)
return document.body.scrollHeight;
return document.body.offsetHeight;
},
_determineZIndex: function() {
if (!window.$j)
return this.ZINDEX;
var zIndex = this.ZINDEX;
$j('.modal:visible').each(function(index, el) {
var elZindex = $j(el).zIndex();
if (elZindex >= zIndex)
zIndex = elZindex + 2;
})
return zIndex;
},
type : function() {
return "GlideDialogWindow";
}
});
;
/*! RESOURCE: /scripts/classes/GwtDraggable.js */
var GwtDraggable = Class.create(GwtObservable, {
initialize : function(header, itemDragged) {
this.header = $(header);
if (!itemDragged)
itemDragged = this.header;
this.parentElement = getFormContentParent();
this.setDraggable($(itemDragged));
this.setCursor("move");
this.setStart(this.genericStart.bind(this));
this.setDrag(this.genericDrag.bind(this));
this.setEnd(this.genericEnd.bind(this));
this.scroll = false;
this.differenceX = 0;
this.differenceY = 0;
this.shiftKey = false;
this.fDrag = this.drag.bind(this);
this.fEnd = this.end.bind(this);
this.enable();
},
enable: function() {
this.header.onmousedown = this.start.bind(this);
this.header.ontouchstart = this.start.bind(this);
},
disable: function() {
this.header.onmousedown = null;
this.header.ontouchstart = null;
},
start: function(e) {
e = getRealEvent(e);
var ex, ey;
if (e.type == 'touchstart') {
ex = e.touches[0].pageX;
ey = e.touches[0].pageY;
} else {
ex = e.clientX;
ey = e.clientY;
}
if (this.getScroll()) {
ex += getScrollX();
ey += getScrollY();
}
this.differenceX = ex - grabOffsetLeft(this.draggable) + grabScrollLeft(this.draggable);
this.differenceY = ey - grabOffsetTop(this.draggable) + grabScrollTop(this.draggable);
this.shiftKey = e.shiftKey;
Event.observe(this.parentElement, "mousemove", this.fDrag);
Event.observe(this.parentElement, "mouseup", this.fEnd);
Event.observe(this.parentElement, "touchmove", this.fDrag);
Event.observe(this.parentElement, "touchend", this.fEnd);
this.active = false;
this._stopSelection(e);
this.draggable.dragging_active = true;
var ret = this.onDragStart(this, ex, ey, e);
this.fireEvent("beforedrag", this, ex, ey, e);
return ret;
},
destroy: function() {
if (this.header) {
this.header.onmousedown = null;
this.header.ontouchstart = null;
}
this.header = null;
this.draggable = null;
this.parentElement = null;
},
drag : function(e) {
if (!this.active) {
createPageShim(this.parentElement);
this.active = true;
}
this._stopSelection(e);
e = getRealEvent(e);
var ex, ey;
if (e.type == 'touchmove') {
ex = e.touches[0].pageX;
ey = e.touches[0].pageY;
} else {
ex = e.clientX;
ey = e.clientY;
}
if (this.getScroll()) {
ex += getScrollX();
ey += getScrollY();
}
var posX = parseInt(ex - this.differenceX);
var posY = parseInt(ey - this.differenceY);
var ret = this.onDrag(this, posX, posY, e);
this.fireEvent("dragging", this, posX, posY, e);
return ret;
},
end : function(e) {
e = getRealEvent(e);
Event.stopObserving(this.parentElement, "mousemove", this.fDrag);
Event.stopObserving(this.parentElement, "mouseup", this.fEnd);
Event.stopObserving(this.parentElement, "touchmove", this.fDrag);
Event.stopObserving(this.parentElement, "touchend", this.fEnd);
this.shiftKey = e.shiftKey;
removePageShim(this.parentElement);
this._restoreSelection();
this.draggable.dragging_active = false;
var ret = this.onDragEnd(this, e);
if (!this.active)
return;
this.active = false;
this.fireEvent("dragged", this, e);
this.resetDraggable();
return ret;
},
getDraggable: function() {
return this.draggable;
},
getYDifference: function() {
return this.differenceY;
},
getXDifference: function() {
return this.differenceX;
},
getScroll: function() {
return this.scroll;
},
setDraggable: function(e) {
this.draggable = e;
},
setStart: function(f) {
this.onDragStart = f;
},
setDrag: function(f) {
this.onDrag = f;
},
setEnd: function(f) {
this.onDragEnd = f;
},
setCursor: function(c) {
if (this.header.style) {
this.header.style.cursor = c;
}
},
setScroll: function(s) {
this.scroll = s;
},
saveAndSetDraggable: function(e) {
this.origDraggable = this.draggable;
this.setDraggable(e);
},
resetDraggable: function() {
if (this.origDraggable) {
this.draggable = this.origDraggable;
this.origDraggable = null;
}
},
genericStart: function(x, y) {
return true;
},
genericEnd: function() {
return true;
},
genericDrag: function(me, x, y) {
me.draggable.style.left = x;
me.draggable.style.top = y;
return true;
},
_stopSelection: function(ev) {
stopSelection(this.parentElement);
if (ie5) {
ev.cancelBubble = true;
ev.returnValue = false;
} else {
if (typeof ev.preventDefault != 'undefined')
ev.preventDefault();
if (typeof ev.stopPropagation != 'undefined')
ev.stopPropagation();
}
},
_restoreSelection: function() {
if (this.parentElement)
restoreSelection(this.parentElement);
},
z: function() {
}
});
function createPageShim(parentElement) {
if (!parentElement)
return;
var w = (parentElement.scrollWidth? parentElement.scrollWidth : parentElement.clientWidth);
var h = (parentElement.scrollHeight? parentElement.scrollHeight : parentElement.clientHeight);
var pageShim = cel("div");
pageShim.id = pageShim.name = "pageshim";
pageShim.style.top = 0;
pageShim.style.left = 0;
pageShim.style.width = w + "px";
pageShim.style.height = h + "px";
pageShim.style.position = "absolute";
pageShim.style.display = "block";
pageShim.style.zIndex = "500";
pageShim.style.backgroundColor = "red";
pageShim.style.opacity=0;
pageShim.style.filter="alpha(opacity=0)";
parentElement.appendChild(pageShim);
}
function removePageShim(parentElement) {
var pageShim = gel("pageshim");
if (pageShim)
parentElement.removeChild(pageShim);
}
;
/*! RESOURCE: /scripts/popupdivs.js */
var PopupCursors = Class.create( {
WAITING_WEBKIT : "wait",
WAITING_OTHER : "progress",
initialize: function() {
if (isWebKit)
this.cursor = this.WAITING_WEBKIT;
else
this.cursor = this.WAITING_OTHER;
},
startWaiting: function(target) {
if (target == null)
return;
this.oldCurosr = target.style.cursor;
target.style.cursor = this.cursor;
},
stopWaiting: function(target) {
if (!target)
return;
target.style.cursor = this.oldCursor ? this.oldCursor : '';
}
});
var GlidePopup = Class.create({
POPUP_PREFIX: "popup_",
initialize: function() {
this.lastMouseX = 0;
this.lastMouseY = 0;
this.thinking;
this.thinkingAbout;
this.sys_id;
},
mousePositionSaveRelative: function(e) {
var answer = getEventCoords(e);
this.lastMouseX = answer.getX();
this.lastMouseY = answer.getY();
},
shouldSkip: function(e, sys_id) {
if (e.ctrlKey)
return true;
if (sys_id != null) {
var div = gel(this.POPUP_PREFIX + sys_id);
if (div)
return true;
}
return false;
},
startThinking: function(e, sys_id) {
this.thinking = true;
this.thinkingAbout = sys_id;
this.eventTarget = e.srcElement ? e.srcElement : e.target;
},
enqueue: function(e, sys_id, url, parms, width) {
this.mousePositionSaveRelative(e);
if (this.shouldSkip(e, sys_id))
return;
if (isNaN(width))
width = 0;
this.startThinking(e, sys_id);
var evalMe = "g_popup_manager.queuePop('" + url + "','" + parms + "'," + this.lastMouseX + "," + this.lastMouseY + ", '" + sys_id + "', '" + width + "')";
setTimeout(evalMe, g_popup_timeout);
},
queuePop: function(url, parms, lastX, lastY, sys_id, width) {
if (!this.thinking)
return;
if (this.lastMouseX != lastX || this.lastMouseY != lastY)
return;
this.cursor = new PopupCursors();
this.cursor.startWaiting(this.eventTarget);
serverRequestPost(url, parms, this.renderPopup.bind(this), [sys_id, width, this.eventTarget]);
this.eventTarget = null;
},
renderPopup: function(response, args) {
var sys_id = args[0];
var width = args[1];
var eventTarget = args[2];
this.cursor.stopWaiting(eventTarget);
if (!this.thinking)
return;
if (this.thinkingAbout.indexOf(sys_id) < 0)
return;
this.destroypopDiv();
this.sys_id = sys_id;
this.createPopupDiv(sys_id, width, response);
_frameChanged();
},
tagImages: function(parent) {
var images = (parent || document.body).getElementsByTagName('img');
for (i=0; i < images.length; i++) {
images[i].onload = function() {
_frameChanged();
};
}
},
createPopupDiv: function(sys_id, width, response) {
var div = cel("div");
div.id = this.POPUP_PREFIX + sys_id;
div.className = "popup";
var newData = response.responseText;
if (newData == null || newData == '')
newData = "None Available";
div.innerHTML = newData;
addChild(div);
newData.evalScripts(true);
this.tagImages(div);
if (width && width > 0)
this._setMinWidth(div, width);
this.placeDiv(div);
this.createPopupShim(div);
div.style.visibility = "visible";
CustomEvent.fire('refresh.event');
},
createPopupShim: function(parentDiv) {
if (!isMSIE)
return;
var height = parentDiv.offsetHeight;
var width = parentDiv.offsetWidth;
var shim = cel("iframe");
shim.id = parentDiv.id + "SHIM";
shim.className = "popup";
shim.scrolling = "no";
shim.src = "javascript:false;";
shim.style.zIndex = 899;
shim.style.left = parentDiv.style.left;
shim.style.top = parentDiv.style.top;
shim.style.height = height;
shim.style.width = width;
addChild(shim);
},
placeDiv: function(div) {
this._sizePopup(div);
var height = div.offsetHeight;
var width = div.offsetWidth;
var topLeft = getRelativeTop();
var targetTop = this.lastMouseY + 4;
var rect = getViewableArea();
var overFlow = (targetTop + height) - (topLeft.getY() + rect.getHeight());
if (overFlow > 0)
targetTop = targetTop - overFlow;
targetTop = Math.max(targetTop, topLeft.getY());
var targetLeft = this.lastMouseX +4;
var parentElement = getFormContentParent();
if (parentElement != document.body && isMSIE)
targetTop = Math.max(targetTop, 35 + parentElement.scrollTop);
if ((targetLeft + width) > (topLeft.getX() + rect.getWidth())) {
targetTop = this.lastMouseY + 4;
targetLeft = this.lastMouseX - (width + 4)
targetLeft = Math.max(targetLeft, 0);
}
div.style.top = targetTop +'px';
div.style.left = targetLeft +'px';
},
_sizePopup: function(div) {
if (div.offsetWidth < 300)
return;
if (!isMSIE)
div.style.display="table";
div.style.width = "300px";
for (var i = div.scrollWidth; i < 1200; i += 50) {
div.style.width = i + '.px';
if (div.offsetWidth >= div.scrollWidth)
return;
}
div.style.width = '';
},
exitPopup: function(e) {
if (e.shiftKey) {
var div = this.getActivePopup();
if (div) {
var firstChild = div.childNodes[0];
if (firstChild.name == 'close_anchor')
return;
var child = cel("div");
child.innerHTML = "<a onclick=\"g_popup_manager.destroypopDiv(event, '" + this.sys_id + "')\"><img src='images/closex.gifx' alt='" + getMessage('Close') + "'/></a>";
child.name = "close_anchor";
div.insertBefore(child, firstChild);
child.className = 'float_right';
}
} else {
this.destroypopDiv();
}
this.thinking = false;
if (this.cursor)
this.cursor.stopWaiting(this.eventTarget);
this.eventTarget = null;
},
getActivePopup : function() {
return gel(this.POPUP_PREFIX + this.sys_id);
},
destroypopDiv: function() {
var div = this.getActivePopup();
if (div) {
var parentNode = div.parentNode;
parentNode.removeChild(div);
}
var shim = gel(this.POPUP_PREFIX + this.sys_id + "SHIM");
if (shim) {
var parentNode = shim.parentNode;
parentNode.removeChild(shim);
}
CustomEvent.fire('refresh.event');
},
popDiv: function(e, sys_id) {
var url = "service_catalog.do";
var parms = "sysparm_action=popup&sysparm_sys_id=" + sys_id;
this.enqueue(e, sys_id, url, parms, 600);
},
popCatDiv: function(e, sys_id) {
var url = "service_catalog.do";
var parms = "sysparm_action=popupCat&sysparm_sys_id=" + sys_id;
this.enqueue(e, sys_id, url, parms, 600);
},
popKnowledgeDiv: function(e, sys_id) {
var url = "kb_preview.do";
var parms = "sys_kb_id=" + sys_id + "&sysparm_nostack=true";
this.enqueue(e, sys_id, url, parms, 600);
},
popIssueDiv: function (e, sys_id) {
var url = "issuespopup.do";
var parms = "sysparm_issues=" + sys_id;
this.enqueue(e, sys_id, url, parms);
},
popListDiv: function(e, tableName, sys_id, viewName, width) {
var url = "popup.do";
var parms = "sysparm_sys_id=" + sys_id + "&sysparm_table_name=" + tableName + "&sysparm_field_name=sys_id&sysparm_view=" + viewName + "&sysparm_popup_direct=true";
sys_id = sys_id + "POPPER";
this.enqueue(e, sys_id, url, parms, width);
},
popReferenceDiv: function(e, inputid, viewName, formTable, refKey) {
var temp = gel(inputid);
var sys_id = temp.value;
if (sys_id == '' || sys_id == null)
return;
var temp = inputid.split('.');
var tableName = temp[0];
var x = inputid.indexOf('.');
var fieldName = inputid.substring(x+1);
var url = "popup.do";
var parms = "sysparm_sys_id=" + sys_id +
"&sysparm_table_name=" + tableName +
"&sysparm_field_name=" + fieldName +
"&sysparm_view=" + viewName;
if (formTable)
parms += "&sysparm_form=" + formTable;
if (refKey)
parms += "&sysparm_refkey=" + refKey;
this.enqueue(e, sys_id, url, parms);
},
popRecordDiv: function(e, tableName, sys_id) {
var url = "popup.do";
var parms = "sysparm_sys_id=" + sys_id + "&sysparm_table_name=" + tableName + "&sysparm_field_name=sys_id&sysparm_view=&sysparm_popup_direct=true";
this.enqueue(e, sys_id, url, parms);
},
popLightWeightReferenceDiv: function(e, inputid) {
var temp = gel(inputid);
var sys_id = temp.value;
if (sys_id == '' || sys_id == null)
return;
var temp = gel(inputid+"TABLE");
var tableName = temp.value;
var fieldName='sys_id';
var viewName = null;
var url = "popup.do";
var parms = "sysparm_sys_id=" + sys_id + "&sysparm_table_name=" + tableName + "&sysparm_field_name=sys_id&sysparm_view=" + viewName + "&sysparm_popup_direct=true";
this.enqueue(e, sys_id, url, parms);
},
popHistoryDiv: function (e, tableName, sys_id, checkpoint, internalCP) {
var url = "historypopup.do";
var parms = "sysparm_table_name=" + tableName + "&sysparm_sys_id=" + sys_id + "&checkpoint=" + checkpoint + "&internalCP=" + internalCP;
sys_id  = sys_id + checkpoint + internalCP
this.enqueue(e, sys_id, url, parms);
},
popReportInfoDiv: function(e , reportId) {
var url = "popup.do";
var parms = "sysparm_sys_id=" + reportId + "&sysparm_table_name=sys_report&sysparm_field_name=user" + "&sysparm_popup_direct=true";
this.enqueue(e, reportId, url, parms);
},
_setMinWidth: function(div, width) {
var widther = cel("div");
widther.style.width = width + "px";
widther.style.height = "1px";
widther.style.overflow = "hidden";
div.appendChild(widther);
widther = null;
},
type: "GlidePopup"
});
var g_popup_manager = new GlidePopup();
function popDiv(e, sys_id) {
g_popup_manager.popDiv(e, sys_id);
}
function popCatDiv(e, sys_id) {
g_popup_manager.popCatDiv(e, sys_id);
}
function popKnowledgeDiv(e, sys_id) {
g_popup_manager.popKnowledgeDiv(e, sys_id);
}
function lockPopupID(e, sys_id) {
g_popup_manager.sys_id = sys_id;
lockPopup(e);
}
function lockPopup(e) {
g_popup_manager.exitPopup(e);
}
function popReferenceDiv(e, inputid, viewName, formTable, refKey) {
g_popup_manager.popReferenceDiv(e, inputid, viewName, formTable, refKey);
}
function popHistoryDiv(e, tableName, sys_id, checkpoint, internalCP) {
g_popup_manager.popHistoryDiv(e, tableName, sys_id, checkpoint, internalCP);
}
function popReportInfoDiv(e, reportId) {
g_popup_manager.popReportInfoDiv(e, reportId);
}
function popRecordDiv(e, tableName, sys_id) {
g_popup_manager.popRecordDiv(e, tableName, sys_id);
}
function popIssueDiv(e, issues) {
g_popup_manager.popIssueDiv(e, issues);
}
function popLightWeightReferenceDiv(e, inputid) {
g_popup_manager.popLightWeightReferenceDiv(e, inputid);
}
function popListDiv(e, tableName, sys_id, viewName, width) {
g_popup_manager.popListDiv(e, tableName, sys_id, viewName, width);
}
function getViewableArea() {
if (document.compatMode  != 'BackCompat') {
return new Rectangle(
document.documentElement.scrollLeft,
document.documentElement.scrollTop,
document.documentElement.clientWidth,
document.documentElement.clientHeight
);
}
return new Rectangle(
document.body.scrollLeft,
document.body.scrollTop,
document.body.clientWidth,
document.body.clientHeight
);
}
var Rectangle = Class.create();
Rectangle.prototype = {
initialize : function(x, y, w, h) {
this.tl = new Point(x, y);
this.width = w;
this.height = h;
},
getTopLeft : function() {
return this.tl;
},
getWidth: function() {
return this.width;
},
getHeight: function() {
return this.height;
}
}
;
/*! RESOURCE: /scripts/classes/ui/Point.js */
var Point = Class.create();
Point.prototype = {
initialize : function(x, y) {
this.x = x;
this.y = y;
},
getX: function() {
return this.x;
},
getY: function() {
return this.y;
}
}
;
/*! RESOURCE: /scripts/accessibility_navpage.js */
CustomEvent.observe('user.login', function() {
var tabPress = false;
var shiftPress = false;
var filter = $('filter');
if (filter && getPreference('glide.ui11.use') != 'true') {
filter.on('keydown', function(evt) {
if (evt.shiftKey)
shiftPress = true;
if (evt.keyCode == Event.KEY_TAB)
tabPress = true;
});
filter.on('keyup', function() {
shiftPress = tabPress = false;
});
filter.on('blur', function(evt) {
if (shiftPress || !tabPress)
return;
setTimeout(function() {
$('gsft_nav').focus();
$('gsft_nav').contentWindow.focus();
}, 0);
});
}
});
addLoadEvent(function() {
if ($$('.skip').length === 0)
return;
document.body.on('click', '.enableAccessibility', function() {
CustomEvent.fire('accessibility.change', true);
});
document.body.on('click', '.navSkip', function() {
var filter = $('filter');
if (filter)
$('filter').focus();
else {
$('gsft_nav').focus();
$('gsft_nav').contentWindow.focus();
}
});
document.body.on('click', '.contentSkip', function() {
$('gsft_main').contentWindow.focus();
});
document.body.on('click', '.formContentSkip', function() {
$('gsft_main_form').contentWindow.focus();
});
});
addLateLoadEvent(function() {
"use strict";
CustomEvent.observe('accessibility.change', function(newValue) {
var action = newValue ? 'enable' : 'disable';
var message = getMessage('To ' + action + ' accessibility, the page must be reloaded');
if (confirm(message)){
setPreference('glide.ui.accessibility', newValue, function() {
window.location.reload();
});
} else {
var $input = document.getElementById('accessibility');
if($input){
$input.checked = !newValue;
}
}
});
})
;
/*! RESOURCE: /scripts/OpticsInspector.js */
var OpticsInspector = Class
.create({
CATEGORIES : {
"sys_script" : "BUSINESS RULE",
"sys_script_client" : "CLIENT SCRIPT",
"data_lookup" : "DATA LOOKUP",
"sys_data_policy2" : "DATA POLICY",
"ui_policy" : "UI POLICY",
"wf_context" : "WORKFLOW",
"request_action" : "REQUEST ACTION",
"script_engine" : "SCRIPT ENGINE",
"wf_activity" : "WORKFLOW ACTIVITY",
"acl" : "ACL",
"sys_ui_action" : "UI ACTION",
"reference_qual" : "REFERENCE QUALIFIER QUERY"
},
initialize : function() {
this.opticsContextStack = new Array();
this.tableName = null;
this.fieldName = null;
this.enabled = false;
},
pushOpticsContext : function(category, name, sys_id) {
if (this.isInspecting())
this.opticsContextStack.push({
"category" : category,
"name" : name,
"sys_id" : sys_id
});
},
popOpticsContext : function() {
if (this.isInspecting() && this.opticsContextStack.length > 0)
return this.opticsContextStack.pop();
return null;
},
isInspecting : function(tableName, fieldName) {
if (this.tableName == null && this.fieldName == null)
return false;
if (arguments.length == 0)
return (this.tableName && this.tableName.length > 0
&& this.fieldName && this.fieldName.length > 0);
if (arguments.length == 2)
return tableName == this.tableName
&& fieldName == this.fieldName;
return false;
},
getTableName : function() {
return (this.tableName && this.tableName.length > 0) ? this.tableName
: '';
},
getFieldName : function() {
return (this.fieldName && this.fieldName.length > 0) ? this.fieldName
: '';
},
hideWatchIcons: function(){
if(isDoctype()) {
$$(".icon-debug.watch_icon").each(function (element) {
$(element).hide()
});
} else {
$$("img.watch_icon").each(function (element) {
$(element).hide()
});
}
},
addWatchIcon:function(watchField){
var td = $('label.' + watchField);
var icon;
if (td) {
if(isDoctype()) {
var label = td.select('label');
icon = '<span class="label-icon icon-debug watch_icon" id="'
+ watchField
+ '.watch_icon"'
+ ' onclick="CustomEvent.fireTop(\'showFieldWatcher\')" '
+ ' src="images/debug.gifx" '
+ ' alt="Field is being watched"'
+ ' title="Field is being watched"></span>';
if(label){
$(label[0]).insert(icon);
}
} else {
icon = '<img class="watch_icon" id="'
+ watchField
+ '.watch_icon"'
+ ' onclick="CustomEvent.fireTop(\'showFieldWatcher\')" '
+ ' src="images/debug.gifx" '
+ ' alt="Field is being watched"'
+ ' title="Field is being watched" />';
td.insert(icon);
}
}
},
clearWatchField : function(watchfield) {
this.opticsContextStack = new Array();
this.tableName = null;
this.fieldName = null;
this.hideWatchIcons();
var debuggerTools = getTopWindow().debuggerTools;
if (debuggerTools && debuggerTools.isDebugPanelVisible()) {
var wndw = debuggerTools.getJsDebugWindow();
if (wndw.updateFieldInfo)
wndw.updateFieldInfo(null);
}
},
setWatchField : function(watchField) {
if (!watchField)
return;
var fieldParts = watchField.split(".");
if (!(fieldParts.length == 2 && fieldParts[0].length > 0 && fieldParts[1].length > 0))
return;
this.tableName = fieldParts[0];
this.fieldName = fieldParts[1];
this.hideWatchIcons();
var icon = $(watchField + ".watch_icon");
if (icon) {
icon.show();
}
else {
this.addWatchIcon(watchField);
}
var debuggerTools = getTopWindow().debuggerTools;
if (debuggerTools && debuggerTools.isDebugPanelVisible()) {
var wndw = debuggerTools.getJsDebugWindow();
if (wndw.updateFieldInfo)
wndw.updateFieldInfo(watchField);
}
},
showWatchField : function(watchField) {
var debuggerTools = getTopWindow().debuggerTools;
if (debuggerTools) {
if (!debuggerTools.isDebugPanelVisible())
debuggerTools.showFieldWatcher();
setWatchField(watchField);
}
},
processClientMessage : function(notification) {
var opticsContext = this.opticsContextStack[this.opticsContextStack.length - 1]
var info = {
type : 'CLIENT ',
message : notification.message,
message_type : "static",
category : opticsContext.category,
name : opticsContext.name,
level : this.opticsContextStack.length,
time : getFormattedTime(new Date()),
call_trace : this._getCallTrace(this.opticsContextStack),
sys_id : opticsContext["sys_id"]
};
if (notification["oldvalue"] && notification["newvalue"]) {
info.message_type = "change";
info.oldvalue = notification["oldvalue"];
info.newvalue = notification["newvalue"];
}
this.process(info);
},
processServerMessages : function() {
var spans = $$('span[data-type="optics_debug"]');
for (var i = 0; i < spans.length; i++) {
var notification = new GlideUINotification({
xml : spans[i]
});
this.processServerMessage(notification);
spans[i].setAttribute("data-attr-processed", "true");
}
},
processServerMessage : function(notification) {
if (notification.getAttribute('processed') == "true")
return;
var info = {
type : 'SERVER',
category : notification.getAttribute('category'),
name : notification.getAttribute('name'),
message : notification.getAttribute('message'),
message_type : notification.getAttribute('message_type'),
oldvalue : notification.getAttribute('oldvalue'),
newvalue : notification.getAttribute('newvalue'),
level : notification.getAttribute('level'),
time : notification.getAttribute('time'),
sys_id : notification.getAttribute('sys_id'),
call_trace : this._getCallTrace(eval(notification
.getAttribute('call_trace')))
};
this.process(info);
},
process : function(notification) {
var msg = '<div class="debug_line ' + notification['category'] + '">' + this._getMessage(notification) + '</div>';
this._log(msg);
},
addLine : function() {
this._log('<hr class="logs-divider"/>');
},
openScriptWindow : function(tablename, sysid) {
if (tablename && sysid) {
if (tablename == "request_action")
tablename = "sys_ui_action";
var url = "/" + tablename + ".do?sys_id=" + sysid;
window.open(url, "tablewindow");
}
},
_log : function(msg) {
var debuggerTools = getTopWindow().debuggerTools;
if (debuggerTools && debuggerTools.isDebugPanelVisible()) {
var wndw = debuggerTools.getJsDebugWindow();
if (wndw.insertJsDebugMsg)
wndw.insertJsDebugMsg(msg);
}
},
_getCallTrace : function(contextStack) {
var trace = '';
var arrows = '<span class="rtl-arrow"> &larr;</span><span class="lrt-arrow">&rarr; </span>';
var space = arrows;
for (i = 0, maxi = contextStack.length; i < maxi; i++) {
var context = contextStack[i];
if (i > 0)
space = arrows + space;
if (context['name'] && context['name'].length > 0)
trace += '<div>' + space
+ this._getCategoryName(context['category'])
+ '&nbsp;-&nbsp;' + context['name'] + '</div>';
else
trace += '<div>' + space
+ this._getCategoryName(context['category'])
+ '</div>';
}
if (trace && trace.length > 0)
trace = '<div class="call_trace">' + trace + '</div>';
return trace;
},
_getMessage : function(notification) {
var notif_type = notification['type'];
var legend_title = (notif_type.indexOf('CLIENT') > -1) ? 'Client-side activity'
: 'Server-side activity';
var msg = '<span class="expand-button" onclick="toggleCallTrace(this);">&nbsp;</span>';
msg += '<img class="infoIcon" height="16"  width="16" border="0" src="images/info-icon.png" title="'
+ legend_title + '" alt="' + legend_title + '">';
msg += '<span class="log-time ' + notif_type + '">'
+ notification['time'] + '</span>';
msg += '<span class="log-category">'
+ this.CATEGORIES[notification['category']];
if (notification['name'] && notification['name'].length > 0) {
if (notification["sys_id"])
msg += '&nbsp;-&nbsp;<a data-tablename="'
+ notification['category']
+ '" data-sys_id="'
+ notification['sys_id']
+ '" onclick="javascript:openScriptWindow(this);">'
+ notification['name'] + '</a></span>';
else
msg += '&nbsp;-&nbsp;' + notification['name']
+ '</span>';
} else
msg += '</span>';
msg += '<span class="log-value">';
if ("request_action" === notification['category']) {
msg += 'Value received from client is: <span class="value" title="Value">'
+ notification['message'] + '</span>';
} else if (notification["message_type"] == "change") {
msg += '<span>'
+ notification["oldvalue"]
+ '</span><span class="rtl-arrow"> &larr; </span><span class="lrt-arrow"> &rarr; </span><span>'
+ notification["newvalue"] + '</span>';
} else {
msg += notification['message'];
}
msg += '</span>';
msg += notification['call_trace'];
return msg;
},
_getCategoryName : function(category) {
var name = this.CATEGORIES[category];
if (name === 'undefined' || name === null)
name = category;
return name;
},
_getLevelStr : function(level) {
if (level == 'undefined' || level == null || level <= 0)
level = 1;
var levelStr = '';
for (i = 0; i < level; i++)
levelStr += '-';
return levelStr + '>';
},
toString : function() {
return 'OpticsInspector';
}
});
var g_optics_inspect_handler = new OpticsInspector();
OpticsInspector.WATCH_EVENT = 'glide:ui_notification.optics_debug';
OpticsInspector.WATCH_EVENT_UI = 'glide:ui_notification.optics_debug_ui';
OpticsInspector.WATCH_FIELD = 'glide_optics_inspect_watchfield';
OpticsInspector.SHOW_WATCH_FIELD = 'glide_optics_inspect_watchfield';
OpticsInspector.UPDATE_WATCH_FIELD = 'glide_optics_inspect_update_watchfield';
OpticsInspector.CLEAR_WATCH_FIELD = 'glide_optics_inspect_clear_watchfield';
OpticsInspector.SHOW_WATCH_FIELD = 'glide_optics_inspect_show_watchfield';
OpticsInspector.PUT_CONTEXT = 'glide_optics_inspect_put_context';
OpticsInspector.POP_CONTEXT = 'glide_optics_inspect_pop_context';
OpticsInspector.PUT_CS_CONTEXT = 'glide_optics_inspect_put_cs_context';
OpticsInspector.POP_CS_CONTEXT = 'glide_optics_inspect_pop_cs_context';
OpticsInspector.PUT_CONTEXT = 'glide_optics_inspect_put_context';
OpticsInspector.POP_CONTEXT = 'glide_optics_inspect_pop_context';
OpticsInspector.LOG_MESSAGE = 'glide_optics_inspect_log_message';
OpticsInspector.WINDOW_OPEN = 'glide_optics_inspect_window_open';
function getClientScriptContextName(name, type) {
var csname = null;
if (type === "submit")
csname = g_event_handlers_onSubmit[name];
else if (type === "load")
csname = g_event_handlers_onLoad[name];
else if (type === "change")
csname = g_event_handlers_onChange[name];
return csname;
}
CustomEvent.observe(OpticsInspector.PUT_CONTEXT, function(category, name) {
g_optics_inspect_handler.pushOpticsContext(category, name);
});
CustomEvent.observe(OpticsInspector.POP_CONTEXT, function() {
g_optics_inspect_handler.popOpticsContext();
});
CustomEvent.observe(OpticsInspector.PUT_CS_CONTEXT, function(name, type) {
var csname = getClientScriptContextName(name, type);
if (csname)
g_optics_inspect_handler.pushOpticsContext("sys_script_client", csname,
g_event_handler_ids[name]);
});
CustomEvent.observe(OpticsInspector.POP_CS_CONTEXT, function(name, type) {
var csname = getClientScriptContextName(name, type);
if (csname)
g_optics_inspect_handler.popOpticsContext();
});
CustomEvent.observe(OpticsInspector.LOG_MESSAGE, function(notification) {
if (g_optics_inspect_handler.isInspecting(notification["table"],
notification["field"])) {
g_optics_inspect_handler.processClientMessage(notification);
}
});
CustomEvent.observe(OpticsInspector.WATCH_EVENT_UI, function(notification) {
g_optics_inspect_handler.process(notification);
});
CustomEvent.observe(OpticsInspector.WATCH_EVENT, function(notification) {
g_optics_inspect_handler.processServerMessage(notification);
});
CustomEvent.observe(OpticsInspector.WATCH_FIELD, function(watchfield) {
g_optics_inspect_handler.setWatchField(watchfield);
});
CustomEvent.observe(OpticsInspector.SHOW_WATCH_FIELD, function(watchfield) {
g_optics_inspect_handler.showWatchField(watchfield);
});
CustomEvent.observe(OpticsInspector.CLEAR_WATCH_FIELD, function(watchfield) {
g_optics_inspect_handler.clearWatchField(watchfield);
});
CustomEvent.observe(OpticsInspector.UPDATE_WATCH_FIELD, function(watchfield) {
g_optics_inspect_handler.setWatchField(watchfield);
if (window.name !== "jsdebugger") {
g_optics_inspect_handler.addLine();
g_optics_inspect_handler.processServerMessages();
}
});
;
;
