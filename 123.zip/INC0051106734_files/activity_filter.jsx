/*! RESOURCE: /scripts/doctype/activity_filter.js */
if (typeof g_activityFilters == "undefined") {
var g_activityFilters = [];
}
var ActivityFilter = Class.create();
ActivityFilter.prototype = {
elements: null,
fieldList: null,
on: false,
visible: false,
initialize: function(table, sys_id, popup, activityPreferences, activityLogDisplay,
activityFilterVisible, activityFilterOn) {
this.table = table;
this.sys_id = sys_id;
if (popup)
this.key = "popup." + sys_id;
else
this.key = sys_id;
var filterElementId = "activity2_filter." + this.key;
this.filter = gel(filterElementId);
if (!this.filter) {
jslog("Activity filter missing filter element '" + filterElementId + "'");
return;
}
if (this.filter.innerHTML)
return;
this.detailTable = gel("activity_detail." + this.key);
if (!this.detailTable) {
jslog("Activity filter attempted to access an unaudited table'");
return;
}
this.elements = $(this.detailTable).select('div.activity_field');
this._createList();
this._createFilters();
this._loadPreferences(activityPreferences);
ActivityFilter._setVisible('activity_table.' + this.key, true);
addUnloadEvent(this.destroy.bind(this));
this.showFilter(activityFilterVisible);
this.setFilterOnPreference(activityFilterOn);
this.setActivityLogDisplay(activityLogDisplay);
g_activityFilters[table + "." + this.key] = this;
},
destroy: function() {
g_activityFilters[this.table + "." + this.key] = null;
delete g_activityFilters[this.table + this.key];
this.filter = null;
this.detailTable = null;
this.elements = null;
for (var i = 0; i < this.fieldList.length; i++)
this.fieldList[i].destroy();
},
setFilterOn: function(on) {
var img = gel('activity2_filter_image.' + this.key);
if (on) {
this._showFiltered();
if (img) {
img.src = img.getAttribute('src_on');
img.title = img.getAttribute('title_on');
img.alt = img.getAttribute('title_on');
}
ActivityFilter._setVisible('activity2_filter_toggle_on.' + this.key, true);
var countSpan = gel('activity2_filter_count.' + this.key);
if (countSpan)
countSpan.innerHTML = "(" + this.getActiveCount() + " of " + this.getTotalCount() + ")";
} else {
this._show('*all*');
if (img) {
img.src = img.getAttribute('src_off');
img.title = img.getAttribute('title_off');
img.alt = img.getAttribute('title_off');
}
ActivityFilter._setVisible('activity2_filter_toggle_on.' + this.key, false);
}
this._showCaptions();
this._showSpacers();
},
toggleFilterOn: function() {
this.on = !this.on;
this.setFilterOn(this.on);
setPreference(this.table + '.activity.filter.on', this.on);
},
setFilterOnPreference: function(on) {
this.on = on;
this.setFilterOn(on);
},
showFilter: function(onOff) {
var allFilter = this._find('*all*');
if (!allFilter)
return;
this.visible = onOff;
var e = this.filter;
var img = gel('activity_filter_toggle.' + this.key);
if (onOff) {
ActivityFilter._setVisible(e, true);
ActivityFilter._setVisible('activity2_filter_toggle.' + this.key, false);
if (img)
img.src = isTextDirectionRTL() ? "images/activity_filter_on.gifx" : "images/activity_filter_off.gifx";
this._toggleToggles(false);
ActivityFilter._setVisible('activity_filter_image.' + this.key, true);
ActivityFilter._setVisible('activity_image.' + this.key, false);
this.expandAllActivityHack();
this.setFilterOn(true);
} else {
ActivityFilter._setVisible(e, false);
if (!allFilter.getValue())
ActivityFilter._setVisible('activity2_filter_toggle.' + this.key, true);
if (img)
img.src = isTextDirectionRTL() ? "images/activity_filter_off.gifx" : "images/activity_filter_on.gifx";
this.setFilterOn(this.on);
this._toggleToggles(true);
ActivityFilter._setVisible('activity_filter_image.' + this.key, false);
ActivityFilter._setVisible('activity_image.' + this.key, true);
}
},
set: function(name, showHide) {
if (showHide)
this._show(name);
else
this._hide(name);
if (name == '*all*')
this._setAll(showHide);
this._showCaptions();
this._showSpacers();
this._setAllCheckBox();
if (!this.on)
this.toggleFilterOn();
this._savePreferences();
},
getActiveCount: function() {
var activeCount = 0;
for (var i = 0; i < this.fieldList.length; i++) {
var f = this.fieldList[i];
if (f.name == '*all*')
continue;
if (f.getValue())
activeCount += f.getCount();
}
return activeCount;
},
getTotalCount: function() {
var totalCount = 0;
for (var i = 0; i < this.fieldList.length; i++) {
var f = this.fieldList[i];
if (f.name == '*all*')
totalCount = f.getCount();
}
return totalCount;
},
_showFiltered: function() {
this._hide('*all*');
for (var i = 0; i < this.fieldList.length; i++) {
var f = this.fieldList[i];
if (f.name == '*all*')
continue;
if (f.getValue())
this._show(f.name);
}
},
_loadPreferences: function(activityPreferences) {
var a = activityPreferences.split(";");
for (var i = 0; i < a.length; i++) {
var nv = a[i].split(",");
var name = nv[0];
var value = nv[1];
var f = this._find(name);
if (!f)
continue;
value = eval(value);
f.setValue(value);
}
var n = this._find('*all*');
if (!n)
return;
if (n.getValue())
this._setAll(true);
},
_savePreferences: function() {
var f = this._find('*all*');
if (f && f.getValue()) {
setPreference(this.table + '.activity.filter', '*all*,true');
return;
}
var p = "";
for (var i = 0; i < this.fieldList.length; i++) {
f = this.fieldList[i];
if (f.name == '*all*')
continue;
p += f.name + "," + f.getValue();
p += ";";
}
setPreference(this.table + '.activity.filter', p);
},
_setAll: function(trueFalse) {
for (var i = 0; i < this.fieldList.length; i++) {
if (this.fieldList[i].name == '*all*')
continue;
this.fieldList[i].setValue(trueFalse);
}
},
_setAllCheckBox: function() {
var allOn = true;
for (var i = 0; i < this.fieldList.length; i++) {
if (this.fieldList[i].name == '*all*')
continue;
if (this.fieldList[i].getValue())
continue;
allOn = false;
break;
}
this._find('*all*').setValue(allOn);
},
_showCaptions: function() {
this.captions = $(this.detailTable).select('.activity_header');
for (var i = 0; i < this.captions.length; i++) {
var c = this.captions[i];
if (this._anyVisible(c)) {
ActivityFilter._setVisible(c, true);
} else {
ActivityFilter._setVisible(c, false);
}
}
},
_showSpacers: function() {
this.spacers = $(this.detailTable).select('tr.activity_spacer');
for (var i = 0; i < this.spacers.length; i++) {
var s = this.spacers[i];
var id = s.id;
var pre = id.substring(0, id.length-6);
var h = gel(pre + "header");
if (this._anyVisible(h) && (this.visible || !ActivityFilter._shouldHideSpacer(s))) {
ActivityFilter._setVisible(s, true);
} else {
ActivityFilter._setVisible(s, false);
}
}
},
_toggleToggles: function(show) {
var t = $(this.detailTable).select('a.activity_toggle');
for (var i = 0; i < t.length; i++) {
ActivityFilter._setVisible(t[i], show);
}
},
_anyVisible: function(parent) {
parent = parent.nextSibling;
return $j('.activity_field:visible', parent).length > 0;
},
_hide: function(name) {
var t = this.elements;
for (var i = 0; i < t.length; i++)
if (name == '*all*' || name == t[i].getAttribute('name'))
hide(t[i]);
},
_show: function(name) {
var t = this.elements;
for (var i = 0; i < t.length; i++)
if (name == '*all*' || name == t[i].getAttribute('name'))
show(t[i]);
},
_find: function(name) {
for (var i = 0; i < this.fieldList.length; i++) {
if (this.fieldList[i].name == name)
return this.fieldList[i];
}
return null;
},
_createFilters: function() {
if (this.fieldList.length === 0)
return;
var a = new ActivityField(this, "*all*", g_activityAll);
a.count = this.count;
this.filter.appendChild(a.createFilter());
for (var i = 0; i < this.fieldList.length; i++) {
var f = this.fieldList[i];
this.filter.appendChild(f.createFilter());
}
this.fieldList.push(a);
},
_createList: function() {
this.fieldList = [];
this.count = 0;
var t = this.elements;
for (var i = 0; i < t.length; i++) {
var e = t[i];
var name = e.getAttribute('name');
var a = this._find(name);
this.count++;
if (a) {
a.count++;
} else {
this.fieldList.push( new ActivityField(this, name, e.getAttribute('label')) );
}
}
this.fieldList = this.fieldList.sort(
function(a,b) {
if ((a.name.toLowerCase()+"") < (b.name.toLowerCase()+"")) { return -1; }
if ((a.name.toLowerCase()+"") > (b.name.toLowerCase()+"")) { return 1; }
return 0;
}
);
},
expandAllActivityHack: function() {
ActivityFilter.toggleActivity(true, this.table, this.key);
var spanTags = $(this.detailTable).select('span');
if (spanTags) {
for(var c=0;c<spanTags.length;++c) {
var spanTag = spanTags[c];
var id = spanTag.id;
if (id) {
var tid = id.substring(0,9);
if (tid == 'activity_')
spanTag.style.display = "block";
}
}
}
var imgTags = $(this.detailTable).select('img.activity_image');
if (imgTags)
for (var i = 0; i < imgTags.length; i++) {
imgTags[i].src = 'images/filter_reveal.gifx';
imgTags[i].alt = getMessage('Expand');
}
var img = gel('activity_image.' + this.key);
if (img) {
img.src = 'images/activity_reveal.gifx';
img.alt = getMessage('Collapse');
}
},
setActivityLogDisplay: function (display) {
var fDiv = gel('toggle_activity.' + this.key);
fDiv.style.display = display;
},
type: 'ActivityFilter'
}
var ActivityField = Class.create();
ActivityField.prototype = {
name: null,
label: null,
count: 1,
element: null,
parent: null,
initialize: function(parent, name, label) {
this.parent = parent;
this.name = name;
this.label = label;
},
destroy: function() {
this.parent = null;
this.element = null;
},
createFilter: function() {
var span = cel('span');
span.className = 'input-group-checkbox';
var e1 = cel('input');
e1.type = 'checkbox';
e1.className = 'checkbox';
e1.onchange = this._toggleFilter.bindAsEventListener(this);
e1.id = "activity_filter." + this.name;
e1.name = e1.id;
this.element = e1;
var lab = cel('label');
lab.className = "checkbox-label"
lab.setAttribute('for', e1.id);
span.appendChild(e1);
span.appendChild(lab);
var txt = document.createTextNode(this.label + " (" + this.count + ") ");
lab.appendChild(txt);
return span;
},
_toggleFilter: function(evt) {
var e = getSrcElement(evt);
var id = e.id;
var v = e.checked;
var ids = id.split("activity_filter.");
if (ids.length > 0)
id = ids[ids.length - 1];
this.parent.set(id, v);
},
setValue: function(onOff) {
this.element.checked = onOff;
},
getValue: function() {
return this.element.checked;
},
getCount: function() {
return this.count;
},
type: 'ActivityField'
}
ActivityFilter.activityFilterToggle = function(table, sys_id, popup) {
var activityFilter = ActivityFilter._getObject(table, sys_id, popup);
var visible = !activityFilter.visible;
activityFilter.showFilter(visible);
setPreference(table + '.activity.filter.visible', visible);
}
ActivityFilter.activityFiltered = function(table, sys_id, popup) {
var activityFilter = ActivityFilter._getObject(table, sys_id, popup);
activityFilter.toggleFilterOn();
}
ActivityFilter._getObject = function(table, sys_id, popup) {
var key = table + ".";
if (popup)
key += "popup.";
key += sys_id;
return g_activityFilters[key];
}
ActivityFilter.activityEmailToggle = function(id) {
var e = gel(id + '.detail');
var toggle = gel(id + '.img');
var altText = getMessage('Show / hide filter');
var wasCollapsed = e.style.display == 'none';
ActivityFilter._setVisible(e, wasCollapsed);
if (wasCollapsed)
setEmailBody(id);
$j(toggle)
.attr('aria-expanded', wasCollapsed)
.find('.sr-only').text(altText);
if (wasCollapsed)
$j(toggle).removeClass('icon-add').addClass('icon-remove');
else
$j(toggle).removeClass('icon-remove').addClass('icon-add');
}
ActivityFilter.displayAllActivity = function(expand_message, collapse_message, expand, collapse, table, key) {
ActivityFilter.toggleActivity(true, table, key);
var spanTags = document.getElementsByTagName('span');
var fImage = gel('activity_image.' + key);
var hide = false;
if ($(fImage).hasClassName('icon-remove')){
$(fImage).removeClassName('icon-remove')
.addClassName('icon-add');
fImage.title = expand_message;
fImage.alt = expand_message;
setPreference(table + ".activity", "none", null);
hide = true;
} else {
$(fImage).removeClassName('icon-add')
.addClassName('icon-remove');
fImage.title = collapse_message;
fImage.alt = collapse_message;
setPreference(table + ".activity", "block", null);
}
if (spanTags) {
for (var c = 0; c < spanTags.length; ++c) {
var spanTag = spanTags[c];
var id = spanTag.id;
if (id) {
var tid = id.substring(0,9);
if (tid == 'activity_') {
var imageid = id.replace('_div', '_image');
var image = gel(imageid);
if (hide) {
spanTag.style.display = 'none';
image.removeClassName('icon-remove')
.addClassName('icon-add');
image.alt = expand_message;
} else {
spanTag.style.display = "block";
image.removeClassName('icon-add')
.addClassName('icon-remove');
image.alt = collapse_message;
}
}
}
}
}
var detailTable = gel("activity_detail." + key);
var spacers = $(detailTable).select('tr.activity_spacer');
for (var i = 0; i < spacers.length; i++) {
if (!ActivityFilter._shouldHideSpacer(spacers[i]))
spacers[i].style.display = '';
else
spacers[i].style.display = 'none';
}
}
ActivityFilter.displayActivity = function(table, activity_num, expand, collapse, toggle, key) {
var id = "activity_" + key + "." + activity_num;
var fDiv = gel(id + '_div');
var fImage = gel(id + '_image');
if (fDiv.style.display == 'none') {
fDiv.style.display = "block";
fImage.removeClassName('icon-add')
.addClassName('icon-remove');
fImage.alt = collapse;
fImage.title = collapse;
} else {
fDiv.style.display = 'none';
fImage.removeClassName('icon-remove')
.addClassName('icon-add');
fImage.alt = expand;
fImage.title = expand;
}
if (toggle) {
ActivityFilter.toggleActivity(true, table, key)
}
}
ActivityFilter.toggleActivity = function(force, table, key) {
var fDiv = gel('toggle_activity.' + key);
var $pDiv = $j(gel('activity_table.' + key));
var $fDiv = $j(fDiv);
$fDiv.addClass('animate');
var h;
if ($pDiv.hasClass('closed_activities') || force) {
var origHeight = $fDiv.outerHeight();
$fDiv.css('overflow', '').css('max-height', 'none').show();
h = $fDiv.outerHeight();
$fDiv.css("max-height", origHeight );
setTimeout(function() {
var animationTimeout = h == origHeight && h !== 0 ? 0 : 500;
$fDiv.css("max-height", h);
setTimeout(function() {
$fDiv.removeClass('animate').css('overflow', '').css('max-height', 'none');
}, animationTimeout);
}, 10);
$pDiv.removeClass('closed_activities');
setPreference(table + ".activity.log.display", "block", null);
} else {
h = $fDiv.outerHeight();
$fDiv.css('overflow', 'hidden').css('max-height', h);
setTimeout(function() {
$fDiv.css('max-height', '0');
}, 10);
$pDiv.addClass('closed_activities');
setPreference(table + ".activity.log.display", "none", null);
}
}
ActivityFilter._setVisible = function(element, onOff) {
var e = typeof element === "string" ? gel(element) : element;
if (!e)
return;
if (onOff)
e.style.display = '';
else
e.style.display = 'none';
}
ActivityFilter._shouldHideSpacer = function(e) {
var id = e.id;
var prefix = id.substring(0, id.length-6);
var h = gel(prefix + "header");
var img = gel(prefix + "image");
return !(img.src.indexOf('reveal') > -1 && h.style.display != 'none');
}
;
