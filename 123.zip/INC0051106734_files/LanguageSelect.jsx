/*! RESOURCE: /scripts/LanguageSelect.js */
var LanguageSelect = Class.create();
LanguageSelect.prototype = {
initialize: function(span_name, maxChars) {
this.span = gel(span_name);
this.select = gel(span_name + "_select");
this.fillSelect();
this.maxChars = maxChars;
CustomEvent.observe('user.logout', this.updateForLogout.bind(this));
CustomEvent.observe('user.login', this.updateForLogin.bind(this));
hideObject(this.span);
},
updateForLogout: function() {
hideObject(this.span);
},
updateForLogin: function(user) {
showObjectInlineBlock(this.span);
showObjectInline(gel("select_toggle"));
this.setDefault(false);
},
fillSelect: function() {
var ajax = new GlideAjax('I18nUtils');
ajax.addParam('sysparm_name', 'getAvailableLanguages');
ajax.getXML(this.getResponse.bind(this));
},
getResponse: function(response) {
var xml = response.responseXML;
var e = xml.documentElement;
var items = xml.getElementsByTagName("item");
if (items.length == 0)
return;
for (var i = this.select.length - 1; i > -1; i--)
this.select.remove(i);
this._add(items);
},
_add: function(items) {
var currentLang = this._get();
var found = false;
for (var i = 0; i < items.length; i++) {
var item = items[i];
var selected = (item.getAttribute("value") == currentLang);
var orig = item.getAttribute('label');
var label = this.maxChars && orig.length > this.maxChars ? orig.substring(0, this.maxChars) + ' ...' : orig;
addOption(this.select, item.getAttribute('value'), label, selected, orig);
if (selected)
found = true;
}
if (!found) {
var label = this.maxChars && currentLang.length > this.maxChars ? currentLang.substring(0, this.maxChars) + ' ...' : currentLang;
addOptionAt(this.select, currentLang, label, 0, currentLang);
this.select.selectedIndex = 0;
}
},
_get: function() {
return g_lang;
},
_getDefault: function(changeFlag) {
var ajax = new GlideAjax('I18nUtils');
ajax.addParam("sysparm_name", "getUserDefaultLanguage");
ajax.getXMLAnswer(this._getDefaultResponse.bind(this), [], changeFlag);
},
_getDefaultResponse: function(answer, changeFlag) {
this._setDefault(answer, changeFlag);
},
change: function() {
var sel = gel('language_select');
var o = sel.options[sel.selectedIndex];
var ajax = new GlideAjax('I18nUtils');
ajax.addParam("sysparm_name", "setLanguage");
ajax.addParam("sysparm_value", o.value);
ajax.getXMLAnswer(this.changeResponse.bind(this));
},
changeResponse: function(answer) {
reloadWindow(getTopWindow());
},
setDefault: function(changeFlag) {
if (changeFlag) {
this._getDefault(changeFlag);
return;
}
this._setDefault(this._get(), changeFlag);
},
_setDefault: function(currentLang, changeFlag) {
for (var i = 0; i < this.select.options.length; i++) {
if (this.select.options[i].value == currentLang) {
this.select.selectedIndex = i;
if (changeFlag)
this.change();
return;
}
}
addOptionAt(this.select, currentLang, currentLang, 0);
this.select.selectedIndex = 0;
if (changeFlag) {
this.change();
}
}
};
;
