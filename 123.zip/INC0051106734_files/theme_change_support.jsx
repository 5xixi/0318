/*! RESOURCE: /scripts/theme_change_support.js */
var ThemeChanger = Class.create();
ThemeChanger.prototype = {
initialize: function(span_name) {
this.span = gel(span_name);
this.select = gel(span_name + "_select");
CustomEvent.observe('user.logout', this.updateThemeForLogout.bind(this));
CustomEvent.observe('user.login', this.updateThemeForLogin.bind(this));
},
updateThemeForLogout: function() {
hideObject(this.span);
},
updateThemeForLogin: function( user) {
if (!user.hasRoles()) {
hideObject(this.span);
return;
}
showObjectInline(this.span);
showObjectInline(gel("select_toggle"));
},
setDefaultTheme: function() {
var ajax = new GlideAjax("ThemeChangerAjax");
ajax.addParam("sysparm_type", "setTheme");
ajax.addParam("sysparm_name", "");
ajax.getXML(this.changeThemeResponse.bind(this));
},
changeTheme: function() {
var o = this.select.options[this.select.selectedIndex];
var v = o.getAttribute("value");
var ajax = new GlideAjax("ThemeChangerAjax");
ajax.addParam("sysparm_type", "setTheme");
ajax.addParam("sysparm_name", v);
ajax.getXML(this.changeThemeResponse.bind(this));
},
changeThemeResponse: function(response) {
reloadWindow(getTopWindow());
}
};
;
