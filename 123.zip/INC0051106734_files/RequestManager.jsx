/*! RESOURCE: /scripts/classes/RequestManager.js */
var RequestManager = Class.create();
RequestManager.prototype = {
interval: 0,
startTime: 0,
cancelling: false,
checkingWithServer: false,
serverCheckTime: 0,
initialize: function() {
CustomEvent.observe("request_start", this.handleRequestStart.bind(this));
CustomEvent.observe("request_complete", this.handleRequestComplete.bind(this));
CustomEvent.observe("request_cancel", this.handleRequestCancel.bind(this));
this.getTimerDelay();
},
getTimerDelay: function() {
this.timerDelay = 15;
if (typeof g_transactionTimerDelay != "undefined")
this.timerDelay = g_transactionTimerDelay;
},
handleRequestStart: function() {
if (this.timeOut)
return;
this.startTime = new Date();
if (this.finalMsgTimeOut)
clearTimeout(this.finalMsgTimeOut);
this.finalMsgTimeOut = 0;
this.timeOut = setTimeout(this.checkTransaction.bind(this), this.timerDelay * 1000);
},
checkTransaction: function() {
if (this.checkingWithServer)
return;
this.checkingWithServer = true;
this.serverCheckTime = new Date();
serverRequest("cancel_my_transaction.do?status=true&sysparm_output=xml", this.checkTransactionResponse.bind(this));
},
checkTransactionResponse: function(request) {
this.checkingWithServer = false;
var r = request.responseXML;
if (r == null) {
this.clearMessage();
return;
}
var m = r.getElementsByTagName("message")[0];
m = m.getAttribute("text");
if (m == "No session, nothing to cancel") {
this.clearMessage();
return;
}
if ("complete" == m)
this.handleRequestComplete();
else
this.startIntervalTimer();
},
startIntervalTimer: function() {
if (this.interval)
return;
this.initializeSpan();
this.handleInterval();
this.interval = setInterval(this.handleInterval.bind(this), 300);
},
initializeSpan: function() {
var img = gel('request_img');
img.src = "images/request_cancel.gif";
img.style.visibility = "";
var e = gel('request_manager_output');
e.style.display = "";
},
clearTimers: function() {
if (this.interval)
clearInterval(this.interval);
if (this.timeOut)
clearTimeout(this.timeOut);
this.interval = 0;
this.timeOut = 0;
},
handleRequestComplete: function() {
var m = "Completed";
var s = "images/request_completed.gif";
if (this.cancelling) {
m = "Cancelled";
s = "images/request_cancelled.gif";
}
this.cancelling = false;
this.clearTimers();
if (this.startTime == 0) {
this.clearMessage();
return;
}
var e = gel('request_message');
if (e.innerHTML != m)
e.innerHTML = m;
var t = this.getTime();
e = gel('request_timer');
e.innerHTML = t;
var img = gel('request_img');
img.src = s;
this.finalMsgTimeOut = setTimeout(this.clearMessage.bind(this), 2500);
this.startTime = 0;
this.serverCheckTime = 0;
},
clearMessage: function() {
var e = gel('request_manager_output');
e.style.display = "none";
var e = gel('request_message');
e.innerHTML = "";
},
handleRequestCancel: function() {
if (this.cancelling)
return;
this.cancelling = true;
this.darkenCancelButton();
serverRequest("cancel_my_transaction.do?sysparm_output=xml", this.checkTransactionResponse.bind(this));
},
getTime: function() {
if (this.startTime == 0)
return 0;
var t = new Date() - this.startTime;
return (t / 1000).toFixed(1) + 's';
},
darkenCancelButton: function() {
var img = gel('request_img');
img.src = "images/request_cancel_onclick.gif";
},
handleInterval: function() {
var t = new Date() - this.serverCheckTime;
if (t > 2000)
this.checkTransaction();
var m = "Running";
if (this.cancelling) {
m = "Cancelling";
this.darkenCancelButton();
}
var e = gel('request_message');
if (e.innerHTML != m)
e.innerHTML = m;
e = gel('request_timer');
e.innerHTML = this.getTime();
},
getIFrameDocument: function(iframe) {
var result = null;
if (iframe.contentWindow)
result = iframe.contentWindow.document;
if (iframe.contentDocument)
result = iframe.contentDocument;
return result;
},
type: function() {
return 'RequestManager';
}
};
var g_request_manager = new RequestManager();
;
